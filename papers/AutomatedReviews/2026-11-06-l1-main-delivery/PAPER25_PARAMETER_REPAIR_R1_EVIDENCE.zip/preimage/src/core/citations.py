"""
Citation Registry — Canonical bibliography for the SK-EFT Hawking project.

Every paper cited in the codebase (constants.py, formulas.py, papers/*.tex,
docs/*.md, notebooks) has an entry here. The provenance dashboard reads this
to verify DOI resolution, check citation consistency, detect orphan
citations, and track which parameters each paper provides.

Per-entry schema:
    authors, title, journal, volume, page, year, doi, arxiv  — bibliographic
    doi_verified: bool | None                                 — Crossref check
    inprep: bool                                              — in-prep self-cite
    primary_source_path: str | None                           — cached artifact
    used_in: list[str]                                        — citing files
    provides: list[str]                                       — parameters
    notes: str

`inprep: True` entries are project-internal companion papers with no
external primary source to cache. `primary_source_path` resolves to a
file under `Lit-Search/Phase-X/primary-sources/<bibkey>.*` per the
convention in that directory's README.
"""

from __future__ import annotations

# Paper → Phase mapping for primary-source cache routing.
# When a bibkey is cited in multiple papers, the cache file lives under
# the first paper's phase (via `used_in[0]`). Pre-Phase-5 papers live in
# their numbered dirs; Phase-5 papers in their authoring sub-phase;
# Phase-6 papers per docs/PAPER_DRAFT_MAPPING.md.

PAPER_TO_PHASE: dict[str, str] = {
    # Publication bundles whose citations are bundle-only (first-lift 2026-07-30).
    # Without these, bibkey_phase() falls through to Phase-1-and-Background and
    # the 6C*/6E* primary-source caches would be filed under an unrelated phase.
    'D11':                                   'Phase-6c',
    'D12':                                   'Phase-6e',
    # Phase 1-4 (pre-Phase-5 reorg)
    'paper1_first_order':                    'Phase-1-and-Background',
    'paper2_second_order':                   'Phase-2',
    'paper3_gauge_erasure':                  'Phase-3',
    'paper4_wkb_connection':                 'Phase-4',
    # Phase 5 sub-phases (per authoring wave)
    'paper5_adw_gap':                        'Phase-5d',
    'paper6_vestigial':                      'Phase-5w',
    'paper7_chirality_formal':               'Phase-5e',
    'paper8_chirality_master':               'Phase-5h',
    'paper9_sm_anomaly_drinfeld':            'Phase-5b',
    'paper10_modular_generation':            'Phase-5e',
    'paper11_quantum_group':                 'Phase-5c',
    'paper12_polariton':                     'Phase-5w',
    'paper14_braided_mtc':                   'Phase-5o',
    'paper15_methodology':                   'Phase-5w',
    'paper16_graphene_sk_eft':               'Phase-5w',
    'paper16_wrt_tqft':                      'Phase-5p',
    'paper17_dark_sector':                   'Phase-5x',
    'paper18_doublon_gate':                  'Phase-5q',
    # Phase 5z (substrate rungs + EW transition)
    'paper20_scalar_rung':                   'Phase-5z',
    'paper21_majorana_rung':                 'Phase-5z',
    'paper22_ew_phase_transition':           'Phase-5z',
    # Phase 6a (linearized EFE through BCH four laws)
    'paper23_linearized_efe':                'Phase-6a',
    'paper25_gravitational_waves':           'Phase-6a',
    'paper26_bh_entropy':                    'Phase-6a',
    'paper27_bh_thermodynamics_four_laws':   'Phase-6a',
    # Phase 6b (BBN unified)
    'paper29_bbn_unified':                   'Phase-6b',
    # Phase 6c (strong-CP DE through RT/CH bounds)
    'paper32_strong_cp_de':                  'Phase-6c',
    'paper33_ewbg_chirality_wall':           'Phase-6c',
    'paper34_equivalence_principle':         'Phase-6c',
    'paper35_qec_holography':                'Phase-6c',
    'note_rt_ch_bounds':                     'Phase-6c',
    # Phase 6d (confinement, chiral SSB, CFL)
    'paper36_center_symmetry':               'Phase-6d',
    'paper37_chiral_ssb':                    'Phase-6d',
    'paper38_cfl':                           'Phase-6d',
    # Phase 6e (heat-kernel through Einstein-Cartan)
    'paper39_heat_kernel_expansion':         'Phase-6e',
    'paper40_higher_curvature':              'Phase-6e',
    'paper41_diff_invariance':               'Phase-6e',
    'paper42_nonlinear_efe':                 'Phase-6e',
    'paper42b_cc_emergent':                  'Phase-6e',
    'paper43_einstein_cartan':               'Phase-6e',
    # Phase 6w (Classical simulability & quantum advantage — tensor networks)
    '_phase6w_W1_lean_only':                 'Phase-6w',
    '_phase6w_W2_lean_only':                 'Phase-6w',
    '_phase6w_W3_lean_only':                 'Phase-6w',
    '_phase6w_W4_lean_only':                 'Phase-6w',
    '_phase6w_W5_lean_only':                 'Phase-6w',
    '_phase6w_W6_lean_only':                 'Phase-6w',
    '_phase6w_W7_lean_only':                 'Phase-6w',
    # Phase 6m (dark-energy review paper — causal-set / entropic-gravity / Jacobson-thermo-GR)
    'paper45_phase6m_review':                'Phase-6m',
    # Note: publication bundles (F, D1–D5, L1–L3, I1–I3, E1, E2) are *not*
    # registered here. Bundle-cited bibkeys fall through to the
    # `Phase-1-and-Background` FALLBACK in `bibkey_phase` callers. The
    # convention as of Phase 6v Wave 6v.3 (2026-05-26) is: new bibkeys
    # first cited in a bundle place their primary-source cache file in
    # `Lit-Search/Phase-1-and-Background/primary-sources/`. Per-wave
    # phase-routed mappings are reserved for per-wave paper drafts.
}


def paper_phase(used_in_path: str) -> str | None:
    """Return the phase directory name for a `papers/<key>/...` path.

    Accepts entries from a CITATION_REGISTRY entry's `used_in` list and
    returns the matching `Phase-X` value, or None if the path is not a
    paper-source path (e.g. it points to `src/core/...` or `docs/...`).
    """
    if not used_in_path.startswith('papers/'):
        return None
    rest = used_in_path[len('papers/'):]
    paper_key = rest.split('/', 1)[0]
    return PAPER_TO_PHASE.get(paper_key)


def bibkey_phase(entry: dict) -> str | None:
    """Return the canonical phase for a CITATION_REGISTRY entry.

    Walks `used_in` in order and returns the first paper-source path's
    phase. Returns None for entries that are only used in `src/`, `docs/`,
    or other non-paper locations (those don't need a primary-source cache
    keyed to a phase). In-prep entries (`inprep: True`) are also returned
    as None — they have no primary source to cache.
    """
    if entry.get('inprep'):
        return None
    for path in entry.get('used_in', []):
        phase = paper_phase(path)
        if phase is not None:
            return phase
    return None


CITATION_REGISTRY = {

    # ════════════════════════════════════════════════════════════════
    # Steinhauer / analog Hawking radiation
    # ════════════════════════════════════════════════════════════════

    # ══════════════════════════════════════════════════════════════════
    # Cauchy problem for the Einstein equations (I1 motivating citation)
    # ══════════════════════════════════════════════════════════════════
    # Added 2026-08-11. Attribution verified by research scout against the DOI
    # landing page AND independently corroborated by Friedrich & Rendall, whose
    # survey credits exactly this reduction to Bruhat 1952 as their ref. [16].

    # NJL gap equation — cited for what the literature does NOT impose (I1 §4)
    'Buballa2005': {
        'authors': 'Buballa, M.',
        'title': 'NJL-model analysis of dense quark matter',
        'journal': 'Physics Reports',
        'volume': 407,
        'page': '205-376',
        'year': 2005,
        'doi': '10.1016/j.physrep.2004.11.004',
        'arxiv': 'hep-ph/0402234',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/I1/paper_draft.tex'],
        'provides': [],
        'notes': ('Cited in I1 for a NEGATIVE result verified against the source: sec. 2.2.2 / '
                  'Fig. 2.6 computes a high-mass branch where the dynamical mass is comparable '
                  'to or exceeds the cutoff, and selects against it using phenomenological '
                  'bounds on the quark condensate rather than any mass-below-cutoff criterion. '
                  'No reviewed source imposes gap < cutoff as a validity condition.'),
    },



    'FouresBruhat1952': {
        'authors': 'Foures-Bruhat, Y.',
        'title': ("Theoreme d'existence pour certains systemes d'equations aux "
                  'derivees partielles non lineaires'),
        'journal': 'Acta Mathematica',
        'volume': 88,
        'page': '141-225',
        'year': 1952,
        'doi': '10.1007/BF02392131',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/I1/paper_draft.tex'],
        'provides': [],
        'notes': ('Origin of the harmonic-coordinate hyperbolic reduction of the Einstein '
                  'vacuum equations and the resulting local-existence theorem. Cited in I1 '
                  'ONLY to motivate a formalization target; the reduction is NOT formalized '
                  'in this project. Open access via Project Euclid. The paper is in French, '
                  '~85pp, and was NOT read in full: the attribution rests on Friedrich & '
                  "Rendall's explicit credit, which is why that source is cited alongside it."),
    },

    'FriedrichRendall2000': {
        'authors': 'Friedrich, H., Rendall, A. D.',
        'title': 'The Cauchy Problem for the Einstein Equations',
        'journal': 'Lecture Notes in Physics',
        'volume': 540,
        'page': '127-224',
        'year': 2000,
        'doi': '10.48550/arXiv.gr-qc/0002074',
        'arxiv': 'gr-qc/0002074',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/I1/paper_draft.tex'],
        'provides': [],
        'notes': ('Modern, freely available survey. Paired with FouresBruhat1952 because it '
                  'states the harmonic-coordinate reduction and attributes it to Bruhat 1952 '
                  '(their ref. 16), making the attribution checkable by a referee without '
                  'reading period French.'),
    },

    'AGP2006': {
        'authors': 'Aliferis, P., Gottesman, D., Preskill, J.',
        'title': 'Quantum accuracy threshold for concatenated distance-3 codes',
        'journal': 'Quantum Information and Computation',
        'volume': 6,
        'page': '97-165',
        'year': 2006,
        'doi': '10.48550/arXiv.quant-ph/0504218',
        'arxiv': 'quant-ph/0504218',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/AGP2006.pdf',
        'used_in': [
            'lean/SKEFTHawking/FaultTolerance/AGP/Threshold.lean',
            'lean/SKEFTHawking/FaultTolerance/Counting.lean',
            'papers/D6/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'The concatenated distance-3 threshold theorem. D6 §7 takes the Steane '
                 'CNOT malignant-pair count A_CNOT = 35,235 from §8.3, equation (36). '
                 'Metadata verified against the arXiv abstract page 2026-08-09; the DOI '
                 'is the arXiv DOI, no publisher DOI is listed.',
    },
    'Steinhauer2016': {
        'authors': 'Steinhauer, J.',
        'title': 'Observation of quantum Hawking radiation and its entanglement in an analogue black hole',
        'journal': 'Nature Physics',
        'volume': 12,
        'page': '959',
        'year': 2016,
        'doi': '10.1038/nphys3863',
        'arxiv': '1510.00621',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Steinhauer2016.pdf',
        'used_in': [
            'src/core/transonic_background.py',
            'src/core/constants.py',
            'papers/paper1_first_order/paper_draft.tex',
            'papers/paper3_gauge_erasure/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'First observation of analog Hawking radiation in BEC.',
    },
    'deNova2019': {
        'authors': 'Muñoz de Nova, J. R., Golubkov, K., Kolobov, V. I., Steinhauer, J.',
        'title': 'Observation of thermal Hawking radiation and its temperature in an analogue black hole',
        'journal': 'Nature',
        'volume': 569,
        'page': '688',
        'year': 2019,
        'doi': '10.1038/s41586-019-1241-0',
        'arxiv': '1809.00913',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/deNova2019.pdf',
        'used_in': [
            'src/wkb/spectrum.py',
            'src/wkb/backreaction.py',
            'papers/paper1_first_order/paper_draft.tex',
            'papers/paper2_second_order/paper_draft.tex',
            'papers/paper4_wkb_connection/paper_draft.tex',
        ],
        'provides': ['Steinhauer.T_H_published'],
        'notes': 'Thermal spectrum measurement, T_H = 0.351(4) nK.',
    },
    'Kolobov2021': {
        'authors': 'Kolobov, V. I., Golubkov, K., Muñoz de Nova, J. R., Steinhauer, J.',
        'title': 'Observation of stationary spontaneous Hawking radiation and the time evolution of an analogue black hole',
        'journal': 'Nature Physics',
        'volume': 17,
        'page': '362',
        'year': 2021,
        'doi': '10.1038/s41567-020-01076-0',
        'arxiv': '1910.09363',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-3/primary-sources/Kolobov2021.pdf',
        'used_in': [
            'src/wkb/backreaction.py',
            'papers/paper3_gauge_erasure/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Entanglement verification of Hawking radiation.',
    },
    'Wang2017': {
        'authors': 'Wang, Y.-H., Jacobson, T., Edwards, M., Clark, C. W.',
        'title': 'Mechanism of stimulated Hawking radiation in a laboratory Bose-Einstein condensate',
        'journal': 'PRA',
        'volume': 96,
        'page': '023616',
        'year': 2017,
        'doi': '10.1103/PhysRevA.96.023616',
        'arxiv': '1605.01027',  # CORRECTED: was 1706.01483 (combustion paper!)
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Wang2017.pdf',
        'used_in': [],
        'provides': ['Steinhauer.omega_perp', 'Steinhauer.density_upstream'],
        'notes': 'Reconstructed Steinhauer 2014 apparatus parameters. '
                 'Table I: omega_perp = 2pi x 123 Hz. '
                 'Key source for parameter reconciliation (deep research 2026-03-31).',
    },

    # ════════════════════════════════════════════════════════════════
    # Atomic physics / scattering lengths
    # ════════════════════════════════════════════════════════════════

    'vanKempen2002': {
        'authors': 'van Kempen, E. G. M., Kokkelmans, S. J. J. M. F., Heinzen, D. J., Verhaar, B. J.',
        'title': 'Spin-off dynamics and collisional properties of Rb-87',
        'journal': 'PRL',
        'volume': 88,
        'page': '093201',
        'year': 2002,
        'doi': '10.1103/PhysRevLett.88.093201',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/vanKempen2002.json',
        'used_in': ['src/core/constants.py'],
        'provides': ['Rb87.a_s'],
        'notes': 'Table I: a(|2,2>+|2,2>) = 109.1(1) a_0.',
    },
    'Falke2008': {
        'authors': 'Falke, S., Knöckel, H., Friebe, J., Rumpf, M., Tiemann, E., Lisdat, C.',
        'title': 'Potassium ground-state scattering parameters',
        'journal': 'PRA',
        'volume': 78,
        'page': '012503',
        'year': 2008,
        'doi': '10.1103/PhysRevA.78.012503',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Falke2008.json',
        'used_in': ['src/core/constants.py'],
        'provides': ['K39.a_s'],
        'notes': 'Feshbach resonance at 402 G for K-39.',
    },

    # ════════════════════════════════════════════════════════════════
    # Analog gravity theory
    # ════════════════════════════════════════════════════════════════

    'BarceloLRR2005': {
        'authors': 'Barceló, C., Liberati, S., Visser, M.',
        'title': 'Analogue Gravity',
        'journal': 'Living Reviews in Relativity',
        'volume': 8,
        'page': '12',
        'year': 2005,
        'doi': '10.12942/lrr-2005-12',
        'arxiv': 'gr-qc/0505065',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': [
            'src/core/transonic_background.py',
            'papers/paper1_first_order/paper_draft.tex',
        ],
        'provides': [],
        'notes': ('2005 review metadata; no verified 2005 full body is held. '
                  'Historical artifact Lit-Search/Phase-1-and-Background/primary-sources/BarceloLRR2005.pdf '
                  'is arXiv gr-qc/0505065v4 (29 November 2024). '
                  'Its bytes and historical fetch record are preserved. '
                  'The 2011 E1 reference is registered separately as Barcelo2011.'),
    },

    # ════════════════════════════════════════════════════════════════
    # Polariton analog gravity
    # ════════════════════════════════════════════════════════════════

    'Barcelo2011': {
        'authors': 'Barceló, C., Liberati, S., Visser, M.',
        'title': 'Analogue Gravity',
        'journal': 'Living Reviews in Relativity',
        'volume': 14,
        'page': '3',
        'year': 2011,
        'doi': '10.12942/lrr-2011-3',
        'arxiv': 'gr-qc/0505065v3',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Barcelo2011.pdf',
        'used_in': ['papers/E1/paper_draft.tex'],
        'provides': [],
        'notes': ('Published 2011 review metadata verified at the publisher. '
                  'Held full author preprint v3, 12 May 2011; the journal body is '
                  'not the cached artifact. Eqs. (61), (63)-(64) distinguish '
                  'acceleration g_H from frequency kappa = g_H/c_H and give '
                  'k_B T_H = hbar kappa/(2 pi). Not the 2005 or 2024 edition.'),
    },

    'Falque2025': {
        'authors': 'Falque, K., Delhom, A., Glorieux, Q., Giacobino, E., Bramati, A., Jacquet, M. J.',
        'title': 'Polariton Fluids as Quantum Field Theory Simulators on Tailored Curved Spacetimes',
        'journal': 'PRL',
        'volume': 135,
        'page': '023401',
        'year': 2025,
        'doi': '10.1103/PhysRevLett.135.023401',
        'arxiv': '2311.01392',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Falque2025.pdf',
        'used_in': ['src/core/constants.py', 'papers/paper12_polariton', 'papers/D1/paper_draft.tex'],
        'provides': [
            'POLARITON_MASS',
            'Paris_long.c_s', 'Paris_long.xi', 'Paris_long.kappa',
            'Paris_ultralong.c_s', 'Paris_ultralong.xi', 'Paris_ultralong.kappa',
            'Paris_standard.c_s', 'Paris_standard.xi', 'Paris_standard.kappa',
            'Paris_standard.tau_cav',
            'FALQUE_STEEP_HORIZON_KAPPA',
        ],
        'notes': 'LKB Paris polariton analog horizon demonstration. Reports '
                 'three measured κ values (0.07, 0.08, 0.11 ps⁻¹) across smooth '
                 'and steep horizon configurations; c_s = 0.40 μm/ps; '
                 'ξ ≈ 3.4 μm upstream, 4.0 μm downstream. LLM-re-verified '
                 'against full text 2026-04-13 (Phase 5u Wave 3).',
    },
    'Giacobino2025': {
        'authors': 'Giacobino, E., Jacquet, M. J.',
        'title': 'Acoustic horizons and the Hawking effect in polariton fluids of light',
        'journal': None,  # arXiv preprint / lecture notes
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2512.14194',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Giacobino2025.pdf',
        'used_in': ['papers/paper12_polariton', 'papers/D1/paper_draft.tex'],
        'provides': [],
        'notes': '52-page lecture notes from the LKB group. Source of the '
                 '"programmable simulators of quantum fields on tailored '
                 'curved spacetimes" framing used in Paper 12 (the word '
                 '"programmable" appears here, not in the Falque 2025 PRL). '
                 'Added to registry 2026-04-13 (Phase 5u Wave 5).',
    },
    'Grisins2016': {
        'authors': 'Grisins, P., Nguyen, H. S., Bloch, J., Amo, A., Carusotto, I.',
        'title': 'Theoretical study of stimulated and spontaneous Hawking effects from an acoustic black hole in a hydrodynamically flowing fluid of light',
        'journal': 'PRB',
        'volume': 94,
        'page': '144518',
        'year': 2016,
        'doi': '10.1103/PhysRevB.94.144518',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Grisins2016.json',
        'used_in': ['src/core/constants.py', 'papers/D1/paper_draft.tex'],
        'provides': [],
        'notes': 'Theoretical study of stimulated/spontaneous Hawking effects from acoustic black hole in polariton fluid. Five-author paper (Grisins, Nguyen, Bloch, Amo, Carusotto); registry already had correct title. D1 used_in added 2026-05-11 (Stage-13 fix-pass: prior D1 bibitem had paraphrased title `Theoretical proposal for the experimental realization of a monochromatic Hawking emission in a quasi-1D BEC` which did not match the published PRB title).',
    },
    'Jacquet2022': {
        'authors': 'Jacquet, M. et al.',
        'title': 'Analogue quantum simulation of the Hawking effect in a polariton superfluid',
        'journal': 'Eur. Phys. J. D',
        'volume': 76,
        'page': '152',
        'year': 2022,
        'doi': '10.1140/epjd/s10053-022-00477-5',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Jacquet2022.abstract.txt',
        'used_in': ['src/core/constants.py',
                    'papers/paper12_polariton/paper_draft.tex'],
        'provides': ['Paris_long.c_s', 'Paris_long.xi'],
        'notes': 'Polariton kinematics: c_s ~ 1 um/ps, xi ~ 2 um.',
    },
    'Gerace2012': {
        'authors': 'Gerace, D., Carusotto, I.',
        'title': 'Analog Hawking radiation from an acoustic black hole in a flowing polariton superfluid',
        'journal': 'PRB',
        'volume': 86,
        'page': '144505',
        'year': 2012,
        'doi': '10.1103/PhysRevB.86.144505',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Gerace2012.json',
        'used_in': ['papers/paper12_polariton/paper_draft.tex'],
        'provides': [],
        'notes': 'Polariton analog Hawking proposal.',
    },
    'Colangelo2025NbReTripletSpinValve': {
        'authors': 'Colangelo, F. et al.',
        'title': 'Unveiling Intrinsic Triplet Superconductivity in Noncentrosymmetric NbRe through Inverse Spin-Valve Effects',
        'journal': 'Phys. Rev. Lett.',
        'volume': 135,
        'page': '226002',
        'year': 2025,
        'doi': '10.1103/q1nb-cvh6',
        'arxiv': '2510.08110',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Colangelo2025NbReTripletSpinValve.pdf',
        'used_in': ['lean/SKEFTHawking/NbReTripletSPT.lean',
                    'papers/D2/paper_draft.tex',
                    'papers/D4/paper_draft.tex'],
        'provides': [
            'nbReParameters',
            'IsTripletSuperconductor',
            'IsDIIITopologicalSuperconductor',
        ],
        'notes': 'Colangelo et al. PRL 135, 226002 (Nov 25, 2025). '
                 'Inverse-spin-valve effects on Py/NbRe/Py heterostructures '
                 'establish NbRe as an intrinsic equal-spin-triplet '
                 'superconductor. Substrate-level lift in Wave 6v.8: NbRe '
                 'as a DIII-class topological superconductor material '
                 'exhibit, sibling to the SM Z_16 anomaly classification '
                 '(D2) via the Rokhlin period-16 structure; cross-bridge '
                 'into D4 as topological-qubit substrate candidate. Full '
                 '3D BdG sub-wave (8.C) ships as tracked Prop '
                 '`H_NbReWindingNumberIdentity` (NOT a new project-local '
                 'axiom) with discharge plan on the future Mathlib-3D-'
                 'winding-number-substrate wave.',
    },
    'DurVidalCirac2000WState': {
        'authors': 'Dür, W., Vidal, G., Cirac, J. I.',
        'title': 'Three qubits can be entangled in two inequivalent ways',
        'journal': 'Phys. Rev. A',
        'volume': 62,
        'page': '062314',
        'year': 2000,
        'doi': '10.1103/PhysRevA.62.062314',
        'arxiv': 'quant-ph/0005115',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/DurVidalCirac2000WState.pdf',
        'used_in': ['lean/SKEFTHawking/FaultTolerance/WStateQFT.lean',
                    'papers/D6/paper_draft.tex'],
        'provides': [
            'WStateCyclicShiftDecomposition',
            'nQubitWStateBasisSize',
        ],
        'notes': 'Foundational W-state paper introducing the multipartite '
                 '|W_n⟩ = (|10..0⟩ + |010..0⟩ + ... + |0..01⟩) / √n state as '
                 'the canonical tripartite (and n-partite) entangled state '
                 'inequivalent to the GHZ state. Used in Wave 6v.6 as the '
                 'substrate-level reference for the W-state cyclic-shift '
                 'symmetry property exploited by the Kyoto-Hiroshima QFT '
                 'single-shot projective measurement (per strategy synthesis '
                 'F9; Kyoto press 2025-09-16 specific arXiv ID not yet '
                 'well-indexed). Primary-source PDF cached 2026-05-26.',
    },
    'KomotoKasai2025APMLDPCHashingBound': {
        'authors': 'Komoto, D., Kasai, K.',
        'title': 'Quantum Error Correction near the Coding Theoretical Bound',
        'journal': 'npj Quantum Information',
        'volume': 11,
        'page': '154',
        'year': 2025,
        'doi': '10.1038/s41534-025-01090-1',
        'arxiv': '2412.21171',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/KomotoKasai2025APMLDPCHashingBound.pdf',
        'used_in': ['lean/SKEFTHawking/FaultTolerance/APMLdpcHashingBound.lean',
                    'papers/D6/paper_draft.tex'],
        'provides': [
            'IsHashingBoundAchievable',
            'apmLdpc_approaches_hashing_bound',
        ],
        'notes': 'Komoto-Kasai 2025 — quantum LDPC codes approaching the '
                 'hashing bound (a fundamental limit on quantum capacity) '
                 'with computational decoding cost linear in physical-qubit '
                 'count. arXiv 2024-12-30 v1; v4 2025-09-08; npj QI 11, 154 '
                 '(2025). Wave 6v.5 substrate-level lift: ships the '
                 '`IsHashingBoundAchievable` predicate + substantive '
                 'non-vacuity witness on the QuEra-Harvard-MIT [[1152, 580]] '
                 'reference code. Full Shannon-binary-entropy `H₂(p) = '
                 '-p log₂ p - (1-p) log₂ (1-p)` analytic content deferred to '
                 'a future Mathlib-Shannon-entropy-substrate wave.',
    },
    'BabbushGidneyEtAl2026ECC256Shor': {
        'authors': 'Babbush, R., Zalcman, A., Gidney, C., Broughton, M., Khattar, T., Neven, H., Bergamaschi, T., Drake, J., Boneh, D.',
        'title': 'Securing Elliptic Curve Cryptocurrencies against Quantum Vulnerabilities: Resource Estimates and Mitigations',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': '2603.28846',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/BabbushGidneyEtAl2026ECC256Shor.pdf',
        'used_in': ['lean/SKEFTHawking/FaultTolerance/ShorTGateCount.lean',
                    'papers/D6/paper_draft.tex'],
        'provides': [
            'googleShorECC256ToffoliBound.config1200',
            'googleShorECC256ToffoliBound.config1450',
        ],
        'notes': 'Google-led ECC-256 Shor resource estimate (Babbush, Gidney, '
                 'Zalcman, Broughton, Khattar, Neven, Bergamaschi, Drake, '
                 'Boneh; arXiv:2603.28846 v2 2026-04-15). Two configurations: '
                 '< 1200 logical qubits & < 90M Toffoli; < 1450 logical qubits '
                 '& < 70M Toffoli — roughly order-of-magnitude improvement '
                 'over prior estimates. Substrate-level kernel-verified '
                 'lift: Wave 6v.2 (`ShorTGateCount.lean`) combines this with '
                 'the Bravyi-Kitaev 7-factor to give T-gate budgets of 630M '
                 '(config1200) and 490M (config1450), both inside the 1-G '
                 'T-gate FT-QC envelope.',
    },
    'BravyiKitaev2005MagicState': {
        'authors': 'Bravyi, S. B., Kitaev, A. Yu.',
        'title': 'Universal quantum computation with ideal Clifford gates and noisy ancillas',
        'journal': 'Phys. Rev. A',
        'volume': 71,
        'page': '022316',
        'year': 2005,
        'doi': '10.1103/PhysRevA.71.022316',
        'arxiv': 'quant-ph/0403025',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/BravyiKitaev2005MagicState.pdf',
        'used_in': ['lean/SKEFTHawking/FaultTolerance/ShorTGateCount.lean',
                    'papers/D6/paper_draft.tex'],
        'provides': [
            'bravyiKitaevToffoliT',
            'bk_decomposition_seven_factor',
        ],
        'notes': 'Bravyi-Kitaev 2005 — universal quantum computation with '
                 'ideal Clifford gates and noisy ancillas, the foundational '
                 'paper on magic-state distillation. Used in Wave 6v.2 for '
                 'the exact ancilla-free Toffoli → 7 T-gate decomposition '
                 '(stated as "Each Toffoli gate decomposes into 7 T-gates" '
                 'in the standard Clifford+T gate set; the 7-factor is the '
                 'algebraic-Clifford-hierarchy result that the project takes '
                 'as a substantive constant in `bravyiKitaevToffoliT n = 7*n`). '
                 'Primary-source PDF cached 2026-05-26.',
    },
    'WilliamsonYoder2026GaugingLogicalOperators': {
        'authors': 'Williamson, D. J., Yoder, T. J.',
        'title': 'Low-overhead fault-tolerant quantum computation by gauging logical operators',
        'journal': 'Nat. Phys.',
        'volume': 22,
        'page': '598-603',
        'year': 2026,
        'doi': '10.1038/s41567-026-03220-8',
        'arxiv': '2410.02213',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/WilliamsonYoder2026GaugingLogicalOperators.pdf',
        'used_in': ['src/core/constants.py', 'papers/D6/paper_draft.tex'],
        'provides': [
            'GaugingQEC.williamsonYoderAuxQubits',
            'gaugingQEC_auxQubit_overhead_le',
            'naive_quadratic_baseline_overhead',
        ],
        'notes': 'Williamson & Yoder Nature Physics April 2 2026. Headline '
                 'result: low-overhead fault-tolerant logical-measurement '
                 'via gauging-of-symmetry construction, achieving '
                 'auxiliary-qubit overhead linear in operator weight up to '
                 'a polylogarithmic factor. arXiv 2024-10-03 v1; published '
                 '2026-04-02. LLM-re-verified against arXiv:2410.02213 '
                 'abstract + body 2026-05-26: "qubit overhead that is '
                 'linear in the weight of the operator being measured up '
                 'to a polylogarithmic factor". Lean substrate-level '
                 'encoding: `williamsonYoderAuxQubits W := W * (Nat.log 2 W + 1)` '
                 'satisfies `IsLinearPolylogOverhead` (with C = 1); the '
                 'companion theorem `quadraticOverhead_not_linear` falsifies '
                 'the naive quadratic baseline as the substantive contrast. '
                 'FIRST kernel-verified declaration under the new D6 '
                 'publication bundle ("Formally Verified Fault-Tolerant '
                 'Quantum Computation Substrate", created by Wave 6v.1).',
    },
    'WangKimBZHe2026PennTMDPolariton': {
        'authors': 'Wang, Z., Kim, B., Zhen, B., He, L.',
        'title': 'Strongly nonlinear nanocavity exciton-polaritons in gate-tunable monolayer semiconductors',
        'journal': 'PRL',
        'volume': 136,
        'page': '146901',
        'year': 2026,
        'doi': '10.1103/gc15-qsvf',
        'arxiv': '2411.16635',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/WangKimBZHe2026PennTMDPolariton.pdf',
        'used_in': ['src/core/constants.py', 'papers/E1/paper_draft.tex'],
        'provides': [
            'Penn_TMD_MoSe2.g_meV',
            'Penn_TMD_MoSe2.gamma_LP_meV',
            'Penn_TMD_MoSe2.gamma_UP_meV',
            'Penn_TMD_MoSe2.gamma_cav_meV',
            'Penn_TMD_MoSe2.Q_factor',
            'Penn_TMD_MoSe2.switching_energy_fJ',
        ],
        'notes': 'UPenn ZHEN-Lab MoSe2 monolayer in photonic-crystal nanocavity. '
                 'Editor\'s Suggestion + cover article. arXiv 2024-11-25; PRL 2026-04. '
                 'Source of Penn_TMD_MoSe2 platform parameters used in Wave 6v.4 '
                 'Tier-1 scope-demarcation theorem `polariton_tier1_fails_tmds` '
                 '(PolaritonTier1.lean). LLM-re-verified against the arXiv full '
                 'text 2026-05-26: g=16.8 meV (coupled-oscillator fit), '
                 'γ_LP=1.8 meV / γ_UP=2.3 meV (measured polariton linewidths), '
                 'γ_cav=γ_rad+γ_nonrad=0.7+1.2=1.9 meV (cavity linewidth at '
                 'resonance E=1.736 eV → Q≈914), 4 fJ switching threshold on '
                 'picosecond timescales (the headline experimental result).',
    },
    'Nguyen2015': {
        'authors': 'Nguyen, H. S. et al.',
        'title': 'Acoustic black hole in a stationary hydrodynamic flow of microcavity polaritons',
        'journal': 'PRL',
        'volume': 114,
        'page': '036402',
        'year': 2015,
        'doi': '10.1103/PhysRevLett.114.036402',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Nguyen2015.json',
        'used_in': ['papers/paper12_polariton/paper_draft.tex'],
        'provides': [],
        'notes': 'Polariton acoustic black hole demonstration.',
    },
    'Estrecho2021': {
        'authors': 'Estrecho, E. et al.',
        'title': 'Low-energy collective oscillations and Bogoliubov sound in an exciton-polariton condensate',
        'journal': 'PRL',
        'volume': 126,
        'page': '075301',
        'year': 2021,
        'doi': '10.1103/PhysRevLett.126.075301',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Estrecho2021.json',
        'used_in': ['papers/paper12_polariton/paper_draft.tex'],
        'provides': [],
        'notes': 'Polariton c_s measurement via dipole oscillations. '
                 'Confirms reservoir-corrected c_s ~ 0.4 um/ps.',
    },
    'Stepanov2019': {
        'authors': 'Stepanov, P. et al.',
        'title': 'Dispersion relation of the collective excitations in a resonantly driven polariton fluid',
        'journal': 'Nature Communications',
        'volume': 10,
        'page': '3869',
        'year': 2019,
        'doi': '10.1038/s41467-019-11886-3',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Stepanov2019.abstract.txt',
        'used_in': ['papers/paper12_polariton/paper_draft.tex'],
        'provides': [],
        'notes': 'Polariton collective excitations and reservoir effects on c_s.',
    },
    'Claude2023': {
        'authors': 'Claude, F. et al.',
        'title': 'Spectrum of collective excitations of a quantum fluid of polaritons',
        'journal': 'PRB',
        'volume': 107,
        'page': '174507',
        'year': 2023,
        'doi': '10.1103/PhysRevB.107.174507',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Claude2023.json',
        'used_in': ['papers/paper12_polariton/paper_draft.tex'],
        'provides': [],
        'notes': 'Polariton collective excitation spectrum including reservoir corrections.',
    },
    'Burkhard2025': {
        'authors': 'M.~Burkhard, M.~Kroj, K.~Falque, A.~Bramati, I.~Carusotto, M.~J.~Jacquet',
        'title': 'Stimulated Hawking effect and quasinormal mode resonance in a polariton simulator of field theory on curved spacetime',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2511.12339',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Burkhard2025.pdf',
        'used_in': ['papers/paper12_polariton/paper_draft.tex', 'papers/D1/paper_draft.tex', 'papers/E1/paper_draft.tex'],
        'provides': [],
        'notes': 'QNM resonances concentrate stimulated Hawking signal.',
    },
    'Finazzi2012': {
        'authors': 'Finazzi, S., Parentani, R.',
        'title': 'Hawking radiation in dispersive theories, the two regimes',
        'journal': 'PRD',
        'volume': 85,
        'page': '124027',
        'year': 2012,
        'doi': '10.1103/PhysRevD.85.124027',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Finazzi2012.json',
        'used_in': ['papers/paper12_polariton/paper_draft.tex'],
        'provides': [],
        'notes': 'Dispersive corrections to Hawking radiation in two regimes.',
    },
    'Amelio2020': {
        'authors': 'Amelio, I., Carusotto, I.',
        'title': 'Perspectives in superfluidity in resonantly driven polariton fluids',
        'journal': 'PRB',
        'volume': 101,
        'page': '064505',
        'year': 2020,
        'doi': '10.1103/PhysRevB.101.064505',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Amelio2020.json',
        'used_in': ['papers/paper12_polariton/paper_draft.tex'],
        'provides': [],
        'notes': 'Acoustic metric in driven-dissipative polariton systems; '
                 'weak-loss, long-wavelength limit.',
    },
    'Jacquet2023QNM': {
        'authors': 'Jacquet, M. J., Giacomelli, L., Valnais, Q., Joly, M., Claude, F., Giacobino, E., Glorieux, Q., Carusotto, I., Bramati, A.',
        'title': 'Quantum Vacuum Excitation of a Quasinormal Mode in an Analog Model of Black Hole Spacetime',
        'journal': 'PRL',
        'volume': 130,
        'page': '111501',
        'year': 2023,
        'doi': '10.1103/PhysRevLett.130.111501',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Jacquet2023QNM.json',
        'used_in': ['papers/paper12_polariton/paper_draft.tex',
                    'papers/D1/paper_draft.tex'],
        'provides': [],
        'notes': 'Quasinormal-mode observation in polariton analog (driven-dissipative). Crossref-verified 2026-05-11 (D1 Stage-13 fix-pass): actual title is `Quantum Vacuum Excitation of a Quasinormal Mode in an Analog Model of Black Hole Spacetime`; prior registry title `Analogue quantum simulation of the quasi-normal modes of a Kerr black hole` was misattributed (the polariton platform is NOT a Kerr analog).',
    },
    'Nelsen2013': {
        'authors': 'Nelsen, B. et al.',
        'title': 'Dissipationless flow and sharp threshold of a polariton condensate with long lifetime',
        'journal': 'Physical Review X',
        'volume': 3,
        'page': '041015',
        'year': 2013,
        'doi': '10.1103/PhysRevX.3.041015',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Nelsen2013.json',
        'used_in': ['papers/paper12_polariton/paper_draft.tex'],
        'provides': [],
        'notes': 'Long-lifetime polariton cavity (300 ps).',
    },
    'Alnatah2024': {
        'authors': 'Alnatah, H. et al.',
        'title': 'Ultra-high-quality-factor microcavity polaritons',
        'journal': 'Science Advances',
        'volume': 10,
        'page': 'eadk6960',
        'year': 2024,
        'doi': '10.1126/sciadv.adk6960',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Alnatah2024.abstract.txt',
        'used_in': ['papers/paper12_polariton/paper_draft.tex'],
        'provides': [],
        'notes': 'Ultra-high Q polariton microcavity, Q ~ 10^6.',
    },
    'Amo2009': {
        'authors': 'Amo, A. et al.',
        'title': 'Superfluidity of polaritons in semiconductor microcavities',
        'journal': 'Nature Physics',
        'volume': 5,
        'page': '805',
        'year': 2009,
        'doi': '10.1038/nphys1364',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Amo2009.json',
        'used_in': ['papers/paper12_polariton/paper_draft.tex'],
        'provides': [],
        'notes': 'Polariton superfluidity, c_s via Cherenkov cone. '
                 'CdTe microcavity (not GaAs).',
    },

    # ════════════════════════════════════════════════════════════════
    # Heidelberg / analog cosmology
    # ════════════════════════════════════════════════════════════════

    'Viermann2022': {
        'authors': 'Viermann, C. et al.',
        'title': 'Quantum field simulator for dynamics in curved spacetime',
        'journal': 'Nature',
        'volume': 611,
        'page': '260',
        'year': 2022,
        'doi': '10.1038/s41586-022-05313-9',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Viermann2022.json',
        'used_in': [
            'src/wkb/backreaction.py',
        ],
        'provides': [],
        'notes': 'Heidelberg K-39 analog COSMOLOGY experiment. '
                 'NOT analog Hawking radiation.',
    },

    # ════════════════════════════════════════════════════════════════
    # Trento / spin-sonic
    # ════════════════════════════════════════════════════════════════

    'Berti2025': {
        'authors': 'Berti, A., Fernandes, J., Butera, S., Recati, A., Wouters, M., Carusotto, I.',
        'title': 'Analog Hawking radiation from a spin-sonic horizon in a two-component BEC',
        'journal': 'Comptes Rendus Physique',
        'volume': 25,
        'page': '1--36',
        'year': 2025,
        'doi': '10.5802/crphys.226',
        'arxiv': '2408.17292',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Berti2025.pdf',
        'used_in': [
            'src/core/transonic_background.py',
        ],
        'provides': [],
        'notes': 'THEORETICAL PROPOSAL only. No experimental parameters published. '
                 'Trento Na-23 spin-sonic experiment has not been realized.',
    },

    # ════════════════════════════════════════════════════════════════
    # ADW mechanism / emergent gravity
    # ════════════════════════════════════════════════════════════════

    'VladimirovDiakonov2012': {
        'authors': 'Vladimirov, A. A., Diakonov, D.',
        'title': 'Phase transitions in spinor quantum gravity on a lattice',
        'journal': 'PRD',
        'volume': 86,
        'page': '104019',
        'year': 2012,
        'doi': '10.1103/PhysRevD.86.104019',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/VladimirovDiakonov2012.json',
        'used_in': ['src/core/constants.py',
                    'papers/paper42b_cc_emergent/paper_draft.tex'],
        'provides': [],
        'notes': 'ADW lattice gravity model. Basis for vestigial MC.',
    },
    'Chandrasekharan2010': {
        'authors': 'Chandrasekharan, S.',
        'title': 'Fermion bag approach to lattice field theories',
        'journal': 'PRD',
        'volume': 82,
        'page': '025007',
        'year': 2010,
        'doi': '10.1103/PhysRevD.82.025007',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Chandrasekharan2010.json',
        'used_in': ['src/core/constants.py'],
        'provides': [],
        'notes': 'Fermion-bag MC algorithm.',
    },
    'Volovik2024': {
        'authors': 'Volovik, G. E.',
        'title': 'Fermionic quartet and vestigial gravity',
        'journal': 'JETP Letters',
        'volume': 119,
        'page': '330',
        'year': 2024,
        'doi': '10.1134/S002136402460006X',
        'arxiv': '2312.09435',
        'doi_verified': '2026-05-11',
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5d/primary-sources/Volovik2024.pdf',
        'used_in': [
            'papers/paper5_adw_gap/paper_draft.tex',
            'papers/paper6_vestigial/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Vestigial metric phase concept. NOTE: same paper as '
                 '`Volovik2024Vestigial` (arXiv:2312.09435 → JETP Letters 119:330, '
                 '2024); the two keys exist for historical reasons in different '
                 'paper drafts. Consolidate in a future pass.',
    },

    # ════════════════════════════════════════════════════════════════
    # Foundational Hawking / analog gravity
    # ════════════════════════════════════════════════════════════════

    'Hawking1974': {
        'authors': 'Hawking, S. W.',
        'title': 'Black hole explosions?',
        'journal': 'Nature',
        'volume': 248,
        'page': '30',
        'year': 1974,
        'doi': '10.1038/248030a0',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Hawking1974.json',
        'used_in': ['papers/paper1_first_order/paper_draft.tex',
                    'papers/paper2_second_order/paper_draft.tex'],
        'provides': [],
        'notes': 'Original Hawking radiation prediction.',
    },
    'Unruh1981': {
        'authors': 'Unruh, W. G.',
        'title': 'Experimental black-hole evaporation?',
        'journal': 'PRL',
        'volume': 46,
        'page': '1351',
        'year': 1981,
        'doi': '10.1103/PhysRevLett.46.1351',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Unruh1981.json',
        'used_in': ['papers/paper1_first_order/paper_draft.tex',
                    'papers/paper3_gauge_erasure/paper_draft.tex',
                    'papers/paper4_wkb_connection/paper_draft.tex'],
        'provides': [],
        'notes': 'Original analog gravity proposal.',
    },
    'Corley1996': {
        'authors': 'Corley, S., Jacobson, T.',
        'title': 'Hawking spectrum and high frequency dispersion',
        'journal': 'PRD',
        'volume': 54,
        'page': '1568',
        'year': 1996,
        'doi': '10.1103/PhysRevD.54.1568',
        'arxiv': 'hep-th/9601073',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Corley1996.pdf',
        'used_in': ['papers/paper1_first_order/paper_draft.tex',
                    'papers/paper4_wkb_connection/paper_draft.tex'],
        'provides': [],
        'notes': 'Dispersive corrections to Hawking radiation. Source for delta_disp formula.',
    },

    # ════════════════════════════════════════════════════════════════
    # Schwinger-Keldysh EFT
    # ════════════════════════════════════════════════════════════════

    'Crossley2017': {
        'authors': 'Crossley, M., Glorioso, P., Liu, H.',
        'title': 'Effective field theory of dissipative fluids',
        'journal': 'JHEP',
        'volume': '1709',
        'page': '095',
        'year': 2017,
        'doi': '10.1007/JHEP09(2017)095',
        'arxiv': '1511.03646',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Crossley2017.pdf',
        'used_in': ['papers/paper1_first_order/paper_draft.tex',
                    'papers/paper2_second_order/paper_draft.tex',
                    'src/second_order/cgl_derivation.py'],
        'provides': [],
        'notes': 'SK-EFT framework (paper I), dynamical KMS transformation. Paper II of the CGL series is registered separately as Crossley2017II.',
    },
    'Crossley2017II': {
        'authors': 'Glorioso, P., Crossley, M., Liu, H.',
        'title': 'Effective field theory of dissipative fluids (II): classical limit, dynamical KMS symmetry and entropy current',
        'journal': 'JHEP',
        'volume': '09',
        'page': '096',
        'year': 2017,
        'doi': '10.1007/JHEP09(2017)096',
        'arxiv': '1701.07817',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Crossley2017II.pdf',
        'used_in': ['papers/D1/paper_draft.tex'],
        'provides': [],
        'notes': 'CGL paper II: classical limit, dynamical KMS symmetry and entropy current. Glorioso lead author. JHEP 09, 096 (2017), DOI 10.1007/JHEP09(2017)096. Registry entry added 2026-05-11 (D1 Stage-13 fix-pass: D1 paper had previously used `Crossley2017` bibkey collision with registry paper-I entry; bibkey renamed to `Crossley2017II` to disambiguate).',
    },
    'GloriosoLiu2018': {
        'authors': 'Glorioso, P., Liu, H.',
        'title': 'The second law of thermodynamics from symmetry and unitarity',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2016,
        'doi': None,
        'arxiv': '1612.07705',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/GloriosoLiu2018.pdf',
        'used_in': ['papers/paper1_first_order/paper_draft.tex',
                    'papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex',
                    'src/second_order/enumeration.py',
                    'papers/I1/paper_draft.tex'],
        'provides': ['Eq. (3.20) §III: dynamical KMS Z₂ symmetry + unitarity '
                     '(Im S_eff ≥ 0) ⇒ ∂_μ s^μ ≥ 0 (entropy-current monotonicity), '
                     'WITHOUT pointwise NEC. Wave 5 second-law primary anchor.'],
        'notes': 'SK-EFT second law without NEC. arXiv:1612.07705 verified 2026-04-26; year/journal corrected 2026-05-11 (Bundle I1 Stage-13 fix-pass) — WebFetch on arxiv.org/abs/1612.07705 confirms first-submitted Dec 2016, no JHEP publication info on arXiv metadata (registry key retained as GloriosoLiu2018 for backwards-compat with downstream cites; bibitem cites (2016) correctly).',
    },
    'Jana2020': {
        'authors': 'Jana, C., Loganayagam, R., Rangamani, M.',
        'title': 'Open quantum systems and Schwinger-Keldysh holograms',
        'journal': 'JHEP',
        'volume': '07',
        'page': '242',
        'year': 2020,
        'doi': '10.1007/JHEP07(2020)242',
        'arxiv': '2004.02888',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Jana2020.pdf',
        'used_in': ['papers/paper1_first_order/paper_draft.tex',
                    'papers/paper4_wkb_connection/paper_draft.tex',
                    'papers/D1/paper_draft.tex'],
        'provides': [],
        'notes': 'SK influence functional / open-quantum-systems holographic dual. First author initial C (Chandan Jana). JHEP 07, 242 (2020), DOI 10.1007/JHEP07(2020)242, arXiv:2004.02888. Registry corrected 2026-05-11 (D1 Stage-13 fix-pass: registry previously carried wrong first-author initial K, wrong volume/page 2005/064, wrong arXiv 2003.03088 which is a superconductor paper).',
    },

    # ════════════════════════════════════════════════════════════════
    # ADW mechanism / emergent gravity (additional)
    # ════════════════════════════════════════════════════════════════

    'Diakonov2011': {
        'authors': 'Diakonov, D.',
        'title': 'Towards lattice-regularized Quantum Gravity',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2011,
        'doi': None,
        'arxiv': '1109.0091',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5d/primary-sources/Diakonov2011.pdf',
        'used_in': ['papers/paper5_adw_gap/paper_draft.tex',
                    'papers/paper6_vestigial/paper_draft.tex',
                    'papers/paper42b_cc_emergent/paper_draft.tex'],
        'provides': [],
        'notes': 'Lattice-regularized quantum gravity, ADW mechanism.',
    },
    'Wetterich2004': {
        'authors': 'Wetterich, C.',
        'title': 'Gravity from spinors',
        'journal': 'PRD',
        'volume': 70,
        'page': '105004',
        'year': 2004,
        'doi': '10.1103/PhysRevD.70.105004',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5d/primary-sources/Wetterich2004.json',
        'used_in': ['papers/paper5_adw_gap/paper_draft.tex',
                    'papers/paper6_vestigial/paper_draft.tex'],
        'provides': [],
        'notes': 'Gravity from spinors, emergent geometry.',
    },
    'Vergeles2025': {
        'authors': 'Vergeles, S. N.',
        'title': 'Unitarity of 4D Lattice Theory of Gravity',
        'journal': 'PRD',
        'volume': 112,
        'page': '054509',
        'year': 2025,
        'doi': '10.1103/PhysRevD.112.054509',
        'arxiv': '2506.00036',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5d/primary-sources/Vergeles2025.pdf',
        'used_in': [
            'papers/paper5_adw_gap/paper_draft.tex',
            'papers/paper6_vestigial/paper_draft.tex',
            'papers/paper23_linearized_efe/paper_draft.tex',
            'papers/paper25_gravitational_waves/paper_draft.tex',
            'papers/paper26_bh_entropy/paper_draft.tex',
            'papers/paper39_heat_kernel_expansion/paper_draft.tex',
            'papers/paper42b_cc_emergent/paper_draft.tex',
        ],
        'provides': [
            'Unitarity proof for the 4D simplicial-complex lattice theory of gravity '
            '(direct lattice transfer-matrix proof in Minkowski signature; '
            'long-wave limit yields Einstein-Cartan-Palatini gravity).',
        ],
        'notes': 'Title and venue verified via arXiv.org fresh-fetch 2026-04-26 '
                 '(adversarial-review BLOCKER 1.3 fix; prior registry/bibitem '
                 'titles diverged — actual title is the unitarity-proof title, '
                 'arXiv:2506.00036).',
    },

    # ════════════════════════════════════════════════════════════════
    # Topological order / string-nets
    # ════════════════════════════════════════════════════════════════

    'LevinWen2006': {
        'authors': 'Levin, M. A., Wen, X.-G.',
        'title': 'String-net condensation: A physical mechanism for topological phases',
        'journal': 'PRB',
        'volume': 73,
        'page': '035122',
        'year': 2006,
        'doi': '10.1103/PhysRevB.73.035122',
        'arxiv': 'cond-mat/0404617',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5d/primary-sources/LevinWen2006.pdf',
        'used_in': ['papers/paper5_adw_gap/paper_draft.tex',
                    'src/adw/wen_model.py'],
        'provides': [],
        'notes': 'String-net condensation, rotor models.',
    },

    # ════════════════════════════════════════════════════════════════
    # Chirality wall
    # ════════════════════════════════════════════════════════════════

    'GoltermanShamir2026': {
        'authors': 'Golterman, M., Shamir, Y.',
        'title': 'Symmetric mass generation and the Nielsen-Ninomiya theorem',
        'journal': 'arXiv preprint (contribution to Lattice 2025 proceedings)',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': '2603.15985',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5e/primary-sources/GoltermanShamir2026.pdf',
        'used_in': ['papers/paper7_chirality_formal/paper_draft.tex',
                    'papers/paper8_chirality_master/paper_draft.tex',
                    'papers/D2/paper_draft.tex',
                    'src/chirality/tpf_gs_analysis.py'],
        'provides': [],
        'notes': 'GS no-go theorem: 9 conditions. Basis for Paper 7. Verified 2026-05-11 via WebFetch arXiv:2603.15985 (D2 Stage-13 fix-pass): actual title is "Symmetric mass generation and the Nielsen-Ninomiya theorem"; comment field "8 pages, 1 figure, contribution to the proceedings of Lattice 2025"; journal-ref empty (preprint only, intended for PoS Lattice 2025 proceedings). Prior cached title "Generalized no-go theorem for chiral fermions on a lattice" + venue "Phys. Rev. D 113, 014503 (2026)" were both fabricated.',
    },

    # ════════════════════════════════════════════════════════════════
    # Quasi-1D BEC theory
    # ════════════════════════════════════════════════════════════════

    'Salasnich2002': {
        'authors': 'Salasnich, L., Parola, A., Reatto, L.',
        'title': 'Effective wave equations for the dynamics of cigar-shaped and disk-shaped Bose condensates',
        'journal': 'PRA',
        'volume': 65,
        'page': '043614',
        'year': 2002,
        'doi': '10.1103/PhysRevA.65.043614',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Salasnich2002.json',
        'used_in': [],
        'provides': [],
        'notes': 'Quasi-1D BEC formula for c_s with transverse confinement corrections. '
                 'Used by Steinhauer to extract c(x) from density profiles.',
    },

    # ════════════════════════════════════════════════════════════════
    # Backreaction
    # ════════════════════════════════════════════════════════════════

    'Balbinot2025': {
        'authors': 'Balbinot, R., Fabbri, A., Ciliberto, A., Pavloff, N.',
        'title': 'Backreaction in acoustic black holes',
        'journal': 'PRD',
        'volume': 112,
        'page': 'L121703',
        'year': 2025,
        'doi': '10.1103/PhysRevD.112.L121703',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['src/wkb/backreaction.py'],
        'provides': [],
        'notes': 'Acoustic BHs cool toward extremality (opposite Schwarzschild).',
    },

    # ════════════════════════════════════════════════════════════════
    # Grassmann TRG
    # ════════════════════════════════════════════════════════════════

    'ShimizuKuramashi2014': {
        'authors': 'Shimizu, Y., Kuramashi, Y.',
        'title': 'Grassmann tensor renormalization group approach to one-flavor lattice Schwinger model',
        'journal': 'PRD',
        'volume': 90,
        'page': '014508',
        'year': 2014,
        'doi': '10.1103/PhysRevD.90.014508',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/ShimizuKuramashi2014.json',
        'used_in': ['src/core/constants.py'],
        'provides': [],
        'notes': 'Grassmann TRG algorithm.',
    },

    # ════════════════════════════════════════════════════════════════
    # SMG / fermion-bag MC
    # ════════════════════════════════════════════════════════════════

    'Catterall2016': {
        'authors': 'Catterall, S.',
        'title': 'Fermion mass without symmetry breaking',
        'journal': 'JHEP',
        'volume': '01',
        'page': '121',
        'year': 2016,
        'doi': '10.1007/JHEP01(2016)121',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Catterall2016.json',
        'used_in': ['src/core/constants.py'],
        'provides': [],
        'notes': 'SO(4) fermion-bag MC for symmetric mass generation.',
    },

    # ════════════════════════════════════════════════════════════════
    # Paper 17 (dark sector) bibkeys — added Phase 5x Wave 10 (2026-04-24)
    # Response to adversarial review 2026-04-23-1500-internal-adversarial
    # ════════════════════════════════════════════════════════════════

    'Visser1998': {
        'authors': 'Visser, M.',
        'title': 'Acoustic black holes: horizons, ergospheres, and Hawking radiation',
        'journal': 'Class. Quant. Grav.',
        'volume': 15,
        'page': '1767',
        'year': 1998,
        'doi': '10.1088/0264-9381/15/6/024',
        'arxiv': 'gr-qc/9712010',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Visser1998.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Visser acoustic metric foundational reference. arXiv verified.',
    },
    'CGL2017a': {
        'authors': 'Crossley, M., Glorioso, P., Liu, H.',
        'title': 'Effective field theory of dissipative fluids',
        'journal': 'JHEP',
        'volume': '09',
        'page': '095',
        'year': 2017,
        'doi': '10.1007/JHEP09(2017)095',
        'arxiv': '1511.03646',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/CGL2017a.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Paper 17 alias for Crossley2017 (same work; registry keeps '
                 'both for direct bibkey lookup compatibility with paper17 tex).',
    },
    'CGL2017b': {
        'authors': 'Glorioso, P., Crossley, M., Liu, H.',
        'title': 'Effective field theory of dissipative fluids (II): classical limit, dynamical KMS symmetry and entropy current',
        'journal': 'JHEP',
        'volume': '09',
        'page': '096',
        'year': 2017,
        'doi': '10.1007/JHEP09(2017)096',
        'arxiv': '1701.07817',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/CGL2017b.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex',
                    'papers/E2/paper_draft.tex',
                    'papers/L3/paper_draft.tex',
                    'papers/I1/paper_draft.tex',
                    'papers/paper16_graphene_sk_eft/paper_draft.tex'],
        'provides': [],
        'notes': 'CGL paper II (JHEP 09, 096 (2017)). Glorioso lead author. arXiv 1701.07817. Registry corrected 2026-05-11 (D1 Stage-13 fix-pass): canonical cross-bundle convention is CGL2017b = paper II (matches E2, L3, I1, paper17, paper16). D1 had a bibkey collision where its CGL2017b bibitem cited the Glorioso-Liu second-law paper (GloriosoLiu2018 / arXiv:1612.07705); D1 was renamed to use GloriosoLiu2018 directly.',
    },
    'Volovik2006': {
        'authors': 'Volovik, G. E.',
        'title': 'Cosmological constant and vacuum energy (JETP Lett note)',
        'journal': 'JETP Lett.',
        'volume': 82,
        'page': '319',
        'year': 2005,
        'doi': None,
        'arxiv': 'gr-qc/0604062',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Volovik2006.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Tetrad-determinant self-tuning of cosmological constant. '
                 'Note: paper17 bibitem uses year 2005 (JETP Lett), arXiv '
                 'year 2006. arXiv ID is tentative — user verify against JETP.',
    },
    'KV2008': {
        'authors': 'Klinkhamer, F. R., Volovik, G. E.',
        'title': 'Self-tuning vacuum variable and cosmological constant',
        'journal': 'Phys. Rev. D',
        'volume': 77,
        'page': '085015',
        'year': 2008,
        'doi': '10.1103/PhysRevD.77.085015',
        'arxiv': '0711.3170',
        'doi_verified': '2026-08-15',  # CrossRef 10.1103/PhysRevD.77.085015 + primary PDF title page (arXiv:0711.3170v6)
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/KV2008.pdf',
        'used_in': [
            'papers/paper17_dark_sector/paper_draft.tex',
            'papers/D5/paper_draft.tex',
            'notebooks/Phase6c1_StrongCPDarkEnergy_Stakeholder.ipynb',
        ],
        'provides': [],
        'notes': 'ORIGIN of Klinkhamer-Volovik q-theory: introduces the self-tuning '
                 'vacuum variable q. Cited as Ref. [3] by KlinkhamerVolovik2010. '
                 'arXiv ID and DOI verified 2026-08-15 (primary PDF title page + '
                 'CrossRef), superseding the prior "tentative — user verify" note. '
                 '⚠️ This paper contains NO oscillating-vacuum result (zero occurrences '
                 'of "oscillat" in the full text); the oscillating effective vacuum '
                 'energy density is KV, "Dynamic vacuum variable and equilibrium '
                 'approach in cosmology", PRD 78, 063528 (2008), arXiv:0806.2805. '
                 'papers/paper17_dark_sector/paper_draft.tex:259 cites this key for the '
                 '"KV oscillating-vacuum mechanism" — filed as a wrong-target citation.',
    },
    'Lean4': {
        'authors': 'de Moura, L., Ullrich, S.',
        'title': 'The Lean 4 theorem prover and programming language',
        'journal': 'CADE 28',
        'volume': None,
        'page': '625',
        'year': 2021,
        'doi': '10.1007/978-3-030-79876-5_37',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Lean4.abstract.txt',
        'used_in': [
            'papers/paper17_dark_sector/paper_draft.tex',
            'papers/paper18_doublon_gate/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Lean 4 citation. Conference: CADE-28, Pittsburgh 2021.',
    },
    'Mathlib': {
        'authors': 'The mathlib Community',
        'title': 'The Lean Mathematical Library',
        'journal': 'CPP 2020 (Proceedings)',
        'volume': None,
        'page': '367',
        'year': 2020,
        'doi': '10.1145/3372885.3373824',
        'arxiv': '1910.09336',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Mathlib.pdf',
        'used_in': [
            'papers/paper17_dark_sector/paper_draft.tex',
            'papers/paper18_doublon_gate/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Mathlib paper, CPP 2020 (Certified Programs and Proofs).',
    },
    'Wan2019': {
        'authors': 'Wan, Z., Wang, J., Zheng, Y.',
        'title': 'Quantum 4d Yang-Mills theory and time-reversal symmetric 5d higher-gauge topological field theory',
        'journal': 'Phys. Rev. D',
        'volume': 100,
        'page': '085012',
        'year': 2019,
        'doi': '10.1103/PhysRevD.100.085012',
        'arxiv': '1904.00994',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Wan2019.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Wan-Wang-Zheng Z16 bordism classification. arXiv tentative — user verify.',
    },
    'Wang2020': {
        'authors': 'Wang, J.',
        'title': 'Anomaly and cobordism constraints beyond the Standard Model',
        'journal': 'Phys. Rev. Research',
        'volume': 2,
        'page': '013189',
        'year': 2020,
        'doi': '10.1103/PhysRevResearch.2.013189',
        'arxiv': '1910.14664',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Wang2020.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Wang Standard Model anomaly/cobordism. arXiv tentative — user verify.',
    },
    'Wang2021': {
        'authors': 'Wang, J.',
        'title': 'Ultra Unification: Quantum fields beyond the Standard Model',
        'journal': 'Mod. Phys. Lett. A',
        'volume': 36,
        'page': '2130008',
        'year': 2021,
        'doi': '10.1142/S0217732321300081',
        'arxiv': '2012.15860',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Wang2021.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Wang Ultra Unification / T-0 topological hidden sector. arXiv tentative — user verify.',
    },
    'Garcia-Etxebarria2019': {
        'authors': 'Garc{\\\'i}a-Etxebarria, I., Montero, M.',
        'title': 'Dai-Freed anomalies in particle physics',
        'journal': 'JHEP',
        'volume': '08',
        'page': '003',
        'year': 2019,
        'doi': '10.1007/JHEP08(2019)003',
        'arxiv': '1808.00009',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Garcia-Etxebarria2019.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Dai-Freed anomalies in Standard Model. arXiv tentative — user verify.',
    },
    'ADW2019': {
        'authors': 'Abrikosov Jr., A. A., Klinkhamer, F. R.',
        'title': 'Tetrad condensation and emergent gravity',
        'journal': 'Phys. Rev. D',
        'volume': 99,
        'page': '105009',
        'year': 2019,
        'doi': '10.1103/PhysRevD.99.105009',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/ADW2019.json',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'ADW (Abrikosov-Diakonov-Wetterich) tetrad condensation / emergent '
                 'gravity. Title reconstructed — user verify via DOI lookup.',
    },
    'BK2015': {
        'authors': 'Berezhiani, L., Khoury, J.',
        'title': 'Theory of dark matter superfluidity',
        'journal': 'Phys. Rev. D',
        'volume': 92,
        'page': '103510',
        'year': 2015,
        'doi': '10.1103/PhysRevD.92.103510',
        'arxiv': '1507.01019',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/BK2015.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [
            'SFDM.m_DM', 'SFDM.Lambda', 'SFDM.c_s_subcluster',
        ],
        'notes': 'Berezhiani-Khoury superfluid dark matter framework. '
                 'BK fiducial: m_DM = 0.6 eV, Lambda = 0.2 meV, '
                 'c_s_subcl = 1525 km/s. arXiv ID verified 2026-04-24.',
    },
    'BK2025': {
        'authors': 'Berezhiani, L., Cintia, G., De Luca, V., Khoury, J.',
        'title': 'Superfluid Dark Matter',
        'journal': 'Physics Reports (in press, accepted 2026)',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': '2505.23900',
        'arxiv_verified': True,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/BK2025.pdf',
        'used_in': ['papers/D5/paper_draft.tex', 'papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'BK2025 SFDM review, Physics Reports (accepted, in press; v2 dated '
                 '2026-02-16 is the journal-matched version). 136 pages, 12 figures. '
                 'Paper 17 cites gap: no quantitative merger forecast. arXiv + page '
                 'count verified 2026-04-24; venue corrected 2026-05-11 from '
                 '"Physics Reports (2025)" — no 2025 published version exists — per '
                 'Stage-13 D5 review finding 1.6 via WebFetch.',
    },
    'BKWang2017': {
        'authors': 'Berezhiani, L., Khoury, J., Wang, J.',
        'title': 'Phonon-mediated late-time acceleration',
        'journal': 'Phys. Rev. D',
        'volume': 95,
        'page': '123530',
        'year': 2017,
        'doi': '10.1103/PhysRevD.95.123530',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/BKWang2017.json',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'BK-Wang phonon-sector acceleration → H_0 tension thematic. '
                 'arXiv ID needs user verification.',
    },
    'DESI2024': {
        'authors': 'DESI Collaboration',
        'title': 'DESI 2024 VI: cosmological constraints from the measurements of BAO',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': '2404.03002',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/DESI2024.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'DESI DR1 / 2024 cosmology result. Used in paper17 KV-withdraw '
                 'reasoning. User verify title exact form.',
    },
    'DESI2025': {
        'authors': 'DESI Collaboration',
        'title': 'DESI DR2 Results II: Measurements of Baryon Acoustic Oscillations and Cosmological Constraints',
        'journal': 'Phys. Rev. D',
        'volume': 112,
        'page': '083515',
        'year': 2025,
        'doi': '10.1103/PhysRevD.112.083515',
        'arxiv': '2503.14738',
        'arxiv_verified': True,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/DESI2025.pdf',
        'used_in': ['papers/D5/paper_draft.tex', 'papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'DESI DR2 2025 cosmology — BAO measurements from >14M galaxies/quasars; '
                 'flat-LCDM with 2.3σ CMB tension; dynamical DE indicated. Registry '
                 'title + venue corrected 2026-05-11 from abbreviated "DESI DR2 BAO: '
                 'cosmological constraints" + missing PRD 112, 083515 per Stage-13 '
                 'D5 review finding 1.5; arXiv title + journal-ref verified via WebFetch.',
    },
    'Sola2023': {
        'authors': 'Sol{\\`a} Peracaula, J.',
        'title': 'Running vacuum model and the H0 tension',
        'journal': 'Class. Quantum Grav.',
        'volume': 40,
        'page': '215004',
        'year': 2023,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'RVM with nu ~ 10^-3 DESI-compatible. User verify DOI + arXiv -- OPEN TODO, and until it lands this entry is `undeclared_class` (ADR-014 D7), never exempt. An unfinished entry used to read as a canonical-textbook exemption; it no longer does.',
    },
    'VanWaerbeke2025': {
        'authors': 'Van Waerbeke, L., Zhitnitsky, A. R.',
        'title': 'DESI results and Dark Energy from QCD topological sectors',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2506.14182',
        'doi_verified': '2026-04-29',  # WebFetch arXiv:2506.14182 confirmed title match (paper32 adversarial 2026-04-29)
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/VanWaerbeke2025.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex',
                    'papers/paper32_strong_cp_de/paper_draft.tex'],
        'provides': [],
        'notes': 'QCD topological DE — 0 free params, phantom crossing. Title corrected 2026-04-29 (was "QCD topological dark energy") per WebFetch verification.',
    },
    'Planck2018': {
        'authors': 'Planck Collaboration',
        'title': 'Planck 2018 results. VI. Cosmological parameters',
        'journal': 'A&A',
        'volume': 641,
        'page': 'A6',
        'year': 2020,
        'doi': '10.1051/0004-6361/201833910',
        'arxiv': '1807.06209',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Planck2018.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex',
                    'papers/paper42b_cc_emergent/paper_draft.tex'],
        'provides': [],
        'notes': 'Planck 2018 cosmological parameters (published 2020).',
    },
    'FangGu2021': {
        'authors': 'Fang, X.-Y., Gu, Z.-C.',
        'title': 'Emergent gravity with torsion from electron-loop condensation',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2021,
        'doi': None,
        'arxiv': '2106.10242',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/FangGu2021.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Fang-Gu topological gravity / torsion DM. arXiv verified.',
    },
    'Pretko2017': {
        'authors': 'Pretko, M.',
        'title': 'Subdimensional particle structure of higher rank U(1) spin liquids',
        'journal': 'Phys. Rev. B',
        'volume': 95,
        'page': '115139',
        'year': 2017,
        'doi': '10.1103/PhysRevB.95.115139',
        'arxiv': '1604.05329',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Pretko2017.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Pretko fracton / tensor gauge framework. arXiv tentative — user verify.',
    },
    'Nandkishore2019': {
        'authors': 'Nandkishore, R. M., Hermele, M.',
        'title': 'Fractons',
        'journal': 'Annu. Rev. Condens. Matter Phys.',
        'volume': 10,
        'page': '295',
        'year': 2019,
        'doi': '10.1146/annurev-conmatphys-031218-013604',
        'arxiv': '1803.11196',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Nandkishore2019.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Nandkishore-Hermele fracton review. arXiv tentative — user verify.',
    },
    'Shen2022': {
        'authors': 'Shen, J., et al.',
        'title': 'Hilbert space fragmentation (fracton diversity mechanism)',
        'journal': 'Phys. Rev. B',
        'volume': 106,
        'page': '045103',
        'year': 2022,
        'doi': '10.1103/PhysRevB.106.045103',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Shen2022.json',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Hilbert space fragmentation. Title reconstructed — user verify.',
    },
    'Krishna2024': {
        'authors': 'Krishna, V., Bridgeman, J., Bartlett, S. D.',
        'title': 'Finite temperature instability of 3D fracton topological order',
        'journal': 'Phys. Rev. B',
        'volume': 109,
        'page': '125131',
        'year': 2024,
        'doi': '10.1103/PhysRevB.109.125131',
        'arxiv': '2407.09625',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Krishna2024.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Krishna et al. 3D gapped fracton no-go at T>0 (resolved by '
                 'p-wave phase per Drilldown). arXiv tentative — user verify.',
    },
    'Kapustin2022': {
        'authors': 'Kapustin, A., Spodyneiko, L.',
        'title': 'Hohenberg-Mermin-Wagner-type theorems and dipole symmetry',
        'journal': 'Phys. Rev. B',
        'volume': 106,
        'page': '245125',
        'year': 2022,
        'doi': '10.1103/PhysRevB.106.245125',
        'arxiv': '2208.09056',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Kapustin2022.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'HMW-type theorems for dipole symmetry — p-wave stability. '
                 'arXiv + page verified 2026-04-24 (corrected paper17 citation: '
                 'paper17 had 085122, actual is 245125).',
    },
    'Jensen2024': {
        'authors': 'Jensen, K., Raz, A.',
        'title': 'Large-N dipole superfluid',
        'journal': 'Phys. Rev. Lett.',
        'volume': 132,
        'page': '071603',
        'year': 2024,
        'doi': '10.1103/PhysRevLett.132.071603',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Jensen2024.abstract.txt',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Jensen-Raz dipole superfluid SSB throughout phase diagram. '
                 'arXiv ID NEEDS USER VERIFICATION — could not be located via '
                 'WebFetch during 2026-04-24 remediation.',
    },
    'Glodkowski2024': {
        'authors': 'G{\\l}{\\\'o}dkowski, A., Pe{\\~n}a-Ben{\\\'i}tez, F., Sur{\\\'o}wka, P.',
        'title': 'Dissipative fracton superfluids',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': '2401.01877',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Glodkowski2024.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Głódkowski-Peña-Benítez-Surówka p-wave dipole superfluid with '
                 'z=4 subdiffusion. arXiv + title verified 2026-04-24 (BLOCKER '
                 '1.1 fix: paper17 previously cited wrong target arXiv:2406.12345 '
                 'which is a knowledge-management / fuzzy-logic paper).',
    },
    'Feistl2026': {
        'authors': 'Feistl, T., Schraven, S., Warzel, S.',
        'title': 'Mermin-Wagner theorems for quantum systems with multipole symmetries',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': '2601.23078',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5x/primary-sources/Feistl2026.pdf',
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Feistl-Schraven-Warzel multipole MW extension (Jan 2026). '
                 'arXiv + title verified 2026-04-24.',
    },
    'Roehm2026GrapheneDeep': {
        'authors': 'SK-EFT Hawking Research Program',
        'title': 'Formally Verified Analog Hawking Radiation Across Three '
                 'Platforms (bundle D1, E2 deep companion)',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/E2/paper_draft.tex'],
        'provides': [],
        'notes': 'Splash/deep companion self-citation, added 2026-08-09 when '
                 'E2 was trimmed under the PRL ceiling and its nu-derivation, '
                 'Kibble-Zurek cross-check and fig105 moved into D1. The '
                 'citation is what makes the trim content-preserving at the '
                 'portfolio level rather than a deletion. No external primary '
                 'source: D1 is this program.',
    },
    'FractonNonAbelian2025': {
        'authors': 'SK-EFT Hawking Research Program',
        'title': 'Yang-Mills incompatibility of fracton topological phases (Paper 8 companion)',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/paper17_dark_sector/paper_draft.tex'],
        'provides': [],
        'notes': 'Internal project companion paper. Renamed from "Paper8" '
                 'to disambiguate from paper7 (which uses "Paper8" for the '
                 'Chirality Wall work). No external primary source.',
    },
    # ────────────────────────────────────────────────────────────────
    # Paper 18 (doublon gate) — added 2026-04-26
    # ────────────────────────────────────────────────────────────────
    # 'Berry1984' formerly appeared HERE as a second, shadowed copy. Deleted 2026-07-31
    # and merged into the single canonical entry later in this dict, which now carries
    # BOTH consumers (D11 and paper18_doublon_gate). Found by D11 Stage-13 in two
    # consecutive rounds. Do not re-add a second literal for this key.
    'Zanardi1999': {
        'authors': 'Zanardi, P., Rasetti, M.',
        'title': 'Holonomic quantum computation',
        'journal': 'Phys. Lett. A',
        'volume': 264,
        'page': '94',
        'year': 1999,
        'doi': '10.1016/S0375-9601(99)00803-8',
        'arxiv': 'quant-ph/9904011',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5q/primary-sources/Zanardi1999.pdf',
        'used_in': ['papers/paper18_doublon_gate/paper_draft.tex'],
        'provides': [],
        'notes': 'Original holonomic quantum computation proposal.',
    },
    'Leek2007': {
        'authors': 'Leek, P. J. et al.',
        'title': "Observation of Berry's phase in a solid-state qubit",
        'journal': 'Science',
        'volume': 318,
        'page': '1889',
        'year': 2007,
        'doi': '10.1126/science.1149858',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5q/primary-sources/Leek2007.abstract.txt',
        'used_in': ['papers/paper18_doublon_gate/paper_draft.tex'],
        'provides': [],
        'notes': 'First Berry-phase observation in a superconducting qubit. '
                 'DOI verified against Science 318, 1889 (2007).',
    },
    'Kiefer2026': {
        'authors': 'Kiefer, S., Zhu, Y., Fischer, P., Jele, Y., '
                   'Gächter, R., Bisson, L., Viebahn, P., Esslinger, T.',
        'title': 'Protected quantum gates using qubit doublons in '
                 'dynamical optical lattices',
        'journal': 'Nature',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,  # Nature DOI pending publication
        'arxiv': '2507.22112',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5q/primary-sources/Kiefer2026.pdf',
        'used_in': ['papers/paper18_doublon_gate/paper_draft.tex'],
        'provides': [],
        'notes': 'Experimental realization of the doublon geometric SWAP gate. '
                 'arXiv:2507.22112 (Nature 2026). Central experimental reference '
                 'for Paper 18 formalization.',
    },
    'Kitaev2009': {
        'authors': 'Kitaev, A.',
        'title': 'Periodic table for topological insulators and superconductors',
        'journal': 'AIP Conf. Proc.',
        'volume': 1134,
        'page': '22',
        'year': 2009,
        'doi': '10.1063/1.3149495',
        'arxiv': '0901.2686',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5q/primary-sources/Kitaev2009.pdf',
        'used_in': ['papers/paper18_doublon_gate/paper_draft.tex',
                    'papers/D2/paper_draft.tex',
                    'papers/L2/paper_draft.tex',
                    'papers/paper10_modular_generation/paper_draft.tex'],
        'provides': [],
        'notes': 'Tenfold-way periodic table of topological phases (Kitaev 2009). '
                 'BDI class reference for Paper 18 W5 symmetry layer. used_in '
                 'completed 2026-05-31 to all four actual consumers (D2, L2, '
                 'paper10, paper18) per Stage-13 finding L2:1.3.',
    },
    'AltlandZirnbauer': {
        'authors': 'Altland, A., Zirnbauer, M. R.',
        'title': 'Nonstandard symmetry classes in mesoscopic '
                 'normal-superconducting hybrid structures',
        'journal': 'Phys. Rev. B',
        'volume': 55,
        'page': '1142',
        'year': 1997,
        'doi': '10.1103/PhysRevB.55.1142',
        'arxiv': 'cond-mat/9602137',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5q/primary-sources/AltlandZirnbauer.pdf',
        'used_in': ['papers/paper18_doublon_gate/paper_draft.tex'],
        'provides': [],
        'notes': 'Foundational Altland-Zirnbauer symmetry classification. '
                 'Original 10-fold way / BDI class definition used in Paper 18.',
    },

    # ════════════════════════════════════════════════════════════════
    # Phase 5z Wave 1 — Paper 20 (scalar-rung interpretation) bibkeys
    # ════════════════════════════════════════════════════════════════

    'ADW': {
        'authors': 'Akama, K.',
        'title': 'An attempt at pregeometry: gravity with composite metric',
        'journal': 'Prog. Theor. Phys.',
        'volume': 60,
        'page': '1900',
        'year': 1978,
        'doi': '10.1143/PTP.60.1900',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/ADW.json',
        'used_in': ['papers/paper20_scalar_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'Original Akama pregeometry composite-metric paper. '
                 'Foundational for the ADW mechanism in this project. '
                 'doi_verified 2026-04-26 via OUP/academic.oup.com DOI '
                 'redirect from doi.org: title, author (K. Akama), journal, '
                 'volume, page, year all match. Title corrected from '
                 '"gauge fields" to "gravity with composite metric" per '
                 'the actual PTP record.',
    },
    'WetterichSpinor2013': {
        'authors': 'Wetterich, C.',
        'title': 'Spinor gravity and diffeomorphism invariance on the lattice',
        'journal': 'Lect. Notes Phys.',
        'volume': 863,
        'page': '67',
        'year': 2013,
        'doi': '10.1007/978-3-642-33036-0_4',
        'arxiv': '1201.2871',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/WetterichSpinor2013.pdf',
        'used_in': ['papers/paper20_scalar_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'Wetterich Lecture Notes Physics 863 chapter on spinor '
                 'gravity (Proceedings of the 6th Aegean Summer School, '
                 'Naxos 2011). doi_verified 2026-04-26: DOI matches; '
                 'arXiv corrected from 1206.3392 (unrelated information-'
                 'theory paper by Vatedka/Kashyap/Thangaraj) to 1201.2871 '
                 '(the actual Wetterich arXiv preprint for this chapter). '
                 'Split from prior WetterichSpinor combined bibitem.',
    },
    'WetterichSpinor2022': {
        'authors': 'Wetterich, C.',
        'title': 'Pregeometry and spontaneous time-space asymmetry',
        'journal': 'JHEP',
        'volume': 6,
        'page': '069',
        'year': 2022,
        'doi': '10.1007/JHEP06(2022)069',
        'arxiv': '2101.11519',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/WetterichSpinor2022.pdf',
        'used_in': ['papers/paper20_scalar_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'Wetterich pregeometry / spontaneous time-space asymmetry. '
                 'doi_verified 2026-04-26: DOI corrected from JHEP02(2022)169 '
                 'to the actual JHEP06(2022)069; arXiv corrected from '
                 '2110.13863 (unrelated exoplanet-ephemeris paper ExoClock '
                 'Project II by Kokori et al.) to the actual 2101.11519. '
                 'Matches Phase-5z deep-research reference (O.2 file table).',
    },
    'WetterichNJL': {
        'authors': 'Wetterich, C.',
        'title': 'Geometry and symmetries in lattice spinor gravity',
        'journal': 'Ann. Phys.',
        'volume': 327,
        'page': '2184',
        'year': 2012,
        'doi': '10.1016/j.aop.2012.04.005',
        'arxiv': '1201.6505',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/WetterichNJL.pdf',
        'used_in': ['lean/SKEFTHawking/WetterichNJL.lean',
                    'papers/paper20_scalar_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'CORRECTED 2026-04-26. Prior entry cited a nonexistent '
                 '"Wetterich, PLB 901, 136223 (2024) - Spinor gravity from '
                 'a fermionic four-vertex" — CrossRef 404, INSPIRE/arXiv '
                 'return no match, and Phase-5z O.2 deep research never '
                 'referenced any such paper. Replaced with the canonical '
                 "lattice version of Wetterich's NJL-type 4-fermion spinor-"
                 'gravity construction: Ann. Phys. 327, 2184 (2012), '
                 'arXiv:1201.6505. This paper explicitly introduces the '
                 'nearest-neighbor bond structure formalized in '
                 'WetterichNJL.lean. doi_verified 2026-04-26 via arXiv '
                 'record (journal reference on arxiv.org/abs/1201.6505 '
                 'confirms Ann. Phys. / 10.1016/j.aop.2012.04.005). '
                 'Hallucinated-citation finding filed as Stage-13 BLOCKER.',
    },
    'Fierz': {
        'authors': 'Fierz, M.',
        'title': 'Zur Fermischen Theorie des β-Zerfalls',
        'journal': 'Z. Phys.',
        'volume': 104,
        'page': '553',
        'year': 1937,
        'doi': '10.1007/BF01330070',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/Fierz.json',
        'used_in': ['papers/paper20_scalar_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'Original Fierz rearrangement identity. Pre-arXiv era; '
                 'DOI-only verification path. doi_verified 2026-04-26 via '
                 'NASA ADS (bibcode 1937ZPhy..104..553F): title, author '
                 '(Markus Fierz), journal, volume, page, year all match.',
    },
    'NJL61': {
        'authors': 'Nambu, Y., Jona-Lasinio, G.',
        'title': 'Dynamical model of elementary particles based on an '
                 'analogy with superconductivity I',
        'journal': 'Phys. Rev.',
        'volume': 122,
        'page': '345',
        'year': 1961,
        'doi': '10.1103/PhysRev.122.345',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/NJL61.json',
        'used_in': ['papers/paper20_scalar_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'Original Nambu-Jona-Lasinio paper. Pre-arXiv; '
                 'DOI-only verification path. doi_verified 2026-04-26 '
                 'via NASA ADS (bibcode 1961PhRv..122..345N): title, '
                 'authors (Nambu, Y.; Jona-Lasinio, G.), journal, volume, '
                 'page, year all match.',
    },
    'GiesScherer': {
        'authors': 'Gies, H., Lippoldt, S.',
        'title': 'Renormalization flow towards gravitational catalysis '
                 'in the 3d Gross-Neveu model',
        'journal': 'Phys. Rev. D',
        'volume': 87,
        'page': '104026',
        'year': 2013,
        'doi': '10.1103/PhysRevD.87.104026',
        'arxiv': '1303.4253',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/GiesScherer.pdf',
        'used_in': ['papers/paper20_scalar_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'Gies-Lippoldt RG-NJL companion. Bibkey is a project-local '
                 'shorthand (not the literal author surname). doi_verified '
                 '2026-04-26 via NASA ADS (bibcode 2013PhRvD..87j4026G): '
                 'title, authors (H. Gies, S. Lippoldt), journal, volume, '
                 'article number, year all match. arXiv corrected from '
                 '1305.6940 (unrelated philosophy-of-physics paper "Quantum '
                 'Objects" by Mansouri/Golshani/Karbasizadeh) to the actual '
                 '1303.4253. Consider renaming bibkey to GiesLippoldt2013 '
                 'in paper-side cleanup (advisory, not required).',
    },
    'BardeenHillLindner': {
        'authors': 'Bardeen, W. A., Hill, C. T., Lindner, M.',
        'title': 'Minimal dynamical symmetry breaking of the standard model',
        'journal': 'Phys. Rev. D',
        'volume': 41,
        'page': '1647',
        'year': 1990,
        'doi': '10.1103/PhysRevD.41.1647',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/BardeenHillLindner.json',
        'used_in': ['papers/paper20_scalar_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'Top-quark condensate / dynamical EWSB foundational paper. '
                 'Pre-arXiv; DOI-only verification path. doi_verified '
                 '2026-04-26 via NASA ADS (bibcode 1990PhRvD..41.1647B): '
                 'title, authors (W. A. Bardeen, C. T. Hill, M. Lindner), '
                 'journal, volume, page, year all match.',
    },
    'MiranskyTanabashiYamawaki1989': {
        'authors': 'Miransky, V. A., Tanabashi, M., Yamawaki, K.',
        'title': 'Is the t-quark responsible for the mass of W and Z bosons?',
        'journal': 'Mod. Phys. Lett. A',
        'volume': 4,
        'page': '1043',
        'year': 1989,
        'doi': '10.1142/S0217732389001210',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/MiranskyTanabashiYamawaki1989.abstract.txt',
        'used_in': ['papers/paper20_scalar_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'MTY second paper — explicit SU(2)_L × U(1)_R 4-fermion '
                 'operator (ψ̄_L t_R)(t̄_R ψ_L) with σ = H ∼ ψ̄_R ψ_L '
                 'identified as SM (1,2)_{+1/2} Higgs doublet. Primary '
                 'precedent for Scenario A in Phase 5z O.2 verdict. '
                 'Pre-arXiv. doi_verified pending — World Scientific MPLA '
                 'CrossRef route, awaiting fetch round.',
    },
    'Hill2025Redux': {
        'authors': 'Hill, C. T.',
        'title': 'Natural top quark condensation (a redux)',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2503.21518',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/Hill2025Redux.pdf',
        'used_in': ['papers/paper20_scalar_rung/paper_draft.tex',
                    'lean/SKEFTHawking/BHLGaugeEmbedding.lean'],
        'provides': [],
        'notes': 'Hill 2025 redux: bilocal H^i(x,y) ∼ ψ̄_R(x) ψ_L^i(y) with '
                 'internal wave-function ϕ(r). The dilution factor '
                 'ϕ(0)/ϕ(∞) is the order parameter resolving the BHL gap '
                 'problem; natural composite scale ~ 6 TeV with quartic λ '
                 'consistent with m_H = 125 GeV at few-percent fine-tuning. '
                 'Most recent load-bearing anchor for Scenario A. '
                 'doi_verified pending — arXiv abstract fetch round.',
    },
    # AndrianovAndrianovAfonin2020 entry REMOVED 2026-04-26 after Stage 13
    # adversarial round verified arXiv:1906.09579 actually resolves to
    # Osipov, Hiller, Blin, Palanca, Moreira, Sampaio, EPJC 80:1135 (DOI
    # …08716-y) — title-only coincidence. The deep research had a wrong-arXiv
    # hallucination similar to documented 5z W2 cases. Hill 2025 + Cvetic
    # 1999 already cover the 125 GeV recovery branch; removed to avoid risk.
    'CsikorFodorHeitger1999': {
        'authors': 'Csikor, F., Fodor, Z., Heitger, J.',
        'title': 'Endpoint of the hot electroweak phase transition',
        'journal': 'Phys. Rev. Lett.',
        'volume': 82,
        'page': '21',
        'year': 1999,
        'doi': '10.1103/PhysRevLett.82.21',
        'arxiv': 'hep-ph/9809291',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/CsikorFodorHeitger1999.pdf',
        'used_in': ['papers/paper22_ew_phase_transition/paper_draft.tex',
                    'papers/I1/paper_draft.tex'],
        'provides': [],
        'notes': 'CFH 1999 lattice analysis: refined the KLRS96 SM EWPT '
                 'crossover threshold to m_H = 72.4 ± 1.7 GeV. The 72 GeV '
                 'value cited in paper 22 is from this paper, NOT from KLRS96 '
                 '(which gave a broader 70-95 GeV range). doi_verified pending — '
                 'APS PRL CrossRef + arXiv hep-ph/9809291 fetch round.',
    },
    'KLRS1996': {
        'authors': 'Kajantie, K., Laine, M., Rummukainen, K., Shaposhnikov, M.',
        'title': 'Is there a hot electroweak phase transition at m_H >~ m_W?',
        'journal': 'Phys. Rev. Lett.',
        'volume': 77,
        'page': '2887',
        'year': 1996,
        'doi': '10.1103/PhysRevLett.77.2887',
        'arxiv': 'hep-ph/9605288',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/KLRS1996.pdf',
        'used_in': ['papers/paper22_ew_phase_transition/paper_draft.tex',
                    'papers/I1/paper_draft.tex'],
        'provides': [],
        # ⚠️ NOTE REWRITTEN TO THE SOURCE 2026-08-14 (I1 Stage-13 finding 1.3). The
        # previous note read "crossover for m_H >~ 72 GeV … canonical crossover
        # threshold m_H_crit = 72 ± 2 GeV" and attributed that number to THIS paper.
        # KLRS96 contains no "72": the string is CFH99's, and the two notes in this
        # registry contradicted each other on the point.
        'notes': 'KLRS 1996 3D-effective-theory + lattice Monte Carlo study of the hot electroweak transition. '
                 'Abstract verbatim (arxiv.org/abs/hep-ph/9605288, re-fetched 2026-08-14): '
                 '"In the minimal standard electroweak theory 70 GeV < m_{H,c} < 95 GeV and most likely m_{H,c} ~ 80 GeV." '
                 'This paper therefore sets a RANGE (70-95 GeV, most likely ~80 GeV) for the critical endpoint, '
                 'NOT the 72.4 ± 1.7 GeV figure — that value is CsikorFodorHeitger1999 '
                 '(arxiv.org/abs/hep-ph/9809291: "the Higgs-boson endpoint mass in the Standard Model is 72.4 ± 1.7 GeV"). '
                 'Phase 5z Wave 3 cite for the SM-as-crossover verdict; cited by I1 §5 for the range, which I1 states correctly. '
                 'doi_verified: arXiv journal-ref confirms Phys. Rev. Lett. 77, 2887-2890 (1996).',
    },
    'DOnofrioRummukainen2016': {
        'authors': "D'Onofrio, M., Rummukainen, K.",
        'title': 'Standard Model cross-over on the lattice',
        'journal': 'Phys. Rev. D',
        'volume': 93,
        'page': '025003',
        'year': 2016,
        'doi': '10.1103/PhysRevD.93.025003',
        'arxiv': '1508.07161',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/DOnofrioRummukainen2016.pdf',
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': [],
        'notes': 'D\'Onofrio-Rummukainen 2016 (arXiv:1508.07161, title '
                 'title-matched against arXiv API 2026-06-10) — the lattice '
                 'crossover temperature T_c = 159.5 ± 1.5 GeV at the physical '
                 'Higgs mass m_H = 125 GeV. Added 2026-06-10 in the '
                 'AttributionContentSweep: D3 §13 had mis-attributed this '
                 '159 GeV/125 GeV result to KLRS1996 (which studied '
                 'm_H = 60-180 GeV and reports no 159 GeV); KLRS1996 is '
                 'retained for the crossover-existence verdict only.',
    },
    'ButtazzoEtAl2013': {
        'authors': 'Buttazzo, D., Degrassi, G., Giardino, P. P., Giudice, G. F., Sala, F., Salvio, A., Strumia, A.',
        'title': 'Investigating the near-criticality of the Higgs boson',
        'journal': 'JHEP',
        'volume': '12',
        'page': '089',
        'year': 2013,
        'doi': '10.1007/JHEP12(2013)089',
        'arxiv': '1307.3536',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/ButtazzoEtAl2013.pdf',
        'used_in': ['papers/paper22_ew_phase_transition/paper_draft.tex'],
        'provides': [],
        'notes': 'SM Higgs vacuum stability under RG: lambda_SM dips near '
                 'zero at ~10^11 GeV, placing SM in metastable regime. '
                 'Phase 5z Wave 3 motivation for the H_VacuumStableUnderRG '
                 'tracked hypothesis. doi_verified pending — Springer JHEP '
                 'CrossRef + arXiv 1307.3536 fetch round.',
    },
    'ShaposhnikovWetterich2010': {
        'authors': 'Shaposhnikov, M., Wetterich, C.',
        'title': 'Asymptotic safety of gravity and the Higgs boson mass',
        'journal': 'Phys. Lett. B',
        'volume': 683,
        'page': '196',
        'year': 2010,
        'doi': '10.1016/j.physletb.2009.12.022',
        'arxiv': '0912.0208',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/ShaposhnikovWetterich2010.pdf',
        'used_in': ['papers/paper22_ew_phase_transition/paper_draft.tex'],
        'provides': [],
        'notes': 'Asymptotic safety of gravity at NGFP yields m_H = 126 ± few '
                 'GeV via gravitational IR fixed-point on lambda. Phase 5z '
                 'Wave 3 cite as a Wetterich-native (elementary Higgs) '
                 'alternative to BHL composite Higgs mechanism. '
                 'doi_verified pending — Elsevier PLB CrossRef + arXiv '
                 '0912.0208 fetch round.',
    },
    'Cvetic1999': {
        'authors': 'Cvetic, G.',
        'title': 'Top quark condensation',
        'journal': 'Rev. Mod. Phys.',
        'volume': 71,
        'page': '513',
        'year': 1999,
        'doi': '10.1103/RevModPhys.71.513',
        'arxiv': 'hep-ph/9702381',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/Cvetic1999.pdf',
        'used_in': ['papers/paper20_scalar_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'Canonical review of top-quark condensation (BHL/MTY/topcolor). '
                 'Documents that the (1,2)_{+1/2} Higgs identification is generic '
                 'to the BHL-class embedding; surveys two-doublet and '
                 'neutrino-condensate extensions. doi_verified pending — APS '
                 'RMP CrossRef + arXiv hep-ph/9702381 fetch round.',
    },
    'PDG2024': {
        'authors': 'Navas, S. et al. (Particle Data Group)',
        'title': 'Review of particle physics',
        'journal': 'Phys. Rev. D',
        'volume': 110,
        'page': '030001',
        'year': 2024,
        'doi': '10.1103/PhysRevD.110.030001',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/PDG2024.abstract.txt',
        'used_in': ['papers/paper20_scalar_rung/paper_draft.tex',
                    'src/core/provenance.py'],
        'provides': [],
        'notes': 'PDG 2024 Review of Particle Physics. Source for '
                 'EW.M_W_GEV / M_Z_GEV / M_H_GEV / V_EW_GEV / SIN2_THETA_W / '
                 'G_FERMI_GEV_M2 / Y_TOP / LAMBDA_SM_HIGGS in PARAMETER_PROVENANCE. '
                 'doi_verified 2026-04-26 via pdg.lbl.gov (official PDG '
                 '2024 authors page): title, lead author (S. Navas et al.), '
                 'journal, volume, page, year all match.',
    },
    'PeskinSchroeder': {
        'authors': 'Peskin, M. E., Schroeder, D. V.',
        'title': 'An Introduction to Quantum Field Theory',
        'journal': 'textbook',
        'volume': None,
        'page': None,
        'year': 1995,
        'doi': None,
        'isbn': '978-0201503975',
        'publisher': 'Westview Press',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper20_scalar_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'Standard QFT textbook. ISBN-only verification path; '
                 'DOI not applicable. doi_verified 2026-04-26 via OpenLibrary '
                 '(partial record, title and year 1995 match; publisher and '
                 'author list consistent with community-standard knowledge '
                 'of the Peskin-Schroeder text). Publisher blocking of '
                 'Routledge/WorldCat direct WebFetch prevented ISBN-level '
                 'primary-source confirmation. Attribution verdict: '
                 'partial-match; no contradictions found.',
    },

    # ────────────────────────────────────────────────────────────────
    # Phase 5z Wave 2 (paper 21 majorana_rung) — verified 2026-04-25
    # WebFetch round per feedback_citation_verification_required.md.
    # Three corrections applied during the round (see individual notes):
    #   - NuFit60: arXiv ID hallucinated (was 2601.14386, corrected to
    #     2410.05380); author list missing two co-authors and contained one
    #     spurious entry; title corrected.
    #   - Davighi2023 → KawasakiYanagida2023: bibkey rename — arXiv:2304.10100
    #     is by Kawasaki & Yanagida, NOT Davighi-Lohitsiri-Tasnak; published
    #     JHEP 11 (2023) 106 (DOI added).
    #   - Volovik2024Spinor: DOI corrected from 10.1134/S0021364024600293
    #     (404) to 10.1134/S002136402460006X (per NASA ADS + CrossRef).
    # ────────────────────────────────────────────────────────────────
    'NuFit60': {
        'authors': 'Esteban, I., Gonzalez-Garcia, M. C., Maltoni, M., Martinez-Soler, I., Pinheiro, J. P., Schwetz, T.',
        'title': 'NuFit-6.0: Updated global analysis of three-flavor neutrino oscillations',
        'journal': 'JHEP',
        'volume': '12',
        'page': '216',
        'year': 2024,
        'doi': '10.1007/JHEP12(2024)216',
        'arxiv': '2410.05380',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/NuFit60.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex',
                    'src/core/provenance.py'],
        'provides': [],
        'notes': 'NuFit-6.0 global three-flavor oscillation fit; source for '
                 'MAJORANA.DELTA_M_SQ_21 / DELTA_M_SQ_31 / THETA_12 / THETA_13 / '
                 'THETA_23 / DELTA_CP. Verified via CrossRef DOI lookup '
                 '2026-04-25 (corrected: arXiv 2601.14386 was a hallucination — '
                 'pointed to a different paper; correct ID is 2410.05380; '
                 'authors corrected to add Martinez-Soler + Pinheiro and remove '
                 'spurious Zhou; title corrected to match published version).',
    },
    'KamLANDZen800': {
        'authors': 'KamLAND-Zen Collaboration (Abe, S. et al.)',
        'title': 'Search for Majorana Neutrinos with the Complete KamLAND-Zen Dataset',
        'journal': 'Phys. Rev. Lett.',
        'volume': 135,
        'page': 262501,
        'year': 2025,
        'doi': '10.1103/jkf6-48j8',
        'arxiv': '2406.11438',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/KamLANDZen800.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex',
                    'src/core/provenance.py'],
        'provides': [],
        'notes': 'KamLAND-Zen 800 full-dataset 0νββ search. T_{1/2} > 3.8 × 10²⁶ '
                 'yr at 90% CL; m_ββ < 28-122 meV depending on NME. Published '
                 'as PRL 135, 262501 (2025); arXiv preprint 2406.11438 v2 '
                 '(March 2026). Source for MAJORANA.M_BB_KAMLAND_ZEN_*. '
                 'Verified via arXiv + INSPIRE 2026-04-25 (corrected: prior '
                 'registry entry listed journal=arXiv before PRL publication '
                 'was confirmed in Stage-13 adversarial round).',
    },
    'LEGEND1000': {
        'authors': 'LEGEND Collaboration (Abgrall, N. et al.)',
        'title': 'The Large Enriched Germanium Experiment for Neutrinoless ββ Decay: LEGEND-1000 Preconceptual Design Report',
        'journal': 'arXiv',
        'volume': None,
        'page': None,
        'year': 2021,
        'doi': '10.48550/arXiv.2107.11462',
        'arxiv': '2107.11462',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/LEGEND1000.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex',
                    'src/core/provenance.py'],
        'provides': [],
        'notes': 'LEGEND-1000 PCDR. Projected 99.7% CL discovery sensitivity '
                 'T_{1/2} = 1.3 × 10²⁸ yr; m_ββ = 9-21 meV reach. Covers full '
                 'inverted-ordering parameter space at 10 yr live time. '
                 'Source for MAJORANA.M_BB_LEGEND_*. Verified via arXiv abstract '
                 'page 2026-04-25.',
    },
    'MohapatraSmirnov2006': {
        'authors': 'Mohapatra, R. N., Smirnov, A. Y.',
        'title': 'Neutrino Mass and New Physics',
        'journal': 'Annu. Rev. Nucl. Part. Sci.',
        'volume': 56,
        'page': 569,
        'year': 2006,
        'doi': '10.1146/annurev.nucl.56.080805.140534',
        'arxiv': 'hep-ph/0603118',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/MohapatraSmirnov2006.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex',
                    'src/core/provenance.py'],
        'provides': [],
        'notes': 'Canonical Type-I seesaw review. Source for the Wave-2 m_ν '
                 'band derivation (m_ν ~ y² v² / M_R) and the M_R = 10⁹-10¹⁵ '
                 'GeV envelope. Cited in deep-research §2.2. Verified via '
                 'CrossRef DOI lookup 2026-04-25 (page range 569-628).',
    },
    'GarciaEtxebarriaMontero2019': {
        'authors': 'García-Etxebarria, I., Montero, M.',
        'title': 'Dai-Freed anomalies in particle physics',
        'journal': 'JHEP',
        'volume': '08',
        'page': '003',
        'year': 2019,
        'doi': '10.1007/JHEP08(2019)003',
        'arxiv': '1808.00009',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/GarciaEtxebarriaMontero2019.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex',
                    'src/core/provenance.py',
                    'lean/SKEFTHawking/Z16AnomalyComputation.lean'],
        'provides': [],
        'notes': 'Garcia-Etxebarria & Montero Dai-Freed anomaly framework: '
                 'sets ν_R = Z₁₆ charge +1, locks Embedding III\'s structural '
                 'choice. Source for MAJORANA.* Z₁₆ context and EW.N_F_WITH_NU_R. '
                 'Verified via CrossRef DOI lookup 2026-04-25.',
    },
    'WanWang2020': {
        'authors': 'Wan, Z., Wang, J.',
        'title': 'Beyond Standard Models and Grand Unifications: Anomalies, Topological Terms, and Dynamical Constraints via Cobordisms',
        'journal': 'JHEP',
        'volume': '07',
        'page': '062',
        'year': 2020,
        'doi': '10.1007/JHEP07(2020)062',
        'arxiv': '1910.14668',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/WanWang2020.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'Wan-Wang Ultra-Unification anomaly tower: 15 ≡ -1 mod 16 per '
                 'no-ν_R generation. Verified via CrossRef DOI lookup 2026-04-25.',
    },
    'KawasakiYanagida2023': {
        'authors': 'Kawasaki, M., Yanagida, T. T.',
        'title': 'Dai-Freed anomaly in the standard model and topological inflation',
        'journal': 'JHEP',
        'volume': '11',
        'page': '106',
        'year': 2023,
        'doi': '10.1007/JHEP11(2023)106',
        'arxiv': '2304.10100',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/KawasakiYanagida2023.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex',
                    'src/core/provenance.py'],
        'provides': [],
        'notes': 'Kawasaki & Yanagida Dai-Freed-anomaly + topological inflation. '
                 'Embedding III phenomenology consistent with reheating ~10⁸ '
                 'GeV. Verified via arXiv abstract + NASA ADS + CrossRef '
                 '2026-04-25 (corrected: prior bibkey "Davighi2023" was a '
                 'hallucinated author attribution — arXiv 2304.10100 is by '
                 'Kawasaki & Yanagida, published JHEP 11 (2023) 106).',
    },
    'Volovik2024Spinor': {
        'authors': 'Volovik, G. E.',
        'title': 'Fermionic quartet and vestigial gravity',
        'journal': 'JETP Lett.',
        'volume': 119,
        'page': 330,
        'year': 2024,
        'doi': '10.1134/S002136402460006X',
        'arxiv': '2312.09435',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/Volovik2024Spinor.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'Volovik 2024 fermionic-quartet/vestigial-gravity construction. '
                 'Establishes that ⟨ÊÊ⟩ and ⟨Ê⟩ vanish independently '
                 '(vestigial regime with phase diagram). Cited as motivation '
                 'for WAVE2-OPEN-1 substrate-bridge tracked-hypothesis. '
                 'Verified via NASA ADS + CrossRef 2026-04-25 (corrected DOI: '
                 'prior 10.1134/S0021364024600293 was a 404; correct DOI is '
                 '10.1134/S002136402460006X).',
    },
    'TooBySmithHepLean': {
        'authors': 'Tooby-Smith, J.',
        'title': 'HepLean: Digitalising high energy physics',
        'journal': 'Comput. Phys. Commun.',
        'volume': 308,
        'page': '109457',
        'year': 2025,
        'doi': '10.1016/j.cpc.2024.109457',
        'arxiv': '2405.08863',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/TooBySmithHepLean.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex',
                    'lean/SKEFTHawking/NeutrinoMixing.lean',
                    'papers/I1/paper_draft.tex'],
        'provides': [],
        'notes': 'HepLean reference: source for the CKMMatrix structure-note '
                 'idiom mirrored by NeutrinoMixing.PMNSMatrix. Verified via '
                 'CrossRef DOI lookup 2026-04-25.',
    },

    # ────────────────────────────────────────────────────────────────
    # Phase 5z Wave 2b — strengthening citations (verified 2026-04-25)
    # One correction applied:
    #   - AntuschKingmanLindnerWetterich2003 → AntuschKerstenLindnerRatz2003:
    #     bibkey rename — actual authors of arXiv:hep-ph/0211385 are Antusch,
    #     Kersten, Lindner, Ratz (NOT Kingman/Wetterich, which were
    #     hallucinated). Journal-ref Nucl.Phys.B658:203-216 (2003) confirmed.
    # ────────────────────────────────────────────────────────────────
    'AntuschKerstenLindnerRatz2003': {
        'authors': 'Antusch, S., Kersten, J., Lindner, M., Ratz, M.',
        'title': 'Dynamical Electroweak Symmetry Breaking by a Neutrino Condensate',
        'journal': 'Nucl. Phys. B',
        'volume': 658,
        'page': 203,
        'year': 2003,
        'doi': '10.1016/S0550-3213(03)00188-3',
        'arxiv': 'hep-ph/0211385',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/AntuschKerstenLindnerRatz2003.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex',
                    'lean/SKEFTHawking/MajoranaRung.lean'],
        'provides': [],
        'notes': 'Source for Wave 2b H_MR_FromADWSubstrate_BCS_LNV form: '
                 'coupled Dirac-Majorana NJL gap equations with M_R as '
                 'external input + supercritical bifurcation. Cited '
                 'verbatim in MajoranaRung §3a for the lepton-number-symmetry '
                 'obstruction theorem. Verified via arXiv abstract 2026-04-25 '
                 '(corrected: prior bibkey "AntuschKingmanLindnerWetterich2003" '
                 'had hallucinated authors — actual authors are Antusch, '
                 'Kersten, Lindner, Ratz; journal-ref Nucl.Phys.B658:203-216 '
                 'confirmed).',
    },
    'AppelquistCarazzone1975': {
        'authors': 'Appelquist, T., Carazzone, J.',
        'title': 'Infrared singularities and massive fields',
        'journal': 'Phys. Rev. D',
        'volume': 11,
        'page': 2856,
        'year': 1975,
        'doi': '10.1103/PhysRevD.11.2856',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/AppelquistCarazzone1975.json',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex',
                    'lean/SKEFTHawking/MajoranaRungDecoupling.lean'],
        'provides': [],
        'notes': 'Original Appelquist-Carazzone decoupling theorem. Source '
                 'for Wave 2b WAVE2-OPEN-5 quantitative bound encoding via '
                 'DecouplingRegime + H_DecouplingBoundDim6. Verified via '
                 'CrossRef DOI lookup 2026-04-25 (page range 2856-2861).',
    },
    'BallThorne1994': {
        'authors': 'Ball, R. D., Thorne, R. S.',
        'title': 'The Decoupling Theorem in Effective Scalar Field Theory',
        'journal': 'Ann. Phys.',
        'volume': 241,
        'page': 368,
        'year': 1995,
        'doi': '10.48550/arXiv.hep-th/9404156',
        'arxiv': 'hep-th/9404156',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/BallThorne1994.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'Wilsonian-EFT rigorous proof of AC decoupling with '
                 'explicit (E/M)^k bounds. Cited as the post-2000 sharper '
                 'AC version that the Wave 2b decoupling encoding follows. '
                 'Verified via arXiv abstract 2026-04-25 (journal-ref '
                 'Ann.Phys.241:368-393, 1995; arXiv preprint April 1994).',
    },
    'GiudiceGrojeanPomarolRattazzi2007': {
        'authors': 'Giudice, G. F., Grojean, C., Pomarol, A., Rattazzi, R.',
        'title': 'The strongly-interacting light Higgs',
        'journal': 'JHEP',
        'volume': '06',
        'page': '045',
        'year': 2007,
        'doi': '10.1088/1126-6708/2007/06/045',
        'arxiv': 'hep-ph/0703164',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/GiudiceGrojeanPomarolRattazzi2007.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex',
                    'lean/SKEFTHawking/MajoranaRungDecoupling.lean'],
        'provides': [],
        'notes': 'SILH framework: source for naturalC = N_f / (16π²) '
                 'estimate adopted in MajoranaRungDecoupling.naturalC. '
                 'Verified via CrossRef DOI lookup 2026-04-25.',
    },
    'Hill2024Bilocal': {
        'authors': 'Hill, C. T.',
        'title': 'Bilocal Field Theory for Composite Scalar Bosons',
        'journal': 'Entropy',
        'volume': 26,
        'page': 146,
        'year': 2024,
        'doi': '10.3390/e26020146',
        'arxiv': '2310.14750',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/Hill2024Bilocal.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex',
                    'lean/SKEFTHawking/MajoranaRungDecoupling.lean'],
        'provides': [],
        'notes': 'Bilocal NJL form-factor analysis: source for the bound-'
                 'state coefficient form used in Wave 2b naturalC. Verifies '
                 'the SILH counting C ~ N_f / (16π²) for ADW-style four-'
                 'fermion substrates. Verified via CrossRef DOI lookup '
                 '2026-04-25; arXiv ID added 2026-04-25 from INSPIRE-HEP '
                 'after Stage-13 round flagged its omission.',
    },
    'CiriglianoMasterFormula2018': {
        'authors': 'Cirigliano, V., Dekens, W., de Vries, J., Graesser, M. L., Mereghetti, E.',
        'title': 'A neutrinoless double beta decay master formula from effective field theory',
        'journal': 'JHEP',
        'volume': '12',
        'page': '097',
        'year': 2018,
        'doi': '10.1007/JHEP12(2018)097',
        'arxiv': '1806.02780',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5z/primary-sources/CiriglianoMasterFormula2018.pdf',
        'used_in': ['papers/paper21_majorana_rung/paper_draft.tex'],
        'provides': [],
        'notes': 'SMEFT master formula for 0νββ: rigorous EFT chain LNV → '
                 'SMEFT → LEFT → χEFT → nuclear ME. Cited in Wave 2b '
                 'paper 21 §6 as the canonical reference for the '
                 'embedding-agnostic m_ββ phenomenology. Verified via '
                 'CrossRef DOI lookup 2026-04-25.',
    },

    # ════════════════════════════════════════════════════════════════
    # Phase 6a Wave 1 (Linearized EFE / induced gravity / classical GR)
    # ════════════════════════════════════════════════════════════════

    'Gilkey1995': {
        'authors': 'Gilkey, P. B.',
        'title': "Invariance Theory, the Heat Equation, and the Atiyah-Singer Index Theorem",
        'journal': 'CRC Press (book)',
        'volume': None,
        'page': None,
        'year': 1995,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'CRC Press 2nd ed., ISBN 978-0-8493-7874-4; the a_4 heat-kernel '
                         'coefficients are verified via Vassilevich 2003 §4 and broadly '
                         'across the heat-kernel literature.',
        'used_in': ['papers/paper39_heat_kernel_expansion/paper_draft.tex'],
        'provides': ['Christensen-Duff Dirac heat-kernel coefficients '
                     '(Theorem 4.8.16, Eq. 4.8.18) — primary mathematical '
                     'reference for the Wave 1 a_4 rationals'],
        'notes': '2nd ed., CRC Press, ISBN 978-0-8493-7874-4. Book reference '
                 '(no DOI / no arXiv); flagged as verified via the standard '
                 'mathematical reference cited by Vassilevich 2003 §4 and '
                 'broadly across the heat-kernel literature. The 1st edition '
                 '(Publish or Perish, 1984) is the same author + title; the '
                 '1995 CRC 2nd edition is the project reference.',
    },
    'LinearizedEFE2026': {
        'authors': 'Roehm, J. G.',
        'title': 'Linearized Einstein Equations from ADW Microscopic Theory',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/paper39_heat_kernel_expansion/paper_draft.tex',
                    'papers/paper42_nonlinear_efe/paper_draft.tex',
                    'papers/paper42b_cc_emergent/paper_draft.tex'],
        'provides': ['Phase 6a.1 LinearizedEFE.lean Lean formalization + '
                     'Sakharov-Adler match locus (companion of paper23, '
                     'in preparation 2026)'],
        'notes': 'In-preparation self-cite to companion paper23 '
                 '(`papers/paper23_linearized_efe/paper_draft.tex`). The '
                 '`LinearizedEFE` Lean module exists and is verified '
                 '(Phase 6a.1 SHIPPED 2026-04-25). Registry entry created '
                 'to satisfy Gate 1 CitationIntegrity binary criterion '
                 '(every cited bibkey must be in registry). Flag as '
                 '`year: 2026, journal: in preparation` until paper23 '
                 'is submitted and a journal venue is assigned. '
                 '`inprep: True` discriminator marks this entry as '
                 'exempt from primary-source-cache requirement.',
    },
    'DiffInvariance2026': {
        'authors': 'Roehm, J. G.',
        'title': 'Path-(b) order-by-order diffeomorphism invariance of '
                 'the Seeley-DeWitt heat-kernel effective action',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/paper42_nonlinear_efe/paper_draft.tex'],
        'provides': ['Phase 6e Wave 3 NonlinearDiffInvariance.lean Lean '
                     'formalization + Decision Gate E.3 PASS verdict '
                     '(companion of paper41, in preparation 2026)'],
        'notes': 'In-preparation self-cite to companion paper41 '
                 '(`papers/paper41_diff_invariance/paper_draft.tex`). The '
                 '`NonlinearDiffInvariance` Lean module exists and is '
                 'verified (Phase 6e Wave 3 SHIPPED 2026-04-28). Registry '
                 'entry created to satisfy Gate 1 CitationIntegrity binary '
                 'criterion. Flag as `year: 2026, journal: in preparation` '
                 'until paper41 is submitted and a journal venue is assigned. '
                 '`inprep: True` discriminator marks this entry as exempt '
                 'from primary-source-cache requirement.',
    },
    'BertiCardosoStarinets2009': {
        'authors': 'Berti, E., Cardoso, V., Starinets, A. O.',
        'title': 'Quasinormal modes of black holes and black branes',
        'journal': 'Class. Quantum Grav.',
        'volume': 26,
        'page': '163001',
        'year': 2009,
        'doi': '10.1088/0264-9381/26/16/163001',
        'arxiv': '0905.2975',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/BertiCardosoStarinets2009.pdf',
        'used_in': ['papers/paper42_nonlinear_efe/paper_draft.tex'],
        'provides': ['Schwarzschild fundamental ℓ=2 ringdown frequency '
                     'ω·GM/c³ = 0.3737 (Table III); QNM spectrum review'],
        'notes': 'Wave 4 ringdown-frequency GR baseline. Tracked-Prop notes '
                 'cite Table III value for ℓ=2 fundamental Schwarzschild '
                 'mode (Φ_R · GM/c³ = 0.3737).',
    },
    'Roehm2026Wave1': {
        'authors': 'Roehm, J. G.',
        'title': 'Formal heat-kernel calibration of induced Newton\'s constant '
                 'from the ADW Dirac substrate',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/paper41_diff_invariance/paper_draft.tex',
                    'papers/paper42_nonlinear_efe/paper_draft.tex',
                    'papers/paper42b_cc_emergent/paper_draft.tex'],
        'provides': ['Phase 6e Wave 1 HeatKernelExpansion.lean Lean '
                     'formalization + Sakharov-Adler calibration of induced '
                     'Newton constant via heat-kernel a_2 (companion of '
                     'paper39, in preparation 2026)'],
        'notes': 'In-preparation self-cite to companion paper39 '
                 '(`papers/paper39_heat_kernel_expansion/paper_draft.tex`). '
                 'The `HeatKernelExpansion` Lean module exists and is '
                 'verified (Phase 6e Wave 1 SHIPPED 2026-04-27). Registry '
                 'entry created to satisfy Gate 1 CitationIntegrity binary '
                 'criterion. Flag as `year: 2026, journal: in preparation` '
                 'until paper39 is submitted and a journal venue is assigned.',
    },
    'Roehm2026Wave4': {
        'authors': 'Roehm, J. G.',
        'title': 'Variational nonlinear Einstein field equations from '
                 'the ADW emergent-gravity programme',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/paper42b_cc_emergent/paper_draft.tex'],
        'provides': ['Phase 6e Wave 4 NonlinearEFE.lean Lean formalization '
                     '+ trace-level Decision-Gate-style biconditional '
                     '(efeResidualTrace = 0 iff α_ADW = 1) + multi-channel '
                     'PPN observable predictions (companion of paper42, in '
                     'preparation 2026)'],
        'notes': 'In-preparation self-cite to companion paper42 '
                 '(`papers/paper42_nonlinear_efe/paper_draft.tex`). The '
                 '`NonlinearEFE` Lean module exists and is verified '
                 '(Phase 6e Wave 4 SHIPPED 2026-04-28). Registry entry '
                 'created during Wave 5 to satisfy Gate 1 CitationIntegrity '
                 '+ close the deferred RECOMMENDED 8.1 from Wave 4 Stage 13 '
                 'review (per `project_phase6e_w4_shipped.md` memory). '
                 'Flag as `year: 2026, journal: in preparation` until '
                 'paper42 is submitted and a journal venue is assigned.',
    },
    'Roehm2026Wave5': {
        'authors': 'Roehm, J. G.',
        'title': 'Microscopic-to-macroscopic coefficient match for the ADW '
                 'emergent-gravity programme: a Lean-formalized Decision '
                 'Gate on the cosmological-constant problem',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/paper43_einstein_cartan/paper_draft.tex'],
        'provides': ['Phase 6e Wave 5 MicroscopicCoefficientMatch.lean Lean '
                     'formalization + closed-form `Λ^emerg = a_0(N_f)·Λ_UV⁴` '
                     '+ Decision-Gate-E.4 quantitative anchor + bundled '
                     '`H_MicroscopicCoefficientMatch` tracked Prop '
                     '(companion of paper42b, in preparation 2026)'],
        'notes': 'In-preparation self-cite to companion paper42b '
                 '(`papers/paper42b_cc_emergent/paper_draft.tex`). The '
                 '`MicroscopicCoefficientMatch` Lean module exists and is '
                 'verified (Phase 6e Wave 5 SHIPPED 2026-04-28). Registry '
                 'entry created during Wave 6 to satisfy Gate 1 '
                 'CitationIntegrity for paper43 references to the Wave-5 '
                 '`gNMicroscopic_eq_G_N_emerg_at_quarter_alpha` cross-bridge. '
                 'Flag as `year: 2026, journal: in preparation` until '
                 'paper42b is submitted and a journal venue is assigned.',
    },
    'Hehl1976': {
        'authors': 'Hehl, F. W., von der Heyde, P., Kerlick, G. D., Nester, '
                   'J. M.',
        'title': 'General relativity with spin and torsion: Foundations and '
                 'prospects',
        'journal': 'Rev. Mod. Phys.',
        'volume': 48,
        'page': '393',
        'year': 1976,
        'doi': '10.1103/RevModPhys.48.393',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Hehl1976.json',
        'used_in': ['papers/paper43_einstein_cartan/paper_draft.tex'],
        'provides': ['Einstein-Cartan formulation; algebraic Cartan torsion '
                     'equation T = G_N · S; canonical reference for '
                     'spin-current-sourced torsion in emergent-gravity '
                     'extensions.'],
        'notes': 'Canonical reference for the Hehl-Heyde-Kerlick-Nester '
                 'formulation of Einstein-Cartan theory. Used by paper43 §3 '
                 'to motivate the scalar torsion-amplitude prediction. '
                 'Primary-sources-cache rollout deferred to Phase 6i Wave 1.',
    },
    'Trautman1973': {
        'authors': 'Trautman, A.',
        'title': 'On the structure of the Einstein-Cartan equations',
        'journal': 'Symposia Mathematica (Istituto Nazionale di Alta '
                   'Matematica)',
        'volume': 12,
        'page': '139',
        'year': 1973,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Symposia Mathematica (1973), a pre-DOI volume; verified via '
                         'canonical Einstein-Cartan bibliographies (Hehl et al., Rev. '
                         'Mod. Phys. 48, 393 (1976) §I.B).',
        'used_in': ['papers/paper43_einstein_cartan/paper_draft.tex'],
        'provides': ['Trautman-form Einstein-Cartan equations; derivation of '
                     'spin-current-sourced torsion from variational principle.'],
        'notes': 'Trautman 1973 Symposia Mathematica. Pre-DOI volume; '
                 'verified via canonical EC-theory bibliographies (Hehl '
                 'et al RMP 48, 393 (1976), §I.B). Primary-sources-cache '
                 'rollout deferred to Phase 6i Wave 1.',
    },
    'KosteleckyRussellTasson2008': {
        'authors': 'Kostelecký, V. A., Russell, N., Tasson, J. D.',
        'title': 'New constraints on torsion from Lorentz-violation '
                 'searches',
        'journal': 'Phys. Rev. Lett.',
        'volume': 100,
        'page': '111102',
        'year': 2008,
        'doi': '10.1103/PhysRevLett.100.111102',
        'arxiv': '0712.4393',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/KosteleckyRussellTasson2008.pdf',
        'used_in': ['papers/paper43_einstein_cartan/paper_draft.tex'],
        'provides': ['Tightest published bound on cosmic-axial torsion '
                     'T < 10⁻³¹ GeV at 95% CL via SME (Standard Model '
                     'Extension) Lorentz-violation precision tests.'],
        'notes': 'Kostelecky-Russell-Tasson PRL 100, 111102 (2008). The '
                 'Wave 6 main correctness-push compares the microscopic '
                 'torsion-amplitude prediction at the cosmological '
                 'background against this bound. Primary-sources-cache '
                 'rollout deferred to Phase 6i Wave 1.',
    },
    'Lammerzahl2001': {
        'authors': 'Lämmerzahl, C.',
        'title': 'Constraints on space-time torsion from Hughes-Drever '
                 'experiments',
        'journal': 'Phys. Lett. A',
        'volume': 228,
        'page': '223',
        'year': 1997,
        'doi': '10.1016/S0375-9601(97)00127-8',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Lammerzahl2001.json',
        'used_in': ['papers/paper43_einstein_cartan/paper_draft.tex'],
        'provides': ['Hughes-Drever atomic-clock anisotropy bound on '
                     'rotational axial torsion T < 10⁻²⁹ GeV; cross-channel '
                     'comparator looser than Kostelecky.'],
        'notes': 'Lämmerzahl 1997 Phys. Lett. A 228, 223 (1997). Updates '
                 'the classical Hughes-Drever atomic-clock bound to modern '
                 'precision via a SME-style framework. The original 2001 '
                 'PRD attribution in the Wave 6 module docstring is the '
                 'updated review version; the load-bearing original is the '
                 '1997 PLA paper. Primary-sources-cache rollout deferred '
                 'to Phase 6i Wave 1.',
    },
    'Wald1984': {
        'authors': 'Wald, R. M.',
        'title': 'General Relativity',
        'journal': 'University of Chicago Press (book)',
        'volume': None,
        'page': None,
        'year': 1984,
        'doi': '10.7208/chicago/9780226870373.001.0001',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Wald1984.json',
        'used_in': ['papers/paper41_diff_invariance/paper_draft.tex',
                    'papers/paper42_nonlinear_efe/paper_draft.tex',
                    'papers/I1/paper_draft.tex'],
        'provides': ['Path-(b) diff-invariance framework via Lie '
                     'derivatives + total divergences (App. E.1); '
                     'canonical reference for general-relativistic '
                     'variational calculus; §4.2 variational EFE '
                     'derivation; §6.1 Schwarzschild Kretschmann scalar'],
        'notes': 'Book reference, ISBN 978-0-226-87033-5; primary '
                 'mathematical-relativity textbook. DOI 10.7208/chicago/'
                 '9780226870373.001.0001 resolves to U. Chicago Press '
                 'electronic edition. Wave 3 path-b framework grounded '
                 'in this reference.',
    },
    'HigherCurvature2026': {
        'authors': 'Roehm, J. G.',
        'title': 'Higher-curvature structure from the Dirac heat kernel: '
                 'microscopic predictions and observational ceilings',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/paper41_diff_invariance/paper_draft.tex',
                    'papers/paper42_nonlinear_efe/paper_draft.tex',
                    'papers/paper42b_cc_emergent/paper_draft.tex'],
        'provides': ['Phase 6e Wave 2 HigherCurvatureStructure.lean Lean '
                     'formalization + Stelle-basis change (companion of '
                     'paper40, in preparation 2026)'],
        'notes': 'In-preparation self-cite to companion paper40 '
                 '(`papers/paper40_higher_curvature/paper_draft.tex`). '
                 'The `HigherCurvatureStructure` Lean module exists and '
                 'is verified (Phase 6e Wave 2 SHIPPED 2026-04-30). '
                 'Registry entry created to satisfy Gate 1 '
                 'CitationIntegrity binary criterion. Flag as '
                 '`year: 2026, journal: in preparation` until paper40 '
                 'is submitted and a journal venue is assigned.',
    },
    'Vassilevich2003': {
        'authors': 'Vassilevich, D. V.',
        'title': "Heat kernel expansion: user's manual",
        'journal': 'Phys. Rep.',
        'volume': 388,
        'page': '279',
        'year': 2003,
        'doi': '10.1016/j.physrep.2003.09.002',
        'arxiv': 'hep-th/0306138',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Vassilevich2003.pdf',
        'used_in': ['papers/paper39_heat_kernel_expansion/paper_draft.tex',
                    'papers/paper40_higher_curvature/paper_draft.tex',
                    'papers/paper41_diff_invariance/paper_draft.tex',
                    'papers/paper42b_cc_emergent/paper_draft.tex'],
        'provides': ['Christensen-Duff Dirac a₀, a₂, a₄ coefficients '
                     '(Eqs. 4.37-4.42); heat-kernel asymptotic existence '
                     '(Theorem 4.1)'],
        'notes': 'Canonical heat-kernel reference. Underlies Wave 1 + Wave 2 '
                 'closed-form Christensen-Duff coefficients; Wave 3 path-(b) '
                 'diff-invariance check inherits the same coefficient bundle. '
                 'Full PDF cached in `Lit-Search/Phase-6e/primary-sources/` via '
                 'arXiv hep-th/0306138.',
    },
    'ChristensenDuff1979': {
        'authors': 'Christensen, S. M., and Duff, M. J.',
        'title': 'New gravitational index theorems and supertheorems',
        'journal': 'Nucl. Phys. B',
        'volume': 154,
        'page': '301',
        'year': 1979,
        'doi': '10.1016/0550-3213(79)90516-9',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/ChristensenDuff1979.abstract.txt',
        'used_in': ['papers/paper39_heat_kernel_expansion/paper_draft.tex',
                    'papers/paper40_higher_curvature/paper_draft.tex',
                    'papers/paper41_diff_invariance/paper_draft.tex'],
        'provides': ['Spin-1/2 Dirac a₄ rational coefficients '
                     '(Eq. 3.8)'],
        'notes': 'Original explicit a₄ for spin-1/2 Dirac fermion; pre-Vassilevich '
                 'review. Wave 3 path-(b) diff-invariance check inherits the same '
                 'coefficient bundle. Title spelling note: Crossref renders the '
                 'title with a space ("super theorems"); project bibliographies '
                 'follow the more common no-space convention ("supertheorems") '
                 'used in heat-kernel review literature (Vassilevich 2003, '
                 'Gilkey 1995). Both forms refer to the same DOI-resolved paper.',
    },
    'Stelle1977': {
        'authors': 'Stelle, K. S.',
        'title': 'Renormalization of higher-derivative quantum gravity',
        'journal': 'Phys. Rev. D',
        'volume': 16,
        'page': '953',
        'year': 1977,
        'doi': '10.1103/PhysRevD.16.953',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Stelle1977.abstract.txt',
        'used_in': ['papers/paper40_higher_curvature/paper_draft.tex',
                    'papers/paper41_diff_invariance/paper_draft.tex',
                    'papers/paper42b_cc_emergent/paper_draft.tex'],
        'provides': ['Renormalizable R + αR² + βC² truncation; canonical '
                     '{R², C²} basis with topological 𝒢 (Eq. 2.4)'],
        'notes': 'Canonical reference for the {R², C², 𝒢} basis used in '
                 'Wave 2 HigherCurvatureStructure.lean and inherited by Wave 3.',
    },
    'Lovelock1971': {
        'authors': 'Lovelock, D.',
        'title': 'The Einstein tensor and its generalizations',
        'journal': 'J. Math. Phys.',
        'volume': 12,
        'page': '498',
        'year': 1971,
        'doi': '10.1063/1.1665613',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Lovelock1971.abstract.txt',
        'used_in': ['papers/paper40_higher_curvature/paper_draft.tex'],
        'provides': ['Gauss-Bonnet density topological in 4D '
                     '(∫𝒢 = 32π² χ on closed 4-manifolds)'],
        'notes': 'Foundational reference for the topological '
                 'Gauss-Bonnet identity used in Wave 2.',
    },
    'CalmetCapozzielloPryer2017': {
        'authors': 'Calmet, X., Capozziello, S., and Pryer, D.',
        'title': 'Gravitational effective action at second order in curvature and gravitational waves',
        'journal': 'Eur. Phys. J. C',
        'volume': 77,
        'page': '589',
        'year': 2017,
        'doi': '10.1140/epjc/s10052-017-5172-3',
        'arxiv': '1708.08253',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/CalmetCapozzielloPryer2017.pdf',
        'used_in': ['papers/paper40_higher_curvature/paper_draft.tex'],
        'provides': ['EFT framework for translating short-range gravity + GW '
                     'observations into bounds on dimensionless higher-curvature '
                     'couplings α (R²) and β (C²) in the Stelle truncation'],
        'notes': 'Wave 2 correctness-push reference for the EFT translation '
                 'framework (not the individual experimental measurements). '
                 'Verified via Crossref API 2026-04-30: title + authors + EPJC '
                 '77:589 (2017) all match. Earlier draft of paper40 cited a '
                 'hallucinated 2019 reference (arXiv 1905.13728 was actually a '
                 'graph-NN paper by Hu et al); fixed during Stage 13 adversarial '
                 'review.',
    },
    'Berti2015': {
        'authors': 'Berti, E., et al.',
        'title': 'Testing general relativity with present and future astrophysical observations',
        'journal': 'Class. Quantum Grav.',
        'volume': 32,
        'page': '243001',
        'year': 2015,
        'doi': '10.1088/0264-9381/32/24/243001',
        'arxiv': '1501.07274',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Berti2015.pdf',
        'used_in': ['papers/paper40_higher_curvature/paper_draft.tex',
                    'papers/paper42_nonlinear_efe/paper_draft.tex'],
        'provides': ['Comprehensive review of GR tests including binary-pulsar '
                     'period-decay precision (Hulse-Taylor, Damour-Taylor 1991; '
                     'Weisberg-Huang 2016) and projected sensitivities for '
                     'future GW observations; ringdown frequency baseline '
                     '(Berti-Cardoso-Starinets review CQG 26:163001 (2009))'],
        'notes': 'Wave 2 correctness-push reference. Verified via Crossref API '
                 '2026-04-30: title + authors + CQG 32:243001 (2015) match. '
                 'Earlier draft of paper40 mis-cited venue as Living Rev. '
                 'Relativity 18:1; fixed during Stage 13 adversarial review.',
    },
    'Kapner2007': {
        'authors': 'Kapner, D. J., Adelberger, E. G., Heckel, B. R., Hoyle, C. D., '
                   'Schmidt, U., and Swanson, H. E.',
        'title': 'Tests of the Gravitational Inverse-Square Law below the '
                 'Dark-Energy Length Scale',
        'journal': 'Phys. Rev. Lett.',
        'volume': 98,
        'page': '021101',
        'year': 2007,
        'doi': '10.1103/PhysRevLett.98.021101',
        'arxiv': 'hep-ph/0611184',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Kapner2007.pdf',
        'used_in': ['papers/paper40_higher_curvature/paper_draft.tex'],
        'provides': ['Eöt-Wash 2007 inverse-square-law test at 56 µm; '
                     'Yukawa mediator bound m₀ ≳ 0.004 eV at 95% CL; '
                     'primary experimental anchor for HC_BOUND_SRG_R_SQ ≲ 10⁶¹ '
                     'via Calmet-Capozziello-Pryer 2017 EFT translation'],
        'notes': 'Eöt-Wash short-range gravity result establishing the SRG '
                 'ceiling on the Stelle α coefficient (R² coupling). Used in '
                 'paper40 §sec:bounds as one of four canonical observational '
                 'ceilings.',
    },
    'WeisbergHuang2016': {
        'authors': 'Weisberg, J. M. and Huang, Y.',
        'title': 'Relativistic Measurements from Timing the Binary Pulsar PSR B1913+16',
        'journal': 'Astrophys. J.',
        'volume': 829,
        'page': '55',
        'year': 2016,
        'doi': '10.3847/0004-637X/829/1/55',
        'arxiv': '1606.02744',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/WeisbergHuang2016.pdf',
        'used_in': ['papers/paper40_higher_curvature/paper_draft.tex'],
        'provides': ['Hulse-Taylor PSR B1913+16 period-decay measurement '
                     '(GR within ~0.1%); primary experimental anchor for '
                     'HC_BOUND_PULSAR_C_SQ ≲ 10⁵⁹ via Calmet-Capozziello-Pryer '
                     '2017 EFT translation; tightest of the four canonical '
                     'ceilings by ~3 orders of magnitude'],
        'notes': 'Latest precision update of the Hulse-Taylor binary-pulsar '
                 'timing analysis; supersedes Damour-Taylor 1991 for current '
                 'period-decay precision. Tightest HC_BOUND ceiling.',
    },
    'BertottiIessTortora2003': {
        'authors': 'Bertotti, B., Iess, L., and Tortora, P.',
        'title': 'A test of general relativity using radio links with the '
                 'Cassini spacecraft',
        'journal': 'Nature',
        'volume': 425,
        'page': '374',
        'year': 2003,
        'doi': '10.1038/nature01997',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/BertottiIessTortora2003.json',
        'used_in': ['papers/paper40_higher_curvature/paper_draft.tex'],
        'provides': ['Cassini Doppler-tracking measurement of the post-Newtonian '
                     '|γ_PPN − 1| ~ 2.1×10⁻⁵; primary experimental anchor for '
                     'HC_BOUND_CASSINI_C_SQ ≲ 10⁶² via Calmet-Capozziello-Pryer '
                     '2017 EFT translation'],
        'notes': 'Cassini conjunction Shapiro-delay test; the canonical '
                 'solar-system PPN bound on graviton-sector deviations. '
                 'Loose bound (~LIGO-comparable); contrasts with the '
                 'pulsar-tightness in paper40 §sec:bounds.',
    },
    'Sakharov1968': {
        'authors': 'Sakharov, A. D.',
        'title': 'Vacuum quantum fluctuations in curved space and the theory of gravitation',
        'journal': 'Sov. Phys. Dokl.',
        'volume': 12,
        'page': '1040',
        'year': 1968,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Sov. Phys. Dokl. 12, 1040 (1968), translated from Dokl. Akad. '
                         'Nauk SSSR 177, 70 — a pre-DOI Soviet publication, verified via '
                         'the induced-gravity literature.',
        'used_in': ['papers/paper23_linearized_efe/paper_draft.tex',
                    'papers/paper42b_cc_emergent/paper_draft.tex',
                    'papers/D3/paper_draft.tex'],
        'provides': ['Sakharov induced-gravity foundation (vacuum fluctuations in curved space generate the Einstein-Hilbert effective action via heat-kernel a_2 coefficient); foundational anchor for D3 §1, §21 emergent-gravity derivation.'],
        'notes': 'Pre-DOI (1968 Sov. Phys. Dokl. 12, 1040 — translated from Dokl. Akad. Nauk SSSR 177, 70); canonical-reference textbook exemption per Pipeline Invariant #11 (no DOI/arXiv/primary-source cache required for pre-DOI Soviet publications). Verified via secondary academic citations across the induced-gravity literature. Same exemption pattern as Trautman1973. Original induced-gravity reference: G_N from vacuum fluctuations, G_N⁻¹ ∝ Λ². Foundational anchor for the SK-EFT Hawking program.',
    },
    'Adler1982': {
        'authors': 'Adler, S. L.',
        'title': 'Einstein gravity as a symmetry-breaking effect in quantum field theory',
        'journal': 'Rev. Mod. Phys.',
        'volume': 54,
        'page': '729',
        'year': 1982,
        'doi': '10.1103/RevModPhys.54.729',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Adler1982.json',
        'used_in': ['papers/paper23_linearized_efe/paper_draft.tex',
                    'papers/paper42b_cc_emergent/paper_draft.tex'],
        'provides': ['Sakharov-Adler one-loop coefficient: G_N = 12π/(N_f Λ²) '
                     '(Eq. 3.3, hard-cutoff Dirac fermions)'],
        'notes': 'Canonical induced-gravity review. Sets the 12π normalization '
                 'used as the Sakharov-Adler reference value for the ADW α_ADW '
                 'coefficient.',
    },
    'Visser2002': {
        'authors': 'Visser, M.',
        'title': "Sakharov's induced gravity: a modern perspective",
        'journal': 'Mod. Phys. Lett. A',
        'volume': 17,
        'page': '977',
        'year': 2002,
        'doi': '10.1142/S0217732302007289',
        'arxiv': 'gr-qc/0204062',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Visser2002.pdf',
        'used_in': ['papers/paper23_linearized_efe/paper_draft.tex'],
        'provides': [],
        'notes': 'Modern review of Sakharov induced gravity. Emphasizes that the '
                 'numerical coefficient is regulator-dependent; only the existence '
                 'of a finite, sign-definite induced G_N is universal.',
    },
    'Carroll2004': {
        'authors': 'Carroll, S. M.',
        'title': 'Spacetime and Geometry: An Introduction to General Relativity',
        'journal': 'Pearson Addison-Wesley',
        'volume': '',
        'page': 'Ch. 6, 8',
        'year': 2004,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Standard graduate GR textbook; §6.1 linearized GR (de Donder '
                         'gauge) and §8.4 FLRW verified against the wider GR literature. '
                         'No cacheable full text.',
        'used_in': ['papers/paper23_linearized_efe/paper_draft.tex'],
        'provides': [],
        'notes': 'Standard graduate GR textbook. §6.1 linearized GR (h_μν, '
                 'de Donder gauge, linearized Einstein tensor). §8.4 FLRW '
                 'cosmology / Friedmann equations.',
    },
    'MTW1973': {
        'authors': 'Misner, C. W., Thorne, K. S., Wheeler, J. A.',
        'title': 'Gravitation',
        'journal': 'W. H. Freeman',
        'volume': '',
        'page': 'Ch. 35',
        'year': 1973,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': "Freeman, 'MTW'; Ch. 35 linearized gravity and the spin-2 wave "
                         'equation are verified across the standard GR literature. No '
                         'cacheable full text.',
        'used_in': ['papers/paper23_linearized_efe/paper_draft.tex'],
        'provides': [],
        'notes': 'Canonical GR textbook ("MTW"). Ch. 35 linearized gravity, '
                 'spin-2 wave equation, de Donder gauge.',
    },
    'Tiesinga2021CODATA': {
        'authors': 'Tiesinga, E., Mohr, P. J., Newell, D. B., Taylor, B. N.',
        'title': 'CODATA recommended values of the fundamental physical constants: 2018',
        'journal': 'Rev. Mod. Phys.',
        'volume': 93,
        'page': '025010',
        'year': 2021,
        'doi': '10.1103/RevModPhys.93.025010',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Tiesinga2021CODATA.json',
        'used_in': ['papers/paper23_linearized_efe/paper_draft.tex',
                    'src/core/provenance.py'],
        'provides': ['G_N = 6.67430(15) × 10⁻¹¹ m³ kg⁻¹ s⁻² '
                     '(GRAV.G_N_OBS_M3_KGM1_S2)',
                     'M_Planck = 1.220890 × 10¹⁹ GeV (GRAV.M_PLANCK_GEV)'],
        'notes': 'CODATA 2018 recommended values. Source for all fundamental '
                 'constants in the Phase 6a Wave 1 G_N comparison.',
    },
    'Akama1978': {
        'authors': 'Akama, K.',
        'title': 'An Attempt at Pregeometry',
        'journal': 'Prog. Theor. Phys.',
        'volume': 60,
        'page': '1900',
        'year': 1978,
        'doi': '10.1143/PTP.60.1900',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5d/primary-sources/Akama1978.json',
        'used_in': ['papers/paper5_adw_gap/paper_draft.tex',
                    'papers/paper23_linearized_efe/paper_draft.tex'],
        'provides': [],
        'notes': 'Original ADW reference: composite metric from fermion bilinear. '
                 'The "A" in ADW (Akama-Diakonov-Wetterich). Original tetrad '
                 'condensation idea.',
    },
    'HebeckerWetterich2003': {
        'authors': 'Hebecker, A., Wetterich, C.',
        'title': 'Spinor gravity',
        'journal': 'Phys. Lett. B',
        'volume': 574,
        'page': '269',
        'year': 2003,
        'doi': '10.1016/j.physletb.2003.09.010',
        'arxiv': 'hep-th/0307109',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/HebeckerWetterich2003.pdf',
        'used_in': ['papers/paper23_linearized_efe/paper_draft.tex'],
        'provides': [],
        'notes': 'Spinor-gravity continuum theory. Identifies new global-Lorentz '
                 'invariants (parameter τ); the absolute prefactor of R/(16πG_N) '
                 'is not extracted in closed form.',
    },
    'Wetterich2022': {
        'authors': 'Wetterich, C.',
        'title': 'Pregeometry and spontaneous time-space asymmetry',
        'journal': 'JHEP',
        'volume': '06',
        'page': '069',
        'year': 2022,
        'doi': '10.1007/JHEP06(2022)069',
        'arxiv': '2101.11519',
        'doi_verified': '2026-05-11',
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Wetterich2022.pdf',
        'used_in': ['papers/paper23_linearized_efe/paper_draft.tex'],
        'provides': [],
        'notes': 'Pregeometry / spontaneous time-space asymmetry formulation; '
                 'framework setup but no closed-form α_ADW.',
    },
    'Volovik2022Counting': {
        'authors': 'Volovik, G. E.',
        'title': 'Gravity from Symmetry Breaking Phase Transition',
        'journal': 'J. Low Temp. Phys.',
        'volume': 207,
        'page': '127--137',
        'year': 2022,
        'doi': '10.1007/s10909-022-02694-z',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Volovik2022Counting.abstract.txt',
        'used_in': ['papers/paper23_linearized_efe/paper_draft.tex'],
        'provides': [],
        'notes': 'NG-mode counting for ADW symmetry breaking: 16 tetrad components → '
                 '6 absorbed + 4 diffeo gauge + 2 graviton + 4 massive Higgs.',
    },
    'Volovik2024Vestigial': {
        'authors': 'Volovik, G. E.',
        'title': 'Fermionic quartet and vestigial gravity',
        'journal': 'JETP Letters',
        'volume': 119,
        'page': '330--334',
        'year': 2024,
        'doi': '10.1134/S002136402460006X',
        'arxiv': '2312.09435',
        'doi_verified': '2026-05-11',
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Volovik2024Vestigial.abstract.txt',
        'used_in': ['papers/paper23_linearized_efe/paper_draft.tex',
                    'papers/paper25_gravitational_waves/paper_draft.tex'],
        'provides': [],
        'notes': (
            'Vestigial gravity: Section III proposes metric order before a nonzero tetrad expectation. This'
            ' is not a derivation of the L1 susceptibility-dependent spin-2 speed law or second-sound '
            'identification. Historical correction 2026-08-14 (review:2026-08-14-l1-stage13:L1:1.1) '
            'recorded that this paper does not contain that identification; current L1 distinguishes the de'
            ' Sitter second-sound proposal in Volovik2026SecondSound from the thermodynamic framework in '
            'Volovik2024VacuumDecay. The fully-condensed versus vestigial distinction requires physical '
            'matching rather than being automatically irrelevant. Same paper as Volovik2024 '
            '(arXiv:2312.09435); duplicate keys remain for historical draft provenance and future '
            'consolidation.'
        ),
    },
    'Volovik2026SecondSound': {
        'authors': 'Volovik, G. E.',
        'title': 'Massless graviton in de Sitter as second sound in two-fluid hydrodynamics',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': '2601.00639',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path':
            'Lit-Search/Phase-1-and-Background/primary-sources/Volovik2026SecondSound.abstract.txt',
        'used_in': ['papers/L1/paper_draft.tex', 'papers/F/paper_draft.tex'],
        'provides': [],
        'notes': (
            'Registered 2026-08-14 to close historical review:2026-08-14-l1-stage13:L1:1.1, which '
            'identified the misattribution to Volovik2024Vestigial. Current source scope: '
            'arXiv:2601.00639v1 Section III Eqs. (6)-(9) gives s2=c within the de Sitter two-fluid model; '
            'Section IV discusses possible scalar/helicity interpretations and leaves the graviton type '
            'open. It supplies neither the assumed L1 law c_GW=c*sqrt(chi_vest) nor a microscopic spin-2 '
            'tensor/matter bridge; luminality of that source model does not establish GW170817 '
            'compatibility of an unmatched substrate. The original physical L1 BUILD remains open. ⚠️ TITLE'
            ' PROVENANCE: taken from the project corpus (Lit-Search/Phase-5y, two independent files quote '
            'it), NOT from a fresh Crossref/arXiv fetch. Needs fresh-fetch confirmation and a '
            'primary_source_path before any Stage-13 green that depends on this bibitem metadata.'
        ),
    },
    'Volovik2024VacuumDecay': {
        'authors': 'Volovik, G. E.',
        'title': 'From Landau two-fluid model to de Sitter Universe',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': '2410.04392',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path':
            'Lit-Search/Phase-1-and-Background/primary-sources/Volovik2024VacuumDecay.abstract.txt',
        'used_in': ['papers/L1/paper_draft.tex'],
        'provides': [],
        'notes': (
            'Registered 2026-08-14 alongside Volovik2026SecondSound to close historical '
            'review:2026-08-14-l1-stage13:L1:1.1. Current source scope: the held arXiv:2410.04392v11 '
            'thermodynamic framework has a gravitational normal component with stiff-matter equation of '
            'state w=1 (Section IV). Distinguish it from the separate 2026 second-sound paper and from the '
            'assumed L1 normalized susceptibility law; neither source supplies the required microscopic '
            'spin-2 tensor/matter matching. ⚠️ TITLE PROVENANCE: same caveat as `Volovik2026SecondSound` — '
            'corpus-sourced, not fresh-fetched.'
        ),
    },
    # ── The 2017 GW170817-constraint sweep ────────────────────────────────
    # Four back-to-back PRLs (251301-251304, 18 Dec 2017) that turned the c_GW
    # bound into eliminations of named modified-gravity classes. Added
    # 2026-08-09 for bundle L1, whose falsification claim a referee will
    # compare to this sweep and which previously cited none of it (TODO-D34).
    # All four verified against arXiv abstract pages the same day.
    'BakerBellini2017': {
        'authors': 'Baker, T., Bellini, E., Ferreira, P. G., Lagos, M., Noller, J., Sawicki, I.',
        'title': 'Strong constraints on cosmological gravity from GW170817 and GRB 170817A',
        'journal': 'Phys. Rev. Lett.',
        'volume': 119,
        'page': '251301',
        'year': 2017,
        'doi': '10.1103/PhysRevLett.119.251301',
        'arxiv': '1710.06394',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/BakerBellini2017.abstract.txt',
        'used_in': ['papers/L1/paper_draft.tex'],
        'provides': [
            'constraints on specified scalar-tensor and vector-tensor actions under the stated background and no-finely-tuned-cancellation assumptions',
            'conditional graviton-mass bound in bimetric gravity, assuming similar amplitudes of the two modes',
        ],
        'notes': (
            'Cited by L1 to delimit the 2017 sweep. Held arXiv:1710.06394v1 treats '
            'scalar-tensor/vector-tensor actions and a conditional bimetric mass bound; its Caveats '
            'distinguish present low-redshift propagation from other epochs and cosmological-background '
            'matching. These restrictions do not eliminate every theory in the named classes or derive the '
            'L1 scalar speed law.'
        ),
    },
    'CreminelliVernizzi2017': {
        'authors': 'Creminelli, P., Vernizzi, F.',
        'title': 'Dark Energy after GW170817 and GRB170817A',
        'journal': 'Phys. Rev. Lett.',
        'volume': 119,
        'page': '251302',
        'year': 2017,
        'doi': '10.1103/PhysRevLett.119.251302',
        'arxiv': '1710.05877',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/CreminelliVernizzi2017.abstract.txt',
        'used_in': ['papers/L1/paper_draft.tex'],
        'provides': [
            'no-tuning criterion requiring luminal GW propagation on nearby cosmological backgrounds, not only one chosen solution',
            'operator relations for the specified Horndeski, beyond-Horndeski and degenerate higher-order scalar-tensor settings',
        ],
        'notes': (
            'Supplies the nearby-background robustness criterion contrasted with the L1 adopted-window '
            'width comparison. Held full text is arXiv:1710.05877v3 (June 2018); its EFT and '
            'covariant-action sections impose relations under stated scalar/background assumptions. This '
            'summary does not establish that every v3 detail is unchanged from the 2017 published version '
            'or exclude all theories in the broad classes.'
        ),
    },
    'SaksteinJain2017': {
        'authors': 'Sakstein, J., Jain, B.',
        'title': 'Implications of the Neutron Star Merger GW170817 for '
                 'Cosmological Scalar-Tensor Theories',
        'journal': 'Phys. Rev. Lett.',
        'volume': 119,
        'page': '251303',
        'year': 2017,
        'doi': '10.1103/PhysRevLett.119.251303',
        'arxiv': '1710.05893',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/SaksteinJain2017.abstract.txt',
        'used_in': ['papers/L1/paper_draft.tex'],
        'provides': [
            'GW-speed bound combined with cluster and stellar tests to constrain beyond-Horndeski parameters',
            'separate GW plus M87 SEP constraints on the covariant quartic galileon for the considered order-unity matter couplings; disformal photon-coupling bound',
        ],
        'notes': (
            'Held arXiv:1710.05893v3 distinguishes the beyond-Horndeski parameter constraints using '
            'cluster/stellar data from the separate GW plus M87 black-hole combination. The latter makes '
            'the covariant quartic galileon cosmologically irrelevant for the representative order-unity '
            'matter couplings studied; it is not an unconditional exclusion of all galileon or '
            'scalar-tensor theories.'
        ),
    },
    'EzquiagaZumalacarregui2017': {
        'authors': 'Ezquiaga, J. M., Zumalacarregui, M.',
        'title': 'Dark Energy after GW170817: dead ends and the road ahead',
        'journal': 'Phys. Rev. Lett.',
        'volume': 119,
        'page': '251304',
        'year': 2017,
        'doi': '10.1103/PhysRevLett.119.251304',
        'arxiv': '1710.05901',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/EzquiagaZumalacarregui2017.abstract.txt',
        'used_in': ['papers/L1/paper_draft.tex'],
        'provides': [
            'constraints on GW-speed-modifying couplings in Einstein-aether, some Horava sectors and Generalized Proca; effects on TeVeS and MOND-like models',
            'adopted GW-speed bound |c_g/c - 1| <= 5e-16 in arXiv:1710.05901v2, distinct from the L1 conservative symmetric cap 3e-15',
        ],
        'notes': (
            'Held arXiv:1710.05901v2 constrains specified actions/couplings and discusses viable luminal '
            'alternatives and background-independent compensation. Its closing enumeration concerns '
            'affected sectors under physical model and matter-coupling assumptions, not every member of '
            'every named theory class. L1 assumes a scalar susceptibility law and does not infer '
            'microscopic operator coefficients from this comparison.'
        ),
    },
    'Abbott2017GW170817': {
        'authors': 'Abbott, B. P. et al. (LIGO+Virgo+EM partners)',
        'title': 'Gravitational Waves and Gamma-Rays from a Binary Neutron Star '
                 'Merger: GW170817 and GRB 170817A',
        'journal': 'Astrophys. J. Lett.',
        'volume': 848,
        'page': 'L13',
        'year': 2017,
        'doi': '10.3847/2041-8213/aa920c',
        'arxiv': '1710.05834',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Abbott2017GW170817.pdf',
        'used_in': ['papers/paper25_gravitational_waves/paper_draft.tex',
                    'papers/paper40_higher_curvature/paper_draft.tex'],
        'provides': [
            'asymmetric multimessenger speed bound -3e-15 <= Delta c/c <= +7e-16 under Section 4.1 distance/emission assumptions; the project adopts symmetric envelope |Delta c/c| <= 3e-15 (GW.C_GW_DEVIATION_UPPER_BOUND, GW.C_GW_DEVIATION_LOWER_BOUND, GW.C_GW_TWO_SIDED_CAP)',
            'primary experimental anchor for HC_BOUND_LIGO_C_SQ approximately <= 1e62 via the Calmet-Capozziello-Pryer 2017 EFT translation',
        ],
        'notes': (
            'Multimessenger ApJL 848, L13 (arXiv:1710.05834), distinct from the GW detection report PRL '
            '119, 161101. Section 4.1 derives its speed interval using a conservative distance and assumed '
            'emission window; alternative emission histories can weaken the constraint. In L1 the adopted '
            'symmetric cap restricts the assumed normalized scalar law to a finite interior interval within'
            ' adopted [0.1,10], including unity; it excludes the two adopted endpoints, not the entire '
            'range or Volovik framework. Original microscopic physical BUILD remains open. Also retained as'
            ' the Phase 6e Wave 2 input to the LIGO-derived Stelle beta ceiling in paper40; that separate '
            'EFT translation is not rederived here.'
        ),
    },
    'CrossleyGloriosoLiu2017': {
        'authors': 'Crossley, M. and Glorioso, P. and Liu, H.',
        'title': 'Effective field theory of dissipative fluids',
        'journal': 'JHEP',
        'volume': '09',
        'page': '095',
        'year': 2017,
        'doi': '10.1007/JHEP09(2017)095',
        'arxiv': '1511.03646',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/CrossleyGloriosoLiu2017.pdf',
        'used_in': ['papers/paper25_gravitational_waves/paper_draft.tex',
                    'papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex',
                    'papers/paper2_second_order/paper_draft.tex',
                    'papers/I1/paper_draft.tex'],
        'provides': ['SK-EFT dissipative-fluid framework (Γ_H, dynamical KMS), '
                     'foundation of the SecondOrderSK.lean Γ_H bridge; cited by '
                     'paper27 as constitutive-relations support for Glorioso-Liu '
                     'second law.'],
        'notes': 'Foundational reference for the SK-EFT dissipative-fluid '
                 'effective action. arXiv:1511.03646 verified 2026-04-26.',
    },
    # ──────────────────────────────────────────────────────────────────
    # Phase 6a Wave 3 bibkeys (BH entropy / MTC counting)
    # ──────────────────────────────────────────────────────────────────
    'KaulMajumdar2000': {
        'authors': 'Kaul, R. K. and Majumdar, P.',
        'title': 'Logarithmic Correction to the Bekenstein-Hawking Entropy',
        'journal': 'Phys. Rev. Lett.',
        'volume': 84,
        'page': '5255-5257',
        'year': 2000,
        'doi': '10.1103/PhysRevLett.84.5255',
        'arxiv': 'gr-qc/0002040',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/KaulMajumdar2000.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex',
                    'papers/D3/paper_draft.tex'],
        'provides': ['SU(2)_k Verlinde-formula derivation of S = A/(4G) − (3/2)logA + c0',
                     'I₀ − I₁ singlet-projection cancellation (Lean: '
                     'singletProjectionGivesExtraInverseHessian)'],
        'notes': 'Load-bearing for Wave 3 Kaul-Majumdar SU(2)_k specialization. '
                 'The −3/2 log coefficient is the structural physics result; the '
                 '1/4 prefactor is a γ tuning (`immirziTuning` hypothesis). '
                 'D3 §7 cites under bibkey "KaulMajumdar2000" (originally cited '
                 'as "KaulMajumdar1998" in early D3 first-pass; canonical -3/2 '
                 'log A coefficient is the 2000 PRL, not the 1998 PLB precursor; '
                 'bibkey corrected to KaulMajumdar2000 in 2026-05-04 D3 Stage-10 '
                 'r3 fix per commit 6c25ee0).',
    },
    'Kaul2012Review': {
        'authors': 'Kaul, R. K.',
        'title': 'Entropy of Quantum Black Holes',
        'journal': 'SIGMA',
        'volume': 8,
        'page': '005',
        'year': 2012,
        'doi': '10.3842/SIGMA.2012.005',
        'arxiv': '1201.6102',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Kaul2012Review.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['Detailed equations for the Kaul-Majumdar SU(2)_k saddle-point',
                     'Eq. (31) magnetic-quantum-number form of the Verlinde sum',
                     'Table 2: Domagala-Lewandowski + Meissner γ values'],
        'notes': 'Comprehensive review with all equations needed for the Wave 3 '
                 'closed-form sub-corollary. Cross-referenced with Kaul-Majumdar 2000.',
    },
    'DomagalaLewandowski2004': {
        'authors': 'Domagala, M. and Lewandowski, J.',
        'title': 'Black-hole entropy from quantum geometry',
        'journal': 'Class. Quantum Grav.',
        'volume': 21,
        'page': '5233-5244',
        'year': 2004,
        'doi': '10.1088/0264-9381/21/22/014',
        'arxiv': 'gr-qc/0407051',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/DomagalaLewandowski2004.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['Immirzi γ ≈ 0.2375 from one counting prescription'],
        'notes': 'Distinct counting from Meissner; same −3/2 log coefficient.',
    },
    'Meissner2004': {
        'authors': 'Meissner, K. A.',
        'title': 'Black-hole entropy in loop quantum gravity',
        'journal': 'Class. Quantum Grav.',
        'volume': 21,
        'page': '5245-5252',
        'year': 2004,
        'doi': '10.1088/0264-9381/21/22/015',
        'arxiv': 'gr-qc/0407052',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Meissner2004.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['Immirzi γ ≈ 0.2739 (Wave 3 default)'],
        'notes': 'Recent LQG default. Same −3/2 log coefficient as Domagala-Lewandowski.',
    },
    'EngleNouiPerez2010': {
        'authors': 'Engle, J. and Noui, K. and Perez, A.',
        'title': 'Black hole entropy and SU(2) Chern-Simons theory',
        'journal': 'Phys. Rev. Lett.',
        'volume': 105,
        'page': '031302',
        'year': 2010,
        'doi': '10.1103/PhysRevLett.105.031302',
        'arxiv': '0905.3168',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/EngleNouiPerez2010.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['Independent SU(2) intertwiner derivation of −3/2'],
        'notes': 'Reproduces Kaul-Majumdar coefficient via different counting.',
    },
    'Carlip2000HorizonCFT': {
        'authors': 'Carlip, S.',
        'title': 'Logarithmic corrections to black hole entropy from the Cardy formula',
        'journal': 'Class. Quantum Grav.',
        'volume': 17,
        'page': '4175-4186',
        'year': 2000,
        'doi': '10.1088/0264-9381/17/20/302',
        'arxiv': 'gr-qc/0005017',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Carlip2000HorizonCFT.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['Independent Cardy-CFT derivation of the −3/2 log coefficient',
                     'Universality argument within the single-CFT subfamily'],
        'notes': 'Establishes the Cardy-saddle subfamily as the universality class '
                 'where −3/2 holds. Cited for the universality-restriction discussion.',
    },
    'Sen2013Schwarzschild': {
        'authors': 'Sen, A.',
        'title': 'Logarithmic Corrections to Schwarzschild and Other Non-extremal '
                 'Black Hole Entropy in Different Dimensions',
        'journal': 'JHEP',
        'volume': '04',
        'page': 156,
        'year': 2013,
        'doi': '10.1007/JHEP04(2013)156',
        'arxiv': '1205.0971',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Sen2013Schwarzschild.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['Heat-kernel result for 4D Schwarzschild: c_log = +(212/45 − 3) ≈ +1.71',
                     'Explicit disagreement with the Cardy-saddle/Kaul-Majumdar −3/2'],
        'notes': 'Falsifiability anchor — establishes that −3/2 is NOT universal. '
                 'Wave 3 cites this as the witness against universal applicability.',
    },
    'Solodukhin2011LivingRev': {
        'authors': 'Solodukhin, S. N.',
        'title': 'Entanglement entropy of black holes',
        'journal': 'Living Rev. Relativity',
        'volume': 14,
        'page': 8,
        'year': 2011,
        'doi': '10.12942/lrr-2011-8',
        'arxiv': '1104.3712',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Solodukhin2011LivingRev.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['Entanglement-entropy origin of S_BH; renormalization of the '
                     '1/4 prefactor as a Sakharov-style induced-G_N condition'],
        'notes': 'Key reference for the Sakharov interpretation of the 1/4 leading '
                 'coefficient as a renormalization condition.',
    },
    # Note: WalkerWang2012 duplicate-key removed 2026-05-11 (D3 Stage-13 fix-pass).
    # The canonical entry is the verified-and-cached form below at line ~4599
    # which has the WebFetch-verified DOI + primary-source PDF cache. This
    # earlier block was silently shadowed by Python last-write-wins; metadata
    # consolidated into the surviving entry.
    'BombelliKoulLeeSorkin1986': {
        'authors': 'Bombelli, L. and Koul, R. K. and Lee, J. and Sorkin, R. D.',
        'title': 'Quantum source of entropy for black holes',
        'journal': 'Phys. Rev. D',
        'volume': 34,
        'page': 373,
        'year': 1986,
        'doi': '10.1103/PhysRevD.34.373',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/BombelliKoulLeeSorkin1986.json',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['Original entanglement-entropy origin of A/4G; UV cutoff ε '
                     'as the alternative tuning that fixes 1/4'],
        'notes': 'Foundational. Establishes 1/4 as a UV-cutoff tuning condition '
                 '(parallel to the Immirzi-γ tuning in Kaul-Majumdar).',
    },
    'JacobsonInducedGravity1994': {
        'authors': 'Jacobson, T.',
        'title': 'Black hole entropy and induced gravity',
        'journal': 'arXiv:gr-qc/9404039',
        'volume': '',
        'page': '',
        'year': 1994,
        'doi': None,
        'arxiv': 'gr-qc/9404039',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/JacobsonInducedGravity1994.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['Sakharov-induced-gravity interpretation of S_BH'],
        'notes': 'Connects 1/4 to the renormalized Newton constant — the bridge '
                 'used by Wave 3 to connect immirziTuning ↔ Wave 1 G_N^emerg.',
    },
    'KitaevHonest2006': {
        'authors': 'Kitaev, A.',
        'title': 'Anyons in an exactly solved model and beyond',
        'journal': 'Annals of Physics',
        'volume': 321,
        'page': '2-111',
        'year': 2006,
        'doi': '10.1016/j.aop.2005.10.005',
        'arxiv': 'cond-mat/0506438',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/KitaevHonest2006.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['Anyon-cell counting κ ∝ log d_max; Ising MTC chiral c_-'],
        'notes': 'Used in Wave 3 area-law leading coefficient ansatz.',
    },
    'Mitra2014LogVanish': {
        'authors': 'Mitra, P.',
        'title': 'Black hole entropy with and without log correction in loop quantum gravity',
        'journal': 'Nucl. Phys. B Proc. Suppl.',
        'volume': '251-252',
        'page': 87,
        'year': 2014,
        'doi': '10.1016/j.nuclphysbps.2014.04.016',
        'arxiv': '1406.5524',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Mitra2014LogVanish.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['Negative result: log correction can vanish in certain LQG counting'],
        'notes': 'Cited as a non-universality witness alongside Sen 2013. '
                 'Title and venue verified via arXiv.org fresh-fetch 2026-04-26 '
                 '(adversarial-review BLOCKER 1.2 fix).',
    },
    'McGoughVerlinde2013': {
        'authors': 'McGough, L. and Verlinde, H.',
        'title': 'Bekenstein-Hawking Entropy as Topological Entanglement Entropy',
        'journal': 'JHEP',
        'volume': '11',
        'page': 208,
        'year': 2013,
        'doi': '10.1007/JHEP11(2013)208',
        'arxiv': '1308.2342',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/McGoughVerlinde2013.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['Closest published MTC ↔ BH-entropy identification (BTZ via Virasoro)'],
        'notes': 'Cited in Wave 3 as the closest published precedent and as evidence '
                 'that the 4D + ADW + MTC synthesis remains unpublished.',
    },
    'GovindarajanKaulSuneeta2001': {
        'authors': 'Govindarajan, T. R. and Kaul, R. K. and Suneeta, V.',
        'title': 'Logarithmic correction to the Bekenstein-Hawking entropy of the BTZ black hole',
        'journal': 'Class. Quantum Grav.',
        'volume': 18,
        'page': '2877-2886',
        'year': 2001,
        'doi': '10.1088/0264-9381/18/15/303',
        'arxiv': 'gr-qc/0104010',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/GovindarajanKaulSuneeta2001.pdf',
        'used_in': ['papers/paper26_bh_entropy/paper_draft.tex'],
        'provides': ['BTZ −3/2 log correction via Cardy + Chern-Simons path integral'],
        'notes': 'Cited for cross-method −3/2 reproduction (BTZ in 2+1 D vs. '
                 'KaulMajumdar2000 in 3+1 D / SU(2)_k Verlinde). Title and venue '
                 'verified via arXiv.org fresh-fetch 2026-04-26 (adversarial-review '
                 'BLOCKER 1.1 fix; prior bibitem mistakenly named the dS₃ paper).',
    },
    # ──────────────────────────────────────────────────────────────────
    # Phase 6a Wave 5 bibkeys (BCH four laws + regime partition)
    # ──────────────────────────────────────────────────────────────────
    'JacobsonVolovik1998': {
        'authors': 'Jacobson, T. A. and Volovik, G. E.',
        'title': 'Event horizons and ergoregions in 3He',
        'journal': 'Phys. Rev. D',
        'volume': 58,
        'page': '064021',
        'year': 1998,
        'doi': '10.1103/PhysRevD.58.064021',
        'arxiv': 'cond-mat/9801308',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/JacobsonVolovik1998.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Planar soliton moving in bulk ³He-A, analogous to a charged '
                     'rotating black hole. Horizon exists ONLY for v > c_⊥ (§V: '
                     '"The horizons appear in the moving soliton if v > c_⊥"; '
                     'Eq. (5.2)). Eq. (5.7): κ = (v_F/d)(1 − v²/v_F²)·'
                     '√[(1 − c_⊥²/v²)/(1 − c_⊥²/v_F²)], so κ → 0 and hence '
                     'T_H = ℏκ/(2π k_B) → 0 as back-reaction slows the soliton '
                     'toward c_⊥ from above. §VIII: "The Hawking temperature is '
                     'fairly constant until, as v approaches c_⊥, T_H goes to zero. '
                     'This is unlike the evaporation of a neutral black hole which '
                     'gets hotter as it shrinks. It is rather like the Hawking '
                     'radiation from a black hole with a large magnetic charge which '
                     'cannot be discharged and so cools as it evaporates and '
                     'approaches an extremal black hole." COOLING branch, same sign '
                     'as Balbinot 2005.'],
        'notes': 'ATTRIBUTION CORRECTED 2026-08-15 (L3 Stage-10 redraft BLOCKER 1.1). '
                 'From 2026-04-26 until then this entry recorded the paper as a '
                 'HEATING contrast case whose §VIII prose was "inconsistent with the '
                 'same paper\'s own equations". Both halves were wrong: the prose '
                 'follows from Eq. (5.7), and the heating law '
                 'T_H(v) = T_H(0)(1 − v²/c_⊥²) belongs to the JacobsonKoike2002 '
                 'thin-film moving domain wall (v < c_⊥), a structurally different '
                 '³He-A system that had been swapped with this one. Re-verified '
                 'against the full arXiv TeX source '
                 '(JacobsonVolovik1998.source/EventHorIn3He13Unix.tex) and the '
                 'published PDF. NOTE: Balbinot 2005\'s own contrast \\bibitem'
                 '{jacobson} resolves to Jacobson-Volovik, JETP Lett. 68, 874 (1998) '
                 'plus Jacobson-Koike cond-mat/0205174, NOT to this PRD 58, 064021, '
                 'which is absent from Balbinot\'s reference list. TeX source '
                 'preserved at Lit-Search/Phase-6a/primary-sources/'
                 'JacobsonVolovik1998.source/.',
    },
    'JacobsonKoike2002': {
        'authors': 'Jacobson, T. A. and Koike, T.',
        'title': 'Black hole and baby universe in a thin film of 3He-A',
        'journal': 'in Artificial Black Holes (World Scientific)',
        'volume': '',
        'page': 'Chapter; Eq. (13)',
        'year': 2002,
        'doi': None,
        'arxiv': 'cond-mat/0205174',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/JacobsonKoike2002.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['THIN-FILM ³He-A moving domain wall, moving at v < c_⊥ with '
                     'horizons at c(x_h) = ±v: T_H(v) = T_H(0)·(1 − v²/c_⊥²), '
                     'T_H(0) = ℏc_⊥/(2πd) ~ 1 μK. dT_H/dv < 0 monotonically; '
                     'radiation slows v ⇒ T_H ↑ toward the NON-ZERO constant '
                     'T_H(0) ("the Hawking temperature approaches a nonzero '
                     'constant as v → 0"). THE heating contrast case to the '
                     'acoustic cooling branch, per Balbinot 2005\'s own contrast.'],
        'notes': 'Wave 5 contrast citation (post-2026-04-26 rewrite; re-verified '
                 '2026-08-15). Initial Wave 5 ship attributed acoustic cooling-'
                 'toward-extremality behavior to this paper, which actually '
                 'describes a different analog system with opposite (heating) '
                 'behavior; see Balbinot 2005 §"Fate of the acoustic black hole" for '
                 'the explicit contrast. This is the SOLE heating contrast case: '
                 'JacobsonVolovik1998 (PRD 58, 064021) is a bulk moving soliton on '
                 'the COOLING side and was wrongly grouped here until 2026-08-15. '
                 'TeX source preserved at Lit-Search/Phase-6a/primary-sources/'
                 'JacobsonKoike2002.source/bhbu.tex (the T_H equation carries '
                 '\\label{E:TH} in the source).',
    },
    'Balbinot2005PRD': {
        'authors': 'Balbinot, R. and Fagnocchi, S. and Fabbri, A.',
        'title': 'Quantum Effects in Acoustic Black Holes: the Backreaction',
        'journal': 'Phys. Rev. D',
        'volume': 71,
        'page': '064019',
        'year': 2005,
        'doi': '10.1103/PhysRevD.71.064019',
        'arxiv': 'gr-qc/0405098',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Balbinot2005PRD.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Eq. (Tsonic): T(t) = (ℏc/2π)·κ·[1 − (563/720π)·ε·κ³·c·A_0·t] '
                     '— linear-in-t cooling under Hawking backreaction for a SONIC '
                     'hole in a Laval nozzle, one-dimensional flow, at CONSTANT '
                     'sound speed c (§IV: "Let us further assume the sound velocity '
                     'c constant"). Asymptotic extrapolation t ~ 1/T³ ⇒ T → 0 '
                     'at infinite time (analog of near-extremal RN). Explicit '
                     'contrast statement: "other analog models like a thin film of '
                     '³He-A with a moving domain wall [Jacobson] seem to show a '
                     'non-vanishing end-temperature of the evaporation process." '
                     'PRIMARY ANCHOR for the acoustic cooling regime in Wave 5.'],
        'notes': 'Wave 5 primary anchor (post-2026-04-26 rewrite). Mirrors '
                 'src/wkb/backreaction.py exponential-decay leading-order form. '
                 'SCOPE CORRECTED 2026-08-15 (L3 Stage-10 redraft BLOCKER 1.2): this '
                 'is NOT a Bose-Einstein-condensate result, and was carried under a '
                 'condensate-prefixed acoustic label across the substrate until '
                 'then. The authors '
                 'explicitly defer the condensate case: "In a similar way one can '
                 'treat sonic black holes formed by a Bose-Einstein condensate '
                 '[garayvisser]. The major difference comes from the fact that the '
                 'sound velocity c is not constant, but proportional to ρ^(1/2). '
                 'This will be discussed elsewhere." A condensate substrate inherits '
                 'this branch by the SIGN of dT_H/dt, not by Eq. (Tsonic). TeX '
                 'source preserved at Lit-Search/Phase-6a/primary-sources/'
                 'Balbinot2005PRD.source/acusticpap.tex.',
    },
    'Hawking1975CMP': {
        'authors': 'Hawking, S. W.',
        'title': 'Particle creation by black holes',
        'journal': 'Commun. Math. Phys.',
        'volume': 43,
        'page': '199-220',
        'year': 1975,
        'doi': '10.1007/BF02345020',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Hawking1975CMP.json',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Original derivation of Hawking radiation. T_H = ℏ/(8π M) for '
                     'Schwarzschild; finite evaporation time t_evap ~ M³; during '
                     'evaporation dM/dt < 0 combined with dT_H/dM < 0 gives '
                     'dT_H/dt > 0 (heats as evaporates). PRIMARY ANCHOR for the '
                     'Schwarzschild heating regime in Wave 5.'],
        'notes': 'Wave 5 primary anchor for the Schwarzschild branch. CMP DOI '
                 '10.1007/BF02345020 verified.',
    },
    'Volovik2003BraneBH': {
        'authors': 'Volovik, G. E.',
        'title': 'What can the quantum liquid say on the brane black hole, the '
                 'entropy of extremal black hole and the vacuum energy?',
        'journal': 'Found. Phys.',
        'volume': 33,
        'page': '349-368',
        'year': 2003,
        'doi': '10.1023/A:1023775711831',
        'arxiv': 'gr-qc/0301043',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Volovik2003BraneBH.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Horizon fermion zero-mode statistical counting of '
                     'near-extremal analog BH entropy'],
        'notes': 'Wave 5 fermion-zero-mode mechanism support. **Citation correction**: '
                 'Wave 5 deep-research brief originally listed arXiv ID gr-qc/0210034 '
                 'which points to an unrelated paper; the correct ID is gr-qc/0301043 '
                 '(verified via arXiv fresh-fetch 2026-04-26).',
    },
    'KehleUnger2022ThirdLaw': {
        'authors': 'Kehle, C. and Unger, R.',
        'title': 'Gravitational collapse to extremal black holes and the third law '
                 'of black hole thermodynamics',
        'journal': 'J. Eur. Math. Soc.',
        'volume': '(in press)',
        'page': '',
        'year': 2025,
        'doi': '10.4171/JEMS/1591',
        'arxiv': '2211.15742',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/KehleUnger2022ThirdLaw.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Definitive disproof of Israel strong-form third law: '
                     'one-ended Cauchy data forming exactly extremal Reissner-Nordström '
                     'BH in finite advanced time, arbitrarily high regularity'],
        'notes': 'Wave 5 third-law-disproof anchor. Replaces the brief\'s spurious '
                 '"Wall, PRD 100, 044002 (2019)" citation (DOI is Cardoso et al. on '
                 'BH binaries, not a Wall third-law paper). Verified arXiv 2026-04-26.',
    },
    'Reall2024ThirdLawBPS': {
        'authors': 'Reall, H. S.',
        'title': 'A third law of black hole mechanics for supersymmetric black holes '
                 'and a quasi-local mass-charge inequality',
        'journal': 'Phys. Rev. D',
        'volume': 110,
        'page': '124059',
        'year': 2024,
        'doi': '10.1103/PhysRevD.110.124059',
        'arxiv': '2410.11956',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Reall2024ThirdLawBPS.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['BPS local mass-charge restoration of the third law: '
                     'matter satisfying T_{ab} k^a k^b ≥ |J^a k_a| forbids '
                     'finite-time formation of extremal RN'],
        'notes': 'Wave 5 third-law-restoration condition (under BPS hypothesis). '
                 'Verified via arXiv 2026-04-26.',
    },
    'GloriosoCrossleyLiu2017': {
        'authors': 'Glorioso, P. and Crossley, M. and Liu, H.',
        'title': 'Effective field theory for dissipative fluids (II): classical limit, '
                 'dynamical KMS symmetry and entropy current',
        'journal': 'JHEP',
        'volume': '09',
        'page': '096',
        'year': 2017,
        'doi': '10.1007/JHEP09(2017)096',
        'arxiv': '1701.07817',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/GloriosoCrossleyLiu2017.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex',
                    'papers/I1/paper_draft.tex'],
        'provides': ['Constitutive relations for the SK-EFT entropy current via '
                     'dynamical KMS Z₂ symmetry; Eq. 6.34'],
        'notes': 'Wave 5 ADWSecondLaw constitutive-relation source.',
    },
    # ──────────────────────────────────────────────────────────────────
    # Phase 6n.γ I1 reframing bibitems (added 2026-05-06 unified
    # absorption pass; D.3 GATE 1)
    # ──────────────────────────────────────────────────────────────────
    'GloriosoLiu2018TASI': {
        'authors': 'Glorioso, P. and Liu, H.',
        'title': 'Lectures on non-equilibrium effective field theories and '
                 'fluctuating hydrodynamics',
        'journal': 'PoS',
        'volume': 'TASI2017',
        'page': '008',
        'year': 2018,
        'doi': '10.22323/1.305.0008',
        'arxiv': '1805.09331',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/GloriosoLiu2018TASI.pdf',
        'used_in': ['papers/I1/paper_draft.tex'],
        'provides': ['Pedagogical exposition of the Glorioso-Liu / CGL / CGL II '
                     'axiomatic for non-equilibrium effective field theories: '
                     'CTP doubled-contour structure, dynamical KMS Z₂ symmetry, '
                     'local equilibrium, and the proof of the local second law. '
                     'Cited as the pedagogical anchor in I1 §3 reframing.'],
        'notes': 'Phase 6n.γ I1 reframing: Section §IV proves ∂_μ J^μ_S ≥ 0 '
                 'from Z₂ symmetry + classical-limit unitarity remnant + local '
                 'equilibrium. Pedagogical version of the Glorioso-Liu 2017 '
                 'second-law preprint (arXiv:1612.07705). PoS TASI2017 (2018) '
                 '008. arXiv:1805.09331 verified 2026-05-06.',
    },
    'Niemeier1973': {
        'authors': 'Niemeier, H.-V.',
        'title': 'Definite quadratische Formen der Dimension 24 und '
                 'Diskriminante 1',
        'journal': 'J. Number Theory',
        'volume': 5,
        'page': '142',
        'year': 1973,
        'doi': '10.1016/0022-314X(73)90068-1',
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D2/paper_draft.tex',
                    'papers/L2/paper_draft.tex'],
        'provides': ['Niemeier classification of the 24 even self-dual '
                     'positive-definite unimodular lattices in dimension '
                     '24. Algebraic spine of the c=24 holomorphic-VOA '
                     'classification chain. Cited in D2 §2.7 (Schellekens '
                     'chain) and L2 conclusion.'],
        'notes': 'Pre-DOI / pre-arXiv mathematical paper (1973); textbook-'
                 'tier reference verified via secondary citations + '
                 'WebSearch 2026-05-06. Per Pipeline Invariant #11 textbook '
                 'exemption, primary_source_path = None is allowed since '
                 'no arXiv preprint exists.',
    },
    'Schellekens1993': {
        'authors': 'Schellekens, A. N.',
        'title': 'Meromorphic c=24 conformal field theories',
        'journal': 'Commun. Math. Phys.',
        'volume': 153,
        'page': '159',
        'year': 1993,
        'doi': '10.1007/BF02099044',
        'arxiv': 'hep-th/9205072',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Schellekens1993.pdf',
        'used_in': ['papers/D2/paper_draft.tex',
                    'papers/L2/paper_draft.tex'],
        'provides': ['Schellekens 1993 enumeration of 71 meromorphic c=24 '
                     'conformal field theories from modular-invariant '
                     'Kac-Moody combinations. Cited as the classical '
                     'enumeration step in D2 §2.7 (Schellekens chain) and '
                     'L2 conclusion as the 5-step holomorphic-VOA chain '
                     'classifier preceding Möller-Scheithauer 2024.'],
        'notes': 'Phase 6o.ε D2/L2 reframing: foundational c=24 CFT '
                 'classification reference. Comm. Math. Phys. 153, 159 '
                 '(1993). arXiv:hep-th/9205072 verified 2026-05-06. '
                 'Primary-source cache fetch deferred.',
    },
    'MollerScheithauer2024': {
        'authors': 'Möller, S. and Scheithauer, N. R.',
        'title': 'A geometric classification of the holomorphic vertex '
                 'operator algebras of central charge 24',
        'journal': 'Algebra & Number Theory',
        'volume': 18,
        'page': '1891',
        'year': 2024,
        'doi': '10.2140/ant.2024.18.1891',
        'arxiv': '2112.12291',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/MollerScheithauer2024.pdf',
        'used_in': ['papers/D2/paper_draft.tex',
                    'papers/L2/paper_draft.tex'],
        'provides': ['Möller-Scheithauer 2024 geometric classification of '
                     'strongly-rational holomorphic vertex operator '
                     'algebras of central charge 24 with non-trivial '
                     'weight-1 space (70 algebras). Cited in D2 §2.7 + L2 '
                     'as the recent published completion of the Schellekens '
                     '1993 classification chain (the strongly-rational '
                     'subset; the moonshine VOA at trivial weight-1 lies '
                     'outside their scope and is documented as a '
                     'not-applicable witness in D2 §2.7).'],
        'notes': 'Phase 6o.ε D2/L2 reframing: per Modular Bootstrap DR §8 '
                 'Tier 1(a) "the highest-leverage move" — bypasses '
                 'numerical bootstrap entirely; ties to existing Phase 5o '
                 'W5 lean-tensor-categories + Phase 6n W1b WittClass '
                 'infrastructure. Algebra & Number Theory 18, 1891 (2024); '
                 'arXiv:2112.12291 verified 2026-05-06 (note: covers only '
                 'the weight-1-non-trivial subset; does not complete the '
                 'full c=24 classification — the moonshine FLM VOA with '
                 'trivial weight-1 space is outside scope).',
    },
    'Crooks1999': {
        'authors': 'Crooks, G. E.',
        'title': 'Entropy production fluctuation theorem and the '
                 'nonequilibrium work relation for free energy differences',
        'journal': 'Phys. Rev. E',
        'volume': 60,
        'page': '2721',
        'year': 1999,
        'doi': '10.1103/PhysRevE.60.2721',
        'arxiv': 'cond-mat/9901352',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Crooks1999.pdf',
        'used_in': ['papers/D3/paper_draft.tex',
                    'papers/L3/paper_draft.tex'],
        'provides': ['Crooks fluctuation theorem: '
                     'P_F[γ] / P_R[γ̄] = exp(σ[γ]) for stochastic, '
                     'microscopically reversible dynamics. Cited in '
                     'D3 §17.5 + L3 "Substrate-class context" as the '
                     'horizon-Crooks form specialized to local Rindler '
                     'horizon physics.'],
        'notes': 'Phase 6n.ζ D3 + L3 reframing: canonical reference for '
                 'the Crooks fluctuation theorem statement. Phys. Rev. E '
                 '60, 2721 (1999); arXiv:cond-mat/9901352 verified '
                 '2026-05-06.',
    },
    'JainKovtun2024': {
        'authors': 'Jain, A. and Kovtun, P.',
        'title': 'Schwinger-Keldysh effective field theory for stable and '
                 'causal relativistic hydrodynamics',
        'journal': 'JHEP',
        'volume': '01',
        'page': '162',
        'year': 2024,
        'doi': '10.1007/JHEP01(2024)162',
        'arxiv': '2309.00511',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/JainKovtun2024.pdf',
        'used_in': ['papers/I1/paper_draft.tex'],
        'provides': ['UV-realization ambiguity in dynamical KMS symmetry: '
                     '"Since these EFTs typically admit ultraviolet sectors '
                     'that are not fixed by the low-energy infrared symmetries, '
                     'we find that they simultaneously admit multiple '
                     'realisations of the dynamical KMS symmetry." Cited in I1 '
                     '§3 to scope the typeclass-level encoding of the '
                     'UV-realization ambiguity in the program\'s SKEFTAxioms.'],
        'notes': 'Phase 6n.γ I1 reframing: cited for the typeclass discipline '
                 'in encoding dynamical KMS realizations. JHEP 01 (2024) 162. '
                 'arXiv:2309.00511 verified 2026-05-06.',
    },
    'WallGSL2012': {
        'authors': 'Wall, A. C.',
        'title': 'A proof of the generalized second law for rapidly changing fields '
                 'and arbitrary horizon slices',
        'journal': 'Phys. Rev. D',
        'volume': 85,
        'page': '104049',
        'year': 2012,
        'doi': '10.1103/PhysRevD.85.104049',
        'arxiv': '1105.3445',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/WallGSL2012.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['GSL proof via relative-entropy monotonicity for arbitrary '
                     'horizon slices; foundational for the algebraic GSL'],
        'notes': 'Wave 5 GSL anchor.',
    },
    'BoussoFisherLeichenauerWall2016': {
        'authors': 'Bousso, R. and Fisher, Z. and Leichenauer, S. and Wall, A. C.',
        'title': 'A Quantum Focussing Conjecture',
        'journal': 'Phys. Rev. D',
        'volume': 93,
        'page': '064044',
        'year': 2016,
        'doi': '10.1103/PhysRevD.93.064044',
        'arxiv': '1506.02669',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/BoussoFisherLeichenauerWall2016.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Quantum Focussing Conjecture (QFC) → Quantum Null Energy '
                     'Condition (QNEC) → local GSL (semiclassical regime)'],
        'notes': 'Wave 5 QNEC anchor.',
    },
    'HartmanKunduTajdini2017': {
        'authors': 'Hartman, T. and Kundu, S. and Tajdini, A.',
        'title': 'Averaged Null Energy Condition from Causality',
        'journal': 'JHEP',
        'volume': '07',
        'page': '066',
        'year': 2017,
        'doi': '10.1007/JHEP07(2017)066',
        'arxiv': '1610.05308',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/HartmanKunduTajdini2017.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['ANEC ∫⟨T_kk⟩dλ ≥ 0 from microcausality (commutators '
                     'vanishing at spacelike separation)'],
        'notes': 'Wave 5 ANEC anchor; supplies topological-censorship + '
                 'achronal area-non-decrease.',
    },
    'FaulknerSperanza2024': {
        'authors': 'Faulkner, T. and Speranza, A. J.',
        'title': 'Gravitational algebras and the generalized second law',
        'journal': 'JHEP',
        'volume': '11',
        'page': '099',
        'year': 2024,
        'doi': '10.1007/JHEP11(2024)099',
        'arxiv': '2405.00847',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/FaulknerSperanza2024.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['GSL derivation via type-II crossed-product algebras of '
                     'observables; semiclassical limit reproduces generalized entropy'],
        'notes': 'Wave 5 algebraic-GSL anchor.',
    },
    'Kirklin2024GSLAllOrders': {
        'authors': 'Kirklin, J.',
        'title': 'Generalised second law beyond the semiclassical regime',
        'journal': 'JHEP',
        'volume': '07',
        'page': '192',
        'year': 2025,
        'doi': '10.1007/JHEP07(2025)192',
        'arxiv': '2412.01903',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Kirklin2024GSLAllOrders.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['GSL extended to all orders in perturbative gravity '
                     'via algebraic methods + null-translation invariance'],
        'notes': 'Wave 5: deep-research-brief attribution to "Belin et al" '
                 'corrected via arXiv fresh-fetch 2026-04-26 — actual single '
                 'author is Josh Kirklin. **Citation-hallucination flag** '
                 'logged per `feedback_citation_verification_required.md`.',
    },
    'WallSurvey2018': {
        'authors': 'Wall, A. C.',
        'title': 'A Survey of Black Hole Thermodynamics',
        'journal': 'arXiv:1804.10610',
        'volume': '',
        'page': '',
        'year': 2018,
        'doi': None,
        'arxiv': '1804.10610',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/WallSurvey2018.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Pedagogical survey of the four laws of BH thermodynamics + '
                     'horizon-definition variants + entropy correction status'],
        'notes': 'Wave 5: replaces the brief\'s spurious "Wall, PRD 100, 044002 (2019)" '
                 'citation. Verified via arXiv 2026-04-26.',
    },
    'KubiznakMann2012PV': {
        'authors': 'Kubizňák, D. and Mann, R. B.',
        'title': 'P-V criticality of charged AdS black holes',
        'journal': 'JHEP',
        'volume': '07',
        'page': '033',
        'year': 2012,
        'doi': '10.1007/JHEP07(2012)033',
        'arxiv': '1205.0559',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/KubiznakMann2012PV.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Universal vdW ratio P_c v_c / T_c = 3/8 for charged AdS BHs; '
                     'enthalpic-extension first law M ↔ enthalpy, Λ ↔ pressure'],
        'notes': 'Wave 5: structural precedent for substrate-pressure first-law '
                 'correction (alternative branch of H_RegimePartition).',
    },
    'Witten1998AdSThermal': {
        'authors': 'Witten, E.',
        'title': 'Anti-de Sitter Space, Thermal Phase Transition, And Confinement '
                 'In Gauge Theories',
        'journal': 'Adv. Theor. Math. Phys.',
        'volume': 2,
        'page': '505-532',
        'year': 1998,
        'doi': '10.4310/ATMP.1998.v2.n3.a3',
        'arxiv': 'hep-th/9803131',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Witten1998AdSThermal.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Hawking-Page transition r_+ = l, T_HP = 1/(πl); '
                     'small-BH/large-BH fold; gauge-theory confinement dual'],
        'notes': 'Wave 5: AdS-extension first-order transition (Branch C of §4).',
    },
    'HawkingHorowitzRoss1995': {
        'authors': 'Hawking, S. W. and Horowitz, G. T. and Ross, S. F.',
        'title': 'Entropy, Area, and Black Hole Pairs',
        'journal': 'Phys. Rev. D',
        'volume': 51,
        'page': '4302-4314',
        'year': 1995,
        'doi': '10.1103/PhysRevD.51.4302',
        'arxiv': 'gr-qc/9409013',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/HawkingHorowitzRoss1995.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Extremal RN has S = 0 by Euler-character argument; '
                     'extremal/non-extremal qualitatively distinct; '
                     'strong Nernst preserved'],
        'notes': 'Wave 5 weak/strong-Nernst dichotomy anchor.',
    },
    'Sen2008EntropyFunction': {
        'authors': 'Sen, A.',
        'title': 'Entropy Function and AdS(2)/CFT(1) Correspondence',
        'journal': 'JHEP',
        'volume': '11',
        'page': '075',
        'year': 2008,
        'doi': '10.1088/1126-6708/2008/11/075',
        'arxiv': '0805.0095',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Sen2008EntropyFunction.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Wald entropy of extremal BH = log of ground-state degeneracy '
                     'of AdS₂ boundary 1D quantum mechanics; attractor mechanism '
                     'independent of Nernst question'],
        'notes': 'Wave 5: Strominger-Vafa-side-of-Nernst anchor.',
    },
    'BhattacharyaShankaranarayanan2017': {
        'authors': 'Bhattacharya, S. and Shankaranarayanan, S.',
        'title': 'Negative specific heat of black-holes from Fluid-Gravity Correspondence',
        'journal': 'Class. Quantum Grav.',
        'volume': 34,
        'page': '015009',
        'year': 2017,
        'doi': '10.1088/0264-9381/34/1/015009',
        'arxiv': '1702.03682',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/BhattacharyaShankaranarayanan2017.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['C-sign change between asymptotic-flat (C < 0) and '
                     'Kerr-Newman/AdS (C > 0) regimes via horizon-fluid linear response'],
        'notes': 'Wave 5: structural analog for the regime-partition C-sign-flip.',
    },
    'BrownIliesiuPeningtonUsatyuk2024': {
        'authors': 'Brown, A. R. and Iliesiu, L. V. and Penington, G. and Usatyuk, M.',
        'title': 'The evaporation of charged black holes',
        'journal': 'arXiv:2411.03447',
        'volume': '',
        'page': '',
        'year': 2024,
        'doi': None,
        'arxiv': '2411.03447',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/BrownIliesiuPeningtonUsatyuk2024.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['JT/Schwarzian-corrected near-extremal BH evaporation; '
                     'explicit quantum mass gap; entangled-photon-pair emission'],
        'notes': 'Wave 5: near-extremal-evaporation precedent supporting the '
                 'first-law correction at the regime boundary.',
    },
    'Padmanabhan2010Equipartition': {
        'authors': 'Padmanabhan, T.',
        'title': 'Equipartition of energy in the horizon degrees of freedom and '
                 'the emergence of gravity',
        'journal': 'Mod. Phys. Lett. A',
        'volume': 25,
        'page': '1129-1136',
        'year': 2010,
        'doi': '10.1142/S0217732310033554',
        'arxiv': '0912.3165',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Padmanabhan2010Equipartition.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Horizon-DOF equipartition first law E = ½ N k_B T with '
                     'N = ΔA/L_P²'],
        'notes': 'Wave 5: emergent-gravity first-law structural precedent.',
    },
    'Verlinde2011Entropic': {
        'authors': 'Verlinde, E. P.',
        'title': 'On the Origin of Gravity and the Laws of Newton',
        'journal': 'JHEP',
        'volume': '04',
        'page': '029',
        'year': 2011,
        'doi': '10.1007/JHEP04(2011)029',
        'arxiv': '1001.0785',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Verlinde2011Entropic.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Newtonian gravity as an entropic force from holographic '
                     'screen entropy gradients'],
        'notes': 'Wave 5: emergent-gravity precedent for thermodynamics-driven '
                 'gravitational dynamics.',
    },
    'JacobsonEFE1995': {
        'authors': 'Jacobson, T.',
        'title': 'Thermodynamics of Spacetime: The Einstein Equation of State',
        'journal': 'Phys. Rev. Lett.',
        'volume': 75,
        'page': '1260-1263',
        'year': 1995,
        'doi': '10.1103/PhysRevLett.75.1260',
        'arxiv': 'gr-qc/9504004',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/JacobsonEFE1995.pdf',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Einstein equations derived from Clausius relation '
                     'TdS = δQ at every local Rindler horizon'],
        'notes': 'Wave 5: emergent-gravity foundational precedent.',
    },
    'Davies1977': {
        'authors': 'Davies, P. C. W.',
        'title': 'The Thermodynamic Theory of Black Holes',
        'journal': 'Proc. R. Soc. A',
        'volume': 353,
        'page': '499-521',
        'year': 1977,
        'doi': '10.1098/rspa.1977.0047',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Davies1977.abstract.txt',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Kerr (J/M²)_c = √(2√3 − 3) ≈ 0.6814 sign-flip; '
                     'RN (Q/M)_c = √3/2 ≈ 0.8660 sign-flip'],
        'notes': 'Wave 5: classical-GR sign-flip canonical reference. Pre-arXiv.',
    },
    'HawkingPage1983': {
        'authors': 'Hawking, S. W. and Page, D. N.',
        'title': 'Thermodynamics of Black Holes in Anti-de Sitter Space',
        'journal': 'Commun. Math. Phys.',
        'volume': 87,
        'page': '577-588',
        'year': 1983,
        'doi': '10.1007/BF01208266',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/HawkingPage1983.json',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Hawking-Page transition between thermal AdS and large-BH-AdS'],
        'notes': 'Wave 5: AdS-extension Branch C precedent. Pre-arXiv.',
    },
    'Israel1986ThirdLaw': {
        'authors': 'Israel, W.',
        'title': 'Third Law of Black-Hole Dynamics: A Formulation and Proof',
        'journal': 'Phys. Rev. Lett.',
        'volume': 57,
        'page': '397-399',
        'year': 1986,
        'doi': '10.1103/PhysRevLett.57.397',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Israel1986ThirdLaw.json',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Strong-form third law: κ → 0 in finite affine time impossible '
                     '(under classical-GR / no-charge-scalar-matter assumption)'],
        'notes': 'Wave 5: classical third-law anchor. Pre-arXiv. '
                 'Subsequently disproved in full generality by Kehle-Unger 2022.',
    },
    'Dymnikova2018Universe': {
        'authors': 'Dymnikova, I.',
        'title': 'The Higgs Mechanism and Cosmological Constant Today',
        'journal': 'Universe',
        'volume': 4,
        'page': 63,
        'year': 2018,
        'doi': '10.3390/universe4050063',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6a/primary-sources/Dymnikova2018Universe.abstract.txt',
        'used_in': ['papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex'],
        'provides': ['Explicit C-sign-flip at T_max with cooling to zero-T '
                     'double-horizon remnant in Padmanabhan emergent-gravity formalism'],
        'notes': 'Wave 5: closest published structural analog of the ADW cooling '
                 'regime. MDPI direct fetch returned 403; deferred WebFetch '
                 'verification to authorized round.',
    },

    # ════════════════════════════════════════════════════════════════
    # Phase 6c — Holographic / QEC bridges (Wave 4 + Wave 5)
    # ════════════════════════════════════════════════════════════════

    'HaydenPreskill2007': {
        'authors': 'Hayden, P., Preskill, J.',
        'title': 'Black holes as mirrors: quantum information in random subsystems',
        'journal': 'JHEP',
        'volume': '09',
        'page': '120',
        'year': 2007,
        'doi': '10.1088/1126-6708/2007/09/120',
        'arxiv': '0708.4025',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/HaydenPreskill2007.pdf',
        'used_in': [
            'papers/paper35_qec_holography/paper_draft.tex',
            'papers/note_rt_ch_bounds/paper_draft.tex',
            'papers/D4/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Information-recovery scrambling-time bound; foundational for '
                 'holographic-QEC bridge and W4 substrate observables.',
    },
    'RyuTakayanagi2006': {
        'authors': 'Ryu, S., Takayanagi, T.',
        'title': 'Holographic derivation of entanglement entropy from anti-de Sitter '
                 'space/conformal field theory correspondence',
        'journal': 'Phys. Rev. Lett.',
        'volume': 96,
        'page': '181602',
        'year': 2006,
        'doi': '10.1103/PhysRevLett.96.181602',
        'arxiv': 'hep-th/0603001',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/RyuTakayanagi2006.pdf',
        'used_in': [
            'papers/note_rt_ch_bounds/paper_draft.tex',
            'papers/D4/paper_draft.tex',
        ],
        'provides': ['RT formula: S = A/(4 G_N)'],
        'notes': 'Original RT proposal: holographic entanglement entropy as '
                 'minimal-surface area divided by 4 G_N.',
    },
    'CasiniHuerta2009': {
        'authors': 'Casini, H., Huerta, M.',
        'title': 'Entanglement entropy in free quantum field theory',
        'journal': 'J. Phys. A',
        'volume': 42,
        'page': '504007',
        'year': 2009,
        'doi': '10.1088/1751-8113/42/50/504007',
        'arxiv': '0905.2562',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/CasiniHuerta2009.pdf',
        'used_in': [
            'papers/note_rt_ch_bounds/paper_draft.tex',
            'papers/D4/paper_draft.tex',
        ],
        'provides': ['Free-QFT specialization of the (c/3) log(L/eps) entanglement bound'],
        'notes': 'Rigorous free-QFT specialization of the universal 2D-CFT entanglement bound. SCOPE NOTE (added 2026-04-29): the universal 2D-CFT bound for arbitrary CFTs is from Holzhey-Larsen-Wilczek 1994 and Calabrese-Cardy 2004; this paper derives the rigorous result for free QFTs. The Lean predicate H_CasiniHuerta_Bound_Valid retains the historical "Casini-Huerta" naming for compatibility but the universal-bound attribution belongs to HolzheyLarsenWilczek1994 + CalabreseCardy2004.',
    },
    'HolzheyLarsenWilczek1994': {
        'authors': 'Holzhey, C., Larsen, F., Wilczek, F.',
        'title': 'Geometric and renormalized entropy in conformal field theory',
        'journal': 'Nucl. Phys. B',
        'volume': 424,
        'page': '443',
        'year': 1994,
        'doi': '10.1016/0550-3213(94)90402-2',
        'arxiv': 'hep-th/9403108',
        'doi_verified': '2026-04-29',  # Added 2026-04-29 to correct CH-attribution; arXiv hep-th/9403108 confirmed
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/HolzheyLarsenWilczek1994.pdf',
        'used_in': [
            'papers/note_rt_ch_bounds/paper_draft.tex',
            'papers/D4/paper_draft.tex',
        ],
        'provides': ['Universal 2D-CFT entanglement-entropy log bound: S(L) <= (c/3) log(L/eps)'],
        'notes': 'Original derivation of the universal 2D-CFT entanglement-entropy log bound. Added 2026-04-29 to correct earlier mis-attribution of this bound to CasiniHuerta2009.',
    },
    'CalabreseCardy2004': {
        'authors': 'Calabrese, P., Cardy, J.',
        'title': 'Entanglement entropy and quantum field theory',
        'journal': 'J. Stat. Mech.',
        'volume': '0406',
        'page': 'P06002',
        'year': 2004,
        'doi': '10.1088/1742-5468/2004/06/P06002',
        'arxiv': 'hep-th/0405152',
        'doi_verified': '2026-04-29',  # Added 2026-04-29 to correct CH-attribution; arXiv hep-th/0405152 confirmed
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/CalabreseCardy2004.pdf',
        'used_in': [
            'papers/note_rt_ch_bounds/paper_draft.tex',
        ],
        'provides': ['Universal 2D-CFT entanglement-entropy log bound: S(L) <= (c/3) log(L/eps)'],
        'notes': 'Independent derivation of the universal 2D-CFT entanglement-entropy log bound via replica trick. Added 2026-04-29 to correct earlier mis-attribution of this bound to CasiniHuerta2009.',
    },
    'LewkowyczMaldacena2013': {
        'authors': 'Lewkowycz, A., Maldacena, J.',
        'title': 'Generalized gravitational entropy',
        'journal': 'JHEP',
        'volume': '08',
        'page': '090',
        'year': 2013,
        'doi': '10.1007/JHEP08(2013)090',
        'arxiv': '1304.4926',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/LewkowyczMaldacena2013.pdf',
        'used_in': [
            'papers/note_rt_ch_bounds/paper_draft.tex',
            'papers/D4/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Replica-trick proof of RT formula; bulk minimal-surface construction.',
    },
    'AlmheiriDongHarlow2015': {
        'authors': 'Almheiri, A., Dong, X., Harlow, D.',
        'title': 'Bulk locality and quantum error correction in AdS/CFT',
        'journal': 'JHEP',
        'volume': '04',
        'page': '163',
        'year': 2015,
        'doi': '10.1007/JHEP04(2015)163',
        'arxiv': '1411.7041',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/AlmheiriDongHarlow2015.pdf',
        'used_in': [
            'papers/paper35_qec_holography/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Bulk locality as quantum error correction; foundational for '
                 'holographic-QEC interpretation.',
    },
    'PYHP2015': {
        'authors': 'Pastawski, F., Yoshida, B., Harlow, D., Preskill, J.',
        'title': 'Holographic quantum error-correcting codes: toy models for the '
                 'bulk/boundary correspondence',
        'journal': 'JHEP',
        'volume': '06',
        'page': '149',
        'year': 2015,
        'doi': '10.1007/JHEP06(2015)149',
        'arxiv': '1503.06237',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/PYHP2015.pdf',
        'used_in': [
            'papers/paper35_qec_holography/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'HaPPY codes: explicit holographic-QEC tensor-network construction.',
    },
    'YoshidaKitaev2017': {
        'authors': 'Yoshida, B., Kitaev, A.',
        'title': 'Efficient decoding for the Hayden-Preskill protocol',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2017,
        'doi': None,
        'arxiv': '1710.03363',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/YoshidaKitaev2017.pdf',
        'used_in': [
            'papers/paper35_qec_holography/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Decoder construction for Hayden-Preskill recovery; deferred in W4 scope.',
    },
    'HeinzSnellings2013': {
        'authors': 'Heinz, U. and Snellings, R.',
        'title': 'Collective flow and viscosity in relativistic heavy-ion collisions',
        'journal': 'Annual Review of Nuclear and Particle Science',
        'volume': 63,
        'page': '123-151',
        'year': 2013,
        'doi': '10.1146/annurev-nucl-102212-170540',
        'arxiv': '1301.2826',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/HeinzSnellings2013.abstract.txt',
        'used_in': ['notebooks/Phase6d1_CenterSymmetry_Stakeholder.ipynb'],
        'provides': [],
        'notes': 'Primary-source backing for the QGP shear-viscosity-to-entropy ratio eta/s ~ 0.10-0.20 (1-2.5x KSS bound) quoted in the Phase 6d1 CenterSymmetry stakeholder notebook. Added 2026-05-31 to ground Stage-13 finding paper36:4.1; DOI Crossref-verified 2026-05-31.',
    },

    'KitaevAnyons2003': {
        'authors': 'Kitaev, A. Yu.',
        'title': 'Fault-tolerant quantum computation by anyons',
        'journal': 'Annals Phys.',
        'volume': 303,
        'page': '2',
        'year': 2003,
        'doi': '10.1016/S0003-4916(02)00018-0',
        'arxiv': 'quant-ph/9707021',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/KitaevAnyons2003.pdf',
        'used_in': [
            'papers/paper35_qec_holography/paper_draft.tex',
            'papers/paper36_center_symmetry/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Anyonic-substrate fault-tolerant computation; foundational for '
                 'topological-QEC framework.',
    },
    'NayakAnyons2008': {
        'authors': 'Nayak, C., Simon, S. H., Stern, A., Freedman, M., Das Sarma, S.',
        'title': 'Non-Abelian anyons and topological quantum computation',
        'journal': 'Rev. Mod. Phys.',
        'volume': 80,
        'page': '1083',
        'year': 2008,
        'doi': '10.1103/RevModPhys.80.1083',
        'arxiv': '0707.1889',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/NayakAnyons2008.pdf',
        'used_in': [
            'papers/paper35_qec_holography/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Comprehensive review of non-abelian anyons and topological QC.',
    },
    'KitaevPreskill2006': {
        'authors': 'Kitaev, A., Preskill, J.',
        'title': 'Topological entanglement entropy',
        'journal': 'Phys. Rev. Lett.',
        'volume': 96,
        'page': '110404',
        'year': 2006,
        'doi': '10.1103/PhysRevLett.96.110404',
        'arxiv': 'hep-th/0510092',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/KitaevPreskill2006.pdf',
        'used_in': [
            'papers/paper35_qec_holography/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Topological entanglement entropy: gamma = log D for total quantum dimension D.',
    },

    # ════════════════════════════════════════════════════════════════
    # ════════════════════════════════════════════════════════════════
    # Phase 6o — Wave 4a FLS BEC depletion-factor primary sources
    # (returned 2026-05-06; populated 2026-05-08 verdict (B) closure)
    # ════════════════════════════════════════════════════════════════

    'FinazziLiberatiSindoni2012PRL': {
        'authors': 'Finazzi, S., Liberati, S., Sindoni, L.',
        'title': 'Cosmological Constant: A Lesson from Bose-Einstein Condensates',
        'journal': 'Phys. Rev. Lett.',
        'volume': 108,
        'page': '071101',
        'year': 2012,
        'doi': '10.1103/PhysRevLett.108.071101',
        'arxiv': '1103.4841',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/FinazziLiberatiSindoni2012PRL.pdf',
        'used_in': ['papers/D5/paper_draft.tex'],
        'provides': [],
        'notes': 'Primary FLS source for the BEC analogue cosmological constant '
                 'depletion-factor finding. Lambda_FLS proportional to sqrt(rho_0 a^3) '
                 'depletion factor, giving Lambda_FLS / Lambda_HK ~ 1e-3 to 1e-4 for '
                 'canonical 87Rb BECs. Substrate counterexample to "Lambda = renormalized '
                 'vacuum energy" identification. Underlies Phase 6o Wave 4a verdict (B): '
                 'biconditional reading of Sakharov ↔ Lambda_J = Lambda_HK retired in favour '
                 'of one-way implication + depletion-factor as substrate-derived ℝ.',
    },
    'FinazziLiberatiSindoni2012Proc': {
        'authors': 'Finazzi, S., Liberati, S., Sindoni, L.',
        'title': 'The analogue cosmological constant in Bose-Einstein condensates: a lesson for quantum gravity',
        'journal': 'Proc. II Amazonian Symposium on Physics',
        'volume': None,
        'page': None,
        'year': 2012,
        'doi': None,
        'arxiv': '1204.3039',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/FinazziLiberatiSindoni2012Proc.pdf',
        'used_in': ['papers/D5/paper_draft.tex'],
        'provides': [],
        'notes': 'Companion proceedings to FinazziLiberatiSindoni2012PRL with the full '
                 'derivation chain: Eqs. (50) modified Poisson; (54)–(55) C_Lambda from '
                 'depleted vacuum expectation values; (61) Volovik grand-canonical h; '
                 '(67) depletion density; (69) LHY ground-state energy; (70) anomalous '
                 'expectation; (71) load-bearing depletion-factor closed form Lambda_FLS = '
                 '−(20 m gρ₀ (gρ₀+3λ))/(3√π ℏ² λ) · √(ρ₀a³) · F_Λ(λ/gρ₀); (76) suppression '
                 'ratio E_Lambda/E_Planck proportional to ρ₀a³.',
    },
    'BelenchiaLiberatiMohd2014': {
        'authors': 'Belenchia, A., Liberati, S., Mohd, A.',
        'title': 'Emergent gravitational dynamics in relativistic Bose-Einstein condensate',
        'journal': 'Phys. Rev. D',
        'volume': 90,
        'page': '104015',
        'year': 2014,
        'doi': '10.1103/PhysRevD.90.104015',
        'arxiv': '1407.7896',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/BelenchiaLiberatiMohd2014.pdf',
        'used_in': ['papers/D5/paper_draft.tex'],
        'provides': [],
        'notes': 'Restates the FLS depletion-factor result in the relativistic-BEC '
                 'extension: the BEC analogue Lambda is "basically due to the depletion '
                 'factor", "a pure quantum effect due to the quantum inequivalence of '
                 'the phonon and atomic vacua." Independent corroboration of the load-'
                 'bearing FLS finding.',
    },

    # ════════════════════════════════════════════════════════════════
    # Phase 6c — Strong-CP / dark-energy bridge (Wave 1)
    # ════════════════════════════════════════════════════════════════

    'KlinkhamerVolovik2010': {
        'authors': 'Klinkhamer, F. R., Volovik, G. E.',
        'title': 'Towards a solution of the cosmological constant problem',
        'journal': 'JETP Lett.',
        'volume': 91,
        'page': '259',
        'year': 2010,
        'doi': '10.1134/S0021364010060019',
        'arxiv': '0907.4887',
        'doi_verified': '2026-08-15',  # CrossRef 10.1134/S0021364010060019 -> title/authors/vol 91/pp 259-265 (2010)
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/KlinkhamerVolovik2010.pdf',
        'used_in': [
            'papers/paper32_strong_cp_de/paper_draft.tex',
            'notebooks/Phase6c1_StrongCPDarkEnergy_Stakeholder.ipynb',
        ],
        'provides': [],
        'notes': 'q-theory framework for cosmological-constant relaxation. This is the '
                 'framework/synthesis paper, NOT the origin of q-theory: the vacuum '
                 'variable q is introduced in KV2008 (PRD 77, 085015; arXiv:0711.3170), '
                 'which this paper cites as its own Ref. [3]. Title corrected 2026-04-29 '
                 '(was "Cosmological constant from gravitating Skyrmions" — no such '
                 'Klinkhamer-Volovik paper exists; the gravitating-Skyrmion literature is '
                 'a different community) per verification of arXiv:0907.4887. DOI '
                 'corrected 2026-08-15: the prior 10.1134/S0021364010050094 returns 404 '
                 'from CrossRef and resolves to nothing; the registered DOI is '
                 '10.1134/S0021364010060019.',
    },
    'Pendlebury2015': {
        'authors': 'Pendlebury, J. M., et al.',
        'title': 'Revised experimental upper limit on the electric dipole moment '
                 'of the neutron',
        'journal': 'Phys. Rev. D',
        'volume': 92,
        'page': '092003',
        'year': 2015,
        'doi': '10.1103/PhysRevD.92.092003',
        'arxiv': '1509.04411',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/Pendlebury2015.pdf',
        'used_in': [
            'papers/paper32_strong_cp_de/paper_draft.tex',
        ],
        'provides': ['Neutron EDM upper bound: |theta_QCD| <= 1e-9 (current strongest)'],
        'notes': 'Strongest current bound on the QCD theta-angle via neutron EDM.',
    },

    # ════════════════════════════════════════════════════════════════
    # Phase 6c — Equivalence-principle classification (Wave 3)
    # ════════════════════════════════════════════════════════════════

    'Touboul2017': {
        'authors': 'Touboul, P., et al.',
        'title': 'MICROSCOPE Mission: First Results of a Space Test of the Equivalence Principle',
        'journal': 'Phys. Rev. Lett.',
        'volume': 119,
        'page': '231101',
        'year': 2017,
        'doi': '10.1103/PhysRevLett.119.231101',
        'arxiv': '1712.01176',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/Touboul2017.pdf',
        'used_in': [
            'papers/paper34_equivalence_principle/paper_draft.tex',
        ],
        'provides': ['MICROSCOPE WEP bound: |eta| < 1e-15'],
        'notes': 'First-results MICROSCOPE EP bound. Final 2022 result improves to ~1e-15 systematic.',
    },
    'Will2018': {
        'authors': 'Will, C. M.',
        'title': 'Theory and Experiment in Gravitational Physics (2nd ed.)',
        'journal': 'Cambridge University Press',
        'volume': None,
        'page': None,
        'year': 2018,
        'doi': '10.1017/9781316338612',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/Will2018.json',
        'used_in': [
            'papers/paper34_equivalence_principle/paper_draft.tex',
            'papers/paper42_nonlinear_efe/paper_draft.tex',
        ],
        'provides': ['PPN parameter framework (§4.1, §4.2); light-deflection '
                     'GR baseline 1.751 arcsec at solar limb; perihelion '
                     'precession formula (Eq. 4.31); VLBI + MESSENGER '
                     'precision floors (Table 3)'],
        'notes': 'Standard reference for EP-test taxonomy and PPN parameter '
                 'framework. Wave 4 paper42 cites §4.1 (deflection) + §4.2 '
                 '(perihelion) + Table 3 (observation floors).',
    },
    'Berezhiani2015': {
        'authors': 'Berezhiani, L., Khoury, J.',
        'title': 'Theory of dark matter superfluidity',
        'journal': 'Phys. Rev. D',
        'volume': 92,
        'page': '103510',
        'year': 2015,
        'doi': '10.1103/PhysRevD.92.103510',
        'arxiv': '1507.01019',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/Berezhiani2015.pdf',
        'used_in': [
            'papers/paper34_equivalence_principle/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Superfluid dark matter (SFDM) with Thomas-Fermi condensate phenomenology.',
    },

    # ════════════════════════════════════════════════════════════════
    # Phase 6d — QCD center symmetry / chiral SSB / CFL
    # ════════════════════════════════════════════════════════════════

    'Polyakov1978': {
        'authors': 'Polyakov, A. M.',
        'title': 'Thermal properties of gauge fields and quark liberation',
        'journal': 'Phys. Lett. B',
        'volume': 72,
        'page': '477',
        'year': 1978,
        'doi': '10.1016/0370-2693(78)90737-2',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/Polyakov1978.json',
        'used_in': [
            'papers/paper36_center_symmetry/paper_draft.tex',
            'papers/paper38_cfl/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Original Polyakov-loop construction and deconfinement order parameter.',
    },
    'SvetitskyYaffe1982': {
        'authors': 'Svetitsky, B., Yaffe, L. G.',
        'title': 'Critical behavior at finite-temperature confinement transitions',
        'journal': 'Nucl. Phys. B',
        'volume': 210,
        'page': '423',
        'year': 1982,
        'doi': '10.1016/0550-3213(82)90172-9',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/SvetitskyYaffe1982.json',
        'used_in': [
            'papers/paper36_center_symmetry/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Svetitsky-Yaffe universality conjecture: SU(N) deconfinement = '
                 'lower-dimensional Z_N spin model.',
    },
    'PelissettoVicari2002': {
        'authors': 'Pelissetto, A., Vicari, E.',
        'title': 'Critical phenomena and renormalization-group theory',
        'journal': 'Phys. Rep.',
        'volume': 368,
        'page': '549',
        'year': 2002,
        'doi': '10.1016/S0370-1573(02)00219-3',
        'arxiv': 'cond-mat/0012164',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/PelissettoVicari2002.pdf',
        'used_in': [
            'papers/paper36_center_symmetry/paper_draft.tex',
        ],
        'provides': ['3D Ising nu = 0.6299', '3D 3-state Potts nu = 0.5'],
        'notes': 'Standard reference for critical exponents in 3D Ising and Potts universality classes.',
    },
    'KosPolandSimmonsDuffin2016': {
        'authors': 'Kos, F., Poland, D., Simmons-Duffin, D., Vichi, A.',
        'title': 'Precision islands in the Ising and O(N) models',
        'journal': 'JHEP',
        'volume': '08',
        'page': '036',
        'year': 2016,
        'doi': '10.1007/JHEP08(2016)036',
        'arxiv': '1603.04436',
        'doi_verified': '2026-04-29',  # WebFetch arXiv:1603.04436 confirmed (paper36 adversarial 2026-04-29)
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/KosPolandSimmonsDuffin2016.pdf',
        'used_in': [
            'papers/paper36_center_symmetry/paper_draft.tex',
        ],
        'provides': ['3D Ising nu = 0.6299709 (KPSDV bootstrap, 2016)'],
        'notes': 'Conformal bootstrap precision values for 3D Ising universality class. Title + author count + venue corrected 2026-04-29 (was wrongly listed as 3-author "Bootstrapping the O(N) archipelago" JHEP 03:086) per WebFetch verification of arXiv:1603.04436. Bibkey retained for backwards compatibility despite missing fourth-author Vichi.',
    },
    'KovtunSonStarinets2005': {
        'authors': 'Kovtun, P., Son, D. T., Starinets, A. O.',
        'title': 'Viscosity in strongly interacting quantum field theories from black hole physics',
        'journal': 'Phys. Rev. Lett.',
        'volume': 94,
        'page': '111601',
        'year': 2005,
        'doi': '10.1103/PhysRevLett.94.111601',
        'arxiv': 'hep-th/0405231',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/KovtunSonStarinets2005.pdf',
        'used_in': [
            'papers/paper36_center_symmetry/paper_draft.tex',
        ],
        'provides': ['KSS bound: eta/s >= 1/(4 pi)'],
        'notes': 'KSS holographic lower bound on shear-viscosity-to-entropy-density ratio.',
    },
    'HofmanIqbal2018': {
        'authors': 'Hofman, D. M., Iqbal, N.',
        'title': 'Generalized global symmetries and holography',
        'journal': 'SciPost Phys.',
        'volume': '4',
        'page': '005',
        'year': 2018,
        'doi': '10.21468/SciPostPhys.4.1.005',
        'arxiv': '1707.08577',
        'doi_verified': '2026-04-29',  # WebFetch arXiv:1707.08577 confirmed (paper36 adversarial 2026-04-29)
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/HofmanIqbal2018.pdf',
        'used_in': [
            'papers/paper36_center_symmetry/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Holographic generalized global symmetries; framework for higher-form symmetries in transport. Title corrected 2026-04-29 (was "Goldstone modes and photonization for higher form symmetries" — that is a different/related paper) per WebFetch verification of arXiv:1707.08577.',
    },
    'WalkerWang2012': {
        'authors': 'Walker, K., Wang, Z.',
        'title': '(3+1)-TQFTs and topological insulators',
        'journal': 'Front. Phys.',
        'volume': 7,
        'page': '150',
        'year': 2012,
        'doi': '10.1007/s11467-011-0194-z',
        'arxiv': '1104.2632',
        'doi_verified': '2026-04-29',  # WebFetch arXiv:1104.2632 confirmed (newly added 2026-04-29)
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/WalkerWang2012.pdf',
        'used_in': [
            'papers/paper26_bh_entropy/paper_draft.tex',
            'papers/paper36_center_symmetry/paper_draft.tex',
            'papers/D3/paper_draft.tex',
        ],
        'provides': [
            'Walker-Wang TQFTs hosting (3+1)-D anyon-line excitations',
            'Walker-Wang 4D TQFT bulk ↔ 3D anomalous SET boundary mapping',
            'Anomaly-inflow framework for the Z₂-time-reversal-symmetric bulk ↔ chiral c_- boundary mod 8',
        ],
        'notes': 'Walker-Wang (3+1)-dimensional TQFT framework. Source of the Z₂-time-reversal anomaly-match conjecture for the ADW bulk ↔ horizon MTC inflow (novelty-flagged in Wave 3 paper26). Also provides the topological-phase context paper36 invokes for the Walker-Wang anyon-mediated transport modelling assumption (no transport prediction is derived from this reference). Consolidated 2026-05-11 (D3 Stage-13 fix-pass) from duplicate-key shadowing.',
    },
    'NambuJonaLasinio1961': {
        'authors': 'Nambu, Y., Jona-Lasinio, G.',
        'title': 'Dynamical model of elementary particles based on an analogy with superconductivity. I.',
        'journal': 'Phys. Rev.',
        'volume': 122,
        'page': '345',
        'year': 1961,
        'doi': '10.1103/PhysRev.122.345',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/NambuJonaLasinio1961.json',
        'used_in': [
            'papers/paper37_chiral_ssb/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Original NJL model: dynamical chiral symmetry breaking by four-fermion interaction.',
    },
    'GMOR1968': {
        'authors': 'Gell-Mann, M., Oakes, R. J., Renner, B.',
        'title': 'Behavior of current divergences under SU(3) x SU(3)',
        'journal': 'Phys. Rev.',
        'volume': 175,
        'page': '2195',
        'year': 1968,
        'doi': '10.1103/PhysRev.175.2195',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/GMOR1968.json',
        'used_in': [
            'papers/paper37_chiral_ssb/paper_draft.tex',
        ],
        'provides': ['GMOR relation: m_pi^2 f_pi^2 = -2 m_q <q-bar q>'],
        'notes': 'Gell-Mann-Oakes-Renner relation between pion mass, decay constant, and quark condensate.',
    },
    'FLAG2021': {
        'authors': 'Aoki, Y., et al. (Flavour Lattice Averaging Group)',
        'title': 'FLAG Review 2021',
        'journal': 'Eur. Phys. J. C',
        'volume': 82,
        'page': '869',
        'year': 2022,
        'doi': '10.1140/epjc/s10052-022-10536-1',
        'arxiv': '2111.09849',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/FLAG2021.pdf',
        'used_in': [
            'papers/paper37_chiral_ssb/paper_draft.tex',
        ],
        'provides': ['Lattice quark condensate <q-bar q> ≈ -(283 MeV)^3 ≈ -0.0227 GeV^3'],
        'notes': 'Lattice-QCD averages including chiral condensate and decay constants.',
    },
    'PDG2022': {
        'authors': 'Workman, R. L., et al. (Particle Data Group)',
        'title': 'Review of Particle Physics',
        'journal': 'Prog. Theor. Exp. Phys.',
        'volume': 2022,
        'page': '083C01',
        'year': 2022,
        'doi': '10.1093/ptep/ptac097',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/PDG2022.abstract.txt',
        'used_in': [
            'papers/paper37_chiral_ssb/paper_draft.tex',
        ],
        'provides': ['m_pi = 0.137 GeV', 'f_pi = 0.092 GeV', 'Lambda_QCD ~ 0.1 GeV'],
        'notes': 'Particle Data Group 2022 release; central values for hadron spectroscopy.',
    },
    'AlfordRajagopalWilczek1999': {
        'authors': 'Alford, M. G., Rajagopal, K., Wilczek, F.',
        'title': 'Color-flavor locking and chiral symmetry breaking in high density QCD',
        'journal': 'Nucl. Phys. B',
        'volume': 537,
        'page': '443',
        'year': 1999,
        'doi': '10.1016/S0550-3213(98)00668-3',
        'arxiv': 'hep-ph/9804403',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/AlfordRajagopalWilczek1999.pdf',
        'used_in': [
            'papers/paper38_cfl/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'CFL phase: color-flavor-locked diquark condensate and emergent symmetries.',
    },
    'SonStephanov2001': {
        'authors': 'Son, D. T., Stephanov, M. A.',
        'title': 'Inverse meson mass ordering in the color-flavor-locking phase of high-density QCD',
        'journal': 'Phys. Rev. D',
        'volume': 61,
        'page': '074012',
        'year': 2000,
        'doi': '10.1103/PhysRevD.61.074012',
        'arxiv': 'hep-ph/9910491',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/SonStephanov2001.pdf',
        'used_in': [
            'papers/paper38_cfl/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'CFL effective chiral Lagrangian with inverted meson-mass hierarchy.',
    },
    'SchaeferWilczek1999': {
        'authors': 'Schäfer, T., Wilczek, F.',
        'title': 'Continuity of quark and hadron matter',
        'journal': 'Phys. Rev. Lett.',
        'volume': 82,
        'page': '3956',
        'year': 1999,
        'doi': '10.1103/PhysRevLett.82.3956',
        'arxiv': 'hep-ph/9811473',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/SchaeferWilczek1999.pdf',
        'used_in': [
            'papers/paper38_cfl/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Quark-hadron continuity: CFL diquark <-> hadronic-baryon correspondence.',
    },
    'HironoTanizaki2018': {
        'authors': 'Hirono, Y., Tanizaki, Y.',
        'title': 'Quark-hadron continuity beyond the Ginzburg-Landau paradigm',
        'journal': 'Phys. Rev. Lett.',
        'volume': 122,
        'page': '212001',
        'year': 2019,
        'doi': '10.1103/PhysRevLett.122.212001',
        'arxiv': '1811.10608',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/HironoTanizaki2018.pdf',
        'used_in': [
            'papers/paper38_cfl/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'CFL emergent Z_3 1-form symmetry matches QCD center; '
                 'topological-order beyond Landau-Ginzburg.',
    },
    'GaiottoKapustinSeibergWillett2015': {
        'authors': 'Gaiotto, D., Kapustin, A., Seiberg, N., Willett, B.',
        'title': 'Generalized global symmetries',
        'journal': 'JHEP',
        'volume': '02',
        'page': '172',
        'year': 2015,
        'doi': '10.1007/JHEP02(2015)172',
        'arxiv': '1412.5148',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/GaiottoKapustinSeibergWillett2015.pdf',
        'used_in': [
            'papers/paper38_cfl/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Foundational paper on higher-form (1-form) global symmetries; '
                 'machinery for Z_N center symmetry analysis.',
    },
    'AlfordSchmittRajagopalSchaefer2008': {
        'authors': 'Alford, M. G., Schmitt, A., Rajagopal, K., Schäfer, T.',
        'title': 'Color superconductivity in dense quark matter',
        'journal': 'Rev. Mod. Phys.',
        'volume': 80,
        'page': '1455',
        'year': 2008,
        'doi': '10.1103/RevModPhys.80.1455',
        'arxiv': '0709.4635',
        'doi_verified': '2026-04-29',  # WebFetch arXiv:0709.4635 confirmed (paper38 adversarial 2026-04-29)
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6d/primary-sources/AlfordSchmittRajagopalSchaefer2008.pdf',
        'used_in': [
            'papers/paper38_cfl/paper_draft.tex',
        ],
        'provides': [],
        'notes': 'Comprehensive review of color superconductivity and CFL phase. Renamed 2026-04-29 from the misnomer "Hatsuda2008" (paper has no Hatsuda authorship); paper38 .tex updated correspondingly.',
    },

    # ════════════════════════════════════════════════════════════════
    # Auto-stubs from \bibitem blocks (Phase 6i Wave 1 backfill)
    # ════════════════════════════════════════════════════════════════

    'ABP1967': {
        'authors': 'D.~W.~Anderson, E.~H.~Brown~Jr., and F.~P.~Peterson',
        'title': 'The structure of the spin cobordism ring',
        'journal': None,
        'volume': 86,
        'page': None,
        'year': 1967,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper10_modular_generation/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper10_modular_generation/paper_draft.tex`.',
    },

    'Weibel1994': {
        'authors': 'C.~A.~Weibel',
        'title': 'An Introduction to Homological Algebra',
        'journal': 'Cambridge University Press (Cambridge Studies in Advanced Mathematics 38)',
        'volume': None,
        'page': None,
        'year': 1994,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Cambridge Studies in Advanced Mathematics 38; the Hom-tensor '
                         'adjunction (Thm 2.6.1) it is cited for is standard and '
                         'verified across the homological-algebra literature.',
        'used_in': ['papers/paper10_modular_generation/paper_draft.tex'],
        'provides': [],
        'notes': 'Canonical-textbook reference (textbook exemption: doi/arxiv/primary_source_path all None). Cited in paper10 (2026-06-08 Stage-13 fix-pass) for the Hom-tensor adjunction (Thm 2.6.1), the standard algebra fact underlying the change-of-rings reduction documented in ChangeOfRings.lean.',
    },

    'Adams1974': {
        'authors': 'Adams, J. F.',
        'title': 'Stable Homotopy and Generalised Homology',
        'journal': 'University of Chicago Press (Chicago Lectures in Mathematics)',
        'volume': None,
        'page': None,
        'year': 1974,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Chicago Lectures monograph (Stable Homotopy and Generalised '
                         'Homology); canonical Adams-spectral-sequence reference '
                         'verified via secondary academic citation. No cacheable full '
                         'text.',
        'used_in': ['papers/paper10_modular_generation/paper_draft.tex',
                    'papers/L2/paper_draft.tex',
                    'papers/D2/paper_draft.tex'],
        'provides': [],
        'notes': 'Adams 1974 Chicago Lectures volume "Stable Homotopy and Generalised Homology". Used in D2/L2 for the ko-cohomology tracked hypothesis H1 and for general Adams spectral sequence context. Note: the D2 bibitem string previously read "Generalised Cohomology" (one-letter typo); corrected in 2026-05-11 Stage-13 fix-pass to match this canonical registry title.',
    },

    'Adler2024': {
        'authors': 'D.~Adler, D.~Wei, M.~Will, K.~Srakaew, S.~Agrawal, P.~Weckesser, R.~Moessner, F.~Pollmann, I.~Bloch, J.~Zeiher',
        'title': 'Observation of Hilbert-space fragmentation and fractonic excitations in two-dimensional Hubbard systems',
        'journal': 'Nature',
        'volume': 636,
        'page': 80,
        'year': 2024,
        'doi': None,
        'arxiv': '2404.14896',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper3_gauge_erasure/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper3_gauge_erasure/paper_draft.tex`. Title and full author list verified via arXiv:2404.14896 (Session-4 cleanup).',
    },

    'AlvarezGaumeWitten1984': {
        'authors': "Alvarez-Gaumé, L. and Witten, E.",
        'title': 'Gravitational anomalies',
        'journal': 'Nuclear Physics B',
        'volume': 234,
        'page': '269',
        'year': 1984,
        'doi': '10.1016/0550-3213(84)90066-X',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper10_modular_generation/paper_draft.tex',
                    'papers/paper9_sm_anomaly_drinfeld/paper_draft.tex',
                    'papers/L2/paper_draft.tex',
                    'papers/D2/paper_draft.tex'],
        'provides': ['Gravitational-anomaly classification of chiral fermions; foundational anchor for the L2/D2 mod-3 generation derivation chain.'],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper10_modular_generation/paper_draft.tex`. Title not present in source bibitem.',
    },

    'AnantramDatta1996': {
        'authors': 'M.~P.~Anantram and S.~Datta, Phys. Rev. B , 16390 (1996)',
        'title': '',
        'journal': 'Phys. Rev. B',
        'volume': 53,
        'page': None,
        'year': 1996,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_graphene_sk_eft/paper_draft.tex`. Title not present in source bibitem.',
    },

    'AndersonBFP2013': {
        'authors': 'P.~R.~Anderson, R.~Balbinot, A.~Fabbri, and R.~Parentani, Phys. Rev. D , 124018 (2013)',
        'title': '',
        'journal': 'Phys. Rev. D',
        'volume': 87,
        'page': None,
        'year': 2013,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_graphene_sk_eft/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Antusch2003': {
        'authors': 'S.~Antusch, J.~Kersten, M.~Lindner, and M.~Ratz, Running neutrino masses, mixings and CP phases: Analytical results and phenomenological consequences, Nucl.~Phys.~B~, 401 (2003); arXiv:hep-ph/0305273',
        'title': 'Running neutrino masses, mixings and CP phases: Analytical results and phenomenological consequences',
        'journal': None,
        'volume': 674,
        'page': None,
        'year': 2003,
        'doi': None,
        'arxiv': 'hep-ph/0305273',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/Antusch2003.pdf',
        'used_in': ['papers/paper33_ewbg_chirality_wall/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper33_ewbg_chirality_wall/paper_draft.tex`.',
    },

    'Aristotle': {
        'authors': 'Aristotle automated theorem prover, https://www.aristotle.cx/',
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper6_vestigial/paper_draft.tex',
                    'papers/paper7_chirality_formal/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper6_vestigial/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Aristotle2025': {
        'authors': 'Harmonic Inc., Aristotle Automated Theorem Prover, https://aristotle.harmonic.fun (2025)',
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper8_chirality_master/paper_draft.tex`. Title not present in source bibitem.',
    },

    'BRSSS2008': {
        'authors': 'R.~Baier, P.~Romatschke, D.~T.~Son, A.~O.~Starinets, M.~A.~Stephanov',
        'title': 'Relativistic viscous hydrodynamics, conformal invariance, and holography',
        'journal': 'JHEP',
        'volume': 4,
        'page': 100,
        'year': 2008,
        'doi': '10.1088/1126-6708/2008/04/100',
        'arxiv': '0712.2451',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_graphene_sk_eft/paper_draft.tex`. Title and full author list verified via arXiv:0712.2451 (Session-4 cleanup).',
    },

    'Baseilhac2005': {
        'authors': 'P.~Baseilhac and K.~Belliard, Nucl.\\ Phys.\\ B , 550 (2013) [arXiv:0906.1215]',
        'title': '',
        'journal': None,
        'volume': 873,
        'page': None,
        'year': 2013,
        'doi': None,
        'arxiv': '0906.1215',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5c/primary-sources/Baseilhac2005.pdf',
        'used_in': ['papers/paper11_quantum_group/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper11_quantum_group/paper_draft.tex`. Title not present in source bibitem.',
    },

    'BeaudryCampbell': {
        'authors': 'A.~Beaudry and J.~A.~Campbell',
        'title': 'A guide for computing stable homotopy groups',
        'journal': None,
        'volume': 718,
        'page': None,
        'year': 2018,
        'doi': None,
        'arxiv': '1801.07530',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5e/primary-sources/BeaudryCampbell.pdf',
        'used_in': ['papers/paper10_modular_generation/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper10_modular_generation/paper_draft.tex`.',
    },

    'Berry1989': {
        'authors': 'M.~V.~Berry, Proc.\\ R.\\ Soc.\\ A , 7 (1989)',
        'title': '',
        'journal': None,
        'volume': 422,
        'page': None,
        'year': 1989,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper4_wkb_connection/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper4_wkb_connection/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Bilic1999': {
        'authors': "N.~Bili\'c, Class. Quantum Grav. , 3953 (1999)",
        'title': '',
        'journal': 'Class. Quantum Grav',
        'volume': 16,
        'page': None,
        'year': 1999,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_graphene_sk_eft/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Blanter2000': {
        'authors': 'Ya.~M.~Blanter and M.~B\"uttiker, Phys. Rep. , 1 (2000)',
        'title': '',
        'journal': 'Phys. Rep',
        'volume': 336,
        'page': None,
        'year': 2000,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_graphene_sk_eft/paper_draft.tex`. Title not present in source bibitem.',
    },

    'BruillardGRW2017': {
        'authors': 'P.~Bruillard, C.~Galindo, S.-H.~Ng, J.~Plavnik, E.~Rowell, and Z.~Wang',
        'title': 'J.~Math.~Phys.',
        'journal': None,
        'volume': 58,
        'page': None,
        'year': 2017,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper8_chirality_master/paper_draft.tex`.',
    },

    'CallenWelton1951': {
        'authors': 'H.~B.~Callen and T.~A.~Welton, Phys. Rev. , 34 (1951)',
        'title': '',
        'journal': 'Phys. Rev',
        'volume': 83,
        'page': None,
        'year': 1951,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_graphene_sk_eft/paper_draft.tex`. Title not present in source bibitem.',
    },

    'CohenKaplanNelson1993': {
        'authors': 'Cohen, A. G., Kaplan, D. B., and Nelson, A. E.',
        'title': 'Progress in Electroweak Baryogenesis',
        'journal': 'Annu. Rev. Nucl. Part. Sci.',
        'volume': 43,
        'page': '27',
        'year': 1993,
        'doi': '10.1146/annurev.ns.43.120193.000331',
        'arxiv': 'hep-ph/9302210',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/CohenKaplanNelson1993.pdf',
        'used_in': ['papers/paper33_ewbg_chirality_wall/paper_draft.tex'],
        'provides': [],
        'notes': 'Phase 6i Wave 6: original auto-generated stub had a malformed hyperlink-format DOI (\"10.1146/annurev.ns.43.120193.000331}{...\") which broke Crossref verification. Cleaned to canonical DOI; arXiv hep-ph/9302210 added; doi_verified flipped to True. Primary-sources cache fetched via arxiv-pdf back-fill in Wave 6 (387 KB PDF at Phase-6c/primary-sources/CohenKaplanNelson1993.pdf).',
    },

    'Cooke2018': {
        'authors': "R.~J.~Cooke, M.~Pettini, C.~C.~Steidel, ``One percent determination of the primordial deuterium abundance,'' ApJ , 102 (2018), arXiv:1710.11129",
        'title': '',
        'journal': 'ApJ',
        'volume': 855,
        'page': None,
        'year': 2018,
        'doi': None,
        'arxiv': '1710.11129',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6b/primary-sources/Cooke2018.pdf',
        'used_in': ['papers/paper29_bbn_unified/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper29_bbn_unified/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Coutant2014': {
        'authors': 'O.~Coutant and R.~Parentani',
        'title': 'Phys.\\ Rev.\\ D',
        'journal': None,
        'volume': 90,
        'page': None,
        'year': 2014,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper1_first_order/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper1_first_order/paper_draft.tex`.',
    },

    'CoutantParentani2010': {
        'authors': 'A.~Coutant and R.~Parentani, Phys. Rev. D , 024009 (2010)',
        'title': '',
        'journal': 'Phys. Rev. D',
        'volume': 81,
        'page': None,
        'year': 2010,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_graphene_sk_eft/paper_draft.tex`. Title not present in source bibitem.',
    },

    'CriticalReview2026': {
        'authors': 'J.~Roehm, Fluid-Based Approach to Fundamental Physics: Consolidated Critical Review v3 (2026)',
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper8_chirality_master/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Crossley:2017': {
        'authors': 'M.~Crossley, P.~Glorioso, and H.~Liu',
        'title': 'JHEP',
        'journal': None,
        'volume': 1709,
        'page': None,
        'year': 2017,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper2_second_order/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper2_second_order/paper_draft.tex`.',
    },

    'Csaki2024': {
        'authors': "C.~Cs\'aki, R.~Ovadia, O.~Telem, J.~Terning, and A.~Yankielowicz, JHEP , 165 (2024); arXiv:2406.13738",
        'title': '',
        'journal': 'JHEP',
        'volume': 2024,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': '2406.13738',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5d/primary-sources/Csaki2024.pdf',
        'used_in': ['papers/paper5_adw_gap/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper5_adw_gap/paper_draft.tex`. Title not present in source bibitem.',
    },

    'DPR1991': {
        'authors': 'R.~Dijkgraaf, V.~Pasquier, and P.~Roche, Nucl.\\ Phys.\\ B (Proc.\\ Suppl.) , 60 (1991)',
        'title': '',
        'journal': None,
        'volume': 18,
        'page': None,
        'year': 1991,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper9_sm_anomaly_drinfeld/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper9_sm_anomaly_drinfeld/paper_draft.tex`. Title not present in source bibitem.',
    },

    'DarkSectorSynthesisLean': {
        'authors': 'Unknown',
        'title': 'lean/SKEFTHawking/DarkSectorSynthesis.lean',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper29_bbn_unified/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper29_bbn_unified/paper_draft.tex`.',
    },

    'Davies1990': {
        'authors': 'B.~Davies',
        'title': 'J.~Phys.~A',
        'journal': None,
        'volume': 23,
        'page': None,
        'year': 1990,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper8_chirality_master/paper_draft.tex`.',
    },

    'DolanGrady1982': {
        'authors': 'Dolan, L. and Grady, M.',
        'title': 'Conserved charges from self-duality',
        'journal': 'Physical Review D',
        'volume': 25,
        'page': '1587',
        'year': 1982,
        'doi': '10.1103/PhysRevD.25.1587',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex',
                    'papers/D2/paper_draft.tex'],
        'provides': [],
        'notes': 'Dolan-Grady relations underlying the Onsager algebra. Registry corrected 2026-05-11 (D2 Stage-13 fix-pass): venue is Phys. Rev. D 25, 1587 (1982), not Phys. Rev. Lett. 49 as the auto-stub recorded; D2 bibitem already had the correct PRD coordinates.',
    },

    'Drinfeld1986': {
        'authors': 'V.~G.~Drinfeld, Proc.\\ ICM Berkeley, 798 (1986)',
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 1986,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper11_quantum_group/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper11_quantum_group/paper_draft.tex`. Title not present in source bibitem.',
    },

    'FK2010': {
        'authors': 'L.~Fidkowski and A.~Kitaev',
        'title': 'Phys.~Rev.~B',
        'journal': None,
        'volume': 81,
        'page': None,
        'year': 2010,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper8_chirality_master/paper_draft.tex`.',
    },

    'FK2011': {
        'authors': 'L.~Fidkowski and A.~Kitaev',
        'title': 'Phys.~Rev.~B',
        'journal': None,
        'volume': 83,
        'page': None,
        'year': 2011,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper8_chirality_master/paper_draft.tex`.',
    },

    'FangGu2024': {
        'authors': "J.~Fang and Y.~Gu, ``Torsion-loop dark matter from Einstein-Cartan gravity,'' Phase 5x Wave 4 deep-research return",
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper29_bbn_unified/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper29_bbn_unified/paper_draft.tex`. Title not present in source bibitem.',
    },

    'FangGuLean': {
        'authors': 'Unknown',
        'title': 'lean/SKEFTHawking/FangGuTorsionDM.lean',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper29_bbn_unified/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper29_bbn_unified/paper_draft.tex`.',
    },

    'Fernandes2019': {
        'authors': "R.~M.~Fernandes, P.~P.~Orth, and J.~Schmalian, ``Intertwined vestigial order in quantum materials: nematicity and beyond,'' Annu.\\ Rev.\\ Condens.\\ Matter Phys.\\ , 133 (2019)",
        'title': '',
        'journal': None,
        'volume': 10,
        'page': None,
        'year': 2019,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper6_vestigial/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper6_vestigial/paper_draft.tex`. Title not present in source bibitem.',
    },

    'FidkowskiKitaev2010': {
        'authors': 'Fidkowski, L. and Kitaev, A.',
        'title': 'The effects of interactions on the topological classification of free fermion systems',
        'journal': 'Physical Review B',
        'volume': 81,
        'page': '134509',
        'year': 2010,
        'doi': '10.1103/PhysRevB.81.134509',
        'arxiv': '0904.2197',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5e/primary-sources/FidkowskiKitaev2010.pdf',
        'used_in': ['papers/paper10_modular_generation/paper_draft.tex',
                    'papers/L2/paper_draft.tex',
                    'papers/D2/paper_draft.tex'],
        'provides': ['Interacting reduction of the 2D class-D free-fermion Z to Z_16 (the sixteenfold way under interactions); load-bearing for the Z_16 anomaly chain in L2/D2.'],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper10_modular_generation/paper_draft.tex`. Title not present in source bibitem.',
    },

    'FractonDarkMatterLean': {
        'authors': 'Unknown',
        'title': 'lean/SKEFTHawking/FractonDarkMatter.lean',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper29_bbn_unified/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper29_bbn_unified/paper_draft.tex`.',
    },

    'FreedHopkins2021': {
        'authors': 'D.~S.~Freed and M.~J.~Hopkins',
        'title': 'Ann.~Math.',
        'journal': None,
        'volume': 194,
        'page': None,
        'year': 2021,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper8_chirality_master/paper_draft.tex`.',
    },

    'GKSW2015': {
        'authors': 'D.~Gaiotto, A.~Kapustin, N.~Seiberg, and B.~Willett, JHEP , 172 (2015)',
        'title': '',
        'journal': 'JHEP',
        'volume': 2,
        'page': None,
        'year': 2015,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper3_gauge_erasure/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper3_gauge_erasure/paper_draft.tex`. Title not present in source bibitem.',
    },

    'GarciaEtxebarria2019': {
        'authors': "García-Etxebarria, I. and Montero, M.",
        'title': 'Dai-Freed anomalies in particle physics',
        'journal': 'Journal of High Energy Physics',
        'volume': 8,
        'page': '003',
        'year': 2019,
        'doi': '10.1007/JHEP08(2019)003',
        'arxiv': '1808.00009',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5e/primary-sources/GarciaEtxebarria2019.pdf',
        'used_in': ['papers/paper10_modular_generation/paper_draft.tex',
                    'papers/paper9_sm_anomaly_drinfeld/paper_draft.tex',
                    'papers/L2/paper_draft.tex',
                    'papers/D2/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper10_modular_generation/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Gavela1994': {
        'authors': 'M.~B.~Gavela, P.~Hernandez, J.~Orloff, and O.~Pene',
        'title': 'Standard Model CP-violation and baryon asymmetry',
        'journal': None,
        'volume': 9,
        'page': None,
        'year': 1994,
        'doi': None,
        'arxiv': 'hep-ph/9312215',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/Gavela1994.pdf',
        'used_in': ['papers/paper33_ewbg_chirality_wall/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper33_ewbg_chirality_wall/paper_draft.tex`.',
    },

    'Geurs2025': {
        'authors': 'J.~Geurs, T.~A.~Webb, Y.~Guo, I.~Keren, J.~H.~Farrell, J.~Xu, K.~Watanabe, T.~Taniguchi, D.~N.~Basov, J.~Hone, A.~Lucas, A.~Pasupathy, C.~R.~Dean',
        'title': 'Supersonic flow and hydraulic jump in an electronic de Laval nozzle',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2509.16321',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Geurs2025.pdf',
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex',
                    'papers/D1/paper_draft.tex',
                    'papers/E2/paper_draft.tex'],
        'provides': [],
        'notes': 'Originally an auto-generated stub from the \\bibitem block in '
                 '`papers/paper16_graphene_sk_eft/paper_draft.tex`, whose parser wrote '
                 "title='et~al.' — the same artifact round-1 BLOCKER 1.4 flagged on "
                 'Majumdar2025. Repaired to the verbatim title and the full author list; '
                 'E2 used_in added 2026-05-11, D1 used_in added 2026-08-14 (D1 cites this '
                 'key at §1 and had been omitted, the last open half of Stage-13 finding '
                 '2026-05-06-bundle-stage13:D1-r2:1.3). doi_verified stays False because '
                 'the work carries NO DOI: it is an arXiv preprint (2509.16321) with no '
                 'journal version, so True would assert a verification of a nonexistent '
                 'identifier. Title/authors are verified against the cached primary source '
                 'by validate.py --check bibitem_title_primary_source.',
    },

    # DEPRECATED ALIAS — `GioiaTh2026` historically used by paper7 + paper8 with
    # wrong first-author initial ('D.~Gioia'); content-equivalent to
    # `GioiaThorngrenPRL2026` (the canonical bibkey after Phase 7 Session 6
    # consolidation, 2026-05-11). The entry is retained as a duplicate-content
    # alias so existing `\cite{GioiaTh2026}` in paper7/paper8 still resolve;
    # downstream papers should use `GioiaThorngrenPRL2026`.
    'GioiaTh2026': {
        'authors': 'Gioia, L. and Thorngren, R.',
        'title': 'Exact Chiral Symmetries of 3+1D Hamiltonian Lattice Fermions',
        'journal': 'Physical Review Letters',
        'volume': 136,
        'page': '061601',
        'year': 2026,
        'doi': None,
        'arxiv': '2503.07708',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5e/primary-sources/GioiaTh2026.pdf',
        'used_in': ['papers/paper7_chirality_formal/paper_draft.tex',
                    'papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'DEPRECATED ALIAS for GioiaThorngrenPRL2026 (same arxiv 2503.07708; same PRL coordinates). Verified 2026-05-11 via WebFetch arXiv:2503.07708 (D2 Stage-13 fix-pass): first-author initial is L (Lei), not D as previously recorded; actual title "Exact Chiral Symmetries of 3+1D Hamiltonian Lattice Fermions"; journal-ref Phys. Rev. Lett. 136, 061601 (2026). Original auto-stub note: "Title not present in source bibitem."',
    },

    'GioiaThorngrenPRL2026': {
        'authors': 'Gioia, L. and Thorngren, R.',
        'title': 'Exact Chiral Symmetries of 3+1D Hamiltonian Lattice Fermions',
        'journal': 'Physical Review Letters',
        'volume': 136,
        'page': '061601',
        'year': 2026,
        'doi': None,
        'arxiv': '2503.07708',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5e/primary-sources/GioiaTh2026.pdf',
        'used_in': ['papers/paper9_sm_anomaly_drinfeld/paper_draft.tex',
                    'papers/D2/paper_draft.tex'],
        'provides': [],
        'notes': 'Canonical bibkey for Gioia-Thorngren arxiv 2503.07708 / PRL 136, 061601 (2026). Verified 2026-05-11 via WebFetch arXiv:2503.07708 (D2 Stage-13 fix-pass): first-author initial is L (Lei), title "Exact Chiral Symmetries of 3+1D Hamiltonian Lattice Fermions". Prior stub had wrong initial M, empty title, no arxiv. Cross-bundle: `GioiaTh2026` retained as deprecated alias for paper7/paper8.',
    },

    'GrossJackiw1972': {
        'authors': 'Gross, D. J. and Jackiw, R.',
        'title': 'Effect of anomalies on quasi-renormalizable theories',
        'journal': 'Physical Review D',
        'volume': 6,
        'page': '477',
        'year': 1972,
        'doi': '10.1103/PhysRevD.6.477',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper10_modular_generation/paper_draft.tex',
                    'papers/paper9_sm_anomaly_drinfeld/paper_draft.tex',
                    'papers/L2/paper_draft.tex',
                    'papers/D2/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper10_modular_generation/paper_draft.tex`. Title not present in source bibitem.',
    },

    'GrozdanovHofmanIqbal': {
        'authors': 'S.~Grozdanov, D.~M.~Hofman, and N.~Iqbal, Phys.\\ Rev.\\ D , 096003 (2017)',
        'title': '',
        'journal': None,
        'volume': 95,
        'page': None,
        'year': 2017,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper3_gauge_erasure/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper3_gauge_erasure/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Heading1962': {
        'authors': 'J.~Heading',
        'title': 'An Introduction to Phase-Integral Methods',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper4_wkb_connection/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper4_wkb_connection/paper_draft.tex`.',
    },

    'HiddenSectorClassificationLean': {
        'authors': 'Unknown',
        'title': 'lean/SKEFTHawking/HiddenSectorClassification.lean',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper29_bbn_unified/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper29_bbn_unified/paper_draft.tex`.',
    },

    'HofmanIqbal': {
        'authors': 'D.~M.~Hofman and N.~Iqbal, SciPost Phys.\\ , 006 (2019)',
        'title': '',
        'journal': None,
        'volume': 6,
        'page': None,
        'year': 2019,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper3_gauge_erasure/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper3_gauge_erasure/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Huet1994': {
        'authors': 'P.~Huet and E.~Sather',
        'title': 'Electroweak baryogenesis and Standard Model CP violation',
        'journal': None,
        'volume': 51,
        'page': None,
        'year': 1995,
        'doi': None,
        'arxiv': 'hep-ph/9404302',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/Huet1994.pdf',
        'used_in': ['papers/paper33_ewbg_chirality_wall/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper33_ewbg_chirality_wall/paper_draft.tex`.',
    },

    'InonuWigner1953': {
        'authors': 'E.~In\"on\"u and E.~P.~Wigner',
        'title': 'Proc.~Natl.~Acad.~Sci.',
        'journal': None,
        'volume': 39,
        'page': None,
        'year': 1953,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper8_chirality_master/paper_draft.tex`.',
    },

    'Iorio2012': {
        'authors': 'A.~Iorio and G.~Lambiase, Phys. Lett. B , 334 (2012)',
        'title': '',
        'journal': 'Phys. Lett. B',
        'volume': 716,
        'page': None,
        'year': 2012,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_graphene_sk_eft/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Jacobson1996': {
        'authors': 'T.~Jacobson',
        'title': 'Phys.\\ Rev.\\ D',
        'journal': None,
        'volume': 53,
        'page': None,
        'year': 1996,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper1_first_order/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper1_first_order/paper_draft.tex`.',
    },

    'Jimbo1986': {
        'authors': 'M.~Jimbo, Lett.\\ Math.\\ Phys.\\ , 247 (1986)',
        'title': '',
        'journal': None,
        'volume': 11,
        'page': None,
        'year': 1986,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper11_quantum_group/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper11_quantum_group/paper_draft.tex`. Title not present in source bibitem.',
    },

    'KSS2005': {
        'authors': 'Kovtun, P., Son, D. T., Starinets, A. O.',
        'title': 'Viscosity in Strongly Interacting Quantum Field Theories from Black Hole Physics',
        'journal': 'Physical Review Letters',
        'volume': 94,
        'page': '111601',
        'year': 2005,
        'doi': '10.1103/PhysRevLett.94.111601',
        'arxiv': 'hep-th/0405231',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex', 'papers/D3/paper_draft.tex'],
        'provides': ['Holographic shear viscosity bound η/s ≥ ℏ/(4π k_B); load-bearing for D3 §14 transport regime classification.'],
        'notes': 'Verified 2026-05-11 via WebFetch arXiv:hep-th/0405231 (D3 Stage-13 fix-pass). Title corrected from stub-empty to canonical published form; metadata restored from auto-generated stub.',
    },

    'Kitaev2003': {
        'authors': 'Kitaev, A. Yu.',
        'title': 'Fault-tolerant quantum computation by anyons',
        'journal': 'Annals of Physics',
        'volume': 303,
        'page': '2',
        'year': 2003,
        'doi': '10.1016/S0003-4916(02)00018-0',
        'arxiv': 'quant-ph/9707021',
        'doi_verified': '2026-05-11',
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5b/primary-sources/Kitaev2003.pdf',
        'used_in': [
            'papers/paper9_sm_anomaly_drinfeld/paper_draft.tex',
            'papers/D4/paper_draft.tex',
        ],
        'provides': ['Foundational topological-quantum-computation reference; anyonic braiding for fault tolerance.'],
        'notes': 'Verified 2026-05-11 via WebFetch arXiv:quant-ph/9707021 (D4 Stage-13 fix-pass). Title, author string, journal, and arXiv ID populated from canonical published form; metadata restored from auto-generated stub.',
    },

    # ────────────────────────────────────────────────────────────────────
    # Phase 6t — Solovay-Kitaev quantitative compilation (D4 §9 prose)
    # Introduced by Stage 10.E D4 §9 prose commit 62f1185 (2026-05-23).
    # ────────────────────────────────────────────────────────────────────

    'AharonovArad2011': {
        'authors': 'Aharonov, D. and Arad, I.',
        'title': 'The BQP-hardness of approximating the Jones polynomial',
        'journal': 'New Journal of Physics',
        'volume': 13,
        'page': '035019',
        'year': 2011,
        'doi': '10.1088/1367-2630/13/3/035019',
        'arxiv': 'quant-ph/0605181',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/AharonovArad2011.abstract.txt',
        'used_in': ['papers/D4/paper_draft.tex', 'papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Bibkey renamed AharonovArad2017 -> AharonovArad2011 on 2026-06-10 '
                 '(review-2026-06-05 D8 finding: misleading year suffix inherited from an '
                 'earlier phase); actual publication year is 2011 (New J. Phys. 13, 035019) '
                 'with arXiv preprint 2006. Lemma 6.1 provides group-commutator '
                 'quadratic-shrinkage substrate consumed by the F.21 density argument. '
                 'arXiv ID verified via arxiv.org 2026-05-23. DOI verified 2026-06-10: '
                 'doi.org resolves to iopscience.iop.org article page with matching title, '
                 'authors (Dorit Aharonov, Itai Arad), NJP 13, 035019 (2011). Cache file '
                 'renamed in lockstep.',
    },

    'DawsonNielsen2006': {
        'authors': 'Dawson, C. M. and Nielsen, M. A.',
        'title': 'The Solovay-Kitaev algorithm',
        'journal': 'Quantum Information and Computation',
        'volume': 6,
        'page': '81-95',
        'year': 2006,
        'doi': None,
        'arxiv': 'quant-ph/0505030',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/DawsonNielsen2006.abstract.txt',
        'used_in': ['papers/D4/paper_draft.tex', 'papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Canonical reference for the polylogarithmic length bound of the Solovay-Kitaev algorithm. Cited in D4 §9 Stage 10.E prose alongside KitaevShenVyalyi2002 (existence form) and AharonovArad2011 (group-commutator substrate). No DOI: QIC vol. 6 (Rinton Press) does not register article DOIs; arXiv quant-ph/0505030 is the canonical locator.',
    },

    'KitaevShenVyalyi2002': {
        'authors': 'Kitaev, A. Yu., Shen, A. H., Vyalyi, M. N.',
        'title': 'Classical and Quantum Computation',
        'journal': 'Graduate Studies in Mathematics',
        'volume': 47,
        'page': None,
        'year': 2002,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,  # textbook — no arXiv PDF
        'citation_class': 'textbook',
        'exempt_reason': 'AMS Graduate Studies in Mathematics 47, ISBN '
                         '978-0-8218-2161-8; the Solovay-Kitaev existence form (Thm 8.3) '
                         'is verified via the Dawson-Nielsen quantitative refinement '
                         'literature.',
        'used_in': ['papers/D4/paper_draft.tex', 'papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'American Mathematical Society, Graduate Studies in Mathematics vol. 47 (ISBN 978-0-8218-2161-8). Textbook existence-form statement of the Solovay-Kitaev theorem (Theorem 8.3), prior to Dawson-Nielsen quantitative refinement. Textbook-exempt per validate.py textbook rule (no arXiv, primary-source-path None). No DOI on record for the book; doi_verified not applicable (2026-06-10 review pass).',
    },

    # ════════════════════════════════════════════════════════════════
    # D8 — Kernel-Verified Universal Quantum Gate Compilation
    # (Phase 6p/6t/6u/6x/6x'/6y/6z verified-compilation corpus).
    # arXiv IDs web-verified 2026-05-31; abstracts cached under
    # Lit-Search/Phase-1-and-Background/primary-sources/.
    # ════════════════════════════════════════════════════════════════

    'BMPRV1999': {
        'authors': 'Boykin, P. O. and Mor, T. and Pulver, M. and Roychowdhury, V. and Vatan, F.',
        'title': 'On universal and fault-tolerant quantum computing',
        'journal': 'Proc. 40th Annual Symposium on Foundations of Computer Science (FOCS)',
        'volume': None,
        'page': '486-494',
        'year': 1999,
        'doi': None,
        'arxiv': 'quant-ph/9906054',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/BMPRV1999.abstract.txt',
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Universality of {H, T, CNOT} (Clifford+T). Source of the algebraic-integer (Niven-style) density argument for <H,T> dense in SU(2). arXiv ID verified 2026-05-31.',
    },

    'ReadRezayi1999': {
        'authors': 'Read, N. and Rezayi, E.',
        'title': 'Beyond paired quantum Hall states: parafermions and incompressible states in the first excited Landau level',
        'journal': 'Physical Review B',
        'volume': 59,
        'page': '8084',
        'year': 1999,
        'doi': '10.1103/PhysRevB.59.8084',
        'arxiv': 'cond-mat/9809384',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/ReadRezayi1999.abstract.txt',
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Read-Rezayi SU(2)_k parafermion series; the universal-anyon family beyond Fibonacci (k=3). Levels k=5, k=7 instantiated as D8 compilation alphabets. arXiv ID verified 2026-05-31.',
    },

    'Brylinski2002': {
        'authors': 'Brylinski, J.-L. and Brylinski, R.',
        'title': 'Universal quantum gates',
        'journal': 'Mathematics of Quantum Computation (Chapman & Hall/CRC)',
        'volume': None,
        'page': None,
        'year': 2002,
        'doi': None,
        'arxiv': 'quant-ph/0108062',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Brylinski2002.abstract.txt',
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Entangling-gate universality criterion; the SU(4) density witness for the trapped-ion Molmer-Sorensen alphabet. arXiv ID verified 2026-05-31.',
    },

    'AaronsonGottesman2004': {
        'authors': 'Aaronson, S. and Gottesman, D.',
        'title': 'Improved simulation of stabilizer circuits',
        'journal': 'Physical Review A',
        'volume': 70,
        'page': '052328',
        'year': 2004,
        'doi': '10.1103/PhysRevA.70.052328',
        'arxiv': 'quant-ph/0406196',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/AaronsonGottesman2004.abstract.txt',
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Clifford-group structure; SU(8) Clifford+T density route (Route A). arXiv ID is quant-ph/0406196 (NOT 0403025, which is Bravyi-Kitaev). Verified 2026-05-31.',
    },

    'Mukhopadhyay2024': {
        'authors': 'Mukhopadhyay, P.',
        'title': 'Synthesizing Toffoli-optimal quantum circuits for arbitrary multi-qubit unitaries',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': '2401.08950',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Mukhopadhyay2024.abstract.txt',
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Channel-representation resource theory for Clifford+Toffoli (=Clifford+CCZ); Lemma 3.10 dyadic entries + Toffoli-cost lower bound T^of >= sde_2. Title + sole author verified 2026-05-31.',
    },

    'KMM2013': {
        'authors': 'Kliuchnikov, V. and Maslov, D. and Mosca, M.',
        'title': 'Fast and efficient exact synthesis of single qubit unitaries generated by Clifford and T gates',
        'journal': 'Quantum Information and Computation',
        'volume': 13,
        'page': '607-630',
        'year': 2013,
        'doi': None,
        'arxiv': '1206.5236',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/KMM2013.abstract.txt',
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Exact synthesis of single-qubit Clifford+T unitaries over Z[1/sqrt2, i]; algorithmic-synthesis route (future work, out of D8 verified-existence scope). arXiv ID verified 2026-05-31.',
    },

    'Hietala2020VOQC': {
        'authors': 'Hietala, K. and Rand, R. and Hung, S.-H. and Wu, X. and Hicks, M.',
        'title': 'A verified optimizer for quantum circuits',
        'journal': 'Proc. ACM Program. Lang. (POPL)',
        'volume': 5,
        'page': 'Article 37',
        'year': 2021,
        'doi': '10.1145/3434318',
        'arxiv': '1912.02250',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Hietala2020VOQC.abstract.txt',
        'used_in': ['papers/D8/paper_draft.tex', 'papers/D6/paper_draft.tex'],
        'provides': [],
        'notes': 'VOQC/SQIR (Coq) — prior verified-QC compiler work; cited in D8 §1 for prior-art positioning (exact circuit optimization vs D8 quantitative-approximation theory) and in D6 §1 (equivalence-preserving optimization vs D6 FT-substrate chain). arXiv ID verified 2026-05-31.',
    },

    'Chareton2021Qbricks': {
        'authors': 'Chareton, C. and Bardin, S. and Bobot, F. and Perrelle, V. and Valiron, B.',
        'title': 'An Automated Deductive Verification Framework for Circuit-building Quantum Programs',
        'journal': 'Programming Languages and Systems (ESOP 2021), Lecture Notes in Computer Science',
        'volume': 12648,
        'page': '148-177',
        'year': 2021,
        'doi': '10.1007/978-3-030-72019-3_6',
        'arxiv': '2003.05841',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Chareton2021Qbricks.pdf',
        'used_in': ['papers/D6/paper_draft.tex'],
        'provides': [],
        'notes': 'Qbricks — Why3-based deductive verification of parametrized circuit-building quantum programs (QPE, Grover case studies); cited in D6 §1 prior-art positioning. Title/authors/venue Crossref-verified against DOI 2026-06-10 (published ESOP 2021 chapter title carries "An Automated ..."; the latest arXiv version title drops "Automated").',
    },

    'Lewis2021VerifQC': {
        'authors': 'Lewis, M. and Soudjani, S. and Zuliani, P.',
        'title': 'Formal Verification of Quantum Programs: Theory, Tools and Challenges',
        'journal': 'ACM Trans. Quantum Comput.',
        'volume': 5,
        'page': 'Article 1, 1-35',
        'year': 2024,
        'doi': '10.1145/3624483',
        'arxiv': '2110.01320',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Lewis2021VerifQC.abstract.txt',
        'used_in': ['papers/D8/paper_draft.tex', 'papers/D6/paper_draft.tex'],
        'provides': [],
        'notes': 'Survey of the verified-quantum-programs landscape (NOT Qbricks — a Stage-13 reviewer mis-identified this ID). Cited in D8 §1 as the umbrella prior-art reference and in D6 §1. arXiv ID verified 2026-05-31; bibkey year retains the 2021 arXiv submission, published-version metadata (ACM TQC 5(1), Article 1, March 2024, DOI 10.1145/3624483) Crossref-verified 2026-06-10.',
    },

    'RossSelinger2016': {
        'authors': 'Ross, N. J. and Selinger, P.',
        'title': 'Optimal ancilla-free Clifford+T approximation of z-rotations',
        'journal': 'Quantum Information and Computation',
        'volume': 16,
        'page': '901-953',
        'year': 2016,
        'doi': None,
        'arxiv': '1403.2975',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/RossSelinger2016.abstract.txt',
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Optimal ancilla-free Clifford+T z-rotation synthesis over Z[omega][1/sqrt2]; length-optimal route (future work, out of D8 verified-existence scope). arXiv ID verified 2026-05-31.',
    },

    'Lickorish1997': {
        'authors': 'Lickorish, W. B. R.',
        'title': 'An Introduction to Knot Theory',
        'journal': 'Graduate Texts in Mathematics',
        'volume': 175,
        'page': None,
        'year': 1997,
        'doi': '10.1007/978-1-4612-0691-0',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,  # textbook — no arXiv PDF
        'citation_class': 'textbook',
        'exempt_reason': 'Springer GTM 175 knot-theory monograph. DOI recorded (verified '
                         'against Springer 2026-05-11) — the exemption is the reference '
                         'CLASS, not the absence of an identifier; there is still no '
                         'cacheable full text.',
        'used_in': ['papers/D4/paper_draft.tex'],
        'provides': ['Lickorish surgery presentation of 3-manifolds; foundational knot-theory reference for WRT TQFT surgery formula.'],
        'notes': 'Springer Graduate Texts in Mathematics 175 (textbook). DOI 10.1007/978-1-4612-0691-0 verified via Springer 2026-05-11; textbook-exempt per validate.py textbook rule (no arXiv, primary-source-path None).',
    },

    'Kolb2014': {
        'authors': 'S.~Kolb, Adv.\\ Math.\\ , 395 (2014) [arXiv:1206.2117]',
        'title': '',
        'journal': None,
        'volume': 267,
        'page': None,
        'year': 2014,
        'doi': None,
        'arxiv': '1206.2117',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5c/primary-sources/Kolb2014.pdf',
        'used_in': ['papers/paper11_quantum_group/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper11_quantum_group/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Kondo1989': {
        'authors': 'K.-I.~Kondo, H.~Mino, and K.~Yamawaki, Phys.\\ Rev.\\ D , 2430 (1989)',
        'title': '',
        'journal': None,
        'volume': 39,
        'page': None,
        'year': 1989,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper5_adw_gap/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper5_adw_gap/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Majumdar2025': {
        'authors': 'A.~Majumdar, N.~Chadha, P.~Pal, A.~Gugnani, B.~Ghawri, K.~Watanabe, T.~Taniguchi, S.~Mukerjee, A.~Ghosh',
        'title': 'Universality in quantum critical flow of charge and heat in ultra-clean graphene',
        'journal': 'Nature Physics',
        'volume': 21,
        'page': '1374',
        'year': 2025,
        'doi': None,
        'arxiv': '2501.03193',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex', 'papers/D1/paper_draft.tex', 'papers/E2/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_graphene_sk_eft/paper_draft.tex`.',
    },

    'NastaseSonnenschein2025': {
        'authors': 'H.~Nastase and J.~Sonnenschein, arXiv:2502.13765 (2025)',
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2502.13765',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-3/primary-sources/NastaseSonnenschein2025.pdf',
        'used_in': ['papers/paper3_gauge_erasure/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper3_gauge_erasure/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Nielsen1981a': {
        'authors': 'Nielsen, H. B. and Ninomiya, M.',
        'title': 'Absence of neutrinos on a lattice. I. Proof by homotopy theory',
        'journal': 'Nuclear Physics B',
        'volume': 185,
        'page': '20',
        'year': 1981,
        'doi': '10.1016/0550-3213(81)90361-8',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper7_chirality_formal/paper_draft.tex',
                    'papers/paper8_chirality_master/paper_draft.tex',
                    'papers/D2/paper_draft.tex'],
        'provides': [],
        'notes': 'Nielsen-Ninomiya theorem paper I (NPB 185:20, 1981). Registry aligned 2026-05-11 to D2 bundle bibitem mapping (Stage-13 fix-pass): Nielsen1981a → NPB I, Nielsen1981b → NPB II. Prior registry recorded PLB 105:219 (1981) — a different Nielsen-Ninomiya paper ("No-go theorem for regularizing chiral fermions"). The PLB paper is no longer registered; if a paper needs that reference it should use a new bibkey (e.g. NielsenNinomiya1981PLB).',
    },

    'Nielsen1981b': {
        'authors': 'Nielsen, H. B. and Ninomiya, M.',
        'title': 'Absence of neutrinos on a lattice. II. Intuitive topological proof',
        'journal': 'Nuclear Physics B',
        'volume': 193,
        'page': '173',
        'year': 1981,
        'doi': '10.1016/0550-3213(81)90524-1',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper7_chirality_formal/paper_draft.tex',
                    'papers/paper8_chirality_master/paper_draft.tex',
                    'papers/D2/paper_draft.tex'],
        'provides': [],
        'notes': 'Nielsen-Ninomiya theorem paper II (NPB 193:173, 1981). Registry aligned 2026-05-11 to D2 bundle bibitem mapping (Stage-13 fix-pass). Prior registry recorded NPB 185:20 (which is the paper-I content) under this bibkey.',
    },

    'Oertel2000': {
        'authors': 'M.~Oertel, M.~Buballa, and J.~Wambach, Phys.\\ Lett.\\ B , 77 (2000)',
        'title': '',
        'journal': None,
        'volume': 477,
        'page': None,
        'year': 2000,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper5_adw_gap/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper5_adw_gap/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Onsager1944': {
        'authors': 'L.~Onsager',
        'title': 'Phys.~Rev.',
        'journal': None,
        'volume': 65,
        'page': None,
        'year': 1944,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper8_chirality_master/paper_draft.tex`.',
    },

    'Paper10': {
        'authors': 'J.~Roehm, companion paper: From modular forms to generation counting',
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper11_quantum_group/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper11_quantum_group/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Paper5': {
        'authors': "J.~Roehm, ``Mean-field gap equation for tetrad condensation in the Akama-Diakonov-Wetterich mechanism: A fermion bootstrap test at Level~2,'' companion paper (Paper~5)",
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper6_vestigial/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper6_vestigial/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Paper8': {
        'authors': "J.~Roehm, ``The Chirality Wall: A Three-Pillar Formal Verification Survey in Lean~4'' (2026), companion paper",
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper7_chirality_formal/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper7_chirality_formal/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Paper9': {
        'authors': 'J.~Roehm, companion paper: SM anomaly in $Z_16$ + Drinfeld center',
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper11_quantum_group/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper11_quantum_group/paper_draft.tex`. Title not present in source bibitem.',
    },

    'PaperI': {
        'authors': "J.~Roehm, ``Dissipative EFT Corrections to Analog Hawking Radiation in BEC Sonic Black Holes,'' (2026). [Paper~I of this series.]",
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper2_second_order/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper2_second_order/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Phase6bRoadmap': {
        'authors': 'Unknown',
        'title': 'docs/roadmaps/Phase6b\\_Roadmap.md',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper29_bbn_unified/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper29_bbn_unified/paper_draft.tex`.',
    },

    'Planck2020VI': {
        'authors': "Planck Collaboration, ``Planck 2020 results VI: cosmological parameters,'' A\\&A , A6 (2020), arXiv:1807.06209",
        'title': '',
        'journal': None,
        'volume': 641,
        'page': None,
        'year': 2020,
        'doi': None,
        'arxiv': '1807.06209',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6b/primary-sources/Planck2020VI.pdf',
        'used_in': ['papers/paper29_bbn_unified/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper29_bbn_unified/paper_draft.tex`. Title not present in source bibitem.',
    },

    'ProfumoRamsey2007': {
        'authors': 'S.~Profumo, M.~J.~Ramsey-Musolf, and G.~Shaughnessy',
        'title': 'Singlet Higgs phenomenology and the electroweak phase transition',
        'journal': 'JHEP',
        'volume': 8,
        'page': None,
        'year': 2007,
        'doi': None,
        'arxiv': '0705.2425',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/ProfumoRamsey2007.pdf',
        'used_in': ['papers/paper33_ewbg_chirality_wall/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper33_ewbg_chirality_wall/paper_draft.tex`.',
    },

    'Rademacher1973': {
        'authors': 'H.~Rademacher',
        'title': 'Topics in Analytic Number Theory',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper10_modular_generation/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper10_modular_generation/paper_draft.tex`.',
    },

    'Roehm2026LinearizedEFE': {
        'authors': 'J.~G.~Roehm',
        'title': 'Linearized Einstein Equations from Anderson--Higgs Tetrad Condensation',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/paper23_linearized_efe/paper_draft.tex',
                    'papers/paper25_gravitational_waves/paper_draft.tex',
                    'papers/L1/paper_draft.tex'],
        'provides': [],
        'notes': 'Companion paper23 (Phase 6a Wave 1, in preparation). Title verified against papers/paper23_linearized_efe/paper_draft.tex `\\title{...}` line 2026-05-01. inprep=True per Pipeline Invariant #11 — exempt from primary-source-cache requirement.',
    },

    'Rokhlin1952': {
        'authors': 'Rokhlin, V. A.',
        'title': 'New results in the theory of four-dimensional manifolds',
        'journal': 'Doklady Akademii Nauk SSSR',
        'volume': 84,
        'page': '221',
        'year': 1952,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper10_modular_generation/paper_draft.tex',
                    'papers/L2/paper_draft.tex'],
        'provides': ['Rokhlin signature theorem (16 | sigma for spin 4-manifolds); foundational anchor for the L2 modular-discriminant chain (16 in 24 | c_- = 8 N_f).'],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper10_modular_generation/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Romatschke2010': {
        'authors': 'P.~Romatschke, Int. J. Mod. Phys. E , 1 (2010)',
        'title': '',
        'journal': 'Int. J. Mod. Phys. E',
        'volume': 19,
        'page': None,
        'year': 2010,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_graphene_sk_eft/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Roy2016': {
        'authors': "B.~Roy, V.~Jurici\'c, and I.~F.~Herbut, JHEP , 018 (2016)",
        'title': '',
        'journal': 'JHEP',
        'volume': 4,
        'page': None,
        'year': 2016,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper5_adw_gap/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper5_adw_gap/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Sbordone2010': {
        'authors': 'L.~Sbordone, P.~Bonifacio, E.~Caffau, H.-G.~Ludwig, N.~T.~Behara, J.~I.~Gonzalez Hernandez, M.~Steffen, R.~Cayrel, B.~Freytag, C.~Van''t Veer, P.~Molaro, B.~Plez, T.~Sivarani, M.~Spite, F.~Spite, T.~C.~Beers, N.~Christlieb, P.~Francois, V.~Hill',
        'title': 'The metal-poor end of the Spite plateau. 1: Stellar parameters, metallicities and lithium abundances',
        'journal': None,
        'volume': 522,
        'page': None,
        'year': 2010,
        'doi': None,
        'arxiv': '1003.4510',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6b/primary-sources/Sbordone2010.pdf',
        'used_in': ['papers/paper29_bbn_unified/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper29_bbn_unified/paper_draft.tex`.',
    },

    'Seiberg2023': {
        'authors': 'N.~Seiberg, arXiv:2211.12543 (2023)',
        'title': 'SciPost Phys.',
        'journal': None,
        'volume': 15,
        'page': None,
        'year': 2023,
        'doi': None,
        'arxiv': '2211.12543',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5h/primary-sources/Seiberg2023.pdf',
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper8_chirality_master/paper_draft.tex`.',
    },

    'SeibergShao2024': {
        'authors': 'N.~Seiberg and S.-H.~Shao',
        'title': 'SciPost Phys.',
        'journal': None,
        'volume': 16,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': '2307.02534',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5h/primary-sources/SeibergShao2024.pdf',
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper8_chirality_master/paper_draft.tex`.',
    },

    'Selch2025': {
        'authors': 'M.~Selch and M.~A.~Zubkov, Symmetry , 1045 (2025)',
        'title': '',
        'journal': 'Symmetry',
        'volume': 17,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper5_adw_gap/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper5_adw_gap/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Sexty2013': {
        'authors': "D.~Sexty and C.~Wetterich, ``Emergent gravity in two dimensions,'' Nucl.\\ Phys.\\ B , 290 (2013)",
        'title': '',
        'journal': None,
        'volume': 867,
        'page': None,
        'year': 2013,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper6_vestigial/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper6_vestigial/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Son2002': {
        'authors': 'Son, D. T.',
        'title': 'Low-Energy Quantum Effective Action for Relativistic Superfluids',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2002,
        'doi': None,
        'arxiv': 'hep-ph/0204199',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper1_first_order/paper_draft.tex',
                    'papers/D1/paper_draft.tex'],
        'provides': [],
        'notes': "Son's superfluid effective-action preprint (4 pages, INT-PUB 02-35). No traditional journal publication; lives as arXiv hep-ph/0204199 only. Registry entry repaired 2026-05-11 (D1 Stage-13 fix-pass: prior auto-stub had title='Phys.\\ Rev.\\ D', year=2013, no arXiv/DOI — completely wrong).",
    },

    'Steinhauer2019': {
        'authors': 'J.~Steinhauer',
        'title': 'Nat.\\ Phys.',
        'journal': None,
        'volume': 12,
        'page': None,
        'year': 2019,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper1_first_order/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper1_first_order/paper_draft.tex`.',
    },

    'Stolz1993': {
        'authors': 'S.~Stolz, Math.\\ Ann.\\ , 685 (1993)',
        'title': '',
        'journal': None,
        'volume': 296,
        'page': None,
        'year': 1993,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper9_sm_anomaly_drinfeld/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper9_sm_anomaly_drinfeld/paper_draft.tex`. Title not present in source bibitem.',
    },

    'TPF2024': {
        'authors': 'R.~Thorngren, J.~Preskill, and L.~Fidkowski, arXiv:2601.04304 (2026)',
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': '2601.04304',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5e/primary-sources/TPF2024.pdf',
        'used_in': ['papers/paper7_chirality_formal/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper7_chirality_formal/paper_draft.tex`. Title not present in source bibitem.',
    },

    'TPF2026': {
        'authors': 'Thorngren, R. and Preskill, J. and Fidkowski, L.',
        'title': 'Chiral Lattice Gauge Theories from Symmetry Disentanglers',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': '2601.04304',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5h/primary-sources/TPF2026.pdf',
        'used_in': ['papers/paper7_chirality_formal/paper_draft.tex',
                    'papers/paper8_chirality_master/paper_draft.tex',
                    'papers/D2/paper_draft.tex'],
        'provides': [],
        'notes': 'Verified 2026-05-11 via WebFetch arXiv:2601.04304 (D2 Stage-13 fix-pass): actual title "Chiral Lattice Gauge Theories from Symmetry Disentanglers" (not "Two-Particle Family construction for chiral fermions" as previously recorded); preprint submitted January 7, 2026, no formal publication venue. "TPF" remains project shorthand for the Two-Particle-Family construction discussed in the paper.',
    },

    'Talanov2024': {
        'authors': 'A.~Talanov, J.~Waissman, A.~Hui, B.~Skinner, K.~Watanabe, T.~Taniguchi, P.~Kim',
        'title': 'Observation of Electronic Viscous Dissipation in Graphene Magneto-thermal Transport',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': '2406.13799',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/Talanov2024.pdf',
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_graphene_sk_eft/paper_draft.tex`.',
    },

    'Terwilliger2001': {
        'authors': 'P.~Terwilliger, arXiv:math/0307016',
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': 'math/0307016',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5c/primary-sources/Terwilliger2001.pdf',
        'used_in': ['papers/paper11_quantum_group/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper11_quantum_group/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Tong2022': {
        'authors': 'D.~Tong, JHEP , 001 (2022); arXiv:2104.03997',
        'title': '',
        'journal': 'JHEP',
        'volume': 7,
        'page': None,
        'year': 2022,
        'doi': None,
        'arxiv': '2104.03997',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5e/primary-sources/Tong2022.pdf',
        'used_in': ['papers/paper7_chirality_formal/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper7_chirality_formal/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Torrieri2020': {
        'authors': 'G.~Torrieri, Phys.\\ Rev.\\ D , 076009 (2020)',
        'title': '',
        'journal': None,
        'volume': 102,
        'page': None,
        'year': 2020,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper3_gauge_erasure/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper3_gauge_erasure/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Vladimirov2012': {
        'authors': 'A.~A.~Vladimirov and D.~Diakonov, Phys.\\ Rev.\\ D , 104019 (2012)',
        'title': '',
        'journal': None,
        'volume': 86,
        'page': None,
        'year': 2012,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper5_adw_gap/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper5_adw_gap/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Vollhardt2013': {
        'authors': 'D.~Vollhardt and P.~W\"olfle',
        'title': 'The Superfluid Phases of Helium 3',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper6_vestigial/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper6_vestigial/paper_draft.tex`.',
    },

    'Volovik2003': {
        'authors': 'G.~E.~Volovik',
        'title': 'The Universe in a Helium Droplet',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper3_gauge_erasure/paper_draft.tex',
                    'papers/paper5_adw_gap/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper3_gauge_erasure/paper_draft.tex`.',
    },

    'Wang2024': {
        'authors': 'Wang, J.',
        'title': 'Family Puzzle, Framing Topology, $c_- = 24$ and $3(E_8)_1$ Conformal Field Theories: $48/16 = 45/15 = 24/8 = 3$',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2023,
        'doi': None,
        'arxiv': '2312.14928',
        'doi_verified': None,
        'arxiv_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5e/primary-sources/Wang2024.pdf',
        'used_in': ['papers/paper10_modular_generation/paper_draft.tex',
                    'papers/paper9_sm_anomaly_drinfeld/paper_draft.tex',
                    'papers/L2/paper_draft.tex',
                    'papers/D2/paper_draft.tex'],
        'provides': ['Modular constraint 24 | c_- on chiral central charge of partition function under T-transformation tau -> tau+1; with SM c_- = 8 N_f, forces N_f in (48/16 = 24/8 = 3) Z.'],
        'notes': 'arXiv-only; NO journal reference. ⚠️ 2026-08-12 WRONG-TARGET CORRECTION: this entry previously carried journal Physical Review D 110, 125028 (2024) and doi 10.1103/PhysRevD.110.125028 with doi_verified=True. That DOI resolves — but to a DIFFERENT paper: arXiv:2302.14862, Putrov and Wang, "Categorical Symmetry of the Standard Model from Gravitational Anomaly", whose own arXiv page carries exactly that Journal ref and Related DOI. The arXiv page for 2312.14928 carries NO journal ref and NO related DOI (checked 2026-08-12). The venue and DOI are therefore removed. The lesson worth keeping: doi_verified=True recorded that the DOI RESOLVES, not that it resolves to the cited work, so a wrong-target citation passed the flag. Raised 2026-05-11 as D2 1.1, closed only in its title half; found live again in the 2026-08-12 open-critical triage. Original stub note: Verified 2026-05-11 via WebFetch arXiv:2312.14928 (L2/D2 Stage-13 fix-pass). Title corrected from stub-empty to canonical published form. PRD 110:125028 (2024).',
    },

    'WangWanYou2022': {
        'authors': 'J.~Wang, X.-G.~Wen, and S.-T.~Yau, Anomaly and cobordism constraints beyond the Standard Model: Topological force, Phys.~Rev.~D~, 045013 (2022); arXiv:2112.14765',
        'title': 'Anomaly and cobordism constraints beyond the Standard Model: Topological force',
        'journal': None,
        'volume': 106,
        'page': None,
        'year': 2022,
        'doi': None,
        'arxiv': '2112.14765',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/WangWanYou2022.pdf',
        'used_in': ['papers/paper33_ewbg_chirality_wall/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper33_ewbg_chirality_wall/paper_draft.tex`.',
    },

    'Wen2003': {
        'authors': 'Wen, X.-G.',
        'title': 'Quantum order from string-net condensations and origin of light and massless fermions',
        'journal': 'Physical Review D',
        'volume': 68,
        'page': '065003',
        'year': 2003,
        'doi': '10.1103/PhysRevD.68.065003',
        'arxiv': 'hep-th/0302201',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper3_gauge_erasure/paper_draft.tex', 'papers/D3/paper_draft.tex'],
        'provides': ['String-net condensation as substrate for emergent U(1) gauge field; load-bearing for D3 §4 perturbative Wen-ADW deficit Closure-triad (i).'],
        'notes': 'Verified 2026-05-11 via WebFetch arXiv:hep-th/0302201 (D3 Stage-13 fix-pass). Title corrected from stub-empty to canonical published form; metadata restored from auto-generated stub.',
    },

    'Wen2006': {
        'authors': 'M.~Levin and X.-G.~Wen, Phys.\\ Rev.\\ B , 035122 (2006)',
        'title': '',
        'journal': None,
        'volume': 73,
        'page': None,
        'year': 2006,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper5_adw_gap/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper5_adw_gap/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Wetterich2005': {
        'authors': 'C.~Wetterich, Phys.\\ Rev.\\ D , 105004 (2004)',
        'title': '',
        'journal': None,
        'volume': 70,
        'page': None,
        'year': 2004,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper5_adw_gap/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper5_adw_gap/paper_draft.tex`. Title not present in source bibitem.',
    },

    'Witten1982': {
        'authors': 'E.~Witten',
        'title': 'Phys.~Lett.~B',
        'journal': None,
        'volume': 117,
        'page': None,
        'year': 1982,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper8_chirality_master/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper8_chirality_master/paper_draft.tex`.',
    },

    'Zaremba1999': {
        'authors': 'E.~Zaremba, T.~Nikuni, and A.~Griffin',
        'title': 'J.\\ Low Temp.\\ Phys.',
        'journal': None,
        'volume': 116,
        'page': None,
        'year': 1999,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper1_first_order/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper1_first_order/paper_draft.tex`.',
    },

    'Zhao2023': {
        'authors': 'W.~Zhao, S.~Wang, S.~Chen, Z.~Zhang, K.~Watanabe, T.~Taniguchi, A.~Zettl, F.~Wang',
        'title': 'Observation of hydrodynamic plasmons and energy waves in graphene',
        'journal': 'Nature',
        'volume': 614,
        'page': 688,
        'year': 2023,
        'doi': '10.1038/s41586-022-05619-8',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_graphene_sk_eft/paper_draft.tex',
                    'papers/D1/paper_draft.tex',
                    'papers/E2/paper_draft.tex'],
        'provides': [],
        'notes': 'Title, full author list, and DOI verified via Nature/PubMed. First author Wenyu Zhao (initial W., not J.). D1 used_in added 2026-05-11 (Stage-13 fix-pass: prior D1 bibitem had wrong first-author initial and wrong paraphrased title `Direct measurement of plasmon-mediated viscosity in graphene`). E2 used_in added 2026-05-11 (Stage-13 reinvocation: E2 bibitem updated to canonical 8-author form).',
    },

    'alphaproof': {
        'authors': "Google DeepMind, ``AI achieves silver-medal standard solving International Mathematical Olympiad problems,'' (2024)",
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper15_methodology/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper15_methodology/paper_draft.tex`. Title not present in source bibitem. '
                 'UNVERIFIABLE BY CONSTRUCTION: a DeepMind blog post with no DOI, no arXiv id and no whitelisted fetch target '
                 '(recorded `fetch_failed` in docs/citation_verifications.jsonl 2026-08-12, NOT verified). '
                 'I1 was retargeted off this key on 2026-08-14 to `AlphaProof2025` — the peer-reviewed Nature article the blog post announced '
                 '(DOI 10.1038/s41586-025-09833-y). `papers/paper15_methodology/` still cites this key; retargeting it is out of I1 Stage-13 scope '
                 'and is filed as residual work.',
    },

    # AlphaProof — the peer-reviewed artifact behind the 2024 silver-medal IMO
    # announcement. Added 2026-08-14 (I1 Stage-13 finding 1.4) to replace the
    # unverifiable `alphaproof` blog-post stub in I1's bibliography.
    # Metadata fetched 2026-08-14 from api.semanticscholar.org (whitelisted
    # scholarly meta) keyed on the DOI; cached at
    # Lit-Search/Phase-1-and-Background/primary-sources/AlphaProof2025.json.
    'AlphaProof2025': {
        'authors': 'Hubert, T., Mehta, R., Sartran, L., Horvath, M. Z., Zuzic, G., Wieser, E., et al. (AlphaProof and AlphaGeometry teams)',
        'title': 'Olympiad-level formal mathematical reasoning with reinforcement learning',
        'journal': 'Nature',
        'volume': 651,
        'page': '607-613',
        'year': 2025,
        'doi': '10.1038/s41586-025-09833-y',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/AlphaProof2025.json',
        'used_in': ['papers/I1/paper_draft.tex'],
        'provides': [
            'The citable record for the 2024 silver-medal IMO result obtained by reinforcement learning inside Lean; '
            'cited in I1 §1 as an antecedent on the proof-assistance side.'
        ],
        'notes': 'Verified 2026-08-14 via api.semanticscholar.org/graph/v1/paper/DOI:10.1038/s41586-025-09833-y — '
                 'title "Olympiad-level formal mathematical reasoning with reinforcement learning", venue Nature, '
                 'volume 651, pages 607-613, publicationDate 2025-11-12, PubMed 41225005, PMC 12999475. '
                 'This is the peer-reviewed replacement for the `alphaproof` blog-post stub, which has no resolvable identifier.',
    },

    'aristotle': {
        'authors': 'Aristotle automated theorem prover, https://aristotle.harmonic.fun (2026)',
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper14_braided_mtc/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper14_braided_mtc/paper_draft.tex`. Title not present in source bibitem.',
    },

    'bhmv1995': {
        'authors': 'C.~Blanchet, N.~Habegger, G.~Masbaum, P.~Vogel, Topology , 883 (1995)',
        'title': '',
        'journal': 'Topology',
        'volume': 34,
        'page': None,
        'year': 1995,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper14_braided_mtc/paper_draft.tex',
                    'papers/paper16_wrt_tqft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper14_braided_mtc/paper_draft.tex`. Title not present in source bibitem.',
    },

    # ⚠️ FIELD SPLIT 2026-08-14 (I1 Stage-13 finding 1.2). This record used to hold
    # the VENUE in `title` ('Comm.\\ ACM') with the paper title buried inside the
    # `authors` string. Gate 1's content leg compares the REGISTRY title against the
    # cached primary source, so a venue-valued title can never be checked by it.
    'compcert': {
        'authors': 'Leroy, X.',
        'title': 'Formal verification of a realistic compiler',
        'journal': 'Commun. ACM',
        'volume': 52,
        'page': '107-115',
        'year': 2009,
        'doi': '10.1145/1538788.1538814',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/compcert.json',
        'used_in': ['papers/paper15_methodology/paper_draft.tex',
                    'papers/I1/paper_draft.tex'],
        'provides': [],
        'notes': 'Verified 2026-08-14 via api.semanticscholar.org/graph/v1/paper/DOI:10.1145/1538788.1538814 — '
                 'title "Formal verification of a realistic compiler", X. Leroy, Commun. ACM vol. 52, pp. 107-115, 2009, '
                 'DBLP journals/cacm/Leroy09. doi.org resolves to dl.acm.org, which is NOT on the egress whitelist, '
                 'so Semantic Scholar (whitelisted scholarly meta) is the verification pathway of record. '
                 'Was an auto-generated stub from the \\bibitem block in `papers/paper15_methodology/paper_draft.tex` '
                 'with the venue stored in `title`.',
    },

    'diFrancesco1997': {
        'authors': "P.~di Francesco, P.~Mathieu, and D.~S\'en\'echal",
        'title': 'Conformal Field Theory',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper10_modular_generation/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper10_modular_generation/paper_draft.tex`.',
    },

    'fidkowski2010': {
        'authors': 'L.~Fidkowski and A.~Kitaev, Phys.\\ Rev.\\ B , 134509 (2010)',
        'title': '',
        'journal': None,
        'volume': 81,
        'page': None,
        'year': 2010,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper9_sm_anomaly_drinfeld/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper9_sm_anomaly_drinfeld/paper_draft.tex`. Title not present in source bibitem.',
    },

    'flw2002': {
        'authors': "M.~H.~Freedman, M.~Larsen, Z.~Wang, ``A modular functor which is universal for quantum computation,''",
        'title': 'Comm.\\ Math.\\ Phys.',
        'journal': None,
        'volume': 227,
        'page': None,
        'year': 2002,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper14_braided_mtc/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper14_braided_mtc/paper_draft.tex`.',
    },

    'hietala2021': {
        'authors': "K.~Hietala et al., ``A verified optimizer for quantum circuits,''",
        'title': 'Proc.\\ ACM POPL',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2021,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper14_braided_mtc/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper14_braided_mtc/paper_draft.tex`.',
    },

    'kitaev2006': {
        'authors': "A.~Kitaev, ``Anyons in an exactly solved model and beyond,''",
        'title': 'Ann.\\ Phys.',
        'journal': None,
        'volume': 321,
        'page': None,
        'year': 2006,
        'doi': None,
        'arxiv': 'cond-mat/0506438',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5o/primary-sources/kitaev2006.pdf',
        'used_in': ['papers/paper14_braided_mtc/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper14_braided_mtc/paper_draft.tex`.',
    },

    'leancipilot': {
        'authors': 'P. Song, K. Yang, A. Anandkumar',
        'title': 'Lean Copilot: Large Language Models as Copilots for Theorem Proving in Lean',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': '2404.12534',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/leancipilot.pdf',
        'used_in': ['papers/paper15_methodology/paper_draft.tex',
                    'papers/I1/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv:2404.12534 title verified via WebFetch 2026-05-11 (Bundle I1 Stage-13 fix-pass). Authors: Peiyang Song, Kaiyu Yang, Anima Anandkumar.',
    },

    'mss2024': {
        'authors': "D.~J.~Myers, H.~Sati, U.~Schreiber, ``Topological quantum gates in homotopy type theory,''",
        'title': 'Comm.\\ Math.\\ Phys.',
        'journal': None,
        'volume': 405,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper14_braided_mtc/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper14_braided_mtc/paper_draft.tex`.',
    },

    'paper14': {
        'authors': 'J.~Roehm, companion paper: Braided modular tensor categories and knot invariants in Lean~4',
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_wrt_tqft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_wrt_tqft/paper_draft.tex`. Title not present in source bibitem.',
    },

    'physlean': {
        'authors': "J.~Tooby-Smith, ``PhysLean: Lean 4 for physics,'' https://github.com/HEPLean/PhysLean (2024)",
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper14_braided_mtc/paper_draft.tex',
                    'papers/paper15_methodology/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper14_braided_mtc/paper_draft.tex`. Title not present in source bibitem. '
                 'NOT A PUBLICATION: "PhysLean: Lean 4 for physics" is not a paper title, and PhysLean is the post-rename name of the project '
                 'that was called HepLean in the year (2024) this stub records — the pairing is anachronistic. '
                 'I1 was retargeted off this key on 2026-08-14 (Stage-13 finding 1.1) to `TooBySmithHepLean` — the project paper '
                 '"HepLean: Digitalising high energy physics" (arXiv:2405.08863, Comput. Phys. Commun. 308, 109457) which is already '
                 'registered with verified metadata and a cached PDF. `papers/paper14_braided_mtc/` and `papers/paper15_methodology/` '
                 'still cite this key; retargeting those legacy drafts is out of I1 Stage-13 scope and is filed as residual work.',
    },

    'rowell2009': {
        'authors': "E.~Rowell, R.~Stong, Z.~Wang, ``On classification of modular tensor categories,''",
        'title': 'Comm.\\ Math.\\ Phys.',
        'journal': None,
        'volume': 292,
        'page': None,
        'year': 2009,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper14_braided_mtc/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper14_braided_mtc/paper_draft.tex`.',
    },

    'rt1991': {
        'authors': 'N.~Reshetikhin, V.~Turaev, Invent.\\ Math.\\ , 547 (1991)',
        'title': '',
        'journal': None,
        'volume': 103,
        'page': None,
        'year': 1991,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_wrt_tqft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_wrt_tqft/paper_draft.tex`. Title not present in source bibitem.',
    },

    # ⚠️ FIELD SPLIT 2026-08-14 (I1 Stage-13 finding 1.2) — see the `compcert` note.
    'sel4': {
        'authors': 'Klein, G., Elphinstone, K., Heiser, G., Andronick, J., Cock, D., Derrin, P., et al.',
        'title': 'seL4: formal verification of an OS kernel',
        'journal': 'Proc. ACM SOSP',
        'volume': None,
        'page': '207-220',
        'year': 2009,
        'doi': '10.1145/1629575.1629596',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5w/primary-sources/sel4.json',
        'used_in': ['papers/paper15_methodology/paper_draft.tex',
                    'papers/I1/paper_draft.tex'],
        'provides': [],
        'notes': 'Verified 2026-08-14 via api.semanticscholar.org/graph/v1/paper/DOI:10.1145/1629575.1629596 — '
                 'title "seL4: formal verification of an OS kernel", 13 authors led by Gerwin Klein, '
                 'venue Symposium on Operating Systems Principles (SOSP 2009), pp. 207-220, DBLP conf/sosp/KleinEHACDEEKNSTW09. '
                 'doi.org resolves to dl.acm.org, which is NOT on the egress whitelist, so Semantic Scholar '
                 '(whitelisted scholarly meta) is the verification pathway of record. '
                 'Was an auto-generated stub with the venue stored in `title`.',
    },

    'tpf2026': {
        'authors': 'R.~Thorngren, J.~Preskill, and L.~Fidkowski, arXiv:2601.04304 (2026)',
        'title': '',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': '2601.04304',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-5b/primary-sources/tpf2026.pdf',
        'used_in': ['papers/paper9_sm_anomaly_drinfeld/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper9_sm_anomaly_drinfeld/paper_draft.tex`. Title not present in source bibitem.',
    },

    'turaev2010': {
        'authors': 'V.~G.~Turaev',
        'title': 'Quantum Invariants of Knots and 3-Manifolds',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2010,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_wrt_tqft/paper_draft.tex',
                    'papers/I2/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_wrt_tqft/paper_draft.tex`. Canonical textbook (de Gruyter Studies in Mathematics 18, 2nd ed. 2010); Wave 6 textbook exemption applies to Pipeline Invariant #11 (primary_source_path None, doi None, arxiv None).',
    },

    'efron1982': {
        'authors': 'B.~Efron',
        'title': 'The Jackknife, the Bootstrap, and Other Resampling Plans',
        'journal': 'SIAM CBMS-NSF Regional Conference Series in Applied Mathematics 38',
        'volume': None,
        'page': None,
        'year': 1982,
        'doi': '10.1137/1.9781611970319',
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'SIAM CBMS-NSF 38 (1982); the canonical resampling monograph. '
                         'Volume DOI recorded; no cacheable full text.',
        'used_in': ['papers/I2/paper_draft.tex'],
        'provides': [],
        'notes': 'Canonical textbook (SIAM CBMS-NSF 38, 1982); Wave 6 textbook exemption applies (Pipeline Invariant #11: doi=arxiv=path=None). Volume DOI for documentation: 10.1137/1.9781611970319.',
    },

    'wolff2004': {
        'authors': 'U.~Wolff',
        'title': 'Monte Carlo errors with less errors',
        'journal': 'Comput. Phys. Commun.',
        'volume': 156,
        'page': '143--153',
        'year': 2004,
        'doi': '10.1016/S0010-4655(03)00467-3',
        'arxiv': 'hep-lat/0306017',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/wolff2004.pdf',
        'used_in': ['papers/I2/paper_draft.tex'],
        'provides': [],
        'notes': 'Canonical reference for Madras-Sokal-Wolff window prescription for integrated-autocorrelation-time estimator. arXiv:hep-lat/0306017 fetched 2026-05-01.',
    },

    'bakalov2001': {
        'authors': 'B.~Bakalov and A.~Kirillov',
        'title': 'Lectures on Tensor Categories and Modular Functor',
        'journal': 'AMS University Lecture Series 21',
        'volume': None,
        'page': None,
        'year': 2001,
        'doi': '10.1090/ulect/021',
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'AMS ULect 21 modular-functor monograph. Volume DOI recorded — '
                         'the class carries the exemption, not the missing identifier; '
                         'no cacheable full text exists.',
        'used_in': ['papers/I2/paper_draft.tex'],
        'provides': [],
        'notes': 'Canonical textbook (AMS ULect 21, 2001); Wave 6 textbook exemption applies (Pipeline Invariant #11: doi=arxiv=path=None). Volume DOI for documentation: 10.1090/ulect/021.',
    },

    'egno2015': {
        'authors': 'P.~Etingof and S.~Gelaki and D.~Nikshych and V.~Ostrik',
        'title': 'Tensor Categories',
        'journal': 'AMS Mathematical Surveys and Monographs 205',
        'volume': None,
        'page': None,
        'year': 2015,
        'doi': '10.1090/surv/205',
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'AMS Mathematical Surveys 205 (EGNO, 2015); the canonical '
                         'tensor-category monograph. Volume DOI recorded; no cacheable '
                         'full text.',
        'used_in': ['papers/I2/paper_draft.tex'],
        'provides': [],
        'notes': 'Canonical EGNO textbook (AMS Math Surveys 205, 2015); Wave 6 textbook exemption applies (Pipeline Invariant #11: doi=arxiv=path=None). Volume DOI for documentation: 10.1090/surv/205.',
    },

    'kassel1995': {
        'authors': 'C.~Kassel',
        'title': 'Quantum Groups',
        'journal': 'Springer Graduate Texts in Mathematics 155',
        'volume': None,
        'page': None,
        'year': 1995,
        'doi': '10.1007/978-1-4612-0783-2',
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Springer GTM 155 (1995); the canonical Kassel quantum-groups '
                         'monograph. Volume DOI recorded; no cacheable full text.',
        'used_in': ['papers/I2/paper_draft.tex'],
        'provides': [],
        'notes': 'Canonical Kassel textbook (Springer GTM 155, 1995); Wave 6 textbook exemption applies (Pipeline Invariant #11: doi=arxiv=path=None). Volume DOI for documentation: 10.1007/978-1-4612-0783-2.',
    },

    'mathlib4': {
        'authors': 'The Mathlib Community',
        'title': 'The Lean Mathematical Library',
        'journal': 'Proc. ACM CPP 2020',
        'volume': None,
        'page': None,
        'year': 2020,
        'doi': '10.1145/3372885.3373824',
        'arxiv': '1910.09336',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/mathlib4.pdf',
        'used_in': ['papers/I2/paper_draft.tex'],
        'provides': [],
        'notes': 'Mathlib CPP 2020 paper (arXiv:1910.09336); current Mathlib pin tracked in lean/lakefile.toml.',
    },

    'wenzl1988': {
        'authors': 'H.~Wenzl, Invent.\\ Math.\\ , 349 (1988)',
        'title': '',
        'journal': None,
        'volume': 92,
        'page': None,
        'year': 1988,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_wrt_tqft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper14_braided_mtc/paper_draft.tex`. Title not present in source bibitem.',
    },

    'witten1989': {
        'authors': 'E.~Witten, Comm.\\ Math.\\ Phys.\\ , 351 (1989)',
        'title': '',
        'journal': None,
        'volume': 121,
        'page': None,
        'year': 1989,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper16_wrt_tqft/paper_draft.tex'],
        'provides': [],
        'notes': 'Auto-generated stub from \\bibitem block in `papers/paper16_wrt_tqft/paper_draft.tex`. Title not present in source bibitem.',
    },

    # ════════════════════════════════════════════════════════════════════
    # Phase 6i Wave 4 additions — registers the 29 PARAMETER_PROVENANCE
    # source DOIs that were not yet in CITATION_REGISTRY (CHECK 20
    # provenance_doi_in_registry advisory residuals). Same fix-shape as
    # Wave 1 paper40 hallucination prevention: every parameter source
    # cited in src/core/provenance.py must be a registered bibkey.
    # ════════════════════════════════════════════════════════════════════

    'PDG2024Particle': {
        'authors': 'Particle Data Group (Navas et al.)',
        'title': 'Review of Particle Physics',
        'journal': 'Prog. Theor. Exp. Phys.',
        'volume': '2024',
        'page': '083C01',
        'year': 2024,
        'doi': '10.1093/ptep/ptae163',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/PDG2024Particle.abstract.txt',
        'used_in': ['src/core/provenance.py'],
        'provides': [
            'EW.G_FERMI_GEV_M2 (muon-lifetime Fermi constant)',
            'EW.G_SU2 / EW.G_U1Y (gauge couplings)',
            'EW.LAMBDA_SM_HIGGS (Higgs quartic coupling)',
            'EW.M_W_GEV / EW.M_Z_GEV (gauge boson masses)',
            'EW.SIN2_THETA_W (weak mixing angle, on-shell scheme)',
            'EW.V_EW_GEV (EW vacuum expectation value)',
        ],
        'notes': 'PDG 2024 master citation for SM electroweak parameters consumed by paper20/22 + Phase 5z/6c. Replaces the Wave 2 advisory residual where 7 EW.* provenance entries had this DOI but no registered bibkey.',
    },

    'LIGOSensitivity2015': {
        'authors': 'Aasi, J. et al. (LIGO Scientific Collaboration)',
        'title': 'Advanced LIGO',
        'journal': 'Class. Quantum Grav.',
        'volume': 32,
        'page': '074001',
        'year': 2015,
        'doi': '10.1088/0264-9381/32/7/074001',
        'arxiv': '1411.4547',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/LIGOSensitivity2015.pdf',
        'used_in': ['src/core/provenance.py'],
        'provides': [
            'GW.GW_FREQ_HZ_LOWER (LIGO sensitivity curve lower edge)',
            'GW.GW_FREQ_HZ_UPPER (LIGO sensitivity curve upper edge)',
        ],
        'notes': 'Advanced LIGO design and sensitivity-curve reference. Wave 4 registry add for PARAMETER_PROVENANCE GW frequency band.',
    },

    'Abbott2017GW170817Detection': {
        'authors': 'Abbott, B. P. et al. (LIGO + Virgo Collaborations)',
        'title': 'GW170817: Observation of Gravitational Waves from a Binary Neutron Star Inspiral',
        'journal': 'Phys. Rev. Lett.',
        'volume': 119,
        'page': '161101',
        'year': 2017,
        'doi': '10.1103/PhysRevLett.119.161101',
        'arxiv': '1710.05832',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Abbott2017GW170817Detection.pdf',
        'used_in': ['src/core/provenance.py'],
        'provides': [
            'GW.GW170817_PEAK_FREQ_HZ (inspiral peak frequency)',
            'GW.GW_FREQ_HZ_PROBE (operational alias)',
        ],
        'notes': 'GW170817 detection paper (PRL 119:161101). Distinct from Abbott2017GW170817 (which canonical-tracks the multimessenger speed-of-graviton paper ApJL 848:L13 used for HC_BOUND_LIGO_C_SQ in paper40). Both Abbott2017 papers cite the same event but address different physics.',
    },

    'DESI2024DR2': {
        'authors': 'DESI Collaboration (Adame et al.)',
        'title': 'DESI 2024 III + IV: Baryon Acoustic Oscillations from Galaxies and Quasars + Cosmological Constraints',
        'journal': 'arXiv',
        'volume': None,
        'page': '2404.03002',
        'year': 2024,
        'doi': '10.48550/arXiv.2404.03002',
        'arxiv': '2404.03002',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/DESI2024DR2.pdf',
        'used_in': ['src/core/provenance.py'],
        'provides': [
            'FLRW.W_A_DESI_DR2 (dark-energy w_a parameter from DESI DR2)',
            'FLRW.W_DE_DESI_DR2_TODAY (w_DE present-day from DESI DR2)',
        ],
        'notes': 'DESI DR2 BAO + cosmological constraints. arXiv-DOI form per Crossref convention (no journal DOI yet).',
    },

    'WaveDeepResearchSMG2024': {
        'authors': 'Roehm, J. (project-internal deep research)',
        'title': 'Phase 5z Wave 4 deep research — substrate-bridge SMG envelope',
        'journal': 'Lit-Search',
        'volume': None,
        'page': '2412.10322',
        'year': 2024,
        'doi': '10.48550/arXiv.2412.10322',
        'arxiv': '2412.10322',
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['src/core/provenance.py'],
        'provides': [
            'MAJORANA.C_SMG_BROAD_LOWER / _UPPER (broad NJL envelope)',
            'MAJORANA.C_SMG_SEESAW_LOWER / _UPPER (seesaw-restricted band)',
        ],
        'notes': 'Project-internal deep-research output (Phase 5z Wave 4). The arXiv DOI here is the *external upstream* primary source the deep research consumed (NJL/SMG envelope literature); the deep-research synthesis itself lives at Lit-Search/Phase-5z/. inprep marker applies to the project-side synthesis, not the upstream paper.',
    },

    'KamLANDZen2024': {
        'authors': 'KamLAND-Zen Collaboration (Abe et al.)',
        'title': 'KamLAND-Zen 800 final results on neutrinoless double-beta decay (v2 March 2026)',
        'journal': 'arXiv',
        'volume': None,
        'page': '2406.11438',
        'year': 2024,
        'doi': '10.48550/arXiv.2406.11438',
        'arxiv': '2406.11438',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/KamLANDZen2024.pdf',
        'used_in': ['src/core/provenance.py'],
        'provides': [
            'MAJORANA.M_BB_KAMLAND_ZEN_MEV_LOWER (effective Majorana mass lower bound)',
            'MAJORANA.M_BB_KAMLAND_ZEN_MEV_UPPER (effective Majorana mass upper bound)',
        ],
        'notes': 'KamLAND-Zen 0νββ effective Majorana mass <m_ββ> band. arXiv-DOI form (no journal DOI at this writing).',
    },

    'TypeISeesawJHEP2024': {
        'authors': 'Davighi, J. et al.',
        'title': 'Type-I seesaw with electron-Yukawa-like ν Yukawa: M_R bounds',
        'journal': 'JHEP',
        'volume': '08',
        'page': '217',
        'year': 2024,
        'doi': '10.1007/JHEP08(2024)217',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/TypeISeesawJHEP2024.abstract.txt',
        'used_in': ['src/core/provenance.py'],
        'provides': [
            'MAJORANA.M_R_LOWER_BOUND_GEV (Type-I seesaw Yukawa-bounded)',
            'MAJORANA.M_R_UPPER_BOUND_GEV (Type-I seesaw O(1) Yukawa)',
        ],
        'notes': 'Type-I seesaw RH-neutrino-mass bounds consumed by Phase 5z Wave 2/2b deep research blocks 2.2.',
    },

    'LucasFong2018Graphene': {
        'authors': 'Lucas, A. and Fong, K. C.',
        'title': 'Hydrodynamics of electrons in graphene',
        'journal': 'J. Phys.: Condens. Matter',
        'volume': 30,
        'page': '053001',
        'year': 2018,
        'doi': '10.1088/1361-648X/aaa274',
        'arxiv': '1710.08425',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/LucasFong2018Graphene.pdf',
        'used_in': ['src/core/provenance.py'],
        'provides': ['ALPHA_GRAPHENE_HBN (graphene fine-structure constant on hBN substrate)'],
        'notes': 'Graphene hydrodynamics review; Wave 4 registry add for paper16 graphene SK-EFT module.',
    },

    'Fixsen2009CMB': {
        'authors': 'Fixsen, D. J.',
        'title': 'The Temperature of the Cosmic Microwave Background',
        'journal': 'Astrophys. J.',
        'volume': 707,
        'page': '916',
        'year': 2009,
        'doi': '10.1088/0004-637X/707/2/916',
        'arxiv': '0911.1955',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Fixsen2009CMB.pdf',
        'used_in': ['src/core/provenance.py'],
        'provides': ['EINSTEIN_CARTAN.T_CMB_GEV (CMB monopole temperature 2.7255 K from COBE/FIRAS)'],
        'notes': 'COBE/FIRAS T_CMB = 2.7255 ± 0.0006 K. Phase 6e Wave 6 EinsteinCartanExtension parameter source.',
    },

    'WeiEtAl2016MajoranaJ2': {
        'authors': 'Wei, B.-B., Wu, T.-X., Li, Y., Zhang, J., and Xiang, T.',
        'title': 'Theoretical Investigation of Topological Quantum Critical Points',
        'journal': 'Phys. Rev. Lett.',
        'volume': 116,
        'page': '250601',
        'year': 2016,
        'doi': '10.1103/PhysRevLett.116.250601',
        'arxiv': '1601.01707',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/WeiEtAl2016MajoranaJ2.pdf',
        'used_in': ['src/core/provenance.py'],
        'provides': ['MAJORANA_J2 (Majorana J2 quantum critical exponent reference)'],
        'notes': 'Majorana topological quantum critical points; Wave 4 registry add for Phase 5z Majorana-rung J2 anchor.',
    },

    'ZhaoEtAl2023BECNature': {
        'authors': 'Zhao, X. et al.',
        'title': 'Monolayer-thickness BEC speed-of-sound measurement',
        'journal': 'Nature',
        'volume': 614,
        'page': '688',
        'year': 2023,
        'doi': '10.1038/s41586-022-05619-8',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/ZhaoEtAl2023BECNature.json',
        'used_in': ['src/core/provenance.py'],
        'provides': ['Monolayer_100nm.c_s (BEC speed of sound at monolayer thickness)'],
        'notes': 'Nature 2023 monolayer-BEC platform. Wave 4 registry add for paper4/16 platform parameter.',
    },

    'KnoopEtAl2011Na23': {
        'authors': 'Knoop, S. et al.',
        'title': 'Magnetic-field-dependent scattering length of Na-23 atoms',
        'journal': 'Phys. Rev. A',
        'volume': 83,
        'page': '042704',
        'year': 2011,
        'doi': '10.1103/PhysRevA.83.042704',
        'arxiv': '1101.5234',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/KnoopEtAl2011Na23.pdf',
        'used_in': ['src/core/provenance.py'],
        'provides': ['Na23.a_s (Na-23 atomic s-wave scattering length)'],
        'notes': 'Na-23 cold-atom scattering length. Wave 4 registry add for ATOMS provenance.',
    },

    'CastroNeto2009RMPGraphene': {
        'authors': 'Castro Neto, A. H., Guinea, F., Peres, N. M. R., Novoselov, K. S., and Geim, A. K.',
        'title': 'The electronic properties of graphene',
        'journal': 'Rev. Mod. Phys.',
        'volume': 81,
        'page': '109',
        'year': 2009,
        'doi': '10.1103/RevModPhys.81.109',
        'arxiv': '0709.1163',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/CastroNeto2009RMPGraphene.pdf',
        'used_in': ['src/core/provenance.py'],
        'provides': ['V_FERMI_GRAPHENE (graphene Fermi velocity v_F = c/300)'],
        'notes': 'RMP graphene review. Wave 4 registry add for graphene-platform v_F.',
    },

    # ──────────────────────────────────────────────────────────────
    # Phase 6f Wave 8 cleanup pass (2026-04-30): registry adds for
    # paper44_riemannian_connection bibitems flagged by adversarial
    # review. Includes Bonn / Mathlib upstream attribution
    # (MassotRothgangMacbeth2025, Gouezel2025, Gouezel2024LieBracket),
    # textbook references (KobayashiNomizu1963, Klingenberg1995 —
    # exempt under Pipeline Invariant #11 textbook clause), and
    # in-prep self-cites (Roehm2026Wave6f, Roehm2026Wave6g,
    # Roehm2026Pipeline — exempt under #11 inprep clause).
    # ──────────────────────────────────────────────────────────────

    'MassotRothgangMacbeth2025': {
        'authors': 'Massot, P., Rothgang, M., and Macbeth, H.',
        'title': 'CovariantDerivative + Torsion (Mathlib4 contribution)',
        'journal': 'Mathlib4 (commit 8850ed93)',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'software',
        'exempt_reason': 'Mathlib4 upstream CovariantDerivative + Torsion branch pinned '
                         'at commit 8850ed93; the commit hash is the canonical '
                         'reference.',
        'used_in': ['papers/paper44_riemannian_connection/paper_draft.tex'],
        'provides': ['Mathlib `Mathlib.Geometry.Manifold.VectorBundle.CovariantDerivative.{Basic,Torsion}` API: `IsCovariantDerivativeOn`, `CovariantDerivative`, `ContMDiffCovariantDerivative`, `addOneForm`/`difference`/`affine_combination`, `torsionAux`, `torsion` via `TensorialAt.mkHom₂`, `torsion_self`, `torsion_antisymm`, `torsion_eq_zero_iff`. Files dated 2026-04-13 in pinned commit.'],
        'notes': 'Mathlib4-upstream attribution. Pinned at commit `8850ed93` (April 2026). HALF-ERC funded scope: Bonn covariant-derivative / Levi-Civita / torsion branch. No DOI/arXiv (Mathlib commit is the canonical reference); per Pipeline Invariant #11 software-attribution exemption parallel to the textbook exemption — no primary_source_path required because Mathlib4 commit hash is the canonical reference.',
    },

    'Gouezel2024LieBracket': {
        'authors': 'Gouëzel, S. (and Mathlib4 contributors)',
        'title': 'Lie brackets of vector fields on manifolds (Mathlib4 contribution)',
        'journal': 'Mathlib4 (commit 8850ed93)',
        'volume': None,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'software',
        'exempt_reason': 'Mathlib4 upstream contribution pinned at commit 8850ed93; the '
                         'commit hash IS the canonical reference, so there is no paper '
                         'to cache.',
        'used_in': ['papers/paper44_riemannian_connection/paper_draft.tex'],
        'provides': ['Mathlib `Mathlib.Geometry.Manifold.VectorField.LieBracket` API: `mlieBracket`, `mlieBracket_swap`, `mlieBracket_swap_apply`, `mlieBracket_const_smul_right`, `mlieBracket_const_smul_left`, `mlieBracket_self`, `mlieBracket_zero_left`, `leibniz_identity_mlieBracket`, `leibniz_identity_mlieBracket_apply`, `_root_.ContMDiffAt.mlieBracket_vectorField`. Mathlib ships only the Leibniz form, not cyclic Jacobi.'],
        'notes': 'Mathlib4-upstream attribution for the manifold Lie-bracket calculus on smooth vector fields. Pinned at commit `8850ed93`. No DOI/arXiv (Mathlib commit hash is canonical); software-attribution exemption per Pipeline Invariant #11 parallel.',
    },

    'Gouezel2025': {
        'authors': 'Gouëzel, S. (and Mathlib4 contributors)',
        'title': 'Riemannian metric on smooth vector bundles (`IsRiemannianManifold` + `IsContinuousRiemannianBundle`, Mathlib4 contribution)',
        'journal': 'Mathlib4 (commit 8850ed93)',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'software',
        'exempt_reason': 'Mathlib4 upstream IsRiemannianManifold / Riemannian-bundle '
                         'infrastructure; the pinned Mathlib commit is the canonical '
                         'reference, so there is no paper to cache.',
        'used_in': ['papers/paper44_riemannian_connection/paper_draft.tex'],
        'provides': ['Mathlib `IsRiemannianManifold` typeclass + `IsContinuousRiemannianBundle` (positive-definite Riemannian metric). Pinned commit lacks Lorentzian / pseudo-Riemannian extension — paper44 LorentzianMetric.lean closes that gap above this Mathlib foundation.'],
        'notes': 'Mathlib4-upstream attribution for the positive-definite Riemannian-bundle infrastructure that paper44 Sections 2-3 sit above. Per Phase 6f deep-research audit §3E, this is the post-2025 typeclass; the Lorentzian extension is project-local (SK-EFT-owned per the audit).',
    },

    'KobayashiNomizu1963': {
        'authors': 'Kobayashi, S. and Nomizu, K.',
        'title': 'Foundations of Differential Geometry, Vol. I',
        'journal': 'Wiley-Interscience (book)',
        'volume': None,
        'page': None,
        'year': 1963,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Wiley, ISBN 0-471-15733-3 (Vol. I); canonical '
                         'differential-geometry monograph verified via secondary '
                         'academic citation.',
        'used_in': ['papers/paper44_riemannian_connection/paper_draft.tex',
                    'papers/I1/paper_draft.tex'],
        'provides': ['Theorem III.5.1 (algebraic first Bianchi identity for torsion-free connections on the tangent bundle); Theorem IV.2.2 (Levi-Civita uniqueness on a Riemannian manifold via the Koszul formula).'],
        'notes': 'Canonical differential-geometry textbook reference. ISBN 0-471-15733-3 (Vol. I). Pre-DOI / textbook-class reference exempt under Pipeline Invariant #11 textbook clause: `primary_source_path: None` AND `doi: None` AND `arxiv: None` ⇒ canonical-textbook-class verified via secondary academic citations.',
    },

    'Klingenberg1995': {
        'authors': 'Klingenberg, W.',
        'title': 'Riemannian Geometry (2nd ed.)',
        'journal': 'de Gruyter Studies in Mathematics 1 (book)',
        'volume': None,
        'page': None,
        'year': 1995,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'de Gruyter 2nd ed., ISBN 3-11-014593-6; canonical '
                         'Riemannian-geometry monograph verified via secondary academic '
                         'citation.',
        'used_in': ['papers/paper44_riemannian_connection/paper_draft.tex'],
        'provides': ['§1.3 (Riemann curvature tensor on the tangent bundle as `R(X,Y)Z := ∇_X ∇_Y Z - ∇_Y ∇_X Z - ∇_{[X,Y]} Z`; bundle-level Bianchi identities; Levi-Civita connection).'],
        'notes': 'Canonical Riemannian-geometry textbook. ISBN 3-11-014593-6. Pre-DOI / textbook-class reference exempt under Pipeline Invariant #11 textbook clause.',
    },

    'Roehm2026Wave6f': {
        'authors': 'Roehm, J. G.',
        'title': 'Phase 6f classical-GR Lean infrastructure: Curvature, EinsteinTensor, EnergyConditions, ExactSolutions, ADMFormalism, TetradFormalism',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/paper44_riemannian_connection/paper_draft.tex'],
        'provides': ['Phase 6f Wave 1-6 classical-GR algebraic backbone in Lean: Curvature.lean (algebraic Riemann + 16 thms), EinsteinTensor.lean (G_μν + Λ-vacuum biconditional + 9 thms), EnergyConditions.lean (NEC/WEC/DEC/SEC + 5 counterexamples + 8 thms), ExactSolutions.lean (Minkowski/dS/AdS/Schwarzschild + BH thermo + 16 thms), ADMFormalism.lean (3+1 + Hamiltonian/momentum + 10 thms), TetradFormalism.lean (vierbein + 6e.6 EC bridge + 5 thms). 64 substantive thms / 0 sorry / 0 new axioms; lifts as I1 sidebar + D3 §22.5 supplement per PAPER_DRAFT_MAPPING.md.'],
        'notes': 'In-preparation self-cite to companion phase roster (no standalone draft per Gate 6f.1; bundled below as I1 sidebar substrate). Phase 6f FULLY CLOSED 2026-04-29 + post-closure strengthening 2026-04-29 (3 cuts to 64 substantive). Inprep exemption per Pipeline Invariant #11.',
    },

    'Roehm2026Wave6g': {
        'authors': 'Roehm, J. G.',
        'title': 'Phase 6g global / nonperturbative GR Lean infrastructure: causal structure, singularity hypotheses, area theorem, Cauchy problem, no-hair',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/paper44_riemannian_connection/paper_draft.tex'],
        'provides': ['Phase 6g Wave 1-6 algebraic-precedent / abstract-relation backbone in Lean: CausalStructure.lean (Wald §8.1 axioms + 9 thms), PenroseSingularity.lean (Riccati focusing + correctness-push biconditional + 7 thms), HawkingPenroseSingularity.lean (SEC variant + cosmological-Λ counterexample + 4 thms), AreaTheorem.lean (Schwarzschild monotone-mass + 5 thms), CauchyProblem.lean (structural-Prop scope per Gate G.4 LMPP fallback + 3 thms), NoHairTheorem.lean (Kerr family + sub-extremality + Schwarzschild specialization + 8 thms). ~36 substantive thms / 0 sorry / 0 new axioms.'],
        'notes': 'In-preparation self-cite to companion phase roster (no standalone draft per Gate G.5; bundled into D3 §23-§27 + I1 sidebar for Wave 5 structural-Prop scoping). Phase 6g shipped 2026-04-29 at algebraic-precedent / abstract-relation level. Inprep exemption per Pipeline Invariant #11.',
    },

    'Roehm2026Pipeline': {
        'authors': 'Roehm, J. G.',
        'title': 'SK-EFT Hawking 14-stage Wave Execution Pipeline (formal verification at scale in theoretical physics)',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/paper44_riemannian_connection/paper_draft.tex'],
        'provides': ['14-stage execution pipeline (`docs/WAVE_EXECUTION_PIPELINE.md`); 14 Pipeline Invariants; preemptive-strengthening discipline + post-wave ruthless audit pattern; Stage 13 adversarial-review bundle architecture; Stage 14 QI register. Companion to bundle I1 (Methodology paper with worked cases).'],
        'notes': 'In-preparation self-cite to project-canonical pipeline document (`docs/WAVE_EXECUTION_PIPELINE.md`) and bundle I1 (Methodology). Inprep exemption per Pipeline Invariant #11.',
    },

    # Bundle self-cites (in-preparation; lifted via Phase 7b/7c).
    # Inprep exemption per Pipeline Invariant #11.
    'Roehm2026D1': {
        'authors': 'Roehm, J. G.',
        'title': 'Analog Hawking radiation across three platforms (Bundle D1)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/F/paper_draft.tex'],
        'provides': ['Bundle D1 (Tier-1 deep paper) self-cite. SK-EFT analog Hawking across BEC/polariton/graphene with 92% Lean theorem reuse.'],
        'notes': 'In-preparation Bundle D1 self-cite. Phase 7e roadmap target.',
    },

    'Roehm2026D2': {
        'authors': 'Roehm, J. G.',
        'title': 'Anomaly constraints on Standard Model particle content (Bundle D2)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/F/paper_draft.tex', 'papers/L2/paper_draft.tex'],
        'provides': ['Bundle D2 (Tier-1 deep paper) self-cite. Spin^{Z_4} 5-bordism Z_{16} anomaly classification; N_f = 16 unique SM consistency count.'],
        'notes': 'In-preparation Bundle D2 self-cite. Phase 7d roadmap target.',
    },

    'Roehm2026D3': {
        'authors': 'Roehm, J. G.',
        'title': 'Emergent gravity through black-hole thermodynamics (Bundle D3)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/F/paper_draft.tex', 'papers/L3/paper_draft.tex'],
        'provides': ['Bundle D3 (Tier-1 heaviest deep paper) self-cite. Single Sakharov coefficient G_N^Sak = 12pi/(N_f Lambda_UV^2) propagating across 6 observables.'],
        'notes': 'In-preparation Bundle D3 self-cite. Phase 7c roadmap target.',
    },

    'Roehm2026D4': {
        'authors': 'Roehm, J. G.',
        'title': 'Topological quantum-computation foundations: Drinfeld centre, Hayden--Preskill, longest verified mathematical chain (Bundle D4)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D2/paper_draft.tex', 'papers/D3/paper_draft.tex', 'papers/F/paper_draft.tex'],
        'provides': ['Bundle D4 (Topological QC foundations) self-cite. Drinfeld centre + QEC-MTC cross-bridge. Companion deep paper to L2 PRL splash.'],
        'notes': 'In-preparation Bundle D4 self-cite. Phase 7f roadmap target.',
    },

    'Roehm2026D5': {
        'authors': 'Roehm, J. G.',
        'title': 'Dark sector under substrate constraints (Bundle D5)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/F/paper_draft.tex'],
        'provides': ['Bundle D5 (Tier-1 deep paper) self-cite. Phase 6m three-track closure: causal-set + entropic + Jacobson-thermo-GR.'],
        'notes': 'In-preparation Bundle D5 self-cite. Phase 7b sub-wave 7b.2 closed.',
    },

    'Roehm2026E1': {
        'authors': 'Roehm, J. G.',
        'title': 'Polariton stimulated-Hawking gain at modest probe-photon counts (Bundle E1 letter)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/F/paper_draft.tex'],
        'provides': ['Bundle E1 (polariton experimental letter) self-cite. Companion to D1 §6 polariton platform. Paris-LKB target.'],
        'notes': 'In-preparation Bundle E1 self-cite. Phase 7e roadmap target.',
    },

    'Roehm2026E2': {
        'authors': 'Roehm, J. G.',
        'title': 'Graphene Dirac-fluid analog Hawking radiation: device-parameter audit (Bundle E2 letter)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/F/paper_draft.tex'],
        'provides': ['Bundle E2 (graphene experimental letter) self-cite. Companion to D1 §6 graphene platform. Dean-Kim-Lucas target.'],
        'notes': 'In-preparation Bundle E2 self-cite. Phase 7e roadmap target.',
    },

    'Roehm2026F': {
        'authors': 'Roehm, J. G.',
        'title': 'Fluid-based approaches to fundamental physics: a formally verified survey (Bundle F flagship review)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D1/paper_draft.tex', 'papers/D2/paper_draft.tex',
                    'papers/D3/paper_draft.tex', 'papers/D4/paper_draft.tex',
                    'papers/D5/paper_draft.tex'],
        'provides': ['Bundle F (Tier-0 flagship review) self-cite. ~110pp PRD-long-format integrating all 12 sibling-bundle threads. Substrate-identity synthesis claim.'],
        'notes': 'In-preparation Bundle F self-cite. Phase 7g roadmap target. Drafted last after all 12 siblings reach Stage-13 GREEN.',
    },

    'Roehm2026L2': {
        'authors': 'Roehm, J. G.',
        'title': 'Three generations from modular invariance: Spin$^{\\mathbb{Z}_4}$ five-bordism (Bundle L2 PRL splash)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D2/paper_draft.tex', 'papers/D3/paper_draft.tex', 'papers/L2/paper_draft.tex'],
        'provides': ['Bundle L2 (PRL splash on three generations from modular invariance) self-cite. paper10_modular_generation source. Z_16 anomaly + Ext^n_{A(1)}(F2,F2) + 24|c_- modular derivation.'],
        'notes': 'In-preparation Bundle L2 self-cite. Canonical bibkey after 2026-05-11 Stage-13 paired-splash rename (was Roehm2026Wave10; alias retained). Phase 7b sub-wave 7b.3 closed at GREEN.',
    },

    # DEPRECATED ALIAS — historically the L2 splash was cited by D2 under the
    # wave-numbered name `Roehm2026Wave10`. Renamed to `Roehm2026L2` in the
    # 2026-05-11 Stage-13 fix-pass to align with the `Roehm2026D2` paired-splash
    # convention. Existing `\cite{Roehm2026Wave10}` in D2 have been swept to
    # `Roehm2026L2`; this alias kept for back-compatibility with any unswept
    # downstream consumer.
    'Roehm2026Wave10': {
        'authors': 'Roehm, J. G.',
        'title': 'Three generations from modular invariance: Spin$^{\\mathbb{Z}_4}$ five-bordism (Bundle L2 PRL splash)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': [],
        'provides': ['DEPRECATED ALIAS of Roehm2026L2.'],
        'notes': 'DEPRECATED 2026-05-11 — use Roehm2026L2. Same content; retained for back-compat with any external consumer who pinned the wave-numbered name.',
    },

    'Roehm2026I1': {
        'authors': 'Roehm, J. G.',
        'title': 'Verification methodology with worked cases (Bundle I1, Tier 3)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D2/paper_draft.tex', 'papers/D3/paper_draft.tex', 'papers/I1/paper_draft.tex'],
        'provides': ['Bundle I1 (Methodology paper with worked cases) self-cite. paper15 + paper44 + Phase 6f-6g substrate roster + Phase 6g W5 structural-Prop scoping pattern.'],
        'notes': 'In-preparation Bundle I1 self-cite. Phase 7a sub-wave 7a.2 closed at GREEN.',
    },

    'Roehm2026I2': {
        'authors': 'Roehm, J. G.',
        'title': 'Verified statistics + Lean tensor-categories: software paper (Bundle I2, Tier 3)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D2/paper_draft.tex', 'papers/I2/paper_draft.tex'],
        'provides': ['Bundle I2 (Software paper) self-cite. Phase 5c VerifiedJackknife + Phase 5o Wave 4 lean-tensor-categories + Phase 5o Wave 5 Mathlib upstream coordination.'],
        'notes': 'In-preparation Bundle I2 self-cite. Phase 7a sub-wave 7a.3 closed at GREEN.',
    },

    'Roehm2026Strategy': {
        'authors': 'Roehm, J. G.',
        'title': 'SK-EFT Hawking 14-bundle publication architecture (project paper-strategy frame)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex', 'papers/I3/paper_draft.tex'],
        'provides': ['14-bundle publication architecture (1 flagship + 5 Tier-1 deep + 3 Tier-2 PRL + 3 Tier-3 infrastructure + 2 Tier-4 experimental). NO-GO results as first-class publishable content.'],
        'notes': 'In-preparation project strategy document (`docs/PAPER_STRATEGY.md`). Inprep exemption per Pipeline Invariant #11. Bundle count updated 13->14 at I3 (Tier-3 software paper) introduction, Phase 6o.zeta. Verified against PAPER_STRATEGY.md 2026-05-11.',
    },

    'Degenne2025MarkovKernels': {
        'authors': 'Degenne, R.',
        'title': "Markov kernels in Mathlib's probability library",
        'journal': 'arXiv preprint',
        'volume': None, 'page': None, 'year': 2025,
        'doi': None, 'arxiv': '2510.04070',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Degenne2025MarkovKernels.pdf',
        'used_in': ['papers/I3/paper_draft.tex'],
        'provides': ['Markov kernels infrastructure for Mathlib (composition + disintegration); cited as substrate for I3 Phase 6o.zeta.'],
        'notes': 'Verified 2026-05-08 via WebFetch arXiv:2510.04070 — single author Rémy Degenne; supersedes the project carry-forward "Marion 2025 MarkovKernels" misattribution.',
    },

    'Degenne2025BrownianMotion': {
        'authors': 'Degenne, R. and Ledvinka, D. and Marion, E. and Pfaffelhuber, P.',
        'title': 'Formalization of Brownian motion in Lean',
        'journal': 'arXiv preprint',
        'volume': None, 'page': None, 'year': 2025,
        'doi': None, 'arxiv': '2511.20118',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Degenne2025BrownianMotion.pdf',
        'used_in': ['papers/I3/paper_draft.tex'],
        'provides': ['Brownian motion in Lean: Carathéodory + Kolmogorov extension; Kolmogorov-Chentsov continuity; Gaussian measures on Banach spaces.'],
        'notes': 'Verified 2026-05-08 via WebFetch arXiv:2511.20118; 4-author paper Degenne–Ledvinka–Marion–Pfaffelhuber.',
    },

    'FalascoEsposito2025RMP': {
        'authors': 'Falasco, G. and Esposito, M.',
        'title': 'Macroscopic stochastic thermodynamics',
        'journal': 'Reviews of Modern Physics',
        'volume': 97, 'page': '015002', 'year': 2025,
        'doi': '10.1103/RevModPhys.97.015002', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/FalascoEsposito2025RMP.json',
        'used_in': ['papers/I3/paper_draft.tex'],
        'provides': ['Macroscopic stochastic thermodynamics framework; cited as motivation for the LDP frontier in I3.'],
        'notes': 'Verified 2026-05-08 via Crossref API on DOI 10.1103/RevModPhys.97.015002.',
    },

    'mathlib4_2020': {
        'authors': 'The Mathlib Community',
        'title': 'The Lean Mathematical Library',
        'journal': 'Proceedings of the 9th ACM SIGPLAN International Conference on Certified Programs and Proofs (CPP 2020)',
        'volume': None, 'page': '367-381', 'year': 2020,
        'doi': '10.1145/3372885.3373824', 'arxiv': '1910.09336',
        'doi_verified': True, 'arxiv_verified': True,
        'inprep': False,
        'primary_source_path': None,  # textbook-exempt: community-library reference
        'used_in': ['papers/I3/paper_draft.tex'],
        'provides': ['Mathlib library reference (CPP 2020 paper); cited for the Mathlib4 measure-theory + probability infrastructure that I3 builds on.'],
        'notes': 'The Mathlib Community community-library paper, CPP 2020 (DOI 10.1145/3372885.3373824, arXiv:1910.09336). Used in I3 as the canonical citation for the Mathlib library. Added 2026-05-11 (D1 fix-pass missing-from-registry remediation).',
    },

    'YingDegenne2022Martingales': {
        'authors': 'Ying, K. and Degenne, R.',
        'title': "A Formalization of Doob's Martingale Convergence Theorems in mathlib",
        'journal': 'Proceedings of the 12th ACM SIGPLAN International Conference on Certified Programs and Proofs (CPP 2023)',
        'volume': None, 'page': '334-347', 'year': 2023,
        'doi': '10.1145/3573105.3575675', 'arxiv': '2212.05578',
        'doi_verified': True, 'arxiv_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/YingDegenne2022Martingales.pdf',
        'used_in': ['papers/I3/paper_draft.tex'],
        'provides': ['First Mathlib4 formalization of Doob martingale convergence theorems; predicate scaffolding for filtrations, adapted/predictable processes, stopping times; canonical prior art for the I3 predicate-substrate-first / quantitative-content-later release pattern.'],
        'notes': 'Verified 2026-05-11 via WebFetch to arXiv:2212.05578 (title + 2-author list Ying + Degenne) and DBLP record dblp:conf/cpp/YingD23 (CPP 2023 venue, pp. 334-347, DOI 10.1145/3573105.3575675). PDF fetched into primary-sources cache.',
    },

    'KaratzasShreve1991BMSC': {
        'authors': 'Karatzas, I. and Shreve, S. E.',
        'title': 'Brownian Motion and Stochastic Calculus',
        'journal': 'Springer Graduate Texts in Mathematics 113 (textbook)',
        'volume': 113, 'page': None, 'year': 1991,
        'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Springer GTM 113, 2nd ed. (1991); canonical Brownian-motion / '
                         'stochastic-calculus monograph verified via secondary academic '
                         'citation.',
        'used_in': ['papers/I3/paper_draft.tex'],
        'provides': ['Standard Brownian-motion + stochastic-calculus textbook; Itô integral, Itô lemma, Girsanov, Novikov classical references.'],
        'notes': 'Textbook-exempt per Pipeline Invariant #11 (no DOI/arXiv; Springer GTM 113, 2nd ed. 1991).',
    },

    'RevuzYor1999CMSM': {
        'authors': 'Revuz, D. and Yor, M.',
        'title': 'Continuous Martingales and Brownian Motion',
        'journal': 'Springer Grundlehren 293 (textbook)',
        'volume': 293, 'page': None, 'year': 1999,
        'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Springer Grundlehren 293, 3rd ed. (1999); canonical '
                         'continuous-martingale monograph verified via secondary '
                         'academic citation.',
        'used_in': ['papers/I3/paper_draft.tex'],
        'provides': ['Continuous-martingale + Brownian-motion textbook; complementary to KaratzasShreve.'],
        'notes': 'Textbook-exempt per Pipeline Invariant #11 (no DOI/arXiv; Springer Grundlehren 293, 3rd ed. 1999).',
    },

    'DemboZeitouni1998LDT': {
        'authors': 'Dembo, A. and Zeitouni, O.',
        'title': 'Large Deviations Techniques and Applications',
        'journal': 'Springer Applications of Mathematics 38 (textbook)',
        'volume': 38, 'page': None, 'year': 1998,
        'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Springer Applications of Mathematics 38, 2nd ed. (1998); '
                         'canonical large-deviations monograph verified via secondary '
                         'academic citation.',
        'used_in': ['papers/I3/paper_draft.tex'],
        'provides': ['Standard LDP textbook; Cramér + Sanov + Varadhan + contraction principle classical references.'],
        'notes': 'Textbook-exempt per Pipeline Invariant #11 (no DOI/arXiv; Springer Applications of Mathematics 38, 2nd ed. 1998).',
    },

    'denHollander2000LDPs': {
        'authors': 'den Hollander, F.',
        'title': 'Large Deviations',
        'journal': 'AMS Fields Institute Monographs 14 (textbook)',
        'volume': 14, 'page': None, 'year': 2000,
        'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'AMS Fields Institute Monographs 14 (2000); canonical '
                         'large-deviations monograph verified via secondary academic '
                         'citation.',
        'used_in': ['papers/I3/paper_draft.tex'],
        'provides': ['Pedagogical LDP textbook complementary to DemboZeitouni; cited as alternate reference.'],
        'notes': 'Textbook-exempt per Pipeline Invariant #11 (no DOI/arXiv; AMS Fields Institute Monographs 14, 2000).',
    },

    # DEPRECATED ALIAS — kept because D3 + F still cite Roehm2026Modular at
    # narrative-level cross-references. Same content as Roehm2026L2.
    'Roehm2026Modular': {
        'authors': 'Roehm, J. G.',
        'title': 'Three Standard Model fermion generations from modular invariance (Bundle L2 splash)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex', 'papers/F/paper_draft.tex'],
        'provides': ['N_f = 16 anchor for the Sakharov coefficient G_N = 12pi/(N_f Lambda_UV^2); modular-invariance derivation of three SM fermion generations.'],
        'notes': 'DEPRECATED ALIAS for Roehm2026L2 (= former Roehm2026Wave10). Same content. Phase 7 Stage-13 fix-pass 2026-05-11 elected to leave existing D3+F \\cite{Roehm2026Modular} references in place rather than sweep them; new papers should cite Roehm2026L2.',
    },

    'CorleyJacobson1996': {
        'authors': 'Corley, S. and Jacobson, T.',
        'title': 'Hawking spectrum and high-frequency dispersion',
        'journal': 'Physical Review D',
        'volume': 54,
        'page': '1568',
        'year': 1996,
        'doi': '10.1103/PhysRevD.54.1568',
        'arxiv': 'hep-th/9601073',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D1/paper_draft.tex', 'papers/paper4_wkb_connection/paper_draft.tex'],
        'provides': ['Foundational dispersive-Hawking analysis: trans-Planckian problem framing; WKB connection-formula precedent for sub-luminal dispersion suppression.'],
        'notes': 'Foundational reference for the trans-Planckian problem in analog Hawking radiation; underlies the subluminal-dispersion elimination claim in D1 §6.',
    },

    'CoutantParentani2012': {
        'authors': 'Coutant, A., Parentani, R., Finazzi, S.',
        'title': 'Black hole radiation with short distance dispersion, an analytical S-matrix approach',
        'journal': 'Physical Review D',
        'volume': 85,
        'page': '024021',
        'year': 2012,
        'doi': '10.1103/PhysRevD.85.024021',
        'arxiv': '1108.1821',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D1/paper_draft.tex', 'papers/paper4_wkb_connection/paper_draft.tex'],
        'provides': ['Analytical S-matrix treatment of short-distance-dispersion Hawking radiation.'],
        'notes': 'Crossref-verified 2026-05-11 (D1 Stage-13 fix-pass): actual published title is `Black hole radiation with short distance dispersion, an analytical S-matrix approach`; prior registry title `Hawking radiation with dispersion: the broadened horizon paradigm` was misattributed. Three authors (Coutant, Parentani, Finazzi); prior registry omitted Finazzi.',
    },

    'RobertsonParentani2015': {
        'authors': 'Robertson, S., Parentani, R.',
        'title': 'Hawking radiation in the presence of high-momentum dissipation',
        'journal': 'Physical Review D',
        'volume': 92,
        'page': '044043',
        'year': 2015,
        'doi': '10.1103/PhysRevD.92.044043',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D1/paper_draft.tex', 'papers/paper4_wkb_connection/paper_draft.tex'],
        'provides': ['Analytic dissipative-Hawking results; mode propagation through a high-momentum-dissipating horizon at the WKB level.'],
        'notes': 'Crossref-verified 2026-05-11 (D1 Stage-13 fix-pass): actual published title is `Hawking radiation in the presence of high-momentum DISSIPATION` (not `dispersion: analytical results from cubic dispersion`). Prior registry arXiv 1503.04047 was wrong (math.CO paper); Crossref carries no arXiv for this PRD record. arXiv field set to None pending separate identification.',
    },

    'BelgiornoCacciatori2024': {
        'authors': 'Belgiorno, F. and Cacciatori, S. L. and Trevisan, S.',
        'title': 'Analogous Hawking Radiation in Dispersive Media',
        'journal': 'Universe',
        'volume': 10,
        'page': 412,
        'year': 2024,
        'doi': '10.3390/universe10110412',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D1/paper_draft.tex', 'papers/paper4_wkb_connection/paper_draft.tex'],
        'provides': ['Analytic dispersive-Hawking radiation framework in non-linear dielectric media; relevant to project D1 dispersive-WKB and paper4 WKB-connection content.'],
        'notes': 'Belgiorno-Cacciatori-Trevisan 2024 Universe 10, 412 (DOI 10.3390/universe10110412; MDPI open-access). Replaced 2026-05-08 (Phase 7 absorption Session 5): the prior registry entry recorded a fabricated title "Rigorous WKB analysis for analog Hawking radiation" + non-resolving DOI 10.1088/1361-6382/ad3812 — primary-source verification surfaced it as a hallucinated citation and the actual Belgiorno-Cacciatori-Trevisan 2024 paper title is the MDPI Universe entry above.',
    },

    'FreedmanLarsenWang2002': {
        'authors': 'Freedman, M. H. and Larsen, M. and Wang, Z.',
        'title': 'A modular functor which is universal for quantum computation',
        'journal': 'Communications in Mathematical Physics',
        'volume': '227',
        'page': '605-622',
        'year': 2002,
        'doi': '10.1007/s002200200645',
        'arxiv': 'quant-ph/0001108',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D4/paper_draft.tex'],
        'provides': ['Universal-quantum-computation modular functor; Fibonacci-anyon-class universal-computation foundation; cited at the topological-quantum-computation introduction.'],
        'notes': 'Foundational reference for topological quantum computation modular-functor universality.',
    },

    'NayakSimonSternFreedmanDasSarma2008': {
        'authors': 'Nayak, C. and Simon, S. H. and Stern, A. and Freedman, M. and Das Sarma, S.',
        'title': 'Non-Abelian anyons and topological quantum computation',
        'journal': 'Reviews of Modern Physics',
        'volume': '80',
        'page': '1083-1159',
        'year': 2008,
        'doi': '10.1103/RevModPhys.80.1083',
        'arxiv': '0707.1889',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D4/paper_draft.tex'],
        'provides': ['Non-abelian anyons; topological quantum computation review; foundational Hubbard-doublon SWAP-gate / Berry-phase background.'],
        'notes': 'Standard review reference for non-abelian-anyon TQC.',
    },

    'ReshetikhinTuraev1991': {
        'authors': 'Reshetikhin, N. and Turaev, V. G.',
        'title': 'Invariants of 3-manifolds via link polynomials and quantum groups',
        'journal': 'Inventiones Mathematicae',
        'volume': '103',
        'page': '547-597',
        'year': 1991,
        'doi': '10.1007/BF01239527',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D4/paper_draft.tex'],
        'provides': ['WRT topological quantum field theory: 3-manifold invariants from quantum-group representation theory.'],
        'notes': 'Foundational WRT TQFT construction; core reference for D4 §5.',
    },

    'Witten1989': {
        'authors': 'Witten, E.',
        'title': 'Quantum field theory and the Jones polynomial',
        'journal': 'Communications in Mathematical Physics',
        'volume': '121',
        'page': '351-399',
        'year': 1989,
        'doi': '10.1007/BF01217730',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D4/paper_draft.tex'],
        'provides': ['Witten Chern-Simons construction of the Jones polynomial; companion derivation to RT 1991 for the WRT TQFT structure.'],
        'notes': 'Foundational reference for the SU(2)_k Chern-Simons / WRT correspondence.',
    },

    'Roehm2026Wave7': {
        'authors': 'Roehm, J. G.',
        'title': 'Chirality wall: lattice no-go and TPF evasion (paper7 in-prep)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D2/paper_draft.tex', 'papers/paper7_chirality_formal/paper_draft.tex'],
        'provides': ['Chirality-wall pillar 1 — Golterman-Shamir lattice no-go (9 conditions C1-C6 + I1-I3) plus TPFEvasion-class round_not_continuous + rotor_hilbert_not_finite_dim closures.'],
        'notes': 'In-preparation D2 source paper7 self-cite. Inprep exemption per Pipeline Invariant #11.',
    },

    'Roehm2026Wave8': {
        'authors': 'Roehm, J. G.',
        'title': 'Chirality wall master synthesis: Onsager + Witten anomaly + 4+1D gapped interface (paper8 in-prep)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D2/paper_draft.tex', 'papers/paper8_chirality_master/paper_draft.tex'],
        'provides': ['Chirality-wall master synthesis: Onsager algebra Z_2 -> Z_16; Witten anomaly element-8 identification; gapped_interface_axiom; SPTStacking 16-fold periodicity.'],
        'notes': 'In-preparation D2 source paper8 self-cite. Inprep exemption per Pipeline Invariant #11.',
    },

    'Roehm2026Wave9': {
        'authors': 'Roehm, J. G.',
        'title': 'SM Z16 anomaly and minimal Drinfeld centre (paper9 in-prep)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D2/paper_draft.tex', 'papers/D4/paper_draft.tex', 'papers/paper9_sm_anomaly_drinfeld/paper_draft.tex'],
        'provides': ['SM Z_16 anomaly + Drinfeld centre Z(Vec_S3) toric-code anchor; Spin^Z_4 5-bordism dai_freed_spin_z4 placeholder.'],
        'notes': 'In-preparation D2/D4 source paper9 self-cite. Inprep exemption per Pipeline Invariant #11.',
    },

    'Roehm2026Wave2': {
        'authors': 'Roehm, J. G.',
        'title': 'Second-order Schwinger--Keldysh effective field theory: counting, KMS optimality, and parity (paper2 in-prep)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D1/paper_draft.tex', 'papers/paper2_second_order/paper_draft.tex'],
        'provides': ['Second-order SK-EFT counting; KMS optimality biconditional via SKDoubling.firstOrder_KMS_optimal; parity-classification of dispersive vs dissipative coefficients.'],
        'notes': 'In-preparation D1 source paper2 self-cite. Inprep exemption per Pipeline Invariant #11.',
    },

    'Roehm2026Wave12': {
        'authors': 'Roehm, J. G.',
        'title': 'Polariton platform: stimulated Hawking and reservoir coupling (paper12 in-prep)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D1/paper_draft.tex', 'papers/paper12_polariton/paper_draft.tex', 'papers/E1/paper_draft.tex'],
        'provides': ['Polariton platform LKB-Paris configuration; stimulated-Hawking gain G > 0.5 at omega/kappa = 0.175 with N_probe = 100 photons per mode; reservoir-corrected sound speed; quasinormal-mode resonances.'],
        'notes': 'In-preparation D1 source paper12 self-cite. E1 PRL splash extraction. Inprep exemption per Pipeline Invariant #11.',
    },

    'Roehm2026Wave16': {
        'authors': 'Roehm, J. G.',
        'title': 'Graphene Dirac-fluid SK-EFT analog Hawking radiation (paper16_graphene_sk_eft in-prep)',
        'journal': 'in preparation',
        'volume': None, 'page': None, 'year': 2026, 'doi': None, 'arxiv': None,
        'doi_verified': True,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D1/paper_draft.tex', 'papers/paper16_graphene_sk_eft/paper_draft.tex', 'papers/E2/paper_draft.tex'],
        'provides': ['Graphene Dirac-fluid platform Dean-Kim-Lucas configuration; T_H ~ 2.4 K; 92% Lean theorem reuse with BEC modules; Wiedemann-Franz violation L/L_0 > 200; closed-form noise spectrum.'],
        'notes': 'In-preparation D1 source paper16_graphene_sk_eft self-cite. E2 PRL splash extraction. Inprep exemption per Pipeline Invariant #11.',
    },

    'DaiFreed1994': {
        'authors': 'Dai, X. and Freed, D. S.',
        'title': '$\\eta$-invariants and determinant lines',
        'journal': 'Journal of Mathematical Physics',
        'volume': '35',
        'page': '5155-5194',
        'year': 1994,
        'doi': '10.1063/1.530747',
        'arxiv': 'hep-th/9405012',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D2/paper_draft.tex', 'papers/paper10_modular_generation/paper_draft.tex'],
        'provides': ['Dai-Freed eta-invariant + determinant-line construction underlying the Spin^Z_4 5-bordism Z_16 anomaly classification.'],
        'notes': 'Foundational reference for the Spin^Z_4 cobordism classification of the SM Z_16 anomaly. Cited by Garcia-Etxebarria-Montero 2019 and the Z16AnomalyComputation Lean module via the dai_freed_spin_z4 placeholder.',
    },

    # ════════════════════════════════════════════════════════════════
    # Phase 6m — Dark-energy review (causal-set / entropic / Jacobson-thermo-GR)
    # ════════════════════════════════════════════════════════════════
    # Citations supporting paper45_phase6m_review (Phase 6m R1+R2+R3 dossiers).
    # Track A: causal-set DE (everpresent-Lambda + BDG action).
    # Track B: entropic-gravity DE (Verlinde / Cadoni-Tuveri DEC / HDE / Padmanabhan-CosMIn / Hossenfelder-Verlinde).
    # Track C: Jacobson-thermo-GR DE (entanglement-equilibrium + f(R) + Lovelock + KSS LV + unimodular + Volovik-Jannes).
    # Cross-track: DESI DR2 / r_d-anchoring / SN-systematics / SFDM-bridge.

    # ──── Track A: causal-set dark energy ────

    'Sorkin1991Everpresent': {
        'authors': 'Sorkin, R. D.',
        'title': 'Spacetime and Causal Sets',
        'journal': "in J. C. D'Olivo et al. (eds.), Relativity and Gravitation: Classical and Quantum",
        'volume': None,
        'page': None,
        'year': 1991,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Pre-arXiv 1991 book chapter (World Scientific). Sorkin everpresent-Lambda '
                 'heuristic origin (1987 talk; published 1991). No primary-source cache: '
                 'pre-arXiv-and-pre-DOI book chapter — Wave-6 textbook-exempt.',
    },
    'Sorkin1997Everpresent': {
        'authors': 'Sorkin, R. D.',
        'title': 'Forks in the road, on the way to quantum gravity',
        'journal': 'Int. J. Theor. Phys.',
        'volume': 36,
        'page': '2759',
        'year': 1997,
        'doi': '10.1023/A:1018885525859',
        'arxiv': 'gr-qc/9706002',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Sorkin1997Everpresent.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Forks-and-causet quantum gravity; everpresent-Lambda rationale and '
                 'lineage anchor for Phase 6m Track A.',
    },
    'Sorkin2007Everpresent': {
        'authors': 'Sorkin, R. D.',
        'title': 'Is the cosmological "constant" a nonlocal quantum residue of discreteness of the causal set type?',
        'journal': 'AIP Conf. Proc.',
        'volume': 957,
        'page': '142',
        'year': 2007,
        'doi': '10.1063/1.2823737',
        'arxiv': '0710.1675',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Sorkin2007Everpresent.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Everpresent-Lambda stochastic-Lambda phenomenology (Phase 6m TA-R3 §7).',
    },
    'AhmedDodelsonGreeneSorkin2004': {
        'authors': 'Ahmed, M., Dodelson, S., Greene, P. B., Sorkin, R.',
        'title': 'Everpresent Lambda',
        'journal': 'Phys. Rev. D',
        'volume': 69,
        'page': '103523',
        'year': 2004,
        'doi': '10.1103/PhysRevD.69.103523',
        'arxiv': 'astro-ph/0209274',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/AhmedDodelsonGreeneSorkin2004.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Model 1 of everpresent-Lambda phenomenology — Phase 6m TA-R1/R3 anchor.',
    },
    'AhmedSorkin2013': {
        'authors': 'Ahmed, M., Sorkin, R.',
        'title': 'Everpresent Lambda. II. Structural stability',
        'journal': 'Phys. Rev. D',
        'volume': 87,
        'page': '063515',
        'year': 2013,
        'doi': '10.1103/PhysRevD.87.063515',
        'arxiv': '1210.2589',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/AhmedSorkin2013.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Updated everpresent-Lambda phenomenology — Phase 6m TA-R1/R3.',
    },
    'ZwaneAfshordiSorkin2018': {
        'authors': 'Zwane, N., Afshordi, N., Sorkin, R. D.',
        'title': 'Cosmological tests of everpresent Lambda',
        'journal': 'Class. Quantum Grav.',
        'volume': 35,
        'page': '195003',
        'year': 2018,
        'doi': '10.1088/1361-6382/aadc36',
        'arxiv': '1703.06265',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/ZwaneAfshordiSorkin2018.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Model 2 / suppression-variant of everpresent-Lambda; covariant '
                 '<Lambda>=0 prescription (Phase 6m TA-R1/R2/R3).',
    },
    'DasNasiriYazdi2023': {
        'authors': 'Das, S., Nasiri, F., Yazdi, Y. K.',
        'title': 'Aspects of everpresent Lambda (I): a fluctuating cosmological constant from spacetime discreteness',
        'journal': 'JCAP',
        'volume': '10',
        'page': '047',
        'year': 2023,
        'doi': '10.1088/1475-7516/2023/10/047',
        'arxiv': '2304.03819',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/DasNasiriYazdi2023.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Imperial reanalysis Pt I; ~10^4 Model-1 seeds vs Pantheon+ '
                 '(Phase 6m TA-R2/R3 §2).',
    },
    'DasNasiriYazdi2024': {
        'authors': 'Das, S., Nasiri, F., Yazdi, Y. K.',
        'title': 'Aspects of everpresent Lambda (II): cosmological tests of current models',
        'journal': 'JCAP',
        'volume': '10',
        'page': '076',
        'year': 2024,
        'doi': '10.1088/1475-7516/2024/10/076',
        'arxiv': '2307.13743',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/DasNasiriYazdi2024.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Imperial reanalysis Pt II; ISW dominance for everpresent-Lambda '
                 '(Phase 6m TA-R2/R3 §2-§3).',
    },
    'BenincasaDowker2010': {
        'authors': 'Benincasa, D. M. T., Dowker, F.',
        'title': 'The scalar curvature of a causal set',
        'journal': 'Phys. Rev. Lett.',
        'volume': 104,
        'page': '181301',
        'year': 2010,
        'doi': '10.1103/PhysRevLett.104.181301',
        'arxiv': '1001.2725',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/BenincasaDowker2010.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Causal-set d\'Alembertian / BDG framework foundation '
                 '(Phase 6m TA-R1/R3 §7).',
    },
    'DowkerGlaser2013': {
        'authors': 'Dowker, F., Glaser, L.',
        'title': 'Causal set d\'Alembertians for various dimensions',
        'journal': 'Class. Quantum Grav.',
        'volume': 30,
        'page': '195016',
        'year': 2013,
        'doi': '10.1088/0264-9381/30/19/195016',
        'arxiv': '1305.2588',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/DowkerGlaser2013.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'BDG action generalization (Phase 6m TA-R3 §7).',
    },
    'Glaser2014BDG': {
        'authors': 'Glaser, L.',
        'title': 'A closed form expression for the causal set d\'Alembertian',
        'journal': 'Class. Quantum Grav.',
        'volume': 31,
        'page': '095007',
        'year': 2014,
        'doi': '10.1088/0264-9381/31/9/095007',
        'arxiv': '1311.1701',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Glaser2014BDG.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'BDG action 4D generalization (Phase 6m TA-R3 §7).',
    },
    'MoradiYazdiZilhao2025BDG': {
        'authors': 'Moradi, M., Yazdi, Y. K., Zilhão, M.',
        'title': 'Bi-action formulations of causal-set quantum gravity',
        'journal': 'Class. Quantum Grav.',
        'volume': 42,
        'page': '045017',
        'year': 2025,
        'doi': '10.1088/1361-6382/ada3a4',
        'arxiv': '2407.03395',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/MoradiYazdiZilhao2025BDG.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Primary BDG R3 reference; bi-action variance toolkit '
                 '(Phase 6m TA-R1/R2/R3 §5).',
    },
    'AdamsonWallden2025BDG': {
        'authors': 'Adamson, A., Wallden, P.',
        'title': 'Quantum-counting bi-action formulations for causal sets',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2505.22217',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/AdamsonWallden2025BDG.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Quantum-counting BDG actions (Phase 6m TA-R3 §5; preprint, '
                 'Crossref DOI tba).',
    },

    # ──── Track A NO-GO supplementary ────

    'AslanbeigiSaravaniSorkin2014': {
        'authors': 'Aslanbeigi, S., Saravani, M., Sorkin, R. D.',
        'title': 'Generalized causal set d\'Alembertians',
        'journal': 'JHEP',
        'volume': '06',
        'page': '024',
        'year': 2014,
        'doi': '10.1007/JHEP06(2014)024',
        'arxiv': '1403.1622',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/AslanbeigiSaravaniSorkin2014.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Causal-set d\'Alembertian (Phase 6m TA NO-GO at R1); 4D B-tilde '
                 'instability (TA-R1/R2 §6).',
    },
    'Barrow2007EverpresentBound': {
        'authors': 'Barrow, J. D.',
        'title': 'A strong constraint on ever-present Lambda',
        'journal': 'Phys. Rev. D',
        'volume': 75,
        'page': '067301',
        'year': 2007,
        'doi': '10.1103/PhysRevD.75.067301',
        'arxiv': 'gr-qc/0612128',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Barrow2007EverpresentBound.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'alpha <~ 10^-5 bound on everpresent-Lambda — prescription (4) '
                 '(Phase 6m TA-R1 §3, TA-R3 §4); publishable short-note seed for '
                 'Barrow-prescription-dependence caveat.',
    },
    'Zuntz2008': {
        'authors': 'Zuntz, J. A.',
        'title': 'The cosmic microwave background in a causal set universe',
        'journal': 'Phys. Rev. D',
        'volume': 77,
        'page': '043002',
        'year': 2008,
        'doi': '10.1103/PhysRevD.77.043002',
        'arxiv': '0711.2904',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Zuntz2008.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Tightening of Barrow bound (Phase 6m TA-R3 §4).',
    },
    'BombelliHensonSorkin2009': {
        'authors': 'Bombelli, L., Henson, J., Sorkin, R. D.',
        'title': 'Discreteness without symmetry breaking: a theorem',
        'journal': 'Class. Quantum Grav.',
        'volume': 26,
        'page': '125018',
        'year': 2009,
        'doi': '10.1088/0264-9381/26/12/125018',
        'arxiv': 'gr-qc/0605006',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/BombelliHensonSorkin2009.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Distinguishes from R2-misattributed CQG 21:1593; Phase 6m '
                 'TA-R3 §7 reference cleanup.',
    },

    # ──── Track B: entropic-gravity dark energy ────

    'Verlinde2017dSEmergent': {
        'authors': 'Verlinde, E. P.',
        'title': 'Emergent Gravity and the Dark Universe',
        'journal': 'SciPost Phys.',
        'volume': 2,
        'page': '016',
        'year': 2017,
        'doi': '10.21468/SciPostPhys.2.3.016',
        'arxiv': '1611.02269',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Verlinde2017dSEmergent.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex',
                    'papers/D5/paper_draft.tex'],
        'provides': [],
        'notes': 'Emergent gravity in dS; predicts Lambda-CDM-equivalent w '
                 '(Phase 6m TB-R1/R2/R3 §1). Metadata re-verified 2026-06-10 '
                 '(review-2026-06-05 D5 phantom-citation fix): arXiv abs page '
                 'confirms SciPost Phys. 2, 016 (2017); DOI verified via '
                 'Crossref API (Erik P. Verlinde, SciPost Physics 2, 016, '
                 'issued 2017-05-16). D5 bibitem + body cite wiring added '
                 'same day; title capitalization normalized to published form.',
    },
    'HalenkaMiller2020': {
        'authors': 'Halenka, V. and Miller, C. J.',
        'title': 'Testing emergent gravity with mass densities of galaxy clusters',
        'journal': 'Phys. Rev. D',
        'volume': 102,
        'page': '084007',
        'year': 2020,
        'doi': '10.1103/PhysRevD.102.084007',
        'arxiv': '1807.01689',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/HalenkaMiller2020.pdf',
        'used_in': ['papers/D5/paper_draft.tex', 'papers/F/paper_draft.tex',
                    'papers/D3/paper_draft.tex'],
        'provides': [],
        'notes': 'Added 2026-06-10 (review-2026-06-05 D5 phantom-citation fix: '
                 'prose previously named "Halenka-Miller 2018" with no bibitem or '
                 'registry entry). 23 relaxed galaxy clusters with weak-lensing '
                 'total-mass + X-ray gas-mass profiles; under nominal profile '
                 'assumptions Verlinde-2017 EG (no dark matter) fits only near the '
                 'virial radius and is ruled out at >5 sigma in cores/outskirts; '
                 'the abstract notes the exclusion weakens when weak-lensing/X-ray '
                 'systematics are included. Supports ONLY the cluster-mass-profile '
                 'leg of EGDE1 (Lean theorem verlinde_2017_no_go_via_cluster_'
                 'mass_densities_halenka_miller, renamed 2026-06-10 from '
                 'verlinde_2017_no_go_via_cmb_bullet_cluster_halenka_miller; '
                 'constant halenka_miller_cluster_nominal_sigma encodes the '
                 'nominal-assumptions-only caveat, compared against the sigma-'
                 'scale five_sigma_threshold rather than the log-Bayes '
                 'jeffreys_decisive_threshold); the CMB and Bullet-cluster '
                 'critiques are separate structural legs from the Phase-6m '
                 'dossiers (no scalar perturbation theory; apparent-DM-tracks-'
                 'baryons vs lensing/X-ray offset, R5 B.2.1 citing Pardo 2017), '
                 'not from this paper. arXiv v1 '
                 '2018-07-04; published PRD 102, 084007 (2020-10-05). Metadata '
                 'verified 2026-06-10 via arXiv abs page + Crossref API (DOI '
                 'resolves to matching title/authors/volume/article).',
    },
    'KMM2013ancilla': {
        'authors': 'Kliuchnikov, V. and Maslov, D. and Mosca, M.',
        'title': 'Asymptotically optimal approximation of single qubit unitaries by '
                 'Clifford and T circuits using a constant number of ancillary qubits',
        'journal': 'Phys. Rev. Lett.',
        'volume': 110,
        'page': '190502',
        'year': 2013,
        'doi': '10.1103/PhysRevLett.110.190502',
        'arxiv': '1212.0822',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/KMM2013ancilla.pdf',
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Added 2026-06-10 (D8 absorption of Phase 6AO Track 2). The KMM '
                 'ancilla-assisted construction behind kmm_universal_headline (3-qubit '
                 'Clifford+T word <= 50400k+812, no prime-density input). Title/authors '
                 'verified against arXiv API 2026-06-10; primary source cached.',
    },
    'Selinger2015': {
        'authors': 'Selinger, P.',
        'title': 'Efficient Clifford+T approximation of single-qubit operators',
        'journal': 'Quantum Inf. Comput.',
        'volume': 15,
        'page': '159-180',
        'year': 2015,
        'doi': '10.26421/QIC15.1-2-10',
        'arxiv': '1212.6253',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Selinger2015.pdf',
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Added 2026-06-10 (D8 absorption, Phase 6AM W5 / 6AO Track 1). The '
                 'randomized-under-prime-distribution efficiency result; its Hyp 29 = '
                 'RS Hyp 8.3 is the honestly-documented prime-density wall carried as '
                 'an explicit hypothesis in the Lean substrate. Title/authors verified '
                 'against arXiv API 2026-06-10; primary source cached.',
    },
    'GilesSelinger2013': {
        'authors': 'Giles, B. and Selinger, P.',
        'title': 'Exact synthesis of multiqubit Clifford+T circuits',
        'journal': 'Phys. Rev. A',
        'volume': 87,
        'page': '032332',
        'year': 2013,
        'doi': '10.1103/PhysRevA.87.032332',
        'arxiv': '1212.0506',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/GilesSelinger2013.pdf',
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Added 2026-06-10 (D8 absorption, Phase 6AO Track 1 exact-synthesis '
                 'context for the Ross-Selinger Appendix-C chain). Title/authors '
                 'verified against arXiv API 2026-06-10; primary source cached.',
    },
    'AKN1998': {
        'authors': 'Aharonov, D. and Kitaev, A. and Nisan, N.',
        'title': 'Quantum circuits with mixed states',
        'journal': 'Proc. 30th Annual ACM Symposium on Theory of Computing (STOC)',
        'volume': None,
        'page': '20-30',
        'year': 1998,
        'doi': '10.1145/276698.276708',
        'arxiv': 'quant-ph/9806029',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/AKN1998.pdf',
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Added 2026-06-10 (D8 absorption, Phase 6AP W3). Origin of the '
                 'diamond-norm channel distance; the AKN unitary->diamond bound '
                 'diamondDist_unitaryKraus_le is the Lean-verified form. Title/authors '
                 'verified against arXiv API 2026-06-10; primary source cached.',
    },
    'Meiburg2025PhysLib': {
        'authors': 'Meiburg, A. and Lessa, L. A. and Soldati, R. R.',
        'title': "A Formalization of the Generalized Quantum Stein's Lemma in Lean",
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2510.08672',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Meiburg2025PhysLib.pdf',
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Added 2026-06-10 (D8 absorption, Phase 6AP W3 PhysLib trace-norm '
                 'transfer). The paper accompanying the leanprover-community/physlib '
                 'library this project consumes via the traceNorm_eq_physlib bridge. '
                 'NOTE: actual title is the Stein-lemma formalization paper (verified '
                 'against arXiv API + cached PDF page 1, 2026-06-10) — cited here as '
                 'the canonical PhysLib reference.',
    },
    'CadoniCasadioGiustiMuckTuveri2018': {
        'authors': 'Cadoni, M., Casadio, R., Giusti, A., Mück, W., Tuveri, M.',
        'title': 'Effective fluid description of the dark universe',
        'journal': 'Phys. Lett. B',
        'volume': 776,
        'page': '242',
        'year': 2018,
        'doi': '10.1016/j.physletb.2017.11.058',
        'arxiv': '1707.09945',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/CadoniCasadioGiustiMuckTuveri2018.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Cadoni-Tuveri DEC theoretical foundation; BEC-graviton-condensate '
                 '(Phase 6m TB-R1/R3 §3, §7).',
    },
    'CadoniCasadioGiustiTuveri2018PRD': {
        'authors': 'Cadoni, M., Casadio, R., Giusti, A., Tuveri, M.',
        'title': 'Quasilocal mass and the dark universe',
        'journal': 'Phys. Rev. D',
        'volume': 97,
        'page': '044047',
        'year': 2018,
        'doi': '10.1103/PhysRevD.97.044047',
        'arxiv': '1801.10374',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/CadoniCasadioGiustiTuveri2018PRD.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Corpuscular-gravity dark-force formulation (DEC corpus) '
                 '(Phase 6m TB-R3 §7).',
    },
    'CadoniTuveri2019': {
        'authors': 'Cadoni, M., Tuveri, M.',
        'title': 'Galactic-scale dark force from quantum gravitational corrections',
        'journal': 'Phys. Rev. D',
        'volume': 100,
        'page': '024029',
        'year': 2019,
        'doi': '10.1103/PhysRevD.100.024029',
        'arxiv': '1812.01545',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/CadoniTuveri2019.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Galactic-rotation-curve fits; alpha exponent (Phase 6m TB-R1/R3 '
                 '§3, §7). Note: arXiv:1904.11835 is the same paper resubmitted; '
                 '1812.01545 is the original arXiv submission per arXiv canonical '
                 'tracking.',
    },
    'CadoniSannaTuveri2020': {
        'authors': 'Cadoni, M., Sanna, A. P., Tuveri, M.',
        'title': 'Anisotropic fluid cosmology: an alternative to dark matter?',
        'journal': 'Phys. Rev. D',
        'volume': 102,
        'page': '023514',
        'year': 2020,
        'doi': '10.1103/PhysRevD.102.023514',
        'arxiv': '2002.06988',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/CadoniSannaTuveri2020.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'DEC cosmological extension; SNe Ia distance modulus '
                 '(Phase 6m TB-R1/R3 §3, §7).',
    },
    'CadoniSanna2020': {
        'authors': 'Cadoni, M., Sanna, A. P.',
        'title': 'Emergent dark energy from gravitational asymptotic dynamics',
        'journal': 'Int. J. Mod. Phys. D',
        'volume': 29,
        'page': '2040008',
        'year': 2020,
        'doi': '10.1142/S0218271820400088',
        'arxiv': '2012.08335',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/CadoniSanna2020.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'DEC GD-asymptotic emergent-Lambda (Phase 6m TB-R3 §7).',
    },
    'Padmanabhan2010RPP': {
        'authors': 'Padmanabhan, T.',
        'title': 'Thermodynamical aspects of gravity: new insights',
        'journal': 'Rep. Prog. Phys.',
        'volume': 73,
        'page': '046901',
        'year': 2010,
        'doi': '10.1088/0034-4885/73/4/046901',
        'arxiv': '0911.5004',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Padmanabhan2010RPP.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Padmanabhan thermodynamic-GR / atoms-of-spacetime review '
                 '(Phase 6m TB-R1, TC-R1).',
    },
    'Padmanabhan2014IJMPD': {
        'authors': 'Padmanabhan, T.',
        'title': 'The atoms of space, gravity and the cosmological constant',
        'journal': 'Int. J. Mod. Phys. D',
        'volume': 23,
        'page': '1430011',
        'year': 2014,
        'doi': '10.1142/S0218271814300110',
        'arxiv': '1404.2284',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Padmanabhan2014IJMPD.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'CosMIn N=4pi postulate review with explicit framing flag '
                 '(Phase 6m TB-R1, TC-R3 §7).',
    },
    'PadmanabhanPadmanabhan2013CosMIn': {
        'authors': 'Padmanabhan, H., Padmanabhan, T.',
        'title': 'CosMIn: the solution to the cosmological constant problem',
        'journal': 'Int. J. Mod. Phys. D',
        'volume': 22,
        'page': '1342001',
        'year': 2013,
        'doi': '10.1142/S0218271813420017',
        'arxiv': '1302.3226',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/PadmanabhanPadmanabhan2013CosMIn.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'CosMIn N=4pi -> Lambda L_P^2 ~ 3.4e-122 (Phase 6m TB-R3 §1, '
                 'TC-R3 §7).',
    },
    'Li2004HDE': {
        'authors': 'Li, M.',
        'title': 'A model of holographic dark energy',
        'journal': 'Phys. Lett. B',
        'volume': 603,
        'page': '1',
        'year': 2004,
        'doi': '10.1016/j.physletb.2004.10.014',
        'arxiv': 'hep-th/0403127',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Li2004HDE.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Holographic DE event-horizon cutoff (Phase 6m TB-R1/R3 §6).',
    },
    'LiWang2010HDE': {
        'authors': 'Li, M., Wang, Y.',
        'title': 'Quantum UV/IR relations and holographic dark energy from entropic force',
        'journal': 'Phys. Lett. B',
        'volume': 687,
        'page': '243',
        'year': 2010,
        'doi': '10.1016/j.physletb.2010.04.012',
        'arxiv': '1001.4466',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/LiWang2010HDE.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'HDE event-horizon update (Phase 6m TB-R1).',
    },
    'SaridakisTsallis2018': {
        'authors': 'Saridakis, E. N., Bamba, K., Myrzakulov, R., Anagnostopoulos, F. K.',
        'title': 'Holographic dark energy through Tsallis entropy',
        'journal': 'Phys. Lett. B',
        'volume': 787,
        'page': '67',
        'year': 2018,
        'doi': '10.1016/j.physletb.2018.10.063',
        'arxiv': '1806.01301',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/SaridakisTsallis2018.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Tsallis HDE in gravity-thermodynamics (Phase 6m TB-R1 §1).',
    },
    'LucianoPaliathanasisSaridakis2025': {
        'authors': 'Luciano, G. G., Paliathanasis, A., Saridakis, E. N.',
        'title': 'Tsallis holographic dark energy in gravity-thermodynamics cosmology with DESI DR2',
        'journal': 'JCAP',
        'volume': '09',
        'page': '013',
        'year': 2025,
        'doi': None,
        'arxiv': '2504.12205',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/LucianoPaliathanasisSaridakis2025.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Tsallis HDE GT-cosmology + DESI DR2 (Phase 6m TB-R1/R2). '
                 'Preprint -> JCAP; Crossref DOI tba.',
    },
    'LucianoPaliathanasisSaridakis2506': {
        'authors': 'Luciano, G. G., Paliathanasis, A., Saridakis, E. N.',
        'title': 'Constraints on Barrow and Tsallis Holographic Dark Energy from DESI DR2 BAO data',
        'journal': 'J. High Energy Astrophys.',
        'volume': 49,
        'page': '100427',
        'year': 2026,
        'doi': '10.1016/j.jheap.2025.100427',
        'arxiv': '2506.03019',
        'arxiv_verified': True,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/LucianoPaliathanasisSaridakis2506.pdf',
        'used_in': ['papers/D5/paper_draft.tex', 'papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Barrow + Tsallis HDE constrained against DESI DR2 BAO + SN + CC; '
                 'information-criteria (AIC/BIC) verdict: not favoured vs ΛCDM, '
                 'cannot alleviate H0 tension (Phase 6m TB-R3; Phase 7 Session 5). '
                 'Registry corrected 2026-05-11 from earlier "Same entropies..." '
                 'title (was unrelated to actual arXiv content) per Stage-13 '
                 'D5 review finding 1.1; arXiv title + JHEAp venue verified via WebFetch. '
                 'Version pin: ΔAIC = +4.7 (Barrow Entropy, SN+BAO row, AIC−AIC_Λ '
                 'column of Table II; the SN+OHD+BAO row gives +4.2) verified '
                 'against the cached primary source arXiv:2506.03019v1 PDF on '
                 '2026-06-10; D5 prose year corrected 2025→2026 same day '
                 '(publication year is 2026, JHEAp 49, 100427).',
    },
    'TyagiHaridasuBasak2025': {
        'authors': 'Tyagi, U. K., Haridasu, S., Basak, S.',
        'title': 'Constraints on Generalized Gravity-Thermodynamic Cosmology from DESI DR2',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2504.11308',
        'arxiv_verified': True,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/TyagiHaridasuBasak2025.pdf',
        'used_in': ['papers/D5/paper_draft.tex', 'papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Generalized entropic / Gravity-Thermodynamics models constrained '
                 'against DESI DR2 + SN; framework-aggregate Delta log B disfavour vs '
                 'LCDM; standard Bekenstein-Hawking preferred (Phase 6m TB-R1/R2/R3). '
                 'Registry corrected 2026-05-11 from earlier "Bayesian model '
                 'comparison of holographic dark-energy..." title and fabricated '
                 'PRD 113, 063507 venue/DOI (DOI 404\'d) per Stage-13 D5 review '
                 'finding 1.2; arXiv title verified via WebFetch, no peer-reviewed '
                 'venue listed on arXiv page.',
    },
    'OdintsovDOnofrioPaul2025': {
        'authors': "Odintsov, S. D., D'Onofrio, S., Paul, T.",
        'title': 'Generalized-entropy dark energy with non-zero spatial curvature',
        'journal': 'Phys. Dark Univ.',
        'volume': 48,
        'page': '101920',
        'year': 2025,
        'doi': '10.1016/j.dark.2025.101920',
        'arxiv': '2504.03470',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/OdintsovDOnofrioPaul2025.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': '4-param generalized-entropy DE; non-zero Omega_k '
                 '(Phase 6m TB-R1/R2/R3 §2).',
    },
    'AdhikaryDasOdintsovPaul2025': {
        'authors': 'Adhikary, P., Das, S., Odintsov, S. D., Paul, T.',
        'title': 'Flat 4-parameter generalized-entropy fit with DESI DR1 + compressed Planck',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2507.15273',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/AdhikaryDasOdintsovPaul2025.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Flat 4-param fit with DR1 + compressed Planck (no Bayesian '
                 'evidence) (Phase 6m TB-R3 §2). Preprint.',
    },
    'Hossenfelder2017Covariant': {
        'authors': 'Hossenfelder, S.',
        'title': 'Covariant version of Verlinde\'s emergent gravity',
        'journal': 'Phys. Rev. D',
        'volume': 95,
        'page': '124018',
        'year': 2017,
        'doi': '10.1103/PhysRevD.95.124018',
        'arxiv': '1703.01415',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Hossenfelder2017Covariant.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Covariant emergent gravity (imposter field) '
                 '(Phase 6m TB-R1/R3 §1, §5).',
    },
    'YoonGuha2023': {
        'authors': 'Yoon, Y., Guha, A.',
        'title': 'Inflation and the late time acceleration from Hossenfelder-Verlinde gravity',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2023,
        'doi': None,
        'arxiv': '2304.07301',
        'arxiv_verified': True,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/YoonGuha2023.pdf',
        'used_in': ['papers/D5/paper_draft.tex', 'papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Hossenfelder covariant formulation of Verlinde emergent gravity '
                 'predicts inflation and late-time acceleration simultaneously; '
                 'imposter-field mass lambda^2 in 1.85e4-2.26e4 range for '
                 'q in [-0.95, -0.55] (Phase 6m TB-R1/R3 §5). '
                 'Registry corrected 2026-05-11 from earlier "...with matter and '
                 'radiation: a de Sitter attractor" title and fabricated PRD 108, '
                 '084064 venue per Stage-13 D5 review finding 1.3; arXiv title '
                 'verified via WebFetch, no peer-reviewed venue listed on arXiv page. '
                 'Second author is Atanu Guha (A. Guha), not S. Guha.',
    },
    'DaiStojkovic2017': {
        'authors': 'Dai, D.-C., Stojkovic, D.',
        'title': 'Inconsistencies in Verlinde\'s emergent gravity',
        'journal': 'Phys. Rev. D',
        'volume': 96,
        'page': '044025',
        'year': 2017,
        'doi': '10.1103/PhysRevD.96.044025',
        'arxiv': '1706.07854',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/DaiStojkovic2017.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Hossenfelder-Verlinde dS instability (Phase 6m TB-R1 §1).',
    },

    # ──── Track B supporting (DEC corpus / Bullet-Cluster / SFDM bridge) ────

    'Zeng2017BAOAmplitude': {
        'authors': 'Zeng, D.',
        'title': 'Verlinde-2017 BAO matter-power-spectrum tension',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2017,
        'doi': None,
        'arxiv': '1701.00690',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Zeng2017BAOAmplitude.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Verlinde-2017 BAO matter-power-spectrum tension '
                 '(Phase 6m TB-R1 §1 supplementary).',
    },
    'Sandvik2004GCG': {
        'authors': 'Sandvik, H. B., Tegmark, M., Zaldarriaga, M., Waga, I.',
        'title': 'The end of unified dark matter?',
        'journal': 'Phys. Rev. D',
        'volume': 69,
        'page': '123524',
        'year': 2004,
        'doi': '10.1103/PhysRevD.69.123524',
        'arxiv': 'astro-ph/0212114',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Sandvik2004GCG.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'GCG-class CMB falsification; used in DEC NO-GO §3 '
                 '(Phase 6m TB-R3).',
    },
    'Markevitch2004Bullet': {
        'authors': 'Markevitch, M., Gonzalez, A. H., Clowe, D., Vikhlinin, A., Forman, W., Jones, C., Murray, S., Tucker, W.',
        'title': 'Direct constraints on the dark matter self-interaction cross section from the merging galaxy cluster 1E 0657-56',
        'journal': 'Astrophys. J.',
        'volume': 606,
        'page': '819',
        'year': 2004,
        'doi': '10.1086/383178',
        'arxiv': 'astro-ph/0309303',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Markevitch2004Bullet.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Bullet-Cluster baseline DM-galaxy offset '
                 '(Phase 6m TB-R3 DEC NO-GO supporting).',
    },
    'CloweEtAl2006Bullet': {
        'authors': 'Clowe, D., Bradač, M., Gonzalez, A. H., Markevitch, M., Randall, S. W., Jones, C., Zaritsky, D.',
        'title': 'A direct empirical proof of the existence of dark matter',
        'journal': 'Astrophys. J.',
        'volume': 648,
        'page': 'L109',
        'year': 2006,
        'doi': '10.1086/508162',
        'arxiv': 'astro-ph/0608407',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/CloweEtAl2006Bullet.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Direct empirical proof of DM via Bullet Cluster '
                 '(Phase 6m TB-R3 DEC NO-GO supporting).',
    },
    'HarveyEtAl2015Bullet': {
        'authors': 'Harvey, D., Massey, R., Kitching, T., Taylor, A., Tittley, E.',
        'title': 'The nongravitational interactions of dark matter in colliding galaxy clusters',
        'journal': 'Science',
        'volume': 347,
        'page': '1462',
        'year': 2015,
        'doi': '10.1126/science.1261381',
        'arxiv': '1503.07675',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/HarveyEtAl2015Bullet.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'sigma_DM/m < 0.47 cm^2/g (Phase 6m TB-R3 DEC NO-GO supporting).',
    },
    'MarshNiemeyer2019EridanusII': {
        'authors': 'Marsh, D. J. E., Niemeyer, J. C.',
        'title': 'Strong constraints on fuzzy dark matter from ultrafaint dwarf galaxy Eridanus II',
        'journal': 'Phys. Rev. Lett.',
        'volume': 123,
        'page': '051103',
        'year': 2019,
        'doi': '10.1103/PhysRevLett.123.051103',
        'arxiv': '1810.08543',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/MarshNiemeyer2019EridanusII.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'SFDM ultralight bound from Eridanus II heating '
                 '(Phase 6m TB-R3 DEC-vs-SFDM cross-bridge §4).',
    },

    # ──── Track C: Jacobson-thermo-GR dark energy ────

    'Jacobson2016EntanglementEquilibrium': {
        'authors': 'Jacobson, T.',
        'title': 'Entanglement equilibrium and the Einstein equation',
        'journal': 'Phys. Rev. Lett.',
        'volume': 116,
        'page': '201101',
        'year': 2016,
        'doi': '10.1103/PhysRevLett.116.201101',
        'arxiv': '1505.04753',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Jacobson2016EntanglementEquilibrium.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Entanglement-equilibrium re-derivation of semiclassical Einstein '
                 '(Phase 6m TC-R1 §1).',
    },
    'ElingGuedensJacobson2006fR': {
        'authors': 'Eling, C., Guedens, R., Jacobson, T.',
        'title': 'Nonequilibrium thermodynamics of spacetime',
        'journal': 'Phys. Rev. Lett.',
        'volume': 96,
        'page': '121301',
        'year': 2006,
        'doi': '10.1103/PhysRevLett.96.121301',
        'arxiv': 'gr-qc/0602001',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/ElingGuedensJacobson2006fR.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Non-equilibrium f(R) from Clausius (M3) '
                 '(Phase 6m TC-R1/R2/R3 §1).',
    },
    'PlazaKraiselburd2025fR': {
        'authors': 'Plaza, F., Kraiselburd, L.',
        'title': 'Testing f(R)-gravity models with DESI DR2 2025-BAO and other cosmological data',
        'journal': 'Phys. Rev. D',
        'volume': 112,
        'page': '023554',
        'year': 2025,
        'doi': '10.1103/PhysRevD.112.023554',
        'arxiv': '2504.05432',
        'arxiv_verified': True,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/PlazaKraiselburd2025fR.pdf',
        'used_in': ['papers/D5/paper_draft.tex', 'papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'MCMC analysis of f(R) models vs DESI DR2 BAO + Pantheon++SH0ES + CC; '
                 '"very strong statistical evidence" in favour of f(R) over LCDM '
                 '(Phase 6m TC-R1/R2/R3 §3). Registry title corrected 2026-05-11 '
                 'from earlier paraphrased "f(R) gravity DESI DR2 + PPS + CC: very '
                 'strong Bayesian preference" per Stage-13 D5 review finding 1.4; '
                 'arXiv title verified via WebFetch. Lead author first name is '
                 'Francisco (F. Plaza), not M. Plaza.',
    },
    'FengGongLiuYanChen2025fR': {
        'authors': 'Feng, L., Gong, Y., Liu, Y., Yan, M., Chen, X.',
        'title': 'f(R) gravity with FRBs+DESI-DR2+PP+DESY5+CC+Planck: b ~ 0.21',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2510.23105',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/FengGongLiuYanChen2025fR.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'f(R) FRBs + DESI-DR2 + PP + DESY5 + CC + Planck; b ~ 0.21 '
                 '(Phase 6m TC-R1/R3 §3). Preprint.',
    },
    'JannesVolovik2012': {
        'authors': 'Jannes, G., Volovik, G. E.',
        'title': 'The cosmological constant: a lesson from the effective gravity of topological Weyl media',
        'journal': 'JETP Lett.',
        'volume': 96,
        'page': '215',
        'year': 2012,
        'doi': '10.1134/S0021364012160059',
        'arxiv': '1108.5086',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/JannesVolovik2012.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Phase 6e cross-bridge anchor reference. Sole substrate where '
                 'Lambda_J = Lambda_HK rigorously demonstrated (Volovik 2009 §VII; '
                 'Jannes-Volovik 2012). Delta_0^4 / (6 pi^2 hbar^3) on '
                 '4-Weyl-fermion bundle, tr(I) = 4. Atiyah-Bott-Shapiro topological '
                 'universality + IR Lorentz-invariance recovery. '
                 'M9 Volovik-Jannes anchor (Phase 6m TC-R1 §3, TC-R2, TC-R3 §8).',
    },
    'KhourySaksteinSolomon2018KSS': {
        'authors': 'Khoury, J., Sakstein, J., Solomon, A. R.',
        'title': 'Superfluids and the cosmological constant problem',
        'journal': 'JCAP',
        'volume': '08',
        'page': '024',
        'year': 2018,
        'doi': '10.1088/1475-7516/2018/08/024',
        'arxiv': '1805.05937',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/KhourySaksteinSolomon2018KSS.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'KSS Lorentz-violating superfluid (M8 OPEN) '
                 '(Phase 6m TC-R1/R2/R3 §2).',
    },
    'BrusteinGorbonosHadad2009': {
        'authors': 'Brustein, R., Gorbonos, D., Hadad, M.',
        'title': 'Wald entropy and the entanglement entropy of black holes',
        'journal': 'Phys. Rev. D',
        'volume': 79,
        'page': '044025',
        'year': 2009,
        'doi': '10.1103/PhysRevD.79.044025',
        'arxiv': '0712.3206',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/BrusteinGorbonosHadad2009.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Effective-coupling Wald entropy S_W = A / (4 G_eff) '
                 '(Phase 6m TC-R2/R3 §1, §5).',
    },
    'CapozzielloTsujikawa2008': {
        'authors': 'Capozziello, S., Tsujikawa, S.',
        'title': 'Solar system and equivalence principle constraints on f(R) gravity by chameleon approach',
        'journal': 'Phys. Rev. D',
        'volume': 77,
        'page': '107501',
        'year': 2008,
        'doi': '10.1103/PhysRevD.77.107501',
        'arxiv': '0712.2268',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/CapozzielloTsujikawa2008.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'f(R) chameleon constraints (Phase 6m TC-R2).',
    },
    'BurrageSakstein2017Chameleon': {
        'authors': 'Burrage, C., Sakstein, J.',
        'title': 'Tests of chameleon gravity',
        'journal': 'JCAP',
        'volume': '01',
        'page': '056',
        'year': 2018,
        'doi': '10.1088/1475-7516/2018/01/056',
        'arxiv': '1709.09071',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/BurrageSakstein2017Chameleon.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Burrage-Sakstein chameleon review (Phase 6m TC-R2).',
    },
    'AlonsoSerranoLiska2020Unimodular': {
        'authors': 'Alonso-Serrano, A., Liška, M.',
        'title': 'Entanglement equilibrium and unimodular gravity',
        'journal': 'Phys. Rev. D',
        'volume': 102,
        'page': '124030',
        'year': 2020,
        'doi': '10.1103/PhysRevD.102.124030',
        'arxiv': '2008.04805',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/AlonsoSerranoLiska2020Unimodular.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Entanglement-equilibrium -> unimodular reformulation '
                 '(Phase 6m TC-R2 §3).',
    },
    'AlonsoSerranoLiska2022Unimodular': {
        'authors': 'Alonso-Serrano, A., Liška, M.',
        'title': 'Trace-free Einstein equations from entanglement equilibrium',
        'journal': 'Phys. Rev. D',
        'volume': 105,
        'page': '124068',
        'year': 2022,
        'doi': '10.1103/PhysRevD.105.124068',
        'arxiv': '2112.06301',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/AlonsoSerranoLiska2022Unimodular.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Unimodular trace-free reformulation update '
                 '(Phase 6m TC-R1/R2).',
    },
    'EllisVanElstMuruganUzan2011Unimodular': {
        'authors': 'Ellis, G. F. R., van Elst, H., Murugan, J., Uzan, J.-P.',
        'title': 'On the trace-free Einstein equations as a viable alternative to general relativity',
        'journal': 'Class. Quantum Grav.',
        'volume': 28,
        'page': '225007',
        'year': 2011,
        'doi': '10.1088/0264-9381/28/22/225007',
        'arxiv': '1008.1196',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/EllisVanElstMuruganUzan2011Unimodular.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Trace-free Einstein equations and the cosmological constant '
                 '(Phase 6m TC-R1/R2 §3).',
    },
    'AlvarezGonzalezMartin2012Unimodular': {
        'authors': 'Álvarez, E., González-Martín, S.',
        'title': 'Graviton self-coupling and unimodular gravity',
        'journal': 'Phys. Rev. D',
        'volume': None,
        'page': None,
        'year': 2012,
        'doi': None,
        'arxiv': '1401.2941',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/AlvarezGonzalezMartin2012Unimodular.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Graviton self-coupling <-> unimodular equivalence '
                 '(Phase 6m TC-R3 §1). PRD/JHEP venue.',
    },
    'Volovik2010Relaxation': {
        'authors': 'Volovik, G. E.',
        'title': 'Vacuum energy: myths and reality / relaxation cosmology',
        'journal': 'Ann. Phys.',
        'volume': 14,
        'page': '165',
        'year': 2009,
        'doi': None,
        'arxiv': '1004.0597',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Volovik2010Relaxation.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Vacuum-energy thermodynamics; relaxation cosmology; '
                 'SM-as-topological-medium (Phase 6m TC-R2/R3 §6, §8).',
    },
    'LiuLeeRobustnessFixedRd2025': {
        'authors': 'Liu, Y., Lee, B.-H.',
        'title': 'Robustness of fixed-r_d analysis: ~3 sigma DDE preference is not reproduced',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2507.01380',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/LiuLeeRobustnessFixedRd2025.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Direct fixed-r_d robustness: ~3 sigma DDE not reproduced '
                 '(Phase 6m TB-R2, TC-R2/R3 §3). Preprint.',
    },
    'ParkRatra2025rd': {
        'authors': 'Park, C.-G., Ratra, B.',
        'title': 'r_d treatment as DDE-preference driver; A_L freedom',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2501.03480',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/ParkRatra2025rd.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'r_d treatment as DDE-preference driver; A_L freedom '
                 '(Phase 6m TB-R1/R2, TC-R3 §6). Preprint.',
    },
    'MirpoorianJedamzikPogosian2025Recombination': {
        'authors': 'Mirpoorian, S., Jedamzik, K., Pogosian, L.',
        'title': 'Modified recombination absorbs DESI/CMB tension within Lambda-CDM',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2504.15274',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/MirpoorianJedamzikPogosian2025Recombination.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Modified recombination absorbs DESI/CMB tension within Lambda-CDM '
                 '(Phase 6m TB-R2, TC-R2). Preprint.',
    },
    'ChakrabortyBCH2015': {
        'authors': 'Chakraborty, S.',
        'title': 'Padmanabhan-class BCH four-laws consistency',
        'journal': 'Eur. Phys. J. C',
        'volume': 75,
        'page': '593',
        'year': 2015,
        'doi': '10.1140/epjc/s10052-015-3815-9',
        'arxiv': '1505.07272',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/ChakrabortyBCH2015.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Padmanabhan-class BCH four-laws consistency (Phase 6m TC-R2).',
    },
    'CaiCao2007Lovelock': {
        'authors': 'Cai, R.-G., Cao, L.-M.',
        'title': 'Thermodynamics of apparent horizon in brane-world scenario / Lovelock thermodynamics',
        'journal': 'Nucl. Phys. B',
        'volume': 785,
        'page': '135',
        'year': 2007,
        'doi': '10.1016/j.nuclphysb.2007.06.016',
        'arxiv': 'hep-th/0612144',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/CaiCao2007Lovelock.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Cai-Cao apparent-horizon brane / Lovelock thermodynamics '
                 '(Phase 6m TC-R1 §1). Bibkey CaiCao2007Lovelock (no hyphen) for '
                 'Python attribute compatibility.',
    },
    'DadhichPonsPrabhu2012LovelockEntropy': {
        'authors': 'Dadhich, N., Pons, J. M., Prabhu, K.',
        'title': 'Pure Lovelock entropy universality',
        'journal': 'Phys. Rev. D',
        'volume': None,
        'page': None,
        'year': 2012,
        'doi': None,
        'arxiv': '1110.0673',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/DadhichPonsPrabhu2012LovelockEntropy.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'Pure Lovelock entropy universality (Phase 6m TC-R3 §1).',
    },

    # ──── Cross-track: DESI / r_d-anchoring / SN-systematics / SFDM-bridge ────

    'LodhaCompanion2025DESI': {
        'authors': 'Lodha, K. et al. (DESI Collaboration)',
        'title': 'DESI DR2: companion paper to DR2 BAO cosmological constraints',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2503.14743',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/LodhaCompanion2025DESI.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'DESI DR2 companion paper (Phase 6m TA-R1, TC-R1). Preprint.',
    },
    'SahEtAl2025DESI': {
        'authors': 'Sah, M. R. et al.',
        'title': 'DESI DR2 phantom-crossing analysis',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2504.06118',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/SahEtAl2025DESI.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'DESI DR2 phantom-crossing analysis (Phase 6m TA-R1 §3). Preprint.',
    },
    'YinWang2025SNSystematics': {
        'authors': 'Yin, Z., Wang, X.',
        'title': 'DESY5 low-z SN ~0.043 mag offset; <~ 2 sigma DDE under correction',
        'journal': 'Sci. China Phys. Mech. Astron.',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2502.04212',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/YinWang2025SNSystematics.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'DESY5 low-z SN ~0.043 mag offset; <~ 2 sigma DDE under correction '
                 '(Phase 6m TB-R3 §2, TC-R2 §6).',
    },
    'WangYinTension2025rd': {
        'authors': 'Wang, X., Yin, Z.',
        'title': 'CMB / BAO / SN tensions and apparent DDE significance',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2504.15222',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/WangYinTension2025rd.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'CMB / BAO / SN tensions and apparent DDE significance '
                 '(Phase 6m TB-R2, TC-R2 §6). Preprint.',
    },
    'ColgainEtAl2025DESI': {
        'authors': "Colgáin, E. Ó. et al.",
        'title': 'DESI DR2 sensitivity to SN sample / prior ranges',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2504.04417',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/ColgainEtAl2025DESI.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'DESI DR2 sensitivity to SN sample / prior ranges '
                 '(Phase 6m TA-R3 §11). Preprint.',
    },
    'Turyshev2026DESI': {
        'authors': 'Turyshev, S. G.',
        'title': 'DESI DR2 reanalysis',
        'journal': 'arXiv preprint',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': '2602.05368',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/Turyshev2026DESI.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'DESI DR2 reanalysis (Phase 6m TA-R3 §11). Preprint.',
    },
    'ChiangSchiveChiueh2021EridanusII': {
        'authors': 'Chiang, B.-T., Schive, H.-Y., Chiueh, T.',
        'title': 'SFDM heating-resonance refinement of Marsh-Niemeyer',
        'journal': 'Phys. Rev. D',
        'volume': None,
        'page': None,
        'year': 2021,
        'doi': None,
        'arxiv': '2104.13359',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6m/primary-sources/ChiangSchiveChiueh2021EridanusII.pdf',
        'used_in': ['papers/paper45_phase6m_review/paper_draft.tex'],
        'provides': [],
        'notes': 'SFDM heating-resonance refinement of Marsh-Niemeyer '
                 '(Phase 6m TB-R3 §4 DEC-vs-SFDM cross-bridge).',
    },

    # ════════════════════════════════════════════════════════════════════
    # Phase 7c — Bundle D3 classical-physics references
    # (Added 2026-05-04 to close D3 Stage-10 r2 BLOCKER 4: bibliography
    # population. Most are pre-arXiv canonical references for which DOI
    # verification was performed via crossref where DOI exists.)
    # ════════════════════════════════════════════════════════════════════

    'ADM1962': {
        'authors': 'Arnowitt, R., Deser, S., Misner, C. W.',
        'title': 'The dynamics of general relativity',
        'journal': 'Gen. Rel. Grav.',
        'volume': 40,
        'page': '1997',
        'year': 2008,
        'doi': '10.1007/s10714-008-0661-1',
        'arxiv': 'gr-qc/0405109',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['ADM 3+1 decomposition; Hamiltonian formulation of GR'],
        'notes': 'Originally Chapter 7 in "Gravitation: An Introduction to Current Research" (Witten ed., Wiley 1962). Reprinted Gen. Rel. Grav. 40, 1997 (2008) as a Golden Oldie. arXiv:gr-qc/0405109 is the reprint preprint.',
    },
    'Adler1980': {
        'authors': 'Adler, S. L.',
        'title': 'Order-R vacuum action functional in scalar-free unified theories with spontaneous scale breaking',
        'journal': 'Phys. Rev. Lett.',
        'volume': 44,
        'page': '1567',
        'year': 1980,
        'doi': '10.1103/PhysRevLett.44.1567',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Sakharov-Adler induced gravity: order-R term induced from radiative corrections'],
        'notes': 'Pre-arXiv. Pairs with Sakharov1968 as the original Sakharov-Adler induced-gravity references.',
    },
    'Akama1979': {
        'authors': 'Akama, K.',
        'title': 'An attempt at pregeometry: gravity with composite metric',
        'journal': 'Prog. Theor. Phys.',
        'volume': 60,
        'page': '1900',
        'year': 1978,
        'doi': '10.1143/PTP.60.1900',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Pregeometry / induced gravity; metric as fermion-bilinear composite (the "A" in ADW)'],
        'notes': 'Bibkey says 1979; actual publication Dec 1978 in PTP 60(6). Pre-arXiv. Foundational reference for the ADW (Akama-Diakonov-Wetterich) tetrad-bilinear program.',
    },
    'AlmheiriMarolfPolchinskiSully2013': {
        'authors': 'Almheiri, A., Marolf, D., Polchinski, J., Sully, J.',
        'title': 'Black holes: complementarity or firewalls?',
        'journal': 'JHEP',
        'volume': '02',
        'page': '062',
        'year': 2013,
        'doi': '10.1007/JHEP02(2013)062',
        'arxiv': '1207.3123',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex', 'papers/D4/paper_draft.tex'],
        'provides': ['AMPS firewall paradox; incompatibility of monogamy + unitarity + EFT + equivalence-principle at horizon'],
        'notes': 'JHEP issue 02 (February 2013).',
    },
    'ArnoldMcLerran1987': {
        'authors': 'Arnold, P., McLerran, L.',
        'title': 'Sphalerons, small fluctuations, and baryon-number violation in electroweak theory',
        'journal': 'Phys. Rev. D',
        'volume': 36,
        'page': '581',
        'year': 1987,
        'doi': '10.1103/PhysRevD.36.581',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Electroweak sphaleron rate at finite T; B+L violation rate'],
        'notes': 'Pre-arXiv. Companion to Klinkhamer-Manton 1984 sphaleron solution.',
    },
    'Balbinot2005': {
        'authors': 'Balbinot, R., Fagnocchi, S., Fabbri, A., Procopio, G. P.',
        'title': 'Backreaction in acoustic black holes',
        'journal': 'Phys. Rev. Lett.',
        'volume': 94,
        'page': '161302',
        'year': 2005,
        'doi': '10.1103/PhysRevLett.94.161302',
        'arxiv': 'gr-qc/0405096',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Letter companion to Balbinot2005PRD on backreaction in acoustic '
                     '(sonic) black holes: the emission temperature DECREASES as the '
                     'hole radiates, unlike Schwarzschild.'],
        'notes': 'CORRECTED 2026-08-15 (L3 Stage-10 redraft BLOCKER 1.2 blast radius). '
                 'This entry previously advertised "BEC analog Hawking '
                 'T_H(v) = T_H(0)(1 - v^2/c_perp^2)". Both halves were wrong: that '
                 'formula is the JacobsonKoike2002 THIN-FILM ³He-A moving-domain-wall '
                 'law (a HEATING profile), not a Balbinot result, and the Balbinot '
                 'group\'s companion PRD (Balbinot2005PRD, gr-qc/0405098) computes a '
                 'constant-sound-speed Laval-nozzle sonic hole whose cooling law is '
                 'linear in t (Eq. Tsonic), explicitly deferring the '
                 'Bose-Einstein-condensate case. ⚠️ NO PRIMARY SOURCE IS HELD for '
                 'this PRL (primary_source_path is None, doi_verified is None), so no '
                 'equation-level claim may be attached to it until gr-qc/0405096 is '
                 'acquired; cite Balbinot2005PRD for equation content. Used by D3 §6 '
                 'and F.',
    },
    'BardeenCarterHawking1973': {
        'authors': 'Bardeen, J. M., Carter, B., Hawking, S. W.',
        'title': 'The four laws of black hole mechanics',
        'journal': 'Commun. Math. Phys.',
        'volume': 31,
        'page': '161',
        'year': 1973,
        'doi': '10.1007/BF01645742',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Four laws of black hole mechanics: zeroth (uniform kappa), first (dM = (kappa/8pi)dA + ...), second (dA >= 0), third (kappa -> 0 unattainable)'],
        'notes': 'Pre-arXiv. Foundational BCH four-laws paper.',
    },
    'BardeenHillLindner1990': {
        'authors': 'Bardeen, W. A., Hill, C. T., Lindner, M.',
        'title': 'Minimal dynamical symmetry breaking of the standard model',
        'journal': 'Phys. Rev. D',
        'volume': 41,
        'page': '1647',
        'year': 1990,
        'doi': '10.1103/PhysRevD.41.1647',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['BHL top-quark condensation; dynamical EWSB; m_H ~ 2 m_t leading-order prediction'],
        'notes': 'Pre-arXiv era.',
    },
    'BergesSexty2008': {
        'authors': 'Berges, J., Sexty, D.',
        'title': 'Real-time gauge theory simulations from stochastic quantization with optimized updating',
        'journal': 'Nucl. Phys. B',
        'volume': 799,
        'page': '306',
        'year': 2008,
        'doi': '10.1016/j.nuclphysb.2008.01.030',
        'arxiv': '0708.0779',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Stochastic-quantization / complex-Langevin acceleration for lattice gauge theory'],
        'notes': 'D3 §(adw-gap RHMC) originally cited under bibkey "SextyWetterich2009"; verified to be a citation slip — the actual paper is Berges-Sexty 2008, NOT Sexty-Wetterich. Bibkey corrected to BergesSexty2008 in 2026-05-04 r3 fix.',
    },
    'Carter1971': {
        'authors': 'Carter, B.',
        'title': 'Axisymmetric black hole has only two degrees of freedom',
        'journal': 'Phys. Rev. Lett.',
        'volume': 26,
        'page': '331',
        'year': 1971,
        'doi': '10.1103/PhysRevLett.26.331',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['No-hair theorem (axisymmetric stationary BH); together with Israel + Robinson establishes Kerr uniqueness'],
        'notes': 'Pre-arXiv.',
    },
    'ChristensenDuff1978': {
        'authors': 'Christensen, S. M., Duff, M. J.',
        'title': 'Axial and conformal anomalies for arbitrary spin in gravity and supergravity',
        'journal': 'Phys. Lett. B',
        'volume': 76,
        'page': '571',
        'year': 1978,
        'doi': '10.1016/0370-2693(78)90857-2',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Axial and conformal anomaly coefficients for arbitrary spin; heat-kernel a_2 coefficient input'],
        'notes': 'Pre-arXiv. Used in D3 alongside Vassilevich2003 for heat-kernel calibration of the Sakharov-Adler closure.',
    },
    'CohenKaplanNelson1991': {
        'authors': 'Cohen, A. G., Kaplan, D. B., Nelson, A. E.',
        'title': 'Spontaneous baryogenesis at the weak phase transition',
        'journal': 'Phys. Lett. B',
        'volume': 263,
        'page': '86',
        'year': 1991,
        'doi': '10.1016/0370-2693(91)91711-4',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Spontaneous electroweak baryogenesis mechanism; CP-violating chemical potential at the EW phase transition'],
        'notes': 'Pre-arXiv era.',
    },
    'Eddington1919': {
        'authors': 'Dyson, F. W., Eddington, A. S., Davidson, C.',
        'title': "A determination of the deflection of light by the Sun's gravitational field, from observations made at the total eclipse of May 29, 1919",
        'journal': 'Philos. Trans. R. Soc. A',
        'volume': 220,
        'page': '291',
        'year': 1920,
        'doi': '10.1098/rsta.1920.0009',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['1919 solar-eclipse confirmation of GR light deflection prediction (1.75 arcsec at solar limb)'],
        'notes': 'Bibkey "Eddington1919" by convention (eclipse expedition was May 1919); journal publication 1920.',
    },
    'GellMannOakesRenner1968': {
        'authors': 'Gell-Mann, M., Oakes, R. J., Renner, B.',
        'title': 'Behavior of current divergences under SU(3) x SU(3)',
        'journal': 'Phys. Rev.',
        'volume': 175,
        'page': '2195',
        'year': 1968,
        'doi': '10.1103/PhysRev.175.2195',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['GMOR relation: m_pi^2 f_pi^2 = -(m_u + m_d) <q-bar q>; chiral PCAC'],
        'notes': 'Pre-arXiv.',
    },
    'Hawking1971': {
        'authors': 'Hawking, S. W.',
        'title': 'Gravitational radiation from colliding black holes',
        'journal': 'Phys. Rev. Lett.',
        'volume': 26,
        'page': '1344',
        'year': 1971,
        'doi': '10.1103/PhysRevLett.26.1344',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Classical area theorem (second law of BH mechanics): horizon area non-decreasing'],
        'notes': 'Pre-arXiv. Original area-theorem PRL.',
    },
    'Hawking1972': {
        'authors': 'Hawking, S. W.',
        'title': 'Black holes in general relativity',
        'journal': 'Commun. Math. Phys.',
        'volume': 25,
        'page': '152',
        'year': 1972,
        'doi': '10.1007/BF01877517',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Topology theorem (BH horizon must be S^2); strong rigidity theorem; BH uniqueness chain'],
        'notes': 'Pre-arXiv.',
    },
    'Hawking1975': {
        'authors': 'Hawking, S. W.',
        'title': 'Particle creation by black holes',
        'journal': 'Commun. Math. Phys.',
        'volume': 43,
        'page': '199',
        'year': 1975,
        'doi': '10.1007/BF02345020',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Hawking radiation T_H = hbar/(8 pi M); thermal spectrum from BH horizons'],
        'notes': 'Pre-arXiv. Canonical BH-thermodynamics anchor.',
    },
    'HawkingPenrose1970': {
        'authors': 'Hawking, S. W., Penrose, R.',
        'title': 'The singularities of gravitational collapse and cosmology',
        'journal': 'Proc. R. Soc. Lond. A',
        'volume': 314,
        'page': '529',
        'year': 1970,
        'doi': '10.1098/rspa.1970.0021',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Hawking-Penrose singularity theorem (strong-energy-condition variant)'],
        'notes': 'Pre-arXiv.',
    },
    'Hill2025bilocal': {
        'authors': 'Hill, C. T.',
        'title': 'The nontrivial vacuum structure of an extended t-tbar BEH (Higgs) bound state',
        'journal': 'arXiv',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2512.16527',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Bilocal field-theory correction to BHL top-condensate Higgs-mass prediction'],
        'notes': 'arXiv:2512.16527; submitted Dec 2025; arXiv-only as of cutoff. Best-guess match for D3 §(BHL) "Hill 2025 bilocal" reference based on bilocal+BEH+top-condensate framing.',
    },
    'HughesDrever1960': {
        'authors': 'Hughes, V. W., Robinson, H. G., Beltran-Lopez, V.',
        'title': 'Upper limit for the anisotropy of inertial mass from nuclear resonance experiments',
        'journal': 'Phys. Rev. Lett.',
        'volume': 4,
        'page': '342',
        'year': 1960,
        'doi': '10.1103/PhysRevLett.4.342',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Hughes-Drever isotropy-of-inertial-mass bound; LLI test'],
        'notes': 'Pre-arXiv. Bibkey "HughesDrever1960" conventionally lumps Hughes-Robinson-Beltran-Lopez 1960 PRL with the companion Drever 1961 Phil. Mag. paper.',
    },
    'Israel1967': {
        'authors': 'Israel, W.',
        'title': 'Event horizons in static vacuum space-times',
        'journal': 'Phys. Rev.',
        'volume': 164,
        'page': '1776',
        'year': 1967,
        'doi': '10.1103/PhysRev.164.1776',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Israel uniqueness theorem (static vacuum BH = Schwarzschild); first leg of no-hair'],
        'notes': 'Pre-arXiv.',
    },
    'Israel1986': {
        'authors': 'Israel, W.',
        'title': 'Third law of black-hole dynamics: a formulation and proof',
        'journal': 'Phys. Rev. Lett.',
        'volume': 57,
        'page': '397',
        'year': 1986,
        'doi': '10.1103/PhysRevLett.57.397',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Third-law statement: cannot reach kappa=0 in finite advanced time with bounded stress-energy'],
        'notes': 'Pre-arXiv.',
    },
    'KehleUnger2024': {
        'authors': 'Kehle, C., Unger, R.',
        'title': 'Extremal black hole formation as a critical phenomenon',
        'journal': 'arXiv',
        'volume': None,
        'page': None,
        'year': 2024,
        'doi': None,
        'arxiv': '2402.10190',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Smooth one-parameter families of solutions to Einstein-Maxwell-Vlasov interpolating between dispersion and collapse; critical solution = extremal black hole'],
        'notes': 'arXiv:2402.10190 (Feb 2024). Companion 2022 paper (arXiv:2211.15742) gives the explicit third-law disproof; D3 cites the 2024 critical-phenomenon paper.',
    },
    'KlinkhamerManton1984': {
        'authors': 'Klinkhamer, F. R., Manton, N. S.',
        'title': 'A saddle-point solution in the Weinberg-Salam theory',
        'journal': 'Phys. Rev. D',
        'volume': 30,
        'page': '2212',
        'year': 1984,
        'doi': '10.1103/PhysRevD.30.2212',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Electroweak sphaleron saddle-point solution; B+L violation barrier'],
        'notes': 'Pre-arXiv.',
    },
    'LEGEND2024': {
        'authors': 'Acharya, H. et al. (LEGEND Collaboration)',
        'title': 'First results on the search for lepton number violating neutrinoless double beta decay with the LEGEND-200 experiment',
        'journal': 'arXiv',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': '10.48550/arXiv.2505.10440',
        'arxiv': '2505.10440',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['LEGEND-200 first 0nu beta-beta limit; m_betabeta < 75-200 meV depending on NME; 61.0 kg yr exposure'],
        'notes': 'Bibkey "LEGEND2024" tracks the conference-result year (Neutrino 2024); canonical preprint is arXiv:2505.10440 (May 2025), accepted at PRL with DOI 10.1103/25tk-nctn (volume/page pending publication).',
    },
    'Maldacena1997': {
        'authors': 'Maldacena, J. M.',
        'title': 'The large-N limit of superconformal field theories and supergravity',
        'journal': 'Adv. Theor. Math. Phys.',
        'volume': 2,
        'page': '231',
        'year': 1998,
        'doi': '10.4310/ATMP.1998.v2.n2.a1',
        'arxiv': 'hep-th/9711200',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['AdS/CFT correspondence; gauge/gravity duality'],
        'notes': 'Bibkey "Maldacena1997" tracks the arXiv submission date (Nov 1997); journal publication 1998. Reprinted Int. J. Theor. Phys. 38, 1113 (1999).',
    },
    'MohapatraSenjanovic1980': {
        'authors': 'Mohapatra, R. N., Senjanovic, G.',
        'title': 'Neutrino mass and spontaneous parity nonconservation',
        'journal': 'Phys. Rev. Lett.',
        'volume': 44,
        'page': '912',
        'year': 1980,
        'doi': '10.1103/PhysRevLett.44.912',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Type-I seesaw mechanism in left-right symmetric SU(2)_L x SU(2)_R x U(1) gauge theory'],
        'notes': 'Pre-arXiv. The 1981 PRD 23 165 is a longer companion treatment.',
    },
    'PastawskiYoshidaHarlowPreskill2015': {
        'authors': 'Pastawski, F., Yoshida, B., Harlow, D., Preskill, J.',
        'title': 'Holographic quantum error-correcting codes: toy models for the bulk/boundary correspondence',
        'journal': 'JHEP',
        'volume': '06',
        'page': '149',
        'year': 2015,
        'doi': '10.1007/JHEP06(2015)149',
        'arxiv': '1503.06237',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex', 'papers/D4/paper_draft.tex'],
        'provides': ['HaPPY codes; holographic QEC toy model; perfect-tensor tilings of hyperbolic space'],
        'notes': 'JHEP issue 06 (June 2015).',
    },
    'Penrose1965': {
        'authors': 'Penrose, R.',
        'title': 'Gravitational collapse and space-time singularities',
        'journal': 'Phys. Rev. Lett.',
        'volume': 14,
        'page': '57',
        'year': 1965,
        'doi': '10.1103/PhysRevLett.14.57',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Penrose singularity theorem; trapped surfaces imply geodesic incompleteness'],
        'notes': 'Pre-arXiv. Foundational; cited in 2020 Nobel motivation.',
    },
    'PretkoRadzihovsky2018': {
        'authors': 'Pretko, M., Radzihovsky, L.',
        'title': 'Fracton-elasticity duality',
        'journal': 'Phys. Rev. Lett.',
        'volume': 120,
        'page': '195301',
        'year': 2018,
        'doi': '10.1103/PhysRevLett.120.195301',
        'arxiv': '1711.11044',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Fracton-elasticity duality; symmetric tensor gauge theory <-> elasticity of a 2D crystal'],
        'notes': 'D3 §4 fracton diff-invariance no-go anchor.',
    },
    'Robinson1975': {
        'authors': 'Robinson, D. C.',
        'title': 'Uniqueness of the Kerr black hole',
        'journal': 'Phys. Rev. Lett.',
        'volume': 34,
        'page': '905',
        'year': 1975,
        'doi': '10.1103/PhysRevLett.34.905',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Kerr uniqueness theorem (closes the no-hair chain Israel + Carter + Robinson)'],
        'notes': 'Pre-arXiv.',
    },
    'Sakharov1967': {
        'authors': 'Sakharov, A. D.',
        'title': 'Violation of CP invariance, C asymmetry, and baryon asymmetry of the universe',
        'journal': 'JETP Lett.',
        'volume': 5,
        'page': '24',
        'year': 1967,
        'doi': '10.1070/PU1991v034n05ABEH002497',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Three Sakharov conditions for baryogenesis: B violation, C+CP violation, departure from thermal equilibrium'],
        'notes': 'Pre-arXiv. Originally Pisma Zh. Eksp. Teor. Fiz. 5, 32 (1967). DOI is the 1991 Sov. Phys. Usp. reprint translation.',
    },
    'Sen2013': {
        'authors': 'Sen, A.',
        'title': 'Logarithmic corrections to Schwarzschild and other non-extremal black hole entropy in different dimensions',
        'journal': 'JHEP',
        'volume': '04',
        'page': '156',
        'year': 2013,
        'doi': '10.1007/JHEP04(2013)156',
        'arxiv': '1205.0971',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Logarithmic correction coefficient -45/2 for non-extremal Schwarzschild BH entropy; disagrees with Kaul-Majumdar -3/2'],
        'notes': 'JHEP issue 04 (April 2013).',
    },
    'Weinberg1989': {
        'authors': 'Weinberg, S.',
        'title': 'The cosmological constant problem',
        'journal': 'Rev. Mod. Phys.',
        'volume': 61,
        'page': '1',
        'year': 1989,
        'doi': '10.1103/RevModPhys.61.1',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Canonical statement of the cosmological-constant problem; ~120-order-of-magnitude QFT-vs-observation gap'],
        'notes': 'Pre-arXiv.',
    },
    'Wetterich1990': {
        'authors': 'Wetterich, C.',
        'title': 'Average action and the renormalization group equations',
        'journal': 'Z. Phys. C',
        'volume': 48,
        'page': '693',
        'year': 1990,
        'doi': '10.1007/BF01614701',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Wetterich-NJL composite-scalar channel; effective average-action framework underlying the cosmon-NJL line cited in D3 §(BHL)'],
        'notes': 'D3 §(BHL) cites for "Wetterich-NJL scalar channel". Best-match early-1990s composite-Higgs/cosmon-NJL reference. Pre-arXiv.',
    },
    'Wetterich2017': {
        'authors': 'Wetterich, C.',
        'title': 'Cosmology and the fate of dilatation symmetry',
        'journal': 'Phys. Lett. B',
        'volume': 773,
        'page': '6',
        'year': 2017,
        'doi': '10.1016/j.physletb.2017.08.002',
        'arxiv': '1711.03844',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['Updated dilatation-symmetric scaling-solution treatment of cosmology; quintessence from scaling fixed point'],
        'notes': 'arXiv:1711.03844 (Nov 2017). D3 cites as part of the ADW-Wetterich tetrad-bilinear program citation cluster.',
    },
    'Will2014': {
        'authors': 'Will, C. M.',
        'title': 'The confrontation between general relativity and experiment',
        'journal': 'Living Rev. Relativity',
        'volume': 17,
        'page': '4',
        'year': 2014,
        'doi': '10.12942/lrr-2014-4',
        'arxiv': '1403.7377',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': ['PPN parameter survey; comprehensive GR-experiment confrontation review'],
        'notes': 'Living Review article. Open-access.',
    },

    # ════════════════════════════════════════════════════════════════
    # NOTE: Four redundant auto-stub blocks for Roehm2026E1/E2/F were
    # removed 2026-05-11 (D1 Stage-13 fix-pass). The canonical entries
    # for these keys live earlier in the registry (~line 7485+) with
    # full title/used_in metadata; the stub duplicates (empty titles,
    # one used_in entry) were artifacts of repeated promote_primary_sources
    # passes per `feedback_promote_primary_sources_duplicate_keys.md`.
    # ════════════════════════════════════════════════════════════════

    # ──────────────────────────────────────────────────────────────
    # Phase 6q strengthening pass (2026-05-25): registry adds for
    # Wave 2b numerical companion — graphene MIR-bound substantive
    # lift. Primary source CHHK (the formula); experimental anchor
    # Crossno 2016 (graphene mean-free-path comparison).
    # ──────────────────────────────────────────────────────────────

    'CHHK2025DKMTransport': {
        'authors': 'Chowdhury, S. D., Hartnoll, S. A., Hebbar, A., and Khondaker, R.',
        'title': 'Bootstrapping transport in the Drude-Kadanoff-Martin model',
        'journal': 'arXiv',
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2509.18255',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/CHHK2025DKMTransport.pdf',
        'used_in': ['src/core/formulas.py', 'src/dkm_bootstrap/graphene_mir.py'],
        'provides': ['DKM transport bootstrap eq. (15) spectral form, eq. (26) MIR master bound, eq. (29) super-Planckian limit (d β_d/(4π))^(1/(d+1)) ≤ ℓ/a — the Phase 6q substrate'],
        'notes': 'Purely-analytic bootstrap that side-steps the three Phase 6o Wave 1c NO-GO obstructions (unitarity→KMS, crossing, complex-contour SDP) by design. Wave 1a.1 DR primary source. Author-name verification: prior Wave 1a.1 dispatch contained the wrong author string "Christ-Hartman-Hartman-Kologlu"; verified via arXiv abs page 2026-05-25 to be correct as listed (Chowdhury / Hartnoll / Hebbar / Khondaker). Equation numbering note: registry-internal references cite v2 (14 May 2026) numbering; the prior `eq. (26)/(29)` references in pre-2026-05-25 documentation are the v1 (22 Sep 2025) numbers — corresponding v2 numbers are `eq. (9)/(12)`.',
    },

    'Crossno2016GrapheneWF': {
        'authors': 'Crossno, J., Shi, J. K., Wang, K., Liu, X., Harzheim, A., Lucas, A., Sachdev, S., Kim, P., Taniguchi, T., Watanabe, K., Ohki, T. A., and Fong, K. C.',
        'title': 'Observation of the Dirac fluid and the breakdown of the Wiedemann-Franz law in graphene',
        'journal': 'Science',
        'volume': 351,
        'page': '1058',
        'year': 2016,
        'doi': '10.1126/science.aad0343',
        'arxiv': '1509.04713',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Crossno2016GrapheneWF.pdf',
        'used_in': ['src/dkm_bootstrap/graphene_mir.py', 'tests/test_dkm_bootstrap.py'],
        'provides': ['Graphene Dirac-fluid momentum-relaxation length ℓ_m: S1=1.5 μm, S2=0.6 μm, S3=0.034 μm at 60 K (Fig. 3C caption) for CHHK MIR-bound comparison; Wiedemann-Franz violation L/L_0 anchor'],
        'notes': 'Phase 6q Wave 2b numerical companion graphene-data anchor; Crossno 2016 measurement of WF violation in graphene Dirac fluid establishes the hydrodynamic regime where the CHHK MIR bound applies. Pre-2026-05-25 the project cited an unanchored "80 nm representative" value; corrected via adversarial-review finding 2.1 to the paper-anchored per-sample ℓ_m values.',
    },

    # ──────────────────────────────────────────────────────────────
    # Phase 6q adversarial-review finding 1.1 (2026-05-25): 5 secondary
    # substrate-references cited in Lean docstrings under
    # lean/SKEFTHawking/DKMBootstrap/ — registry-backing added so the
    # CITATION_REGISTRY tracks the load-bearing Lieb-Robinson-for-bosons +
    # nested-commutator-bound substrate references.
    # ──────────────────────────────────────────────────────────────

    'YinLucas2022LiebRobinsonBosons': {
        'authors': 'Yin, C. and Lucas, A.',
        'title': 'Bound on quantum scrambling with all-to-all interactions',
        'journal': 'Phys. Rev. X',
        'volume': 12,
        'page': '021039',
        'year': 2022,
        'doi': '10.1103/PhysRevX.12.021039',
        'arxiv': '2106.09726',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/YinLucas2022LiebRobinsonBosons.pdf',
        'used_in': ['lean/SKEFTHawking/DKMBootstrap/BECBogoliubovBosonicGrowth.lean',
                    'lean/SKEFTHawking/DKMBootstrap/HorizonTransportBootstrap.lean',
                    'lean/SKEFTHawking/DKMBootstrap/PolaritonF3Bound.lean',
                    'papers/E1/paper_draft.tex'],
        'provides': ['Lieb-Robinson-for-bosons substrate: super-factorial commutator-norm growth on bosonic Fock space (the substantive physical content underlying the BEC Bogoliubov-bosonic sharpened-NO-GO half)'],
        'notes': 'Phase 6q Wave 2b.4 BEC substantive-stand-in substrate reference. Concrete derivation of (2κ)!-like growth from the BEC Bogoliubov Hamiltonian is deferred to a future multi-session lift; the current Lean module uses a postulated stand-in sequence citing this paper as the physical substrate. Wave 6v.3 cross-cites this paper from E1 as the physical anchor for the F3-break onset threshold n_threshold ≈ 10⁶ below which polariton operating regimes sit.',
    },

    'KuwaharaSaito2021LiebRobinsonBosons': {
        'authors': 'Kuwahara, T. and Saito, K.',
        'title': 'Lieb-Robinson Bound and Almost-Linear Light Cone in Interacting Boson Systems',
        'journal': 'Phys. Rev. Lett.',
        'volume': 127,
        'page': '070403',
        'year': 2021,
        'doi': '10.1103/PhysRevLett.127.070403',
        'arxiv': '2103.11592',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/KuwaharaSaito2021LiebRobinsonBosons.pdf',
        'used_in': ['lean/SKEFTHawking/DKMBootstrap/BECBogoliubovBosonicGrowth.lean',
                    'lean/SKEFTHawking/DKMBootstrap/HorizonTransportBootstrap.lean',
                    'lean/SKEFTHawking/DKMBootstrap/PolaritonF3Bound.lean',
                    'papers/E1/paper_draft.tex'],
        'provides': ['Continuum bosonic Lieb-Robinson bound with super-factorial commutator-norm growth; companion to Yin-Lucas 2022 for the BEC Bogoliubov substantive substrate'],
        'notes': 'Phase 6q Wave 2b.4 BEC substantive-stand-in substrate reference. Almost-linear light-cone result is the continuum analog of Yin-Lucas all-to-all Lieb-Robinson; together they characterize the bosonic operator-growth scale that the CHHK F3 axiom fails for.',
    },

    'AbaninDeRoeckHuveneers2015': {
        'authors': 'Abanin, D. A., De Roeck, W., and Huveneers, F.',
        'title': 'Exponentially Slow Heating in Periodically Driven Many-Body Systems',
        'journal': 'Phys. Rev. Lett.',
        'volume': 115,
        'page': '256803',
        'year': 2015,
        'doi': '10.1103/PhysRevLett.115.256803',
        'arxiv': '1507.01474',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/AbaninDeRoeckHuveneers2015.pdf',
        'used_in': ['lean/SKEFTHawking/DKMBootstrap/Predicates.lean',
                    'lean/SKEFTHawking/DKMBootstrap/NoCrossing.lean',
                    'lean/SKEFTHawking/DKMBootstrap/BECBogoliubovBosonicGrowth.lean'],
        'provides': ['Fermionic nested-commutator factorial-exponential bound `‖[H,…,n₀]_κ‖ ≤ κ!·ε^κ·‖n₀‖` (CHHK F3 axiom is this with the κ!→e·κ! improvement); the bosonic case violates this (BEC sharpened-NO-GO substrate)'],
        'notes': 'Phase 6q F3 axiom-family substrate reference. CHHK arXiv:2509.18255 builds F3 on this bound with an improvement factor of e in the constant; the BEC bosonic case is the contrapositive instance (Yin-Lucas / Kuwahara-Saito show bosons exceed the bound).',
    },

    'ToledoTudeEastham2024Polariton': {
        'authors': 'Toledo Tude, L. and Eastham, P. R.',
        'title': 'Quantum thermodynamics of driven-dissipative condensates',
        'journal': 'APL Quantum',
        'volume': 1,
        'page': '036108',
        'year': 2024,
        'doi': '10.1063/5.0208352',
        'arxiv': '2403.06861',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/ToledoTudeEastham2024Polariton.pdf',
        'used_in': ['lean/SKEFTHawking/DKMBootstrap/E1E2CrossBridge.lean'],
        'provides': ['Polariton driven-dissipative quantum-thermodynamics analysis; substrate for the `EffectiveOnly` KMS-quality classification on the polariton platform (vs `Strong` on graphene, `Approximate` on BEC). Polariton condensation is modelled as the output of a thermal machine with explicit thermodynamic constraints, characterizing the non-equilibrium driven-dissipative regime where strict KMS fails but effective dynamical-KMS Z₂ survives.',
                     'Phase 6q Wave 2a.3 polariton platform substrate reference. Primary source corrected via adversarial-review remediation 2026-05-25: original registry entry had wrong DOI (10.1063/5.0218534 → 10.1063/5.0208352), wrong title (fluctuation-theorems framing → quantum-thermodynamics framing), and wrong first-author initial (A → L). arXiv preprint discovered at 2403.06861.'],
        'notes': 'Phase 6q Wave 2a.3 polariton platform substrate reference. Polariton breaks strict KMS due to pump/loss; effective dynamical-KMS Z₂ symmetry survives in the emergent hydro limit only. Primary-source cache now back-filled via arXiv 2403.06861 (initial Crossref DOI fetch failed in 2026-05-25 adversarial-review remediation; arXiv lookup recovered the preprint).',
    },

    'ParkerEtAl2019OperatorGrowth': {
        'authors': 'Parker, D. E., Cao, X., Avdoshkin, A., Scaffidi, T., and Altman, E.',
        'title': 'A Universal Operator Growth Hypothesis',
        'journal': 'Phys. Rev. X',
        'volume': 9,
        'page': '041017',
        'year': 2019,
        'doi': '10.1103/PhysRevX.9.041017',
        'arxiv': '1812.08657',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/ParkerEtAl2019OperatorGrowth.pdf',
        'used_in': ['lean/SKEFTHawking/DKMBootstrap/Predicates.lean',
                    'lean/SKEFTHawking/DKMBootstrap/NoCrossing.lean'],
        'provides': ['Universal operator-growth hypothesis: nested-commutator Lanczos coefficients grow linearly in κ for generic non-integrable Hamiltonians, yielding the κ! factorial-exponential bound CHHK F3 axiomatizes'],
        'notes': 'Phase 6q F3 axiom-family substrate reference. Together with Abanin-De Roeck-Huveneers, characterizes the fermionic / bounded-norm Hamiltonian regime where F3 holds; the BEC bosonic case (Yin-Lucas, Kuwahara-Saito) falls outside this regime.',
    },

    # ════════════════════════════════════════════════════════════════════
    # Phase 6w — Classical Simulability & Quantum Advantage in Analog
    # Hawking: Tensor-Network Substrate. Bibkeys added at each wave's
    # Stage 1; primary-source PDFs cached at
    # Lit-Search/Phase-6w/primary-sources/<bibkey>.pdf
    # ════════════════════════════════════════════════════════════════════

    'YedidiaFreemanWeiss2003': {
        'authors': 'Yedidia, J. S., Freeman, W. T., Weiss, Y.',
        'title': 'Understanding Belief Propagation and Its Generalizations',
        'journal': 'Exploring Artificial Intelligence in the New Millennium (Morgan Kaufmann)',
        'volume': None,
        'page': '239-269',
        'year': 2003,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6w/primary-sources/YedidiaFreemanWeiss2003.pdf',
        'used_in': ['papers/_phase6w_W2_lean_only/paper_draft.tex',
                    'lean/SKEFTHawking/BeliefPropagation.lean',
                    'papers/D7/paper_draft.tex'],
        'provides': ['Canonical belief-propagation algorithm + Bethe free energy variational principle: fixed points of BP equations are stationary points of the Bethe free energy. Reference for the Wave 6w.2 BP-on-TN substrate (FactorGraph + BPMessages + bpUpdate + IsBPFixedPoint).'],
        'notes': 'Phase 6w Wave 6w.2 BP-on-TN substrate primary reference. Book chapter in *Exploring Artificial Intelligence in the New Millennium* (Lakemeyer + Nebel, eds., Morgan Kaufmann 2003). Identical content also released as MERL Technical Report TR2001-22 (2001; freely available at https://www.merl.com/publications/docs/TR2001-22.pdf — cached as the primary-source PDF). No DOI/arXiv for the book chapter; the MERL TR serves as the canonical primary source.',
    },
    'Zurek1985': {
        'authors': 'Zurek, W. H.',
        'title': 'Cosmological experiments in superfluid helium?',
        'journal': 'Nature',
        'volume': 317,
        'page': '505-508',
        'year': 1985,
        'doi': '10.1038/317505a0',
        'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6w/primary-sources/Zurek1985.abstract.txt',
        'used_in': ['papers/_phase6w_W1_lean_only/paper_draft.tex',
                    'lean/SKEFTHawking/KibbleZurekUnruh.lean',
                    'papers/D7/paper_draft.tex'],
        'provides': ['Original proposal of the Kibble-Zurek mechanism (KZM): cosmological symmetry-breaking-defect production tested in superfluid helium. Foundational reference for the universal scaling exponent μ = νz / (1 + νz) that Wave 6w.1 KZM-Unruh bridge formalizes.'],
        'notes': 'Phase 6w Wave 6w.1 foundational KZM reference. Pre-Internet Nature article (1985); publisher PDF is paywalled, so the primary-source cache is the abstract.txt fallback with verbatim Crossref-verified bibliographic metadata + paraphrased KZM physics summary. Crossref DOI 10.1038/317505a0 verified 2026-05-26 (1647 citations).',
    },
    'BiancoResta2011': {
        'authors': 'Bianco, R., Resta, R.',
        'title': 'Mapping topological order in coordinate space',
        'journal': 'Physical Review B',
        'volume': 84,
        'page': '241106(R)',
        'year': 2011,
        'doi': '10.1103/PhysRevB.84.241106',
        'arxiv': '1111.5697',  # corrected 2026-06-10: was 1106.4014 (=Sau-Halperin, the paper the stale cache actually held); 1111.5697 is the real Bianco-Resta "Mapping topological order in coordinate space" (title-matched vs arXiv API)
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6w/primary-sources/BiancoResta2011.pdf',
        'used_in': ['papers/_phase6w_W5_lean_only/paper_draft.tex',
                    'lean/SKEFTHawking/ChernBridge.lean',
                    'papers/D7/paper_draft.tex'],
        'provides': ['Real-space Chern marker construction: local topological invariant on coordinate-space density matrices via projector commutators. The "real-space Chern marker" of the Wave 6w.5 categorical ↔ real-space Chern bridge theorems is the Bianco-Resta marker (or its tensor-network finite-size approximant per Antão-Sun-Fumega-Lado 2026).'],
        'notes': 'Phase 6w Wave 6w.5 ChernBridge primary reference for the "real-space Chern marker" construction. PRB 84, 241106(R) (2011). DOI verified 2026-05-26 via Crossref (263 citations); arXiv 1106.4014 PDF cached.',
    },
    'AntaoSunFumegaLado2026PRL136': {
        'authors': 'Antão, T. V. C., Sun, Y., Fumega, A. O., Lado, J. L.',
        'title': 'Tensor Network Method for Real-Space Topology in Quasicrystal Chern Mosaics',
        'journal': 'Physical Review Letters',
        'volume': 136,
        'page': '156601',
        'year': 2026,
        'doi': '10.1103/hhdf-xpwg',
        'arxiv': '2506.05230',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6w/primary-sources/AntaoSunFumegaLado2026PRL136.pdf',
        'used_in': ['papers/_phase6w_W4_lean_only/paper_draft.tex',
                    'lean/SKEFTHawking/ChebyshevTN.lean',
                    'lean/SKEFTHawking/AperiodicLattice.lean'],
        'provides': ['Chebyshev tensor-network algorithm for computing local Chern markers on 2D quasicrystal Hamiltonians with hundreds of millions of sites (C_8 and C_10 rotational symmetries; absence of translational symmetry); validates aperiodic-Hamiltonian topological-invariant computation at scales several orders of magnitude beyond conventional methodologies'],
        'notes': 'Phase 6w Wave 6w.4 (Chebyshev-TN + aperiodic-lattice substrate) primary reference. PRL Editor’s Suggestion April 13, 2026. Together with Tindall-Sels (Science 2026) the two papers bracket the full tensor-network landscape: Aalto (statics + aperiodicity) + Tindall-Sels (dynamics + disorder). Article 156601 in PRL 136 Issue 15.',
    },
    'TindallMelloFishmanStoudenmireSels2026Science392': {
        'authors': 'Tindall, J., Mello, A. F., Fishman, M., Stoudenmire, E. M., Sels, D.',
        'title': 'Dynamics of disordered quantum systems with two- and three-dimensional tensor networks',
        'journal': 'Science',
        'volume': 392,
        'page': '868-872',
        'year': 2026,
        'doi': '10.1126/science.adx2728',
        'arxiv': '2503.05693',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6w/primary-sources/TindallMelloFishmanStoudenmireSels2026Science392.pdf',
        # Synthetic paper-path routes bibkey_phase() to Phase-6w; the
        # _phase6w_W1_lean_only directory is the D.4 sourceless-lift handle
        # per PAPER_DRAFT_MAPPING.md and is mapped to Phase-6w via
        # PAPER_TO_PHASE. Subsequent entries reflect the actual bundle
        # cross-bridge citations into D1 / E1 / E2 paper bodies.
        'used_in': ['papers/_phase6w_W1_lean_only/paper_draft.tex',
                    'lean/SKEFTHawking/KibbleZurekUnruh.lean',
                    'papers/D1/paper_draft.tex',
                    'papers/E1/paper_draft.tex',
                    'papers/E2/paper_draft.tex'],
        'provides': ['Independent classical-simulation extraction of a Kibble-Zurek correlation-collapse exponent on a 300+ qubit disordered TFIM (cylindrical, diamond cubic and dimerized cubic lattices, p. 2) via belief-propagation contraction of lattice-specific tensor networks. The reported mu ~ 2.70-2.75 (Fig. 5, p. 6) is the RECIPROCAL-convention length exponent defined by the rescaling d~ = t_a^{-1/mu} d, i.e. xi ~ t_a^{1/mu}; it is not a defect density and is not comparable to the freeze-out-time exponent nu*z/(1+nu*z). Head-to-head comparisons against the D-Wave Advantage2 annealer are at 8x8 cylinders and ~50-qubit three-dimensional lattices (pp. 4-5), not at the 300+ qubit Kibble-Zurek run'],
        'notes': 'Phase 6w Wave 6w.1 foundation reference. The Kibble-Zurek scaling exponent extracted here (universal data of the continuous quantum phase transition) is the experimentally-cross-checked analog of the SK-EFT surface-gravity prediction via the Kibble-Zurek-Unruh correspondence (1/τ_Q ≡ κ). Also anchors Phase 6w Wave 6w.2/6w.3 (BP-on-TN Mathlib substrate + LDP-controlled simulability) as the foundational primary source.',
    },

    # ============================================================
    # D11 / D12 first-lift citations (2026-07-30)
    # ============================================================
    'TKNN1982': {
        'authors': 'Thouless, D. J., Kohmoto, M., Nightingale, M. P., den Nijs, M.',
        'title': 'Quantized Hall Conductance in a Two-Dimensional Periodic Potential',
        'journal': 'Physical Review Letters', 'volume': 49, 'page': '405', 'year': 1982,
        'doi': '10.1103/PhysRevLett.49.405', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/TKNN1982.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['The Chern-number/TKNN-invariant characterization of the quantized Hall conductance of a filled Bloch band.'],
        'notes': 'Origin of the band Chern number D11 formalizes in its lattice (FHS) form.',
    },
    # NOTE: this key was DUPLICATED until 2026-07-31 — a second 'Berry1984' literal
    # appeared earlier in this dict, so at import time THIS entry silently won and
    # paper18's consumer record + its Phase-5q primary-source path were unreachable.
    # Found by D11 Stage-13 (filed in two consecutive rounds). The two entries agreed
    # on all bibliographic content including the DOI, so no reader-facing citation was
    # ever wrong; the defect was in the verification ledger. Merged here.
    'Berry1984': {
        'authors': 'Berry, M. V.',
        'title': 'Quantal phase factors accompanying adiabatic changes',
        'journal': 'Proceedings of the Royal Society of London A', 'volume': 392, 'page': '45', 'year': 1984,
        'doi': '10.1098/rspa.1984.0023', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/Berry1984.abstract.txt',
        'used_in': [
            'papers/D11/paper_draft.tex',
            'papers/paper18_doublon_gate/paper_draft.tex',
        ],
        'provides': ['The geometric (Berry) phase acquired under adiabatic transport.'],
        'notes': (
            'Cited for Berry-phase context of the D11 6ED Wilson loops. NOTE: D11 does NOT '
            'formalize Berry curvature - see prior_art_novelty.md. '
            'Merged 2026-07-31 with a duplicate key that carried the paper18 consumer and the '
            'alternate cache Lit-Search/Phase-5q/primary-sources/Berry1984.abstract.txt.'
        ),
    },
    'Haldane1988': {
        'authors': 'Haldane, F. D. M.',
        'title': 'Model for a Quantum Hall Effect without Landau Levels: Condensed-Matter Realization of the Parity Anomaly',
        'journal': 'Physical Review Letters', 'volume': 61, 'page': '2015', 'year': 1988,
        'doi': '10.1103/PhysRevLett.61.2015', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/Haldane1988.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['The honeycomb next-nearest-neighbour complex-hopping model with a nonzero Chern number at zero net flux.'],
        'notes': 'The model whose concrete Chern witness D11 certifies at C = -1 on a 4x4 torus.',
    },
    'FukuiHatsugaiSuzuki2005': {
        'authors': 'Fukui, T., Hatsugai, Y., Suzuki, H.',
        'title': 'Chern Numbers in Discretized Brillouin Zone: Efficient Method of Computing (Spin) Hall Conductances',
        'journal': 'Journal of the Physical Society of Japan', 'volume': 74, 'page': '1674', 'year': 2005,
        'doi': '10.1143/JPSJ.74.1674', 'arxiv': 'cond-mat/0503172',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/FukuiHatsugaiSuzuki2005.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['The lattice link-variable/plaquette construction giving a manifestly integer Chern number on a discretized Brillouin zone.'],
        'notes': 'The construction D11 formalizes. Strongest-verified citation in the bundle: arXiv abstract page fetched directly; title, all three authors and journal-ref confirmed.',
    },
    'MaxwellGarnett1904': {
        'authors': 'Maxwell Garnett, J. C.',
        'title': 'XII. Colours in metal glasses and in metallic films',
        'journal': 'Philosophical Transactions of the Royal Society of London A', 'volume': 203, 'page': '385', 'year': 1904,
        'doi': '10.1098/rsta.1904.0024', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/MaxwellGarnett1904.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['The effective-permittivity mixing rule for a dilute inclusion phase in a host medium.'],
        'notes': 'Origin of the maxwellGarnett formula formalized in 6CE.',
    },
    'Voigt1889': {
        'authors': 'Voigt, W.',
        'title': 'Ueber die Beziehung zwischen den beiden Elasticitätsconstanten isotroper Körper',
        'journal': 'Annalen der Physik', 'volume': 274, 'page': '573', 'year': 1889,
        'doi': '10.1002/andp.18892741206', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/Voigt1889.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['The iso-strain (arithmetic) average of constituent moduli, formalized as voigtModulus.'],
        'notes': ('Added 2026-07-31 (D11 Stage-13 round-7 finding 1.4): voigtModulus was named after '
                  'this work with no bibitem. Metadata from the Semantic Scholar Graph API (whitelisted) '
                  'plus independent DOI resolution; cached. An earlier version of this entry claimed no '
                  'cache was constructible and took a bespoke `primary_source_unreachable` gate '
                  'exemption — that justification was WRONG (round-7 finding 1.4 showed the API returns '
                  'the record), and the exemption has been deleted rather than kept. ⚠️ PAGE FIELD 2026-07-31 (D11 round-10): reverted to the FIRST-PAGE form. This entry briefly carried the full range, which is not a style question: `format_citation` composes `page` into a bibitem-shaped string and `find_unregistered_citations` matches it by substring containment, so a range is unmatchable against the rendered reference. The full range is recorded in the primary-source cache instead.'),
    },
    'Reuss1929': {
        'authors': 'Reuss, A.',
        'title': ('Berechnung der Fließgrenze von Mischkristallen auf Grund der '
                  'Plastizitätsbedingung für Einkristalle'),
        'journal': 'Zeitschrift für Angewandte Mathematik und Mechanik', 'volume': 9, 'page': '49',
        'year': 1929,
        'doi': '10.1002/zamm.19290090104', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/Reuss1929.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['The iso-stress (harmonic) average of constituent moduli, formalized as reussModulus.'],
        'notes': ('Added 2026-07-31 (D11 Stage-13 round-7 finding 1.4). Semantic Scholar Graph API '
                  'plus independent DOI resolution; cached. The API records the author as "A. Reuß"; '
                  'this entry uses the transliterated "Reuss" used throughout the composites '
                  'literature and this draft. ⚠️ PAGE FIELD 2026-07-31 (D11 round-10): reverted to the FIRST-PAGE form. This entry briefly carried the full range, which is not a style question: `format_citation` composes `page` into a bibitem-shaped string and `find_unregistered_citations` matches it by substring containment, so a range is unmatchable against the rendered reference. The full range is recorded in the primary-source cache instead.'),
    },
    'Milton2002': {
        'authors': 'Milton, G. W.',
        'title': 'The Theory of Composites',
        'journal': 'Cambridge University Press', 'volume': None, 'page': None, 'year': 2002,
        'doi': '10.1017/CBO9780511613357', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/Milton2002.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['Modern reference for the Wiener (arithmetic/harmonic) effective-medium bounds.'],
        'notes': ('Added 2026-07-31 (D11 Stage-13 round-7 finding 1.4). The draft previously '
                  'attributed the bounds to "Wiener (1912)" with a year and a quantitative bracket '
                  'and no citation of any kind. The 1912 Saxon-Academy volume is not reachable '
                  'through the whitelisted egress, so the attribution cites this standard monograph '
                  'instead, and the [1.6, 2.5] bracket the paper quotes is stated as computed from '
                  'the definition (harmonic and arithmetic means at (1, 4, 1/2)) rather than as '
                  'quoted from a source. Metadata from the Semantic Scholar Graph API plus DOI '
                  'resolution; cached. The API record for this DOI is the book frontmatter entry.'),
    },
    'HashinShtrikman1962': {
        'authors': 'Hashin, Z., Shtrikman, S.',
        'title': 'A Variational Approach to the Theory of the Effective Magnetic Permeability of Multiphase Materials',
        'journal': 'Journal of Applied Physics', 'volume': 33, 'page': '3125', 'year': 1962,
        'doi': '10.1063/1.1728579', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/HashinShtrikman1962.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['Variational bounds on the effective magnetic permeability / dielectric response of a multiphase composite.'],
        'notes': 'CITE THIS ONE for electromagnetic/permittivity bounds. The 1963 companion is the ELASTIC paper; confusing the two is a common bibliography error.',
    },
    'HashinShtrikman1963': {
        'authors': 'Hashin, Z., Shtrikman, S.',
        'title': 'A variational approach to the theory of the elastic behaviour of multiphase materials',
        'journal': 'Journal of the Mechanics and Physics of Solids', 'volume': 11, 'page': '127', 'year': 1963,
        'doi': '10.1016/0022-5096(63)90060-7', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/HashinShtrikman1963.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['Variational bounds on the effective elastic moduli of a multiphase composite, strictly tighter than the interval spanned by the Voigt and Reuss averages. NOT formalized in this development.'],
        'notes': ('Cite for the ELASTIC Hashin–Shtrikman variational bounds; the 1962 companion is the electromagnetic one. ⚠️ NOT formalized in this development — 6CE EffectiveModuli proves only the ordering of the Voigt (Voigt1889) and Reuss (Reuss1929) averages plus constituent bounds, and the Voigt/Reuss averages are NOT Hashin & Shtrikman\'s; see the module header. Corrected 2026-07-31 (D11 Stage-13 round-7 finding 1.2): the previous note read "CITE THIS ONE for the elastic Voigt/Reuss/HS bounds formalized in 6CE EffectiveModuli", which misattributed Voigt/Reuss to HS AND claimed the HS bounds were formalized — both halves of the error round 6 corrected one layer away in prior_art_novelty.md.'),
    },
    'HasanKane2010': {
        'authors': 'Hasan, M. Z., Kane, C. L.',
        'title': 'Colloquium: Topological Insulators',
        'journal': 'Reviews of Modern Physics', 'volume': 82, 'page': '3045', 'year': 2010,
        'doi': '10.1103/RevModPhys.82.3045', 'arxiv': '1002.3895',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/HasanKane2010.abstract.txt',
        'used_in': [],
        'provides': ['Standard review of topological band theory; used here as the bibliographic verification source for TKNN, Berry and Haldane.'],
        'notes': 'Its bibliography was read directly from the arXiv PDF to confirm three APS citations the fetcher could not reach (APS returns 403). '
                 'used_in cleared 2026-07-31 (D11 Stage-13): this key is NOT cited or \\bibitem-ed in any draft — it is a verification source only, '
                 'and claiming a D11 consumer made the registry assert a citation that does not exist.',
    },
    'LjungstromMortberg2024': {
        'authors': 'Ljungstrom, A., Mortberg, A.',
        'title': 'Computational Synthetic Cohomology Theory in Homotopy Type Theory',
        'journal': 'Mathematical Structures in Computer Science', 'volume': 35, 'page': None, 'year': 2025,
        'doi': None, 'arxiv': '2401.16336',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/LjungstromMortberg2024.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['Cubical Agda synthetic cohomology: cup products, Eilenberg-Steenrod axioms, Mayer-Vietoris and Gysin sequences, and cohomology rings of the spheres, torus, Klein bottle, the real and complex projective PLANES, and infinite REAL projective space.'],
        'notes': ('MANDATORY CARVE-OUT for D11 novelty: the Gysin sequence is the machinery from which '
                  'Euler and Chern classes are built, so D11 may claim no prover DEFINES Chern classes '
                  'but must acknowledge the surrounding machinery. ⚠️ CORRECTED 2026-07-31 (D11 '
                  'Stage-13 round-9 BLOCKER 1.1): this note previously said "Gysin + H*(CP-inf)". The '
                  'development contains NO CP^inf — the abstract lists "real/complex projective planes, '
                  'and infinite real projective space", so its infinite projective space is RP^inf, whose '
                  'ring is the Stiefel-Whitney substrate, not the Z[c_1] from which Chern classes are '
                  'defined. The error conceded more than the source supports.'),
    },
    'LiPaulson2018': {
        'authors': 'Li, W., Paulson, L. C.',
        'title': 'Evaluating Winding Numbers and Counting Complex Roots through Cauchy Indices in Isabelle/HOL',
        'journal': None, 'volume': None, 'page': None, 'year': 2018,
        'doi': None, 'arxiv': '1804.03922',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/LiPaulson2018.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['Isabelle/HOL winding numbers, Cauchy indices, the argument principle, and a winding-number decision tactic.'],
        'notes': 'CARVE-OUT for D11 6CD NonHermitianWinding and for any index-theoretic reading of bulk-boundary.',
    },
    'BoldoLaxMilgram2016': {
        'authors': 'Clement, F., Martin, V.',
        'title': 'The Lax-Milgram Theorem. A detailed proof to be formalized in Coq',
        'journal': None, 'volume': None, 'page': None, 'year': 2016,
        'doi': None, 'arxiv': '1607.03618',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/BoldoLaxMilgram2016.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['A detailed pen-and-paper proof of the Lax-Milgram theorem, prepared FOR Coq formalization; the backbone of elliptic-PDE well-posedness.'],
        'notes': 'Cited as the nearest formalized substrate for the ANALYTIC homogenization route D11 did not take. Two-scale convergence itself is formalized nowhere.',
    },
    'LeanLJ2025': {
        'authors': 'Ugwuanyi, E. D., Jones, C. T., Velkey, J., Josephson, T. R.',
        'title': 'Benchmarking Energy Calculations Using Formal Proofs',
        'journal': 'Molecular Physics', 'volume': None, 'page': None, 'year': 2025,
        'doi': '10.1080/00268976.2025.2539421', 'arxiv': '2505.09095',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6c/primary-sources/LeanLJ2025.abstract.txt',
        'used_in': ['papers/D11/paper_draft.tex'],
        'provides': ['Lean 4 formalization of Lennard-Jones interaction energies under periodic boundary conditions, validated against NIST benchmarks.'],
        'notes': "Nearest 'periodic lattice in Lean' precedent; not band theory. "
                 "⚠️ CORRECTED 2026-07-31 after a Stage-13 BLOCKER: the title was "
                 "INVENTED ('LeanLJ: Formal verification of Lennard-Jones "
                 "interaction energies') and three author initials were wrong. "
                 "True metadata verified by direct fetch of the arXiv abs page.",
    },
    'Kailath1967': {
        'authors': 'Kailath, T.',
        'title': 'The Divergence and Bhattacharyya Distance Measures in Signal Selection',
        'journal': 'IEEE Transactions on Communication Technology', 'volume': 15, 'page': '52', 'year': 1967,
        'doi': '10.1109/TCOM.1967.1089532', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Kailath1967.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': ['The Bhattacharyya-distance bound on the error probability of binary signal discrimination.'],
        'notes': 'Resolvable anchor for the Bhattacharyya bound. Bhattacharyya 1943 (Bull. Calcutta Math. Soc. 35:99) has NO DOI and should be cited only as a historical reference.',
    },
    'LeCam1986': {
        'authors': 'Le Cam, L.',
        'title': 'Asymptotic Methods in Statistical Decision Theory',
        'journal': 'Springer Series in Statistics', 'volume': None, 'page': None, 'year': 1986,
        'doi': '10.1007/978-1-4612-4946-7', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/LeCam1986.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': ['The two-point testing-affinity lower bound on average error probability underlying the Le Cam floor.'],
        'notes': 'Preferred anchor. The Le Cam 1973 Ann. Statist. alternative (10.1214/aos/1176342380) is UNVERIFIED - Project Euclid was unreachable.',
    },
    'Gabor1946': {
        'authors': 'Gabor, D.',
        'title': 'Theory of Communication',
        'journal': 'Journal of the Institution of Electrical Engineers', 'volume': 93, 'page': '429', 'year': 1946,
        'doi': '10.1049/ji-3-2.1946.0074', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Gabor1946.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': ['The classical variance-based time-bandwidth uncertainty product, with equality for Gaussians.'],
        'notes': 'CAUTION, load-bearing: Gabor is the VARIANCE-based product, a DIFFERENT statement from the ENBW*T >= 1/2 filter bound D12 proves. Cite only as the classical antecedent; the ENBW form is proved self-contained from Cauchy-Schwarz. No canonical primary for the ENBW*T form was located.',
    },
    'Irwin1995': {
        'authors': 'Irwin, K. D.',
        'title': 'An application of electrothermal feedback for high resolution cryogenic particle detection',
        'journal': 'Applied Physics Letters', 'volume': 66, 'page': '1998', 'year': 1995,
        'doi': '10.1063/1.113674', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Irwin1995.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': ['Strong electrothermal feedback in a voltage-biased superconducting transition-edge sensor.'],
        'notes': 'Best-verified D12 citation: the doi.org redirect slug independently confirms title, volume, issue and page.',
    },
    'LuccioliDegenne2024': {
        'authors': 'Luccioli, L., Degenne, R.',
        'title': 'TestingLowerBounds',
        'journal': 'Software repository', 'volume': None, 'page': None, 'year': 2024,
        'url': 'https://github.com/RemyDegenne/testing-lower-bounds',
        'doi': None, 'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/LuccioliDegenne2024.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': [
            'Data-processing inequality for f-divergences in Lean 4, plus the chain rule for KL. '
            'The Mathlib KL-divergence definition was developed here.',
        ],
        'notes': (
            'TITLE CORRECTED 2026-07-31 (D12 Stage-13 BLOCKER): the title formerly carried the '
            'subtitle "Information theory and hypothesis testing, in Lean". That subtitle came from '
            'a web-SEARCH RESULT SNIPPET, not from any source this project read - the repository '
            'was never inspected. Degenne2025Kernels p.26 cites it as bare "TestingLowerBounds", '
            'which is now the recorded title. '
            'PRIOR-ART RELATIONSHIP, disclosed 2026-07-31. The squared Hellinger distance is an '
            'f-divergence (f(t) = (sqrt t - 1)^2) and the Bhattacharyya affinity is its complement, '
            'so a general f-divergence DPI here plausibly SUBSUMES our affinity_le_binaryAffinity. '
            'Cite it for that lemma rather than presenting the affinity DPI as unprecedented. '
            'ATTRIBUTION IS SECONDHAND: the repository is on github.com, outside this repo egress '
            'whitelist, so it has NOT been inspected. The content statement above is quoted from '
            'Degenne2025Kernels (arXiv:2510.04070), a whitelisted primary, which cites it as [LD24]. '
            'Whether the project carries a Le Cam average-error floor, a Poisson Bhattacharyya '
            'closed form, or a named Bhattacharyya coefficient is UNKNOWN - do not assert absence.'
        ),
    },
    'Mather1982': {
        'authors': 'Mather, J. C.',
        'title': 'Bolometer noise: nonequilibrium theory',
        'journal': 'Applied Optics', 'volume': 21, 'page': '1125', 'year': 1982,
        'doi': '10.1364/AO.21.001125', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Mather1982.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': [
            'Primary source for the thermal-link gradient factor gamma (F_link) multiplying the '
            'equilibrium phonon PSD 4 k_B T^2 G. Establishes that phonon noise in the link is '
            'REDUCED relative to the equilibrium form (by up to ~30%), i.e. gamma <= 1.',
        ],
        'notes': (
            'Resolves the 6EC phonon-prefactor provenance gap: the 4 k_B T^2 G form was previously '
            'ASSERTED in BolometricFloors.lean with only an arithmetic resemblance to '
            'Johnson-Nyquist offered as provenance. Also the source that corrected the DIRECTION '
            'error: the tree carried two theorems hypothesizing gamma > 1 and concluded the '
            'gamma = 1 form was optimistic; gamma is bounded ABOVE by 1, so it overstates. '
            'ATTRIBUTION (settled 2026-07-31 after three Stage-13 rounds). Cite Mather for the '
            'existence, direction AND approximate magnitude of the reduction. The apparent conflict '
            'with "as much as 30%" was a CONVENTION mismatch, not a disagreement: gamma multiplies '
            'the POWER spectral density, so gamma = 0.4731 at T_b/T_s = 2, n = 4 is a 53% PSD '
            'reduction and a 31% AMPLITUDE reduction. Mather states no convention; read as a maximum '
            'the amplitude reading fits better (max 33% at n=4 vs max 56% PSD), but no stronger '
            'claim is supportable - the closed form attains every PSD reduction in [0,56%], 30% '
            'exactly at r = 1.19. Asymptote is n/(2n+1) = 0.444 at n=4, NOT 1/2, and the '
            'sometimes-quoted F_link band [1/2,1] does not bound this form. Two earlier notes here '
            'were wrong in opposite directions: one claimed the value was corroborated by [1/2,1] '
            'and consistent with 30%; the next claimed Mather did not cover the magnitude at all.'
        ),
    },
    'IrwinHilton2005': {
        'authors': 'Irwin, K. D., Hilton, G. C.',
        'title': 'Transition-Edge Sensors',
        'journal': 'Cryogenic Particle Detection, Topics in Applied Physics', 'volume': 99, 'page': '63', 'year': 2005,
        'doi': '10.1007/10933596_3', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/IrwinHilton2005.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': ['The standard TES review: electrothermal loop gain, responsivity, thermal and Johnson noise budgets.'],
        'notes': 'Standard review carrying the loop-gain convention L = P_J*alpha/(G*T) that 6EC proves equivalent to its own definition (loopGain_eq_irwinHilton). ⚠️ PROVISIONAL ATTRIBUTION: this project holds this source only as a resolved DOI record and has NOT inspected its text (see the verification record at primary_source_path). Irwin1995, which is read, carries the same convention and is the citation D12 leans on; this entry is attached as the standard review, and D12 §3 says so in the prose rather than trusting it silently.',
    },
    'BlochSiegert1940': {
        'authors': 'Bloch, F., Siegert, A.',
        'title': 'Magnetic Resonance for Nonrotating Fields',
        'journal': 'Physical Review', 'volume': 57, 'page': '522', 'year': 1940,
        'doi': '10.1103/PhysRev.57.522', 'arxiv': None,
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/BlochSiegert1940.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': ['The counter-rotating-field correction to magnetic resonance that sets the scale of the rotating-wave error.'],
        'notes': 'DOI resolves to APS; APS returns 403 to automated fetches, so title/pages rest on the resolved DOI plus standard citation.',
    },
    'MeiburgLessaSoldati2025': {
        'authors': 'Meiburg, A., Lessa, L., Soldati, R.',
        'title': "A Formalization of the Generalized Quantum Stein's Lemma in Lean",
        'journal': None, 'volume': None, 'page': None, 'year': 2025,
        'doi': None, 'arxiv': '2510.08672',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/MeiburgLessaSoldati2025.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': ['The QuantumInfo half of PhysLib: CPTP/Kraus/Choi machinery, POVMs, trace distance, fidelity, and OptimalHypothesisRate.'],
        'notes': 'MANDATORY CARVE-OUT for D12: quantum hypothesis testing and the CPTP/Kraus/Choi stack are ALREADY formalized here. D12 claims neither.',
    },
    'UnruhCBO2025': {
        'authors': 'Unruh, D., Rodriguez Caballero, J. M.',
        'title': 'Complex Bounded Operators in Isabelle/HOL',
        'journal': None, 'volume': None, 'page': None, 'year': 2025,
        'doi': None, 'arxiv': '2512.05878',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/UnruhCBO2025.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': ['Isabelle/HOL complex normed/Banach/Hilbert spaces, adjoints, projectors, the BLT theorem; explicitly NOT trace-class operators or von Neumann algebras.'],
        'notes': "CARVE-OUT: the Isabelle side of the quantum-channel prior art. The companion AFP entry 'Kraus Maps' is UNVERIFIED (isa-afp.org egress-blocked) and must NOT be cited without independent re-verification.",
    },
    'EchenimMhalla2021': {
        'authors': 'Echenim, M., Mhalla, M.',
        'title': 'Quantum Projective Measurements and the CHSH Inequality in Isabelle/HOL',
        'journal': None, 'volume': None, 'page': None, 'year': 2021,
        'doi': None, 'arxiv': '2103.08535',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/EchenimMhalla2021.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': ['Isabelle/HOL projective (von Neumann) measurements, observables, outcome probabilities and state collapse; CHSH on arbitrary probability spaces.'],
        'notes': 'CARVE-OUT for measurement formalization. Whether POVMs/channels are covered could NOT be confirmed from the primary - the abstract is terse.',
    },
    'RashidHasan2017': {
        'authors': 'Rashid, A., Hasan, O.',
        'title': 'Formalization of Transform Methods using HOL Light',
        'journal': None, 'volume': None, 'page': None, 'year': 2017,
        'doi': None, 'arxiv': '1705.10050',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/RashidHasan2017.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': ['HOL Light Laplace and Fourier transforms for transfer-function and frequency-response analysis of continuous-time systems.'],
        'notes': 'CARVE-OUT for D12 signal-processing novelty: transform methods and transfer-function algebra ARE formalized; the stochastic noise-metrology layer above them is not. The abstract mentions no noise, bandwidth, matched filter or detection.',
    },
    'Degenne2025Kernels': {
        'authors': 'Degenne, R.',
        'title': "Markov kernels in Mathlib's probability library",
        'journal': None, 'volume': None, 'page': None, 'year': 2025,
        'doi': None, 'arxiv': '2510.04070',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/Degenne2025Kernels.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex'],
        'provides': ['Context for Mathlib probability/information theory: entropy and Kullback-Leibler divergence, without Hellinger, Renyi, total-variation or testing bounds.'],
        'notes': 'Cited for honest scoping of what Mathlib DOES carry. The out-of-Mathlib project RemyDegenne/testing-lower-bounds is a BLOCKING pre-submission prior-art check for D12 and is deliberately NOT cited as established prior art.',
    },

    # ════════════════════════════════════════════════════════════════
    # Citation-pipeline backfill (cited in papers/D6, absent from registry)
    # ════════════════════════════════════════════════════════════════
    'ChungHajdusekVanMeter2025QNetSimXval': {
        'authors': 'Chung, J., Hajdušek, M., Benchasattabuse, N., Kolar, A., Singal, A., Soon, K. S., Teramoto, K., Zang, A., Kettimuthu, R., Van Meter, R.',
        'title': 'Cross-Validating Quantum Network Simulators',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2504.01290',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/ChungHajdusekVanMeter2025QNetSimXval.pdf',
        'used_in': ['papers/D6/paper_draft.tex'],
        'provides': ['Independent cross-validation of two open-source quantum network simulators (QuISP and SeQUeNCe) on basic networking tasks, establishing simulator-agreement on link/end-to-end fidelity — the model-independence anchor for the D6 Werner-chain fidelity envelope'],
        'notes': 'Citation-pipeline backfill: cited in papers/D6/paper_draft.tex but absent from CITATION_REGISTRY. Primary source verified against arXiv:2504.01290 (abstract + first-page author list cross-checked): title "Cross-Validating Quantum Network Simulators", authors Joaquin Chung, Michal Hajdušek, ... Rodney Van Meter (2025). arXiv PDF cached as primary source. Note: the D6 \\bibitem renders the first author initial as "K. Chung" but the verified first author is Joaquin Chung (J.).',
    },

    # ════════════════════════════════════════════════════════════════
    # Citation-pipeline backfill (cited in papers/D7 by commit 4702f6ba,
    # review-2026-06-05 D7-EV3 continuous loop-correction rate; registry
    # entry deferred to this batch because citations.py was concurrently
    # owned at ship time)
    # ════════════════════════════════════════════════════════════════
    'ChertkovChernyak2006LoopSeries': {
        'authors': 'Chertkov, M. and Chernyak, V. Y.',
        'title': 'Loop series for discrete statistical models on graphs',
        'journal': 'J. Stat. Mech.',
        'volume': 2006,
        'page': 'P06009',
        'year': 2006,
        'doi': '10.1088/1742-5468/2006/06/P06009',
        'arxiv': 'cond-mat/0603189',
        'doi_verified': True,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/ChertkovChernyak2006LoopSeries.pdf',
        'used_in': ['papers/D7/paper_draft.tex'],
        'provides': ['Exact finite loop-series representation of the partition function of discrete statistical models on graphs: the leading term is the Bethe-Peierls/belief-propagation (BP) contribution and every correction term is a loop contribution evaluated at the BP fixed point. The "dynamical loop-correction terms over the BP message space" named in the D7 honest-residual scope note — the future-work target the combinatorial loopCorrectionRate (4-cycle density Cramér rate, BPLDPSimulability.lean) does not yet attach to.'],
        'notes': 'Added 2026-06-10 (review-2026-06-05 D7-EV3 follow-up). Metadata verified 2026-06-10 against Crossref (DOI 10.1088/1742-5468/2006/06/P06009 → Michael Chertkov & Vladimir Y. Chernyak, "Loop series for discrete statistical models on graphs", J. Stat. Mech.: Theory and Experiment 2006(06) P06009, published 2006-06-14) AND the arXiv Atom API (cond-mat/0603189v3 carries journal_ref "J. Stat. Mech. (2006) P06009" + the same DOI). The D7 bibitem as first shipped in 4702f6ba listed arXiv:cond-mat/0601487, which is the COMPANION Chertkov-Chernyak letter "Loop Calculus in Statistical Physics and Information Science" (Phys. Rev. E 73, 065102(R) (2006), DOI 10.1103/PhysRevE.73.065102), not this paper — bibitem corrected to cond-mat/0603189 in this batch. arXiv PDF cached as primary source (bundle-first bibkey → Phase-1-and-Background cache routing per the Phase 6v Wave 6v.3 convention).',
    },

    # ════════════════════════════════════════════════════════════════
    # Auto-stubs from \bibitem blocks (Phase 6i Wave 1 backfill)
    # ════════════════════════════════════════════════════════════════

    'Alberti1983': {
        'authors': 'P.~M. Alberti',
        'title': 'A note on the transition probability over $C^*$-algebras',
        'journal': 'Lett. Math. Phys',
        'volume': 7,
        'page': None,
        'year': 1983,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Lett. Math. Phys. (1983) — predates arXiv deposit; '
                         'bibliographic record verified against the journal of record.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Pre-arXiv classic (Lett. Math. Phys. 1983). No arXiv preprint exists; bibliographic record verified against the journal of record. Textbook/pre-arXiv exempt from primary-source caching.',
    },

    'Audenaert2007': {
        'authors': 'K.~M.~R. Audenaert',
        'title': 'A sharp continuity estimate for the von Neumann entropy',
        'journal': 'Math. Theor',
        'volume': 40,
        'page': None,
        'year': 2007,
        'doi': None,
        'arxiv': 'quant-ph/0610146',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Audenaert2007.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/0610146 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'BB84': {
        'authors': 'C.~H. Bennett and G.~Brassard',
        'title': 'Quantum cryptography: public key distribution and coin tossing',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'IEEE ICCSSP Bangalore 1984 proceedings — predates arXiv and '
                         'carries no DOI; verified via the QKD literature that reprints '
                         'it (TCS 560).',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Conference proceedings (IEEE ICCSSP, Bangalore, 1984). No arXiv/DOI; canonical foundational reference. Textbook/pre-arXiv exempt.',
    },

    'BBPSSW1996': {
        'authors': 'C.~H. Bennett, G.~Brassard, S.~Popescu, B.~Schumacher, J.~A. Smolin, and W.~K. Wootters',
        'title': 'Purification of noisy entanglement and faithful teleportation via noisy channels',
        'journal': 'Phys. Rev. Lett',
        'volume': 76,
        'page': None,
        'year': 1996,
        'doi': None,
        'arxiv': 'quant-ph/9511027',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/BBPSSW1996.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/9511027 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'BDCZ1998': {
        'authors': 'H.-J. Briegel, W.~D\\"ur, J.~I. Cirac, and P.~Zoller',
        'title': 'Quantum repeaters: the role of imperfect local operations in quantum communication',
        'journal': 'Phys. Rev. Lett',
        'volume': 81,
        'page': None,
        'year': 1998,
        'doi': None,
        'arxiv': 'quant-ph/9803056',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/BDCZ1998.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/9803056 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'BennettDiVincenzoSmolin1997': {
        'authors': 'C.~H. Bennett, D.~P. DiVincenzo, and J.~A. Smolin',
        'title': 'Capacities of quantum erasure channels',
        'journal': 'Phys. Rev. Lett',
        'volume': 78,
        'page': None,
        'year': 1997,
        'doi': None,
        'arxiv': 'quant-ph/9701015',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/BennettDiVincenzoSmolin1997.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/9701015 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Bhatia1997': {
        'authors': 'R.~Bhatia',
        'title': 'Matrix Analysis',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Springer GTM 169 monograph; the standard matrix-analysis '
                         'reference, verified via secondary academic citation. No '
                         'downloadable full-text primary source.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Textbook (Springer GTM 169). No arXiv/DOI primary source. Textbook exempt.',
    },

    'CalsamigliaLutkenhaus2001': {
        'authors': 'J.~Calsamiglia and N.~L\\"utkenhaus',
        'title': 'Maximum efficiency of a linear-optical Bell-state analyzer',
        'journal': 'Appl. Phys. B',
        'volume': 72,
        'page': None,
        'year': 2001,
        'doi': None,
        'arxiv': 'quant-ph/0007058',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/CalsamigliaLutkenhaus2001.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/0007058 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Caves1982': {
        'authors': 'C.~M. Caves',
        'title': 'Quantum limits on noise in linear amplifiers',
        'journal': 'Phys. Rev. D',
        'volume': 26,
        'page': None,
        'year': 1982,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Phys. Rev. D (1982) — predates arXiv deposit; bibliographic '
                         'record verified against the journal of record.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Pre-arXiv classic (Phys. Rev. D 1982). No arXiv preprint. Pre-arXiv exempt.',
    },

    'Choi1975': {
        'authors': 'M.-D. Choi',
        'title': 'Completely positive linear maps on complex matrices',
        'journal': 'Linear Algebra Appl',
        'volume': 10,
        'page': None,
        'year': 1975,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Linear Algebra Appl. (1975) — predates arXiv deposit; '
                         'bibliographic record verified against the journal of record.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Pre-arXiv classic (Linear Algebra Appl. 1975). No arXiv preprint. Pre-arXiv exempt.',
    },

    'Chung2025': {
        'authors': 'K.~Chung, M.~Hajdu\\v{s}ek, R.~Van~Meter',
        'title': 'Cross-verification of quantum network simulators',
        'journal': None,
        'volume': None,
        'page': None,
        'year': 2025,
        'doi': None,
        'arxiv': '2504.01290',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Chung2025.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint 2504.01290 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'DEJMPS1996': {
        'authors': 'D.~Deutsch, A.~Ekert, R.~Jozsa, C.~Macchiavello, S.~Popescu, and A.~Sanpera',
        'title': 'Quantum privacy amplification and the security of quantum cryptography over noisy channels',
        'journal': 'Phys. Rev. Lett',
        'volume': 77,
        'page': None,
        'year': 1996,
        'doi': None,
        'arxiv': 'quant-ph/9604039',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/DEJMPS1996.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/9604039 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Fannes1973': {
        'authors': 'M.~Fannes',
        'title': 'A continuity property of the entropy density for spin lattice systems',
        'journal': 'Commun. Math. Phys',
        'volume': 31,
        'page': None,
        'year': 1973,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Commun. Math. Phys. (1973) — predates arXiv deposit; '
                         'bibliographic record verified against the journal of record.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Pre-arXiv classic (Commun. Math. Phys. 1973). No arXiv preprint. Pre-arXiv exempt.',
    },

    'FordFulkerson1956': {
        'authors': 'L.~R. Ford and D.~R. Fulkerson',
        'title': 'Maximal flow through a network',
        'journal': 'Canad. J. Math',
        'volume': 8,
        'page': None,
        'year': 1956,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Canad. J. Math. (1956) — predates arXiv deposit; bibliographic '
                         'record verified against the journal of record.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Pre-arXiv classic (Canad. J. Math. 1956). No arXiv preprint. Pre-arXiv exempt.',
    },

    'FortescueLo2007': {
        'authors': 'B.~Fortescue and H.-K. Lo',
        'title': 'Random bipartite entanglement from W and W-like states',
        'journal': 'Phys. Rev. Lett',
        'volume': 98,
        'page': None,
        'year': 2007,
        'doi': None,
        'arxiv': 'quant-ph/0607126',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/FortescueLo2007.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/0607126 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'FuchsvandeGraaf1999': {
        'authors': 'C.~A. Fuchs and J.~van~de~Graaf',
        'title': 'Cryptographic distinguishability measures for quantum-mechanical states',
        'journal': 'IEEE Trans. Inf. Theory',
        'volume': 45,
        'page': None,
        'year': 1999,
        'doi': None,
        'arxiv': 'quant-ph/9712042',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/FuchsvandeGraaf1999.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/9712042 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Gambetta2007': {
        'authors': 'J.~Gambetta, W.~A. Braff, A.~Wallraff, S.~M. Girvin, and R.~J. Schoelkopf',
        'title': 'Protocols for optimal readout of qubits using a continuous quantum nondemolition measurement',
        'journal': 'Phys. Rev. A',
        'volume': 76,
        'page': None,
        'year': 2007,
        'doi': None,
        'arxiv': 'cond-mat/0701078',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Gambetta2007.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint cond-mat/0701078 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Geerlings2013': {
        'authors': 'K.~Geerlings, Z.~Leghtas, I.~M. Pop, S.~Shankar, L.~Frunzio, R.~J. Schoelkopf, M.~Mirrahimi, and M.~H. Devoret',
        'title': 'Demonstrating a driven reset protocol for a superconducting qubit',
        'journal': 'Phys. Rev. Lett',
        'volume': 110,
        'page': None,
        'year': 2013,
        'doi': None,
        'arxiv': '1211.0491',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Geerlings2013.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint 1211.0491 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Helstrom1976': {
        'authors': 'C.~W. Helstrom',
        'title': 'Quantum Detection and Estimation Theory',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Academic Press monograph; the canonical quantum '
                         'detection-and-estimation reference, verified via secondary '
                         'academic citation.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Textbook (Academic Press, 1976). No arXiv/DOI primary source. Textbook exempt.',
    },

    'Horodecki1999': {
        'authors': 'M.~Horodecki, P.~Horodecki, and R.~Horodecki',
        'title': 'General teleportation channel, singlet fraction, and quasidistillation',
        'journal': 'Phys. Rev. A',
        'volume': 60,
        'page': None,
        'year': 1999,
        'doi': None,
        'arxiv': 'quant-ph/9807091',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Horodecki1999.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/9807091 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'HorodeckiPPT1996': {
        'authors': 'M.~Horodecki, P.~Horodecki, and R.~Horodecki',
        'title': 'Separability of mixed states: necessary and sufficient conditions',
        'journal': 'Phys. Lett. A',
        'volume': 223,
        'page': None,
        'year': 1996,
        'doi': None,
        'arxiv': 'quant-ph/9605038',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/HorodeckiPPT1996.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/9605038 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Jin2015': {
        'authors': 'X.~Y. Jin, A.~Kamal, A.~P. Sears, T.~Gudmundsen, D.~Hover, J.~Miloshi, R.~Slattery, F.~Yan, J.~Yoder, T.~P. Orlando, S.~Gustavsson, and W.~D. Oliver',
        'title': 'Thermal and residual excited-state population in a 3D transmon qubit',
        'journal': 'Phys. Rev. Lett',
        'volume': 114,
        'page': None,
        'year': 2015,
        'doi': None,
        'arxiv': '1412.2772',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Jin2015.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint 1412.2772 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Kitaev1997': {
        'authors': 'A.~Yu. Kitaev',
        'title': 'Quantum computations: algorithms and error correction',
        'journal': 'Russ. Math. Surv',
        'volume': 52,
        'page': None,
        'year': 1997,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Russ. Math. Surv. 52, 1191 (1997) review — no arXiv deposit '
                         'exists for this review; record verified against the journal of '
                         'record.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Review article (Russ. Math. Surv. 52, 1191, 1997). No arXiv preprint for this review. Pre-arXiv exempt.',
    },

    'Macchiavello1998': {
        'authors': 'C.~Macchiavello',
        'title': 'On the analytical convergence of the QPA procedure',
        'journal': 'Phys. Lett. A',
        'volume': 246,
        'page': None,
        'year': 1998,
        'doi': None,
        'arxiv': 'quant-ph/9807074',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Macchiavello1998.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/9807074 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Magesan2011': {
        'authors': 'E.~Magesan, J.~M. Gambetta, and J.~Emerson',
        'title': 'Scalable and robust randomized benchmarking of quantum processes',
        'journal': 'Phys. Rev. Lett',
        'volume': 106,
        'page': None,
        'year': 2011,
        'doi': None,
        'arxiv': '1009.3639',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Magesan2011.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint 1009.3639 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'MassarPopescu1995': {
        'authors': 'S.~Massar and S.~Popescu',
        'title': 'Optimal extraction of information from finite quantum ensembles',
        'journal': 'Phys. Rev. Lett',
        'volume': 74,
        'page': None,
        'year': 1995,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Phys. Rev. Lett. 74, 1259 (1995) — predates routine quant-ph '
                         'deposit; record verified against the journal of record.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Pre-arXiv classic (Phys. Rev. Lett. 74, 1259, 1995). No arXiv preprint (predates quant-ph deposit). Pre-arXiv exempt.',
    },

    'Mirsky1960': {
        'authors': 'L.~Mirsky',
        'title': 'Symmetric gauge functions and unitarily invariant norms',
        'journal': 'Q. J. Math',
        'volume': 11,
        'page': None,
        'year': 1960,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Quart. J. Math. (1960) — predates arXiv deposit; bibliographic '
                         'record verified against the journal of record.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Pre-arXiv classic (Quart. J. Math. 1960). No arXiv preprint. Pre-arXiv exempt.',
    },

    'Nielsen2002': {
        'authors': 'M.~A. Nielsen',
        'title': 'A simple formula for the average gate fidelity of a quantum dynamical operation',
        'journal': 'Phys. Lett. A',
        'volume': 303,
        'page': None,
        'year': 2002,
        'doi': None,
        'arxiv': 'quant-ph/0205035',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Nielsen2002.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/0205035 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'NielsenChuang2010': {
        'authors': 'M.~A. Nielsen and I.~L. Chuang',
        'title': 'Quantum Computation and Quantum Information',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Cambridge Univ. Press, 10th anniversary ed.; the canonical '
                         'quantum-computation textbook, verified via secondary academic '
                         'citation.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Textbook (Cambridge Univ. Press, 10th anniv. ed.). No arXiv/DOI primary source. Textbook exempt.',
    },

    'Nyquist1928': {
        'authors': 'H.~Nyquist',
        'title': 'Thermal agitation of electric charge in conductors',
        'journal': 'Phys. Rev',
        'volume': 32,
        'page': None,
        'year': 1928,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Phys. Rev. 32, 110 (1928) — predates arXiv by six decades; '
                         'record verified against the journal of record.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Pre-arXiv classic (Phys. Rev. 32, 110, 1928). No arXiv preprint. Pre-arXiv exempt.',
    },

    'PLOB2017': {
        'authors': 'S.~Pirandola, R.~Laurenza, C.~Ottaviani, and L.~Banchi',
        'title': 'Fundamental limits of repeaterless quantum communications',
        'journal': 'Nat. Commun',
        'volume': 8,
        'page': None,
        'year': 2017,
        'doi': None,
        'arxiv': '1510.08863',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/PLOB2017.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint 1510.08863 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Peres1996': {
        'authors': 'A.~Peres',
        'title': 'Separability criterion for density matrices',
        'journal': 'Phys. Rev. Lett',
        'volume': 77,
        'page': None,
        'year': 1996,
        'doi': None,
        'arxiv': 'quant-ph/9604005',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Peres1996.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/9604005 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Plenio2005': {
        'authors': 'M.~B. Plenio',
        'title': 'Logarithmic negativity: a full entanglement monotone that is not convex',
        'journal': 'Phys. Rev. Lett',
        'volume': 95,
        'page': None,
        'year': 2005,
        'doi': None,
        'arxiv': 'quant-ph/0505071',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Plenio2005.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/0505071 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Sangouard2011': {
        'authors': 'N.~Sangouard, C.~Simon, H.~de~Riedmatten, and N.~Gisin',
        'title': 'Quantum repeaters based on atomic ensembles and linear optics',
        'journal': 'Rev. Mod. Phys',
        'volume': 83,
        'page': None,
        'year': 2011,
        'doi': None,
        'arxiv': '0906.2699',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Sangouard2011.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint 0906.2699 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'ShorPreskill2000': {
        'authors': 'P.~W. Shor and J.~Preskill',
        'title': 'Simple proof of security of the BB84 quantum key distribution protocol',
        'journal': 'Phys. Rev. Lett',
        'volume': 85,
        'page': None,
        'year': 2000,
        'doi': None,
        'arxiv': 'quant-ph/0003004',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/ShorPreskill2000.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/0003004 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Uhlmann1976': {
        'authors': 'A.~Uhlmann',
        'title': "The `transition probability' in the state space of a *-algebra",
        'journal': 'Rep. Math. Phys',
        'volume': 9,
        'page': None,
        'year': 1976,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Rep. Math. Phys. 9, 273 (1976) — predates arXiv deposit; '
                         'record verified against the journal of record.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Pre-arXiv classic (Rep. Math. Phys. 9, 273, 1976). No arXiv preprint. Pre-arXiv exempt.',
    },

    'VidalWerner2002': {
        'authors': 'G.~Vidal and R.~F. Werner',
        'title': 'Computable measure of entanglement',
        'journal': 'Phys. Rev. A',
        'volume': 65,
        'page': None,
        'year': 2002,
        'doi': None,
        'arxiv': 'quant-ph/0102117',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/VidalWerner2002.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint quant-ph/0102117 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Walter2017': {
        'authors': "T.~Walter, P.~Kurpiers, S.~Gasparinetti, P.~Magnard, A.~Poto\\v{c}nik, Y.~Salath\\'e, M.~Pechal, M.~Mondal, M.~Oppliger, C.~Eichler, and A.~Wallraff",
        'title': 'Rapid high-fidelity single-shot dispersive readout of superconducting qubits',
        'journal': 'Phys. Rev. Applied',
        'volume': 7,
        'page': None,
        'year': 2017,
        'doi': None,
        'arxiv': '1701.06933',
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Walter2017.pdf',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'arXiv preprint 1701.06933 (id title-matched against the arXiv API 2026-06-10). PDF cached as primary source.',
    },

    'Watrous2018': {
        'authors': 'J.~Watrous',
        'title': 'The Theory of Quantum Information',
        'journal': None,
        'volume': None,
        'page': None,
        'year': None,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Cambridge Univ. Press (2018); canonical '
                         'quantum-information-theory monograph verified via secondary '
                         'academic citation.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Textbook (Cambridge Univ. Press, 2018). No arXiv/DOI primary source. Textbook exempt.',
    },

    'WernerState1989': {
        'authors': 'R.~F. Werner',
        'title': 'Quantum states with Einstein-Podolsky-Rosen correlations admitting a hidden-variable model',
        'journal': 'Phys. Rev. A',
        'volume': 40,
        'page': None,
        'year': 1989,
        'doi': None,
        'arxiv': None,
        'doi_verified': False,
        'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Phys. Rev. A 40, 4277 (1989) — predates quant-ph deposit; '
                         'record verified against the journal of record.',
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Pre-arXiv classic (Phys. Rev. A 40, 4277, 1989). No arXiv preprint (predates quant-ph deposit). Pre-arXiv exempt.',
    },

    # ════════════════════════════════════════════════════════════════
    # D10 — Computational quantum chemistry & open-system foundations
    # (Phases 6BA/6BB/6BC first-lift, 2026-06-30). Canonical textbooks +
    # classic primaries + ITP-ecosystem refs; all textbook/exempt path
    # (no local PDF cache — canonical, or off the egress whitelist with
    # arXiv ID + authors verified by the D10 Stage-13 adversarial review).
    # ════════════════════════════════════════════════════════════════

    'lean4': {
        'authors': 'de Moura, L., Ullrich, S.',
        'title': 'The Lean 4 Theorem Prover and Programming Language',
        'journal': 'CADE 28, LNCS 12699', 'volume': None, 'page': '625', 'year': 2021,
        'doi': '10.1007/978-3-030-79876-5_37', 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'software',
        'exempt_reason': 'Tool paper for the Lean 4 prover (CADE-28); the artifact '
                         'actually cited is the pinned toolchain, and the DOI records '
                         'the paper of record.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Tool reference (DOI 10.1007/978-3-030-79876-5_37). Canonical; textbook-exempt.',
    },
    'mathlib': {
        'authors': 'The Mathlib Community',
        'title': 'The Lean Mathematical Library',
        'journal': 'CPP 2020', 'volume': None, 'page': None, 'year': 2020,
        'doi': '10.1145/3372885.3373824', 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'software',
        'exempt_reason': 'Tool paper for the Lean mathematical library (CPP 2020); the '
                         'artifact actually cited is the pinned Mathlib commit, and the '
                         'DOI records the paper of record.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Tool reference (DOI 10.1145/3372885.3373824). Canonical; textbook-exempt.',
    },
    'survey2021': {
        'authors': 'Lewis, M., Soudjani, S., Zuliani, P.',
        'title': 'Formal Verification of Quantum Programs: Theory, Tools and Challenges',
        'journal': 'arXiv', 'volume': None, 'page': None, 'year': 2021,
        'doi': None, 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'arXiv:2110.01320; ID + authors verified by D10 Stage-13 adversarial review 2026-06-30. ITP-ecosystem honest-situating ref. NOT EXEMPT (ADR-014 D7): the arXiv id above belongs in the `arxiv` field and the source needs caching. It sits in `undeclared_class` until then -- an under-populated entry, not a reference class.',
    },
    'coqq2022': {
        'authors': 'Zhou, L., Barthe, G., Strub, P.-Y., Liu, J., Ying, M.',
        'title': 'CoqQ: Foundational Verification of Quantum Programs',
        # Published at POPL 2023 (Proc. ACM Program. Lang.); the DOI below is the ACM one,
        # so `journal: 'arXiv'` contradicted the entry's own DOI and its primary-source
        # cache header. Caught 2026-08-14 by the Venue leg of
        # `citation_primary_sources_present` (D11 round-4 finding 1.1 / round-8 1.1).
        'journal': 'Proc. ACM Program. Lang.', 'volume': None, 'page': None, 'year': 2022,
        'doi': '10.1145/3571222', 'arxiv': '2207.11350', 'doi_verified': True, 'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-6e/primary-sources/coqq2022.abstract.txt',
        'used_in': ['papers/D12/paper_draft.tex', 'papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'arXiv:2207.11350; ID + author list verified + corrected by D10 Stage-13 review 2026-06-30 (Strub/Liu, not Hsu/Yu). ITP honest-situating ref; PDF off egress whitelist; exempt.',
    },
    'leanQI2025': {
        'authors': 'Meiburg, A., Lessa, L. A., Soldati, R. R.',
        'title': "A Formalization of the Generalized Quantum Stein's Lemma in Lean",
        'journal': 'arXiv', 'volume': None, 'page': None, 'year': 2025,
        'doi': None, 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'arXiv:2510.08672; ID + authors verified + corrected by D10 Stage-13 review 2026-06-30 (Meiburg/Lessa/Soldati). The Lean PhysLib/QuantumInfo CPTP layer D10 builds on. NOT EXEMPT (ADR-014 D7): the arXiv id above belongs in the `arxiv` field and the source needs caching. It sits in `undeclared_class` until then -- an under-populated entry, not a class.',
    },
    'isabelleCBO': {
        'authors': 'Rodríguez Caballero, J. M., Unruh, D.',
        'title': 'Complex Bounded Operators in Isabelle/HOL',
        'journal': 'arXiv', 'volume': None, 'page': None, 'year': 2025,
        'doi': None, 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'arXiv:2512.05878; ID + title verified by D10 Stage-13 review 2026-06-30. ITP honest-situating ref. NOT EXEMPT (ADR-014 D7): the arXiv id above belongs in the `arxiv` field and the source needs caching. It sits in `undeclared_class` until then -- an under-populated entry, not a reference class.',
    },
    'datta1995': {
        'authors': 'Datta, S.',
        'title': 'Electronic Transport in Mesoscopic Systems',
        'journal': 'Cambridge University Press', 'volume': None, 'page': None, 'year': 1995,
        'doi': '10.1017/CBO9780511805776', 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Cambridge Univ. Press; the canonical NEGF mesoscopic-transport '
                         'monograph. Volume DOI recorded; no cacheable full text.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Canonical NEGF textbook (DOI 10.1017/CBO9780511805776). Textbook-exempt.',
    },
    'landauer1957': {
        'authors': 'Landauer, R.',
        'title': 'Spatial Variation of Currents and Fields Due to Localized Scatterers in Metallic Conduction',
        'journal': 'IBM J. Res. Dev.', 'volume': 1, 'page': '223', 'year': 1957,
        'doi': '10.1147/rd.13.0223', 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'IBM J. Res. Dev. 1, 223 (1957) — predates arXiv. DOI recorded; '
                         'the class carries the exemption.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Canonical classic (DOI 10.1147/rd.13.0223). Pre-arXiv; textbook-exempt.',
    },
    'buttiker1986': {
        'authors': 'Büttiker, M.',
        'title': 'Four-Terminal Phase-Coherent Conductance',
        'journal': 'Phys. Rev. Lett.', 'volume': 57, 'page': '1761', 'year': 1986,
        'doi': '10.1103/PhysRevLett.57.1761', 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Phys. Rev. Lett. 57, 1761 (1986) — predates arXiv deposit. DOI '
                         'recorded: the exemption is the reference CLASS, not a missing '
                         'identifier.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Canonical classic (DOI 10.1103/PhysRevLett.57.1761). Pre-arXiv; textbook-exempt.',
    },
    'meirWingreen1992': {
        'authors': 'Meir, Y., Wingreen, N. S.',
        'title': 'Landauer Formula for the Current through an Interacting Electron Region',
        'journal': 'Phys. Rev. Lett.', 'volume': 68, 'page': '2512', 'year': 1992,
        'doi': '10.1103/PhysRevLett.68.2512', 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Phys. Rev. Lett. 68, 2512 (1992) — no arXiv deposit. DOI '
                         'recorded and the record verified against the journal of '
                         'record.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Canonical classic (DOI 10.1103/PhysRevLett.68.2512). Textbook-exempt.',
    },
    'kato1995': {
        'authors': 'Kato, T.',
        'title': 'Perturbation Theory for Linear Operators',
        'journal': 'Springer', 'volume': None, 'page': None, 'year': 1995,
        'doi': '10.1007/978-3-642-66282-9', 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Springer 2nd ed.; the canonical '
                         'perturbation-theory-for-linear-operators monograph. Volume DOI '
                         'recorded; no cacheable full text.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Canonical operator-theory textbook (2nd ed., DOI 10.1007/978-3-642-66282-9). Textbook-exempt.',
    },
    'reedSimon2': {
        'authors': 'Reed, M., Simon, B.',
        'title': 'Methods of Modern Mathematical Physics II: Fourier Analysis, Self-Adjointness',
        'journal': 'Academic Press', 'volume': None, 'page': None, 'year': 1975,
        'doi': None, 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'textbook',
        'exempt_reason': 'Academic Press, Methods of Modern Mathematical Physics Vol. '
                         'II; canonical mathematical-physics monograph verified via '
                         'secondary academic citation.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Canonical math-physics textbook. Textbook-exempt.',
    },
    'hohenbergKohn1964': {
        'authors': 'Hohenberg, P., Kohn, W.',
        'title': 'Inhomogeneous Electron Gas',
        'journal': 'Phys. Rev.', 'volume': 136, 'page': 'B864', 'year': 1964,
        'doi': '10.1103/PhysRev.136.B864', 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Phys. Rev. 136, B864 (1964), the DFT founding paper — predates '
                         'arXiv. DOI recorded; the class carries the exemption.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Canonical DFT founding paper (DOI 10.1103/PhysRev.136.B864). Pre-arXiv; textbook-exempt.',
    },
    'levy1979': {
        'authors': 'Levy, M.',
        'title': 'Universal Variational Functionals of Electron Densities, First-Order Density Matrices, and Natural Spin-Orbitals and Solution of the v-Representability Problem',
        'journal': 'Proc. Natl. Acad. Sci. USA', 'volume': 76, 'page': '6062', 'year': 1979,
        'doi': '10.1073/pnas.76.12.6062', 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'PNAS 76, 6062 (1979), the constrained-search paper — predates '
                         'arXiv. DOI recorded; the class carries the exemption.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Canonical Levy constrained-search paper (DOI 10.1073/pnas.76.12.6062). Pre-arXiv; textbook-exempt.',
    },
    'lieb1983': {
        'authors': 'Lieb, E. H.',
        'title': 'Density Functionals for Coulomb Systems',
        'journal': 'Int. J. Quantum Chem.', 'volume': 24, 'page': '243', 'year': 1983,
        'doi': '10.1002/qua.560240302', 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Int. J. Quantum Chem. 24, 243 (1983) — predates arXiv. DOI '
                         'recorded; the class carries the exemption.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Canonical Lieb DFT paper (DOI 10.1002/qua.560240302). Pre-arXiv; textbook-exempt.',
    },
    'gksl1976': {
        'authors': 'Gorini, V., Kossakowski, A., Sudarshan, E. C. G.',
        'title': 'Completely Positive Dynamical Semigroups of N-Level Systems',
        'journal': 'J. Math. Phys.', 'volume': 17, 'page': '821', 'year': 1976,
        'doi': '10.1063/1.522979', 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'J. Math. Phys. 17, 821 (1976), the GKSL founding paper — '
                         'predates arXiv. DOI recorded; the class carries the exemption.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Canonical GKSL founding paper (DOI 10.1063/1.522979). Pre-arXiv; textbook-exempt.',
    },
    'lindblad1976': {
        'authors': 'Lindblad, G.',
        'title': 'On the Generators of Quantum Dynamical Semigroups',
        'journal': 'Commun. Math. Phys.', 'volume': 48, 'page': '119', 'year': 1976,
        'doi': '10.1007/BF01608499', 'arxiv': None, 'doi_verified': False, 'inprep': False,
        'primary_source_path': None,
        'citation_class': 'pre_arxiv',
        'exempt_reason': 'Commun. Math. Phys. 48, 119 (1976), the Lindblad founding '
                         'paper — predates arXiv. DOI recorded; the class carries the '
                         'exemption.',
        'used_in': ['papers/D10/paper_draft.tex'], 'provides': [],
        'notes': 'Canonical Lindblad founding paper (DOI 10.1007/BF01608499). Pre-arXiv; textbook-exempt.',
    },

    # ════════════════════════════════════════════════════════════════
    # Auto-stubs from \bibitem blocks (Phase 6i Wave 1 backfill)
    # ════════════════════════════════════════════════════════════════

    # Exact citing-key identities reconciled against current sources (2026-10-15).
    'CompanionCompilation': {
        'authors': 'Roehm, John',
        'title': 'Kernel-Verified Universal Quantum Gate Compilation: Alphabet-Agnostic Solovay--Kitaev across Dimensions',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Internal companion manuscript identity verified against papers/D8/paper_draft.tex title and author, 2026-10-15. Existing citing key retained. No external deposit or publication identity is established; no external primary-source artifact is claimed.',
    },

    'CompanionFaultTolerance': {
        'authors': 'Roehm, John G.',
        'title': 'Minimal Hypotheses for the Aliferis--Gottesman--Preskill Threshold Recursion, Machine-Checked in Lean 4',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Internal companion manuscript identity verified against papers/D6/paper_draft.tex title and author, 2026-10-15. Existing citing key retained. No external deposit or publication identity is established; no external primary-source artifact is claimed.',
    },

    'CompanionStochastic': {
        'authors': 'Roehm, John',
        'title': "Verified Stochastic Calculus and Large-Deviation Foundations for Lean 4 / Mathlib4: A Predicate-Substrate Library for the Stochastic Integral, Quadratic Variation, Itô's Lemma, and Large-Deviation Principles, with a Typeclass Bridge to Schwinger--Keldysh Effective Field Theory",
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D9/paper_draft.tex'],
        'provides': [],
        'notes': 'Internal companion manuscript identity verified against papers/I3/paper_draft.tex title and author, 2026-10-15. Existing citing key retained. No external deposit or publication identity is established; no external primary-source artifact is claimed.',
    },

    'Roehm2026TQC': {
        'authors': 'Roehm, John',
        'title': 'Machine-checked universality of the Fibonacci braid representation, with a graded verification of the surrounding modular-tensor-category apparatus',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': [],
        'notes': 'Internal companion manuscript identity verified against papers/D4/paper_draft.tex title and author, 2026-10-15. Existing citing key retained. No external deposit or publication identity is established; no external primary-source artifact is claimed.',
    },

    'RoehmD8Compilation': {
        'authors': 'Roehm, John',
        'title': 'Kernel-Verified Universal Quantum Gate Compilation: Alphabet-Agnostic Solovay--Kitaev across Dimensions',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D4/paper_draft.tex'],
        'provides': [],
        'notes': 'Internal companion manuscript identity verified against papers/D8/paper_draft.tex title and author, 2026-10-15. Existing citing key retained. No external deposit or publication identity is established; no external primary-source artifact is claimed.',
    },

    'RoehmD4Topological': {
        'authors': 'Roehm, John',
        'title': 'Machine-checked universality of the Fibonacci braid representation, with a graded verification of the surrounding modular-tensor-category apparatus',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Internal companion manuscript identity verified against papers/D4/paper_draft.tex title and author, 2026-10-15. Existing citing key retained. No external deposit or publication identity is established; no external primary-source artifact is claimed.',
    },

    'RoehmD6FaultTolerant': {
        'authors': 'Roehm, John G.',
        'title': 'Minimal Hypotheses for the Aliferis--Gottesman--Preskill Threshold Recursion, Machine-Checked in Lean 4',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Internal companion manuscript identity verified against papers/D6/paper_draft.tex title and author, 2026-10-15. Existing citing key retained. No external deposit or publication identity is established; no external primary-source artifact is claimed.',
    },

    'RoehmD9Certification': {
        'authors': 'Roehm, John',
        'title': 'Kernel-Verified Quantum-Network and Device-Characterization Certification Substrate',
        'journal': 'in preparation',
        'volume': None,
        'page': None,
        'year': 2026,
        'doi': None,
        'arxiv': None,
        'doi_verified': None,
        'inprep': True,
        'primary_source_path': None,
        'used_in': ['papers/D8/paper_draft.tex'],
        'provides': [],
        'notes': 'Internal companion manuscript identity verified against papers/D9/paper_draft.tex title and author, 2026-10-15. Existing citing key retained. No external deposit or publication identity is established; no external primary-source artifact is claimed.',
    },

    'FinazziLiberatiSindoni2012': {
        'authors': 'Finazzi, S., Liberati, S., Sindoni, L.',
        'title': 'Cosmological Constant: A Lesson from Bose-Einstein Condensates',
        'journal': 'Phys. Rev. Lett.',
        'volume': 108,
        'page': '071101',
        'year': 2012,
        'doi': '10.1103/PhysRevLett.108.071101',
        'arxiv': '1103.4841',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/FinazziLiberatiSindoni2012.pdf',
        'used_in': ['papers/D3/paper_draft.tex'],
        'provides': [],
        'notes': 'Existing citing-key alias of FinazziLiberatiSindoni2012PRL; New key-named artifact acquired through the existing writer from the exact pinned preprint URL on 2026-10-15; bytes match the preserved canonical artifact. Held body is arXiv:1103.4841v2, 28 February 2012; the separate proceedings source 1204.3039 is not substituted.',
    },

    'Kitaev2006': {
        'authors': 'Kitaev, A.',
        'title': 'Anyons in an exactly solved model and beyond',
        'journal': 'Annals of Physics',
        'volume': 321,
        'page': '2-111',
        'year': 2006,
        'doi': '10.1016/j.aop.2005.10.005',
        'arxiv': 'cond-mat/0506438',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Kitaev2006.pdf',
        'used_in': ['papers/D2/paper_draft.tex'],
        'provides': [],
        'notes': 'Existing citing-key alias of KitaevHonest2006; New key-named artifact acquired through the existing writer from the exact pinned preprint URL on 2026-10-15; bytes match the preserved canonical artifact. Held body is arXiv:cond-mat/0506438v3, 1 January 2008, distinct from the 2006 publication metadata.',
    },

    'Wang2026TMDPolariton': {
        'authors': 'Wang, Z., Kim, B., Zhen, B., He, L.',
        'title': 'Strongly Nonlinear Nanocavity Exciton Polaritons in Gate-Tunable Monolayer Semiconductors',
        'journal': 'PRL',
        'volume': 136,
        'page': '146901',
        'year': 2026,
        'doi': '10.1103/gc15-qsvf',
        'arxiv': '2411.16635',
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Wang2026TMDPolariton.pdf',
        'used_in': ['papers/D1/paper_draft.tex'],
        'provides': [],
        'notes': 'Existing citing-key alias of WangKimBZHe2026PennTMDPolariton; New key-named artifact acquired through the existing writer from the exact pinned preprint URL on 2026-10-15; bytes match the preserved canonical artifact. Held body is arXiv:2411.16635v1 (2024), authors Wang/He/Kim/Zhen; published metadata has author order Wang/Kim/Zhen/He. The published body was read online for the cited linewidths, but is not the cached file. No identity of all parameters across revisions is asserted.',
    },

    'Verlinde1988': {
        'authors': 'Verlinde, Erik',
        'title': 'Fusion rules and modular transformations in 2D conformal field theory',
        'journal': 'Nuclear Physics B',
        'volume': 300,
        'page': '360-376',
        'year': 1988,
        'doi': '10.1016/0550-3213(88)90603-7',
        'arxiv': None,
        'doi_verified': None,
        'inprep': False,
        'primary_source_path': 'Lit-Search/Phase-1-and-Background/primary-sources/Verlinde1988.json',
        'used_in': ['papers/D4/paper_draft.tex'],
        'provides': [],
        'notes': 'Publisher bibliographic identity verified 2026-10-15. Full body not held or read in this package. Existing acquisition writer cached Crossref metadata only on 2026-10-15; no abstract or full body was acquired, so this does not back a source-content claim. No citation-class exemption is declared.',
    },
}


# ════════════════════════════════════════════════════════════════════
# Helper functions
# ════════════════════════════════════════════════════════════════════

def get_citation(key):
    """Look up a citation by key."""
    return CITATION_REGISTRY.get(key)


def format_citation(key, style='short'):
    """Format a citation for display.

    Args:
        key: Citation registry key
        style: 'short' (Author, Journal Volume, Page (Year))
               or 'full' (with title)
    """
    entry = CITATION_REGISTRY.get(key)
    if not entry:
        return f"[{key}: NOT IN REGISTRY]"

    authors = entry['authors'].split(',')[0].strip()
    if ',' in entry['authors']:
        authors += ' et al.'

    if style == 'short':
        page = entry['page'] or '(in press)'
        return f"{authors}, {entry['journal']} {entry['volume']}, {page} ({entry['year']})"
    else:
        return (f"{entry['authors']}, \"{entry['title']}\", "
                f"{entry['journal']} {entry['volume']}, {entry['page']} ({entry['year']})")


def find_unregistered_citations():
    """Scan codebase for citations not in the registry.

    Returns list of (file, line, text) tuples for unregistered references.
    """
    import re
    from pathlib import Path

    project_root = Path(__file__).resolve().parent.parent.parent

    # Known journal patterns
    journal_pattern = re.compile(
        r'(Nature|PRL|PRD|PRA|PRB|JHEP|JETP|Phys\.?\s*Rev|Eur\.?\s*Phys)\s*'
        r'(?:\.?\s*(?:Lett\.?|[A-Z])?\s*)?'
        r'\\?(?:textbf\{)?(\d+)\}?\s*,?\s*(\d+|[A-Z]?\d+)',
        re.IGNORECASE
    )

    # Known DOIs in registry
    known_dois = {e['doi'] for e in CITATION_REGISTRY.values() if e.get('doi')}

    unregistered = []
    for ext in ('*.py', '*.tex'):
        for filepath in (project_root / 'src').rglob(ext):
            for i, line in enumerate(filepath.read_text().splitlines(), 1):
                for match in journal_pattern.finditer(line):
                    ref_text = match.group(0)
                    # Check if this matches any known citation
                    matched = False
                    for entry in CITATION_REGISTRY.values():
                        if (str(entry.get('volume', '')) in ref_text and
                                str(entry.get('page', '')) in ref_text):
                            matched = True
                            break
                    if not matched:
                        unregistered.append((str(filepath), i, ref_text))

    return unregistered


def summary():
    """Print citation registry summary."""
    total = len(CITATION_REGISTRY)
    with_doi = sum(1 for e in CITATION_REGISTRY.values() if e.get('doi'))
    verified = sum(1 for e in CITATION_REGISTRY.values() if e.get('doi_verified'))
    with_arxiv = sum(1 for e in CITATION_REGISTRY.values() if e.get('arxiv'))

    print(f"Citation Registry: {total} papers")
    print(f"  With DOI:     {with_doi}/{total}")
    print(f"  DOI verified: {verified}/{total}")
    print(f"  With arXiv:   {with_arxiv}/{total}")
