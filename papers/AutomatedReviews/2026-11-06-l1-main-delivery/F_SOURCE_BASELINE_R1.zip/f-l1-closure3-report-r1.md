# Scoped drafting handoff

Deliverable: `/tmp/f-l1-closure3-proposed-r1.tex`. Replace ONLY Closure 3 and its immediately following synthesis paragraph, originally F lines 1042–1075. ROOT owns review, serial integration, bibliography and acceptance. No repository file, claims_review.json, notebook, planner, ledger or other section was edited. No staging/commit, native checks, Lean/LSP invocation, build, tests, cache/resource action, or new scientific proof was performed. This is source-qualified prose, not compile/review/publication acceptance.

Venue read from `papers/F/bundle_metadata.json`: Living Rev. Relativity | Phys. Rep.; declared 80–150 pages. The local scoped replacement does not claim to resolve global length or review readiness.

## Primary sections read and claims supported

All three PDFs were read through complete claim-carrying sections, via pdftotext extraction of the supplied pinned files; abstracts and registry summaries were not used as substitutes.

1. `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/Lit-Search/Phase-5d/primary-sources/Volovik2024.pdf`, arXiv:2312.09435v2, complete III (Vestigial Gravity), PDF pp. 3–4, Eqs. (18)–(23). Eq. (18) introduces bilinear tetrad order; Eq. (19) allows nonzero metric quartet order with vanishing tetrad expectation; Eq. (20) orders disorder → GR → ECSK. That is the scope of the retained 2024 citation. It is not used for a second-sound speed law or polarization identification.
2. `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/Lit-Search/Phase-1-and-Background/primary-sources/Volovik2026SecondSound.pdf`, arXiv:2601.00639v1. Complete II, III and IV, PDF pp. 1–3: Eq. (2) gives the de Sitter normal-component relation; III Eqs. (6)–(9) combine Landau's second-sound formula with those thermodynamics to yield s2=c. IV explicitly leaves the mode's graviton interpretation open, discussing scalar/helicity/Goldstone possibilities and an extra mode beyond usual gravitons. The proposed prose distinguishes this luminal de Sitter model from the separately assumed susceptibility law and tensor/matter bridge. No inference about distinct F EOS/H4/q-theory claims is made.
3. `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/Lit-Search/Phase-6a/primary-sources/Abbott2017GW170817.pdf`, ApJL 848 L13. Complete 4 introductory text and 4.1 (Speed of Gravity), PDF p. 6; also 2.1 observation/emission context. Section 4.1 Eq. (1) supplies −3e−15 ≤ Δv/v_EM ≤ +7e−16. The source uses D=26 Mpc (conservative lower distance), simultaneous emission for the upper bound and a 10-second gamma-ray delay for the lower bound. The section explicitly discusses longer/earlier emission histories weakening the inference. Prose retains the conditional source-emission scope, using the conservative symmetric envelope τ=3e−15. No new literal source-time/distance numerical claims enter manuscript text.

## Direct Lean and canonical source inspection

`lean/SKEFTHawking/GravitationalWaves.lean` actual declarations and proof bodies were read, including the following. Carrier types are Mathlib real numbers and real closed intervals; the law is a definition, not an extracted physical propagator. Names below use namespace SKEFTHawking.GravitationalWaves.

- `c_GW` (124): `(χ_vest c : ℝ) : ℝ := c * Real.sqrt χ_vest`. `c_GW_at_chi_one` (127): `(c : ℝ) : c_GW 1 c = c`, by unfold/simp.
- `c_GW_deviation` (139): sqrt χ−1. `c_GW_relative_deviation_eq` (152): hypothesis `c ≠ 0`; conclusion `(c_GW χ c-c)/c = c_GW_deviation χ`, by unfolding, division rewrite and ring. This is the manuscript's explicit nonzero-reference qualification.
- `tolGW170817` (190) is fixed real 3e−15. `LigoSatisfied` (193) is `|δ| ≤ tolGW170817`.
- `c_GW_match_iff_chi_close_to_one` (206): binder χ:ℝ, hypothesis `0 ≤ χ`; conclusion `LigoSatisfied (c_GW_deviation χ) ↔ (1−τ)^2 ≤ χ ∧ χ ≤ (1+τ)^2`. Proof uses positivity and τ<1, sqrt_nonneg, sq_sqrt with hχ, abs_le and squared inequalities. It neither derives the law nor a physical response.
- `natural_lower_violates_ligo` and `natural_upper_violates_ligo` exclude χ=1/10 and χ=10 using sqrt comparisons with 1/4 and 4 respectively. `vestigial_natural_range_violates_ligo` (306) is precisely their conjunction, not universal exclusion of [0.1,10].
- `natural_endpoints_violate_ligo_window` (435), cited in prose, is `¬ ∃ χ:ℝ, (χ=lower ∨ χ=upper) ∧ LigoSatisfied (c_GW_deviation χ)`. Its proof performs the two cases and calls the endpoint lemmas.
- `natural_endpoints_violate_ligo_for_every_c` (453): hypothesis c≠0 and χ equal one endpoint; conclusion `¬ LigoSatisfied ((c_GW χ c-c)/c)`. Proof rewrites using the relative-deviation bridge, then applies the endpoint lemmas. Read as a scalar relative-speed fact only.
- `ligo_confines_chi_vest_within_natural_range` (365), cited: hypotheses `0 ≤ χ` and `LigoSatisfied (c_GW_deviation χ)`; conclusion lower-square ≤ χ, χ ≤ upper-square, adopted lower<χ and χ<adopted upper. Proof calls the biconditional plus exact endpoint comparisons.
- `ligo_window_subset_natural_range` (332): `Icc ((1−τ)^2) ((1+τ)^2) ⊆ Icc lower upper`; proof uses the strict endpoint comparison lemmas. `chi_one_mem_ligo_window` (342), cited, explicitly puts 1 in the compatible interval using the biconditional and `ligo_satisfied_at_chi_one`. `ligo_window_inter_natural_range_nonempty` (350) witnesses intersection at 1. Thus endpoint exclusion and universal range exclusion are different statements, and only the former is retained.
- `ligo_window_width_eq` (374), cited: upper-square minus lower-square =4τ, by ring. `natural_range_width_eq` (388): adopted width =99/10, by unfolding/norm_num. `ligo_window_width_lt_natural_range_width_by_1e14` (397), cited: 1e14*(upper-square−lower-square)<upper−lower, by rewriting those width identities and norm_num. Fixed-width interval comparison supplies no prior probability. `ligo_window_width_lt_1e13` was also read, not needed in prose.

`src/core/formulas.py` actual bodies/docstrings read at 8548–8699: c_GW_from_chi_vest, c_GW_deviation_from_c, ligo_constraint_check, c_GW_natural_range, plus neighboring product-correction definition to avoid false transport inference. Canonical `GW` constants at `src/core/constants.py` 5882–5898 supply the retained speed caps and adopted endpoints. `src/core/provenance.py` 2910 onward states projected normalized comparison range and open physical matching. No new numerical evaluation or manually invented quantitative claim was added. Width/offset algebra is existing actual Lean/documented algebra, not a new physical estimate.

Owning Phase6a roadmap and actual module history were consulted; stale roadmap wording is not used to override current declarations. Existing lean_deps theorem entries and atlas were consulted only for orientation; no absence/stronger-theorem or fresh kernel-build claim is made. No native authority was available/admitted.

## Supporting accepted L1 claim contract

Read `papers/L1/paper_draft.tex` current source, particularly motivation/speed law, range provenance and Physical scope, and `papers/AutomatedReviews/2026-11-06-l1-main-delivery/NORMALIZATION_R1_READBACK.json`. These support the current shared scope but do not substitute for primary reading above. The source-qualified correction leaves original physical B3 normalization/window, state, tensor, matter/light and controlled transport/frequency-band BUILD open. It neither discharges nor requests a reduced version of that construction.

## Specific invalid numerical inferences avoided

The manuscript replacement does not carry F1057's conflation of endpoint speed deviations and deviation/cap ratios. It makes no common approximate endpoint ratio claim. It retains endpoint exclusion as the actual theorem states. It explicitly gives susceptibility offsets −2τ+τ² and +2τ+τ², while τ bounds the speed deviation, avoiding F1073's incorrect susceptibility-offset bound of 3e−15. Finite-tolerance compatibility is an interval, not exact equality χ=1.

## Integration and boundary pressure

The proposed synthesis removes only the invalid uniqueness implication depending on the GW leg. It motivates ADW without claiming the compatible interval physically eliminates an alternative. It does not re-review or rewrite the surrounding Wen, gauge/fracton, Standard Model, Sakharov, vestigial EOS, H4 or q-theory claims. Those remain untouched and unverified by this assignment.

The claims_review legacy summary was not touched and must remain exact. There is no partial v2 replacement. No findings, checks, gates, routing ledgers or planners were created.

A new bibliography citation is required for this proposal. ROOT owns the bibliography. The following optional entry is verified directly against the supplied 2026 PDF title/author/arXiv header and full carrying sections; it is not copied as authority from L1 metadata:

```tex
\bibitem{Volovik2026SecondSound}
G.~E.~Volovik, ``Massless graviton in de Sitter as second sound in
two-fluid hydrodynamics,'' arXiv:2601.00639v1 (2026).
```

## Freshness and limits

First and final same-packet checks returned `fresh:true`, `changed:[]` for task f-l1-closure3-author-r1. Direct SHA256 readback of all three PDFs and F source matched `/tmp/f-l1-source-pins-r1.json`; F source was 77e41db051be7ebf4df88bbcb8ce3ed16d07e70d17633fcadfa5b94f9fe0a610. No drift observed. Scope is draft handoff with ROOT review/acceptance outstanding. No compilation, test, current kernel verification or global readiness claim is made. No ungrounded manuscript claim requiring a TODO was retained in this scoped proposal.

## CONTRADICTIONS BETWEEN THE BRIEF AND THE SOURCES

None found against the requested corrected scope. The current target prose, rather than the corrective brief, conflicts with the sources/types: the 2024 quartet paper is not the carrying source for the second-sound identification; the 2026 carrying model is luminal and leaves graviton type open; adopted normalized endpoints are not determined by an unevaluated RPA resummation; the actual Lean interval retains compatible interior points including unity; τ bounds speed deviation rather than susceptibility offset; and this conditional scalar result cannot support the synthesis's unique physical selection inference.
