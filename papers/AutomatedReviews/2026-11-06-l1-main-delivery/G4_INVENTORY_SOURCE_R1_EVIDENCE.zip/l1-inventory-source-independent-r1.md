# Independent inventory source adoption review — r1

Verdict: **SOURCE PASS** for the frozen inventory adoption at HEAD `4737b36dcae1fb556449d7b816f087e0f5f4f885`, with the exact 21 donor `1550f5ff11ab6c350081abf607d4431e28e02ef1` postimages. No source-blocking finding. This accepts source adoption and the proposed current inventory deltas before ROOT's canonical writer; it does not certify a baseline, production controls, runtime activation, delivery or publication.

## Identity and immutability

The initial and final continuity checks independently matched packet-owned paths, all 21 changed/untracked postimages, seven protected scientific/source files, HEAD, semantic index hash, exact NUL-delimited status hash, roadmap, notebook and every authority reference. Index SHA256 is `7dd9cebde3ec8cdebbddb7508d1e6f5712e28c1b62b1c239cfd5401bc682a51e`; status SHA256 is `d1653a216cb731db0552da08fc3130bb16d3effea3b20366fd0d87e57c7ea466`. Packet SHA256 is `5966f3cf53667708986c0618bbda4139b68150e17882ec022da46bea29e2a151`.

## Source and intent assessment

- **D1: pass.** `_git_hook_directory` obtains its identity anchor through Git's explicit checkout `.git` resolution after removing only GIT_DIR/GIT_WORK_TREE/GIT_COMMON_DIR from the anchor environment. Actual queries preserve inherited environment/config; top-level, admin directory and common directory must all equal the independently anchored identities. Hook lookup uses Git's `--path-format=absolute --git-path hooks`. Git resolves supported local/worktree/inherited config precedence; there is no physical-path fallback or manual config parser. Queries are bounded, return-code checked and reject ambiguous/control-bearing/relative output. Foreign administration refuses, while legitimate external hooksPath remains supported.
- **D2: pass.** The collector reads only plugin public manifest text plus directory/entry stat and listing metadata for Git hooks; it does not read, execute, copy or hash private hook bodies. Sorted immediate regular files preserve nonexecutable and symlink membership, excluding `.sample`. Successful absent/non-directory/empty observations remain distinct from failed queries, unreadable metadata, incomplete listings or races, which raise and reach the existing reader's `derivation_runs` failure. The CheckResult/measured policy is unchanged. Public hooks() API remains a list; collect() takes rows/context from one observation.
- **D3: pass.** Git command values are logical `git-path:hooks/<event>` locators; additive context contains only lookup/directory_state. Rendering explains catalog metadata versus activation and exposes no private directory paths, timestamps or body hashes. Every original generator function other than hooks/collect/render is AST-identical to HEAD. All original 25 inventory test methods are AST-identical; additions provide real isolated Git fixtures covering main/linked/nested lookup, absolute/relative/spaced/inherited/worktree config precedence, same-top foreign selectors, no-body membership, known-empty outcomes and refusal/race paths. No tests were run by this reviewer.
- **D4: pass.** END_TO_END_MAP now names descriptive KNOWLEDGE_GRAPH prose, authoritative SHAPE_MAP/per-edge extractor source and derived SURFACE_INVENTORY rather than an absent working document. Ownership/Answers allocation and schema source remain unchanged; no dummy schema or reference exemption is introduced.
- **D5: source contract pass; current controls owed.** Existing writer/check ownership and real-source mutation obligations are preserved. Source adoption uses existing machinery. Historical donor owner/spec statements and dcb review/control receipts describe their original bounded checkpoint; they cannot assert this checkout's fresh baseline, runtime or delivery acceptance. The recorded current focused run is 111 passed plus one expected stale-inventory failure, not a fully passing current run.

## Read-only current collection and every candidate delta

Collector/import origins were bound to this checkout; an isolated empty bytecode prefix and disabled bytecode writes avoided stale project pyc and repository writes. Only collect/render and bounded Git metadata queries were executed; no validation, tests, native preparation, controller, build, update_counts or canonical writer ran.

Candidate Markdown SHA256: `7ac84ea95e4a1e78fc5845f0fbb2b9b7b6f65f554a94462fbc236bd706868b7a`.
Candidate JSON SHA256: `9a30cca8f1c26db41146b6dc9652382196261c491d066351d08c39894fa1245c`.

Compared with `/tmp/l1-g4-inventory-before-r1.json`, all complete gates, graph, agents, commands, registries and bundles records are equal. All plugin hook rows are equal. The only collection deltas are check row 66's corrected readiness_submission_gate description, the recovered Git pre-commit row, and additive git_hook_context `{lookup: git-path:hooks, directory_state: directory}`. Current families comprise 89 checks, 11 gates, 7 hooks, 10 agents, 6 commands, 10 registry records and 21 bundles. Registry imports independently report PAPER_DEPENDENCIES=18 and CITATION_REGISTRY=677; no donor 17/664 snapshot was adopted.

Compared with tracked SURFACE_INVENTORY.md, the complete rendered diff is limited to the corrected check description; new hook catalog explanation/context; pre-commit locator `.git/hooks/pre-commit` → `git-path:hooks/pre-commit`; and registry counts 17 → 18 and 664 → 677. Tracked inventory already has the Git row, whereas the old linked collector omitted it: retaining seven is justified by measured metadata, not a fixed count floor.

The checkout's `.git` is a file. Read-only metadata collection with the reviewed source found identical resolved directories and full hook rows for the current linked checkout, nested launch and primary checkout. This demonstrates current catalog equivalence only, with no hook execution or config changes.

## Required next controls, in order

1. ROOT establishes the reviewed canonical baseline through the existing writer, checks its entire diff against the candidate above, and freshly confirms the targeted existing reader. Write only after the source-review checkpoint and current authorization; a corrected baseline alone is not full acceptance.
2. Under exclusive ROOT seed_journal ownership, regress the actual generator to the old physical `.git/hooks` behavior. A fresh source-bound process in the actual linked checkout must report the intended missing known-present entry and targeted freshness RED. Restore exact bytes/full mode/nsmtime, require the same targeted GREEN and an empty journal. Preserve all failures, source/import witnesses, argv, times and raw outputs. No writer runs while source is seeded.
3. Separately corrupt the actual canonical generated inventory, prove intended RED through its real existing reader, and restore the established baseline exactly with targeted GREEN and empty journal.
4. Run the retained full original inventory module, affected architecture claims and required current registration/gate/delivery profile at their appropriate milestone; preserve optional-OWED versus mandatory registration distinctions. Do not infer whole-tree green from targeted success. Obtain independent whole implementation/actual-control review before normal protected delivery/closure.

No new machinery or source repair is requested. Preserve original dcb receipts as scoped historical evidence; do not copy donor counts/inventory/supersession ledger or treat historical 112 passes/57 inventory cases as fresh current acceptance.

Artifacts: `/tmp/l1-inventory-source-independent-candidate-r1.{md,json,diff}`, `/tmp/l1-inventory-source-independent-deltas-r1.json`, `/tmp/l1-inventory-source-independent-context-r1.json`, and initial/final continuity checks.
