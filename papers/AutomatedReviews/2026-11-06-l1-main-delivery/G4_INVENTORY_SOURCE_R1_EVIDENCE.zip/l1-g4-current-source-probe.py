from pathlib import Path
import sys,json,hashlib,ast
sys.path.insert(0,str(Path.cwd()/'scripts'))
def deny(event,args):
 if event in ['subprocess.Popen','socket.connect','socket.getaddrinfo']:raise RuntimeError('Probe forbids native/external/network operations')
sys.addaudithook(deny)
import build_graph as b,readiness_gates as r
formulas=b.extract_formula_nodes();papers=b.extract_paper_nodes();claims=b.extract_paper_claim_nodes();tests=b.extract_python_test_nodes();params=b.extract_parameter_nodes()
nodes=formulas+papers+claims+tests+params;ids={n['id'] for n in nodes}
edges=b.extract_claims_edges(ids)+b.extract_grounded_in_edges(ids)+b.extract_verifies_edges(ids)
idx=r.GraphIndex({'nodes':nodes,'links':edges})
rows={p['id']:r._eval_computation_correctness(p,idx).to_node_payload() for p in papers}
phase=sys.argv[1];source=Path('src/core/formulas.py');expected=['formula:'+n.name for n in ast.parse(source.read_text()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and not n.name.startswith('_')]
proof={'phase':phase,'scope':'Actual production G4 input extractors and evaluator over all its Paper/Claim/Formula/PythonTest/Parameter input types; no full graph/native/DB/test-execution certification','external_processes_forbidden':True,'full_formulas':formulas,'papers':papers,'python_tests':tests,'g4_rows':rows,'links':edges,'expected_ast_formula_ids':expected,'missing_public_ids':sorted(set(expected)-{n['id'] for n in formulas}),'source_hashes':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['scripts/build_graph.py','scripts/readiness_gates.py','src/core/formulas.py','src/core/provenance.py','lean/lean_deps.json']}}
Path('/tmp/l1-g4-production-'+phase+'.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'phase':phase,'formulas':len(formulas),'expected':len(expected),'omitted':len(proof['missing_public_ids']),'papers':len(papers),'l1':rows.get('paper:L1')},indent=2))
