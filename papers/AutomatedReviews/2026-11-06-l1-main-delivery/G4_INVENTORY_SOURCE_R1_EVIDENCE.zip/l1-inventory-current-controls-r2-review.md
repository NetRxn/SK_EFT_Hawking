# Independent current inventory baseline and control review — r2

**PASS — bounded current inventory source, corrected baseline and authentic production-reader controls.** No blocking finding or required correction. This is not G4/native/full-graph, scientific, delivery, publication or protected-main acceptance.

## Frozen scope and baseline

HEAD is `4737b36dcae1fb556449d7b816f087e0f5f4f885`. All 21 adopted donor postimages and all seven protected science files still match the previous source review. The only additional repository change is the canonical inventory. Its SHA256 is `7ac84ea95e4a1e78fc5845f0fbb2b9b7b6f65f554a94462fbc236bd706868b7a`, exactly the independently reviewed read-only candidate. The entire current canonical diff matches the accepted check-description correction, hook metadata explanation/logical locator, and live registry counts 18 dependencies/677 citations. No old donor 17/664 inventory or omitted linked-worktree catalog was canonized.

ROOT reports use of the existing canonical writer after source acceptance; the resulting bytes and captured baseline freshness are independently confirmed here. The supplied control driver contains no canonical writer invocation and does not regenerate from seeded source.

## Actual production controls

I read the complete current control JSON and driver, original D1–D5 spec/plan, relevant existing reader, seed_journal restoration implementation, current baseline and prior independent source review.

The child calls the real `validation.checks.freshness.check_architecture_inventory_fresh` through checkout-bound imports in a fresh subprocess. Each invocation uses a distinct empty temporary PYTHONPYCACHEPREFIX with bytecode writing disabled, so existing project pyc cannot hide the regression. Recorded validate/inventory origins point to this linked checkout. The reader dynamically loads the actual generator and compares against the actual canonical inventory.

1. **Hard baseline:** exit 0; passed/measured true; all reader details pass; pre-commit is present with the public logical locator.
2. **Real generator regression:** existing seed_journal mutates the actual `directory = _git_hook_directory()` call to the old physical `PROJECT_ROOT / ".git" / "hooks"` lookup. Exit 1; only inventory_fresh fails; known pre-commit disappears and the real comparator reports tracked seven hooks versus derived six. This is the intended observed defect, not an unrelated RED. Exact restoration gives exit 0 with every detail passing and pre-commit recovered.
3. **Real canonical-row deletion:** existing seed_journal removes the known pre-commit row from the actual canonical inventory, leaving repaired source intact. Exit 1; only inventory_fresh fails; current Git metadata still returns pre-commit and the comparator identifies the missing canonical row at line 178. Exact restoration returns exit 0 with every detail passing.

The complete captured sequence is **0 → 1 → 0 → 1 → 0**, with empty stderr throughout. Both control records show equal before/after SHA256, full st_mode and nanosecond mtime. I independently compared current live files to those after snapshots; all fields match exactly. The driver checks outstanding(include_live=True) before and after control windows, and the current journal directory has no JSON entries. Persistent unlocked `.lock` files are not outstanding transactions. Existing seeded_mutation restores in `finally`, including assertion/subprocess exceptions; no new injected-exception run is claimed. No private Git hook bodies are opened, changed, executed or hashed by this driver.

## Current retained tests

The supplied `/tmp/l1-g4-original-focused-r2.xml` records **112 tests, zero failures, zero errors and zero skipped**, including all **57 inventory cases**. Exact `(classname, testname)` identities and order equal the original r1 selection, which had 111 passed plus one expected stale-inventory failure. Thus the baseline checkpoint resolved that original assertion without dropping cases or weakening it. This is supplied current test evidence, not a reviewer-run test suite or full-tree qualification.

## Evidence precision and remaining scope

The artifact retains argv, UTC start times, complete stdout/stderr text, return codes, origins and actual targeted deltas. `subprocess.run(text=True)` means these are decoded text channel captures, not independently retained original OS pipe bytes. Separate seeded-state SHA256 values and child environment snapshots were not contemporaneously serialized; the pinned deterministic mutator/empty-cache environment and observed targeted failures support source attribution. Do not label those absent fields as captured. These limits do not undermine the bounded demonstrated catalog/comparator controls and do not require another seed run for this inventory verdict.

D1–D4 source acceptance remains unchanged: anchored independent admin identity, retained supported config precedence, foreign-selector refusal, metadata-only privacy, known-empty/refusal distinction, worktree/common-catalog behavior and all other-family conservation remain covered by frozen reviewed source and current retained inventory tests. The reviewed D5 corrected-baseline prerequisite and both real-source/artifact controls are now satisfied for this exact inventory checkpoint.

Current G4 producer/declaration controls, full graph/native/runtime qualification, current registration/affected architecture gates, broader delivery profile and normal protected delivery/closure remain separate ROOT-owned requirements. The focused tests do not prove numerical accuracy, physical correctness, hook activation or scientific/publication acceptance. Original dcb receipts remain historical bounded evidence.

## Final continuity

Before verdict, the new packet remained byte-identical (SHA256 `2df9be700bdc10fd41b1cc6609ec5484642078a3be02be4ca0ac566524d98d49`). HEAD, semantic index hash, NUL-delimited status hash, all three owned files, all 22 changed/untracked file hashes, every authority/reference, roadmap, frozen primary notebook, all 21 donor postimages and all seven science files matched. No unexpected source or authority drift was observed.

Evidence SHA256: `76b6fed2cc383958ead8c9f886676241e70bf5a0c314a9f1bb4321907e2f0557`.
Driver SHA256: `0fa3fda277a23bca2148bfd0ccac31394fde4961d5116092a4cd905b4758350e`.
Current XML SHA256: `ef43e6fdc9d8dee431a6f42a0e64c8b08f55f5126dfa13c4d414d7dd288c12af`.

Reviewer actions were read-only inspection of source, recorded evidence, XML and metadata, plus writing these two `/tmp` reports. No test/project execution, new seeds, repository/notebook/Git mutation, native preparation, controller operation, build, canonical writer or private-hook body access occurred.
