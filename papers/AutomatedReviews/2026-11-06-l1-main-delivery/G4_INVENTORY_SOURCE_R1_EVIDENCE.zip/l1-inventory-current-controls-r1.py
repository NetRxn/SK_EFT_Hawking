from pathlib import Path
import sys, os, json, hashlib, subprocess, tempfile, datetime
root=Path.cwd().resolve(); sys.path.insert(0,str(root/'scripts'))
from seed_journal import seeded_mutation, outstanding
assert not outstanding(include_live=True), 'Another seed is live or unrepaired'
py=sys.executable
child='''from pathlib import Path
import sys,json
root=Path.cwd().resolve();sys.path.insert(0,str(root/'scripts'))
import validate
import architecture_inventory as inv
from validation.checks.freshness import check_architecture_inventory_fresh
r=check_architecture_inventory_fresh()
print(json.dumps({'passed':r.passed,'measured':r.measured,'details':[{'name':d.name,'passed':d.passed,'message':d.message} for d in r.details],'git_rows':[x for x in inv.hooks() if x['kind']=='git'],'origins':{'validate':validate.__file__,'inventory':inv.__file__}}))
sys.exit(0 if r.passed else 1)
'''
def snapshot(p):
 s=p.stat();return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':s.st_mode,'mtime_ns':s.st_mtime_ns}
def run(label):
 with tempfile.TemporaryDirectory(prefix='l1-inventory-fresh-bytecode-') as cache:
  env=dict(os.environ,PYTHONPYCACHEPREFIX=cache,PYTHONDONTWRITEBYTECODE='1')
  t=datetime.datetime.now(datetime.timezone.utc).isoformat()
  p=subprocess.run([py,'-B','-c',child],cwd=root,env=env,text=True,capture_output=True,timeout=60)
  row={'label':label,'time_utc':t,'argv':[py,'-B','-c',child],'rc':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
  results.append(row); print(label,p.returncode,flush=True)
  return p.returncode,json.loads(p.stdout)
results=[]; evidence={'root':str(root),'controls':results,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
out=Path('/tmp/l1-inventory-current-controls-r1.json')
try:
 rc,b=run('baseline'); assert rc==0 and b['measured']
 assert any(x['event']=='pre-commit' for x in b['git_rows'])
 source=root/'scripts/architecture_inventory.py'; doc=root/'docs/architecture/SURFACE_INVENTORY.md'
 assert not (root/'.git/hooks').exists()
 assert snapshot(doc)['sha256']=='7ac84ea95e4a1e78fc5845f0fbb2b9b7b6f65f554a94462fbc236bd706868b7a'
 for name,path,mutator in [
 ('physical_dotgit_hook_regression',source,lambda s:s.replace('directory = _git_hook_directory()','directory = PROJECT_ROOT / ".git" / "hooks"')),
 ('canonical_known_row_deleted',doc,lambda s:s.replace('| git | `pre-commit` | `-` | `git-path:hooks/pre-commit` |\n',''))]:
  before=snapshot(path)
  with seeded_mutation(path,mutator,reason='L1 existing inventory production control: '+name):
   rc,r=run(name+'_seeded');assert rc==1
   assert any(not x['passed'] for x in r['details'])
   if name=='physical_dotgit_hook_regression':assert not r['git_rows']
  after=snapshot(path);assert before==after,(before,after)
  rc,r=run(name+'_restored');assert rc==0
  assert not outstanding(include_live=True)
  evidence[name]={'before':before,'after':after,'exact_bytes_full_mode_nsmtime_restored':True}
 evidence['journal_empty']=not outstanding(include_live=True);evidence['accepted_observed_sequence']=[x['rc'] for x in results]
finally:
 out.write_text(json.dumps(evidence,indent=2)+'\n')
