# Existing native validation route — read-only review

Verdict: no existing independent exact-candidate native/full-graph route was found in the inspected source. Do not retarget the primary, run a sidecar controller, copy caches, forge epochs, or treat the nonnative guard as certification. Native/full-graph acceptance remains owed.

## Bound source and packet

Candidate read HEAD: `4737b36dcae1fb556449d7b816f087e0f5f4f885`, branch `codex/publication-l1-main-delivery-20261106`, with the packet's 21 G4/inventory file postimages. Primary read HEAD: `4fca5970f4f4cb0b408ea33243076c72058f6e56`, branch `codex/publication-primary-custody-20261105`. Final packet check: both assigned source files, every referenced authority/notebook/roadmap/evidence hash, HEAD, and all 21 changed postimages match. No runtime, test, build, status, help, lease, network, cache, Git or repository source mutation performed. Only these requested /tmp reports were written. This review establishes no live capacity or process/session termination.

## Existing route and why it cannot certify this candidate now

All candidate pointers below are relative to the assigned checkout at the bound HEAD. Primary pointers refer to the canonical primary path in the handoff packet at bound `4fca5970`.

* ADR-008 `docs/adrs/ADR-008-shared-lean-slot-control-plane.md:174` assigns authoritative build/extraction/validation and lifecycle to the primary non-worktree orchestrator. Candidate operator guide `:114` requires controller commands from primary, not a linked checkout.
* Candidate `scripts/lean_slots/controller.py:361-400` fingerprints the full commit SHA plus pinned inputs; `:402-415` requires exact fingerprint equality. A custody epoch cannot match another commit merely because Lean files or dependency pins match.
* Candidate controller `:417-449` builds configured primary only, requires a clean committed primary, invokes inventory build command, and publishes its fingerprint. `config/lean-slots.public.json:59-65` defines that command as `lake build SKEFTHawking.ExtractDeps`.
* Candidate controller `:488-510` resolves acquired base again and requires that matching epoch before preparation. `:788-793` requires literal primary branch name equal lease `base_ref` at absorption; a SHA is not the branch name.
* Primary operator guide `:377-383` explicitly documents actual primary branch plus matching epoch, no retarget verb, and preserving work rather than spoofing primary/lease. `:481-530`, “Guarded source delivery before shared native admission,” supplies the existing ordered route: independent whole review and scoped/broader checks; protected Git checkpoint after complete prerequisites/ancestry; lease/owner/dependency/capacity/request reconciliation; clean canonical-primary `slotctl build`; admitted loaded-code/drain controls; acquire with actual primary branch, prepare, native work, ordinary release or ready/absorb, reconnect and paired/session/capacity controls. Step 2 at `:499-504` expressly forbids moving primary merely to ease transport and requires missing prerequisites to use the existing reviewed dependency/integration process.

Thus neither `slotctl build` on today's custody primary nor acquiring main/HEAD by SHA proves the main publication candidate. The patch is uncommitted, so even its present base HEAD is not its exact complete candidate identity.

## Hosted CI search

`git ls-tree -r --name-only <ref> .github` at candidate HEAD, primary `4fca5970`, and local `main` returned only `.github/dependabot.yml`. There is no tracked `.github/workflows` directory, dispatch trigger, preparation job, exact-head candidate workflow, or native/full-graph job to invoke in these source snapshots. `.github/dependabot.yml:1-18` schedules dependency PRs and distinguishes automatic security alerts; neither is native validation.

`tests/test_ci_mode.py:3-32` explicitly explains why `--ci` is a command mode rather than a workflow and why naive validate+pytest Actions loses meaningful freshness/toolchain measurement. `tests/test_ci_mode.py:171-188` tests the real measured-check floor through the real registry; a normal default run excludes this slow test. `pyproject.toml:112-125` defines both repository/plugin testpaths and excludes slow/e2e by default. No remote query was made; externally managed or organization-level workflows/checks remain UNKNOWN, not ruled out by local source.

The existing full profile is `scripts/verify_scope.py:220-262` (`--merge-gate`): full bare `pytest -m '' -q`; `validate.py --ci --no-memo` with substrate-clean expected-output handling; the four CI_SKIP checks explicitly; `lake build SKEFTHawking.ExtractDeps`. `:298-336` captures tree state and checks reader-induced dirtiness. This is an actual local certification profile, not hosted capacity, not an ADR-008 exception, not an authoritative epoch publisher, and not permission to run native commands in this assigned linked worktree. It needs appropriate environment/dependencies and ROOT admission. Publication/readiness remains separately gated.

## Source and receipt limits

Primary contains materially newer lifecycle code: `controller.py` +165/-14, `state.py` +934/-38, `supervisor.py` +1828/-267, `proxy.py` +28/-6, `cli.py` +26/-3 relative to candidate HEAD. Primary adds fail-closed observations, reserved-slot accounting, stop-only recovery authority checks and lease-transition fences; status/doctor account for incomplete capacity. Its `controller.py:370,409,424,495,898,924-928` retains the same full-commit fingerprint / matching epoch / primary-only build / branch-equality rules. Candidate's old guide restart instructions must not supersede primary's newer ownership and drained reload requirements. Fresh primary CLI source does not prove persistent proxies loaded it (primary guide `:483-487`).

Retained `/tmp/l1-source-docs-wt1-native-baseline-20261105.json` and `/tmp/l1-source-docs-wt1-result-20261105.json` record scoped GravitationalWaves diagnostics/core-three axiom checks at a different source and explicitly disclaim integration/publication completion. They are evidence that the ordinary leased route has been used, not reusable full-graph acceptance for this candidate.

Expanded receipt `/tmp/l1-g4-nonnative-expanded-r1.json` reports exit 1. Its XML records four production-reader failures through `scripts/extract_lean_deps.py:148-161` trying Physlib GitHub resolution. `tests/test_build_graph.py:4-9` documents native refresh when cached dependency hashes are stale. No new run was attempted. Guards which prohibit external calls establish only the guarded source scope; they cannot replace the full graph/native floor.

## ROOT decision / commands, conditional only

Next safe step is existing protected dependency/integration reconciliation of the exact reviewed main candidate with the canonical primary's custody prerequisites and current authority. Preserve both lineages and all peer work. If that existing integration cannot presently be admitted, retain an explicit pending native gate and obtain the owner decision about delivery order/deferred acceptance. Do not infer an automatic primary checkout switch from this report. There is no existing source-defined hosted job to select instead.

After actual canonical-source, ownership, request drain, runtime and epoch prerequisites are admitted by ROOT, the documented commands are:

```text
# In canonical primary, clean and committed at its admitted actual source:
uv run python scripts/slotctl.py build
# Only if a leased native task is required and an existing number is actually eligible:
uv run python scripts/slotctl.py acquire --slot <N> --client codex --base-ref <actual-primary-branch>
uv run python scripts/slotctl.py prepare --slot <N>
# Matching worker native diagnostics; ordinary no-change release or ready/absorb as appropriate.
# Full project certification, under ROOT's native admission and correct checkout/environment:
uv run python scripts/verify_scope.py --merge-gate
```

These are conditional existing operations, not commands executed by this reviewer or authorization for a transport-driven primary move. They only qualify the exact source actually admitted; a custody-only success cannot certify the publication candidate.
