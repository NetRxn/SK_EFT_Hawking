from pathlib import Path
import os,sys,subprocess,json,datetime,hashlib
primary=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking')
candidate=Path('/Users/johnroehm/.codex/worktrees/l1-main-delivery/SK_EFT_Hawking')
sys.path.insert(0,str(primary/'scripts'))
from lean_slots.state import Inventory,directory_lock
assert Path.cwd()==primary
head=subprocess.check_output(['git','-C',str(candidate),'rev-parse','HEAD'],text=True).strip()
assert head=='0e2894344b35e1fe45bc6d9602b4e388f7c56a65'
assert not subprocess.check_output(['git','-C',str(candidate),'status','--porcelain'],text=True)
inv=Inventory.load();assert inv.repo_root.resolve()==primary.resolve()
assert not (candidate/'lean/.lake').is_symlink()
assert (candidate/'lean/.lake').resolve() != (primary/'lean/.lake').resolve()
assert all(p.resolve().is_relative_to(candidate/'lean/.lake') for p in (candidate/'lean/.lake/packages').iterdir())
env=dict(os.environ,UV_PROJECT_ENVIRONMENT=str(primary/'.venv'),UV_NO_SYNC='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1')
prefix=Path('/tmp/l1-complex-main-native-r1')
assert not prefix.with_suffix('.invocation.json').exists()
receipt={'candidate':head,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':['lake','build','SKEFTHawking.ExtractDeps'],'scope':'Actual main-based candidate standalone native library and ExtractDeps build; not full merge or publication acceptance','pins':{p:hashlib.sha256((candidate/p).read_bytes()).hexdigest() for p in ['lean/SKEFTHawking/ADW/GaussianAuxiliaryComplex.lean','lean/SKEFTHawking/FKLW/GenericSUdSkLengthExponent.lean','lean/SKEFTHawking.lean','lean/lean-toolchain','lean/lake-manifest.json']}}
with directory_lock(inv.state_root/'locks/authoritative-build.lock',purpose='ROOT actual main full complex auxiliary native qualification'):
 lines=subprocess.check_output(['ps','-axo','pid=,ppid=,ucomm=,args='],text=True).splitlines()
 competing=[]
 for line in lines:
  a=line.strip().split(None,3)
  if len(a)!=4 or int(a[0])==os.getpid():continue
  name=a[2].lower();args=a[3]
  if name in {'lean','lake','leanc'} or (name.startswith('python') and ('verify_scope.py' in args or 'extract_lean_deps.py' in args or 'slotctl.py build' in args)):competing.append(line.strip())
 assert not competing,competing
 prefix.with_suffix('.invocation.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print('STARTED '+head,flush=True)
 with prefix.with_suffix('.stdout').open('w') as out,prefix.with_suffix('.stderr').open('w') as err:r=subprocess.run(receipt['argv'],cwd=candidate/'lean',env=env,stdout=out,stderr=err)
 receipt.update(returncode=r.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head_after=subprocess.check_output(['git','-C',str(candidate),'rev-parse','HEAD'],text=True).strip(),status_after=subprocess.check_output(['git','-C',str(candidate),'status','--porcelain'],text=True))
 prefix.with_suffix('.result.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print('TERMINAL returncode='+str(r.returncode),flush=True)
sys.exit(r.returncode)
