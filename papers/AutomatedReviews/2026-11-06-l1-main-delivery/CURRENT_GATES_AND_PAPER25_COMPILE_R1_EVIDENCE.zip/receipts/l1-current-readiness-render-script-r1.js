
(() => {
const root=document.getElementById('publication-readiness-comparison');
const data=JSON.parse(root.querySelector('#pr-data').textContent);
const names=['Citation coverage','Cross-paper consistency','Parameter provenance','Computation correctness','Proof substance','Assumption disclosure','Claim grounding','Run evidence','Numerical freshness','Novelty / first claims','Fix propagation'];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const stamp=t=>String(t||'').slice(0,16).replace('T',' ')+' UTC';
let mode='candidate',selected='L1',gate=null;
const old=window.openai?.widgetState?.privateContent;
if(old?.readinessVersion===4){mode=['then','now','candidate'].includes(old.mode)?old.mode:'candidate';if(data.rows.some(r=>r.code===old.selected))selected=old.selected;}
root.querySelector('#pr-date').textContent='Gate snapshot '+stamp(data.candidate_measurement.ended)+' · measured '+data.candidate_measurement.head.slice(0,8)+' · latest delivery '+data.latest_source_head.slice(0,8)+' · main '+data.live_main_checkpoint.sha.slice(0,8)+' · baseline Oct 16';
root.querySelector('#pr-head').insertAdjacentHTML('beforeend',names.map((n,i)=>'<th scope="col" class="text-center" data-tooltip="G'+(i+1)+' · '+esc(n)+'">G'+(i+1)+'</th>').join('')+'<th scope="col">Recorded repair progress</th>');
root.querySelector('#pr-criteria').innerHTML=names.map((n,i)=>'<div><strong>G'+(i+1)+'</strong> '+esc(n)+'</div>').join('');
const cells=r=>mode==='candidate'?r.candidate_gates:mode==='now'?r.current_gates:r.gates;
const viewLabel=()=>mode==='candidate'?'Candidate gates · '+stamp(data.candidate_measurement.ended):mode==='now'?'Historical primary · '+stamp(data.observed_at):'Historical baseline · Oct 16';
function save(){if(window.openai?.setWidgetState)window.openai.setWidgetState({modelContent:{bundle:selected,view:mode},privateContent:{readinessVersion:4,selected,mode}}).catch(()=>{});}
function detail(){
 const r=data.rows.find(x=>x.code===selected)||data.rows[0];
 const metadata=mode==='candidate'?r.candidate_metadata:mode==='then'?r.then_metadata:r.current_metadata;
 const stages=['stage9_status','stage10_status','stage13_status'].map((k,i)=>'S'+[9,10,13][i]+': '+(metadata?.[k]||'unrecorded')).join(' · ');
 let extra='';
 if(gate!==null){const g=cells(r)[gate];extra='<div class="section"><strong>G'+(gate+1)+' · '+esc(names[gate])+'</strong><div>'+esc(viewLabel())+': '+esc(g.state)+(g.quality_caveat?' · coverage caveat':'')+'</div><div>'+esc(g.detail)+'</div>'+(g.evidence?.length?'<div class="text-small">'+g.evidence.map(esc).join(' · ')+'</div>':'')+'<div class="text-small">Mechanical coverage and scientific acceptance are separate.</div></div>';}
 root.querySelector('#pr-detail').innerHTML='<h3>'+esc(r.code+' · '+r.title)+'</h3><div><strong>Publication acceptance:</strong> not established</div><div class="section"><strong>'+esc(r.progress_label)+'</strong><div>'+esc(r.progress_detail)+'</div></div><div class="section"><strong>Still owed:</strong> '+esc(r.remaining)+'</div><div class="section text-small"><strong>Recorded stage metadata:</strong> '+esc(stages)+' · '+esc(viewLabel())+'</div>'+extra+(r.evidence.length?'<div class="section text-small"><strong>Receipt:</strong> '+esc(r.evidence[0].path.split('/').slice(-2).join('/'))+' · SHA256 '+esc(r.evidence[0].sha256.slice(0,16))+'</div>':'');
}
function render(){
 root.querySelector('#pr-now').setAttribute('aria-pressed',String(mode==='now'));root.querySelector('#pr-then').setAttribute('aria-pressed',String(mode==='then'));root.querySelector('#pr-candidate').setAttribute('aria-pressed',String(mode==='candidate'));
 const counts=mode==='candidate'?data.candidate_measurement.gate_counts:mode==='now'?data.current_gate_counts:data.baseline_gate_counts;
 const differences=data.rows.reduce((total,r)=>total+cells(r).filter((g,i)=>g.state!==r.gates[i].state).length,0);
 root.querySelector('#pr-summary').innerHTML='<span><strong>21</strong> bundles</span><span><strong>0</strong> newly accepted</span><span><strong>231</strong> gates evaluated</span><span><strong>'+differences+' / 231</strong> state differences vs Oct 16</span>';
 root.querySelector('#pr-mode').textContent=viewLabel()+': '+counts.passed+' pass, '+counts.blocked+' blocked, '+counts.open+' open, '+counts['needs-recheck']+' recheck. State differences include coverage changes; G4 is static coverage and G6 carries vacuity caveats. Candidate versus AF255: L1 G9 recheck to pass. Current default suite RED: 7084 pass / 27 fail / 11 skip / 92 deselected. Progress receipts are branch-specific. Unmerged; publication acceptance remains open.';
 root.querySelector('#pr-rows').innerHTML=data.rows.map(r=>'<tr class="'+(r.code===selected?'selected':'')+'"><th scope="row"><button type="button" class="btn btn-ghost" data-bundle="'+r.code+'" aria-pressed="'+(r.code===selected)+'">'+r.code+'</button></th>'+cells(r).map((g,i)=>{const s=g.state==='passed'?'passed':g.state==='blocked'?'blocked':g.state==='open'?'unknown':'pending';const mark=g.state==='passed'?(g.quality_caveat?'◌':'✓'):g.state==='blocked'?'×':g.state==='open'?'?':'↻';return '<td class="text-center"><button type="button" class="btn btn-ghost" data-gate="'+i+'" data-code="'+r.code+'" aria-label="'+r.code+' G'+(i+1)+' '+esc(names[i])+' '+esc(g.state)+'" data-tooltip="'+esc(viewLabel())+': '+esc(g.state)+(g.quality_caveat?' · coverage caveat':'')+'"><span class="mark '+s+'">'+mark+'</span></button></td>';}).join('')+'<td>'+esc(r.overview_progress||r.progress_label)+'</td></tr>').join('');
 root.querySelectorAll('[data-bundle]').forEach(b=>b.addEventListener('click',()=>{selected=b.dataset.bundle;gate=null;render();save();}));root.querySelectorAll('[data-gate]').forEach(b=>b.addEventListener('click',()=>{selected=b.dataset.code;gate=Number(b.dataset.gate);render();save();}));detail();
}
root.querySelector('#pr-now').addEventListener('click',()=>{mode='now';render();save();});root.querySelector('#pr-then').addEventListener('click',()=>{mode='then';render();save();});root.querySelector('#pr-candidate').addEventListener('click',()=>{mode='candidate';render();save();});
window.addEventListener('openai:set_globals',e=>{const s=e.detail?.globals?.widgetState?.privateContent;if(s?.readinessVersion===4){mode=['then','now','candidate'].includes(s.mode)?s.mode:'candidate';if(data.rows.some(r=>r.code===s.selected))selected=s.selected;render();}});
render();
})();
