# Independent Hermite integration source composition review R1
Verdict: **ACCEPT_SOURCE_COMPOSITION_ONLY**. No actionable defect in the proposed selected source composition. Neither patch has been applied. No native or publication acceptance follows.
## Frozen custody
Initial and final checks of the SAME assigned packet returned fresh=true, changed=[], exit 0. No refresh was made. Actual clean heads independently read: main `59ea56558b373f288bd96a8f46ca1f42777b9732`; primary `f597f91e12704b30e8b31ace0f38bd32f2e6aff3`; wt1 author `bfb8ca2576ccdfb25ad2ebf3bebc1a2bfb7d9fc0`. Author parent is exactly primary; the author commit changes only the new module. Main and primary source history are not asserted equivalent.
Read relevant governing AGENTS/CLAUDE/pipeline/ADR-008/ADR-017/continuity contracts and frozen notebook/roadmap context; read the complete module, complete IBP dependency, full proposal object and both patches. The entire aggregate postimages were validated bytewise through strict reconstruction rather than relying on diff excerpts.
## Independent full hash evidence
- main_patch_sha256: `503e9bfb139a34cabb6df4f72bf99977cb4ff3913604ac25b1bc7fc6022f5e4e`
- primary_patch_sha256: `dcf6d63fed8c529fbeb4ff6a7118bcb894fbb3bd871f6d5f8360efb9153fcf41`
- proposal_json_sha256: `72cfeade9c56e201783a36818d3e364a0e33f34f7677a0ed8bce31226acda04f`
- accepted_kernel_md_sha256: `8d81d85292adc17548c13e6392fa08f483b49cd8c73231f6c9e8e3856e499e83`
- accepted_kernel_json_sha256: `b5826840dfc350c5b10bbce96b6dbe4e8c8ae8526f66eab0f8dd1f3c5e2bfd5b`
- main_index_sha256: `cfe643cf7fff973259021bf873ab85cea76fba1a4b3ec75c5ad8e519e3e43ac4`

Exact postimages:
- main/lean/SKEFTHawking/ADW/GaussianPolynomialHermite.lean: `2d4f1dee5432252a28aca49038f870ecdb98ea06122eafa1cfa121d1f27c5893`, 7011 bytes, 135 lines.
- main/lean/SKEFTHawking.lean: `b444de34752554a1d7460052a163a78d0e6cf4116844e68678f5a2a78492237e`, 367779 bytes, 5277 lines.
- primary_slot/lean/SKEFTHawking.lean: `ec3d0ada998443d37b4ab3de20d3ac0a80cd62af09f7034c729dad88fce2d0bf`, 374151 bytes, 5386 lines.

Preimages conserved after removing only `import SKEFTHawking.ADW.GaussianPolynomialHermite` and its newline:
- main: `8b84989b46fe0c57cef25596fde5cfee91d0e6711587c07d7bc948aa0d01e46b`. Every prior byte remains in original order.
- primary: `08e8b0d3746c25f6511b6f5c4957731e617a566146e7c5c8e2f95f24c5a77d5e`. Every prior byte remains in original order.
- wt1: `08e8b0d3746c25f6511b6f5c4957731e617a566146e7c5c8e2f95f24c5a77d5e`. Every prior byte remains in original order.

Actual equal pins in main, primary and wt1:
- lean/lean-toolchain: `2773c517aa90b66ea8a2c52bddddf84393157797f8341be0df45294fff7fd32e`.
- lean/lake-manifest.json: `6620cd482acd9c924acd5715c07cb59f8cb840d605ad211c31c1666839516464`.
- lean/SKEFTHawking/ADW/GaussianPolynomialIBP.lean: `ffb651c528b22d256b05e8a5ea5118ff3d6fb5bf917d00cd9544b25daccfb396`.
- Actual Hermite Basic source in all three contexts: `ee3c048c290f996b71e71894ae498822e46e96622df20da1ab5e73aa8638968f`.
- Toolchain leanprover/lean4:v4.32.0; Mathlib manifest rev/inputRev `81a5d257c8e410db227a6665ed08f64fea08e997`.

## Composition and hypotheses
- Read the full proposed 135-line module and full existing IBP module. No new project axiom, tracked-hypothesis binder, placeholder, sorry, native_decide, or heartbeat override.
- Actual gaussianReal 0 1 is the standard variance-one Gaussian; integrability is proved for real polynomials and their products. Arbitrary n/p carrying identity has no degree bound or assumed Stein identity.
- Degree hypotheses apply to vanishing/coefficient corollaries only; mixed monomial identity is a reduction to an actual moment. All-order orthogonality/norm are included. No exponential, arbitrary sigma, multivariate, complex W, or physical B3 claim.
- Project import graph is root -> new Hermite -> existing IBP -> Mathlib. IBP has no project imports; no cycle is introduced. Both actual ExtractDeps entrypoints import root, so proposed aggregate additions provide the required future reachability.
- All old aggregate bytes, import order, and comments are exactly conserved after removing only the single new leading import. Every other main file, including paper/metadata/gate/history source and old Lean source, is outside the patch. This is source conservation, not a claim that compiled exports or full-tree behavior have already been requalified.
- No main compiled-index name collision across all 16 new fully qualified exports; additional scan of all main Lean source declaration names also found none.
- Selected source composition only: main, primary, and author histories differ. No whole-frontier merge/cherry-pick or dependency/configuration transplant is endorsed.

The module is independently byte-identical to `git show bfb8ca2576ccdfb25ad2ebf3bebc1a2bfb7d9fc0:lean/SKEFTHawking/ADW/GaussianPolynomialHermite.lean` and its current author checkout: SHA256 `2d4f1dee5432252a28aca49038f870ecdb98ea06122eafa1cfa121d1f27c5893`, 135 lines, 7011 UTF-8 bytes, 15 theorems plus one abbrev. No source changes or unrelated primary ancestry are necessary for these dependencies.

Accepted kernel evidence is retained at the exact report hashes above. Its complete companion JSON parses and contains 19 actual verify calls (16 new exports plus 3 IBP exports), nine goal calls, five hover calls and two diagnostics. Independently inspected all retained verify structured outputs: each has exactly propext/Classical.choice/Quot.sound and no warnings. This review did not rerun or re-prove that mathematics and does not relabel the earlier calls as current native build evidence.

Both actual ExtractDeps files import SKEFTHawking. Main ExtractDeps hash `3fe6a135d105a01dc65a74fb2311285e991b757c22c35c7c7639713237e4791e`; primary hash `4aeec59d8fb69588d640e0e863a48af93260253f606f281d343e9ecf110f31db`. The two aggregate patches add the missing reachability edge needed for future extraction. Successful future extraction remains unmeasured.

## ROOT acceptance and limits
- Commit the aggregate-only patch in the author slot where the exact module already exists, then use existing ready/absorb lifecycle under current independent ownership/admission. Do not build primary with the new aggregate import before the new module is transported there.
- Authoritative native root build must actually include the newly imported module and ExtractDeps, on the accepted exact candidate, with existing lifecycle/build owners. File-level kernel evidence is not a native epoch/build/absorption certificate.
- Integrate the exact reviewed two-file selected source composition separately on frozen main. Qualify actual main candidate with required Lean/dependency, freshness/count/document sync, appropriate broader tests/validation and independent gates before claiming main/publication acceptance.
- Use existing closure writer with actual declared Verify evidence for any closure; this review records no closure and changes no scientific or readiness state.
- Full auxiliary construction still owes arbitrary positive sigma scaling, finite-dimensional products/Fubini/multi-index assembly, complex signed W, formal exponential/truncation/Grassmann evaluation and source/coframe/Berezin/link/response assembly. Physical B3 and all inherited physical/publication/human gates remain open.

## Operations and preservation

Read-only file/JSON/source/history/hash inspection and exact continuity checks; Python reconstruction only in memory. Wrote only the two assigned /tmp review artifacts. No pytest, Lean/LSP/MCP proof/build/extraction/controller/process/runtime/Git mutation or cache/dependency changes. Full JSON evidence is in the companion review JSON. The supplied packet and notebook stayed unchanged. No finding closure, source integration, native full-tree qualification, complete auxiliary identity, physical B3 or publication readiness is certified.
