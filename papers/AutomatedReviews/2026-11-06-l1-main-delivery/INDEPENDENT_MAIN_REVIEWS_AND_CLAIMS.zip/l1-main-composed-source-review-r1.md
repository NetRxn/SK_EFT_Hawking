# Independent exact-composition source review R1

Verdict: ACCEPT the composed L1 source corrections and assigned D3/Paper25 consumer, numerical/figure-producer, metadata, scanner and Lean-comment repairs at source scope. No newly introduced blocking discrepancy found. This is not whole-D3 scientific acceptance, canonical finding closure, native certification, main merge qualification, physical acceptance or human approval.

Reviewed actual checkout HEAD 521f574e91bc0bdf6cfea4bff160f0697e6eb1c4 plus the frozen dirty/untracked composition against exact main ce194cdc4bf939b108c17edc9530a7f0a14565f9. Donor1805e3358 and archived donor reviews were provenance only. First continuity check of l1-main-render-source-521f-r1.json was fresh. Read governing CLAUDE/pipeline/continuity, notebook, Phase6a roadmap, existing priority/disposition queue, claims-reviewer role, paper-authoring skill and prohibited-pattern reference. Reviewed actual complete tracked diff, actual L1 manuscript, assigned D3 consumer changes, Paper25, proof bodies/imports, scientific tests and registry, current scanner/ADR/spec/plan, retained receipts. No candidate edits, test execution, seeding, compilation, DB/graph/native/slot/controller/dependency/Git mutation.

## Substantive source acceptance

The manuscripts now distinguish the assumed scalar law from a derived physical propagating mode. For chi>=0 and fixed tau=3e-15, the real compatible interval [(1-tau)^2,(1+tau)^2] is retained, including its nonzero width4tau, anchor1, nesting inside adopted[0.1,10], endpoint violations and exact c!=0 relative-deviation bridge. D3/Paper25 correctly retain center1+tau^2 and half-width2tau. No replacement by a singleton or empty interval. Endpoint exclusion is not represented as microscopic impossibility or exclusion of an entire vestigial branch. The distinction between width ratio and probability under an explicitly specified prior survives.

The scalar conjunction audit correctly states that P2 implies P3' and, on the stated nonnegative carrier, P1. The quarter witness establishes P1 does not imply P3', while failing P2 as well; all four counterexamples and the positive unity witness remain. The corrected appendix and consumer prose retain stronger existing mathematics rather than discarding inconvenient witnesses.

The real-product dispersion algebra remains conditional, separates correction-only from total-deviation bounds, and discloses unmatched frequency, units and physical transport. The reverse triangle exclusion |delta0|>tau+B and permitted near-boundary compensation are mathematically valid; neither licenses a derived compensating microscopic correction. The Newton-coupling comparison remains conditional on the adopted Planck anchor and species conventions and does not identify either free response coefficient with its physical microscopic value.

D3 finite phase flags are now described as assigned classifier flags rather than derived matter trajectories or guaranteed physical EP restoration. The connected-metric issue is preserved. The unrelated D3 TQC bibliography transplant is absent; the small QEC prose punctuation rewrite preserves its substantive assertion.

## Actual implementation, tests and preservation

The canonical speed helper now takes sqrt(chi) directly, preserving tiny positive inputs that 1+(chi-1) destroyed. Stable deviation rationalization (chi-1)/(sqrt(chi)+1) avoids cancellation near unity and retains wider NumPy scalar precision until its float return. Negative inputs and nonfinite behavior are explicitly bounded; real physical domains in prose remain nonnegative. The inverse window validates finite nonnegative caps, clamps its lower preimage to0 for cap>=1, and distinguishes rounded endpoints from exact algebraic width. D3 uses4tau for its actual narrow-width producer rather than subtracting rounded near-unity endpoints. Independent Fraction/Decimal references, nextafter/wider scalar cases, negative/nonfinite controls, prior-sensitive interval checks and figure numeric-input checks provide meaningful regression coverage.

Read actual retained SOURCE_COMPOSITION_RECEIPTS.zip: original26FAIL/63PASS, repaired89PASS; current RENDER_AND_NAMESPACE_RECEIPTS.zip includes corrected124PASS terminal receipt (the initial nonexistent-test collection error is preserved, not substituted). Reviewer did not rerun these suites. Both ZIP CRCs pass; all three archived PDFs equal the actual files byte-for-byte. Compile receipts say5/66/5pages, zero errors/unresolved/dropped options and twelve unwaived D3 overflows. Actual render acceptance belongs to the independent render review.

Metadata comparison against main, parsed semantically: L1 changes only nine apex claims and compiled_pages; D3 only sixteen apex claims and compiled_pages. Names, declaration dates, human/stage/readiness and every other field are exact. D3's broad textual JSON diff is canonical Unicode serialization, not broad semantic replacement. New PAPER_DEPENDENCIES.L1 accurately declares the current computational inputs and limitations; the three parameter provenance locator corrections do not change old values/dates/human state.

Current scanner implementation matches accepted ADR018/spec/plan: it adds only identifier-valued first repository-relative components of nested Python paths from the same pruned walk. No imports executed, fake dependency, exception, skip relaxation, new validate registration or weakened scientific test. The new fixture rejects data/pruned roots; production test calls the actual declaration assertion before/during/after a journalled sentinel import, clears both caches, expects actual sentinel rejection, and checks byte/mtime restoration. Its cache fixtures restore REPO before final clear. The combined retained run exercises this test and residue suite. Independent read-only AST/source-walk census on this actual main composition adds only papers; only imported affected root is papers. Donor pilot added docs and papers because that donor preimage differed; this is not an implementation discrepancy. Existing stem/parent heuristic limitations remain outside ADR018's bounded repair.

## Lean source and stored registry

Independently lexed nested block comments and compared main with actual GravitationalWaves.lean: all49 non-block segments byte-identical, concatenated SHA256 2e84faa34934b06504b5a31ab71dde726b2236706c20bd315a6b02ac1622524d. Imports, declarations, types, proof tactics and inline non-block source are preserved. Actual source has32 theorem declarations, each present in lean_deps.json; stored registry dependencies have no project axioms and only Classical.choice/Quot.sound/propext core axioms. Read the actual proof bodies, not only names/docstrings: the fixed-tolerance squared inverse, endpoint inequalities, nesting, width, reference-speed bridge, bundle counterexamples and correction-only division proof support the corrected statements. Registry evidence is existing extraction, not a new native/build certificate.

## Actionable inherited residues and acceptance limits

1. Canonical HYPOTHESIS_REGISTRY entry src/core/constants.py:4060-4068 is unchanged inherited debt. It still identifies the scalar conjunction with a graviton DOF, attributes the luminal second-sound result to Volovik2024, and labels the microscopic bridge out of scope/a different theory. The actual corrected manuscripts and original open physical BUILD do not justify those registry statements. Reconcile this existing record through the owning finding/planner/writer process before claiming canonical hypothesis/publication consistency; do not treat metadata preservation here as ratification or silently relax the original construction requirement.
2. tests/test_gravitational_waves.py:478-480 retains inherited test name/docstring saying P3' is genuinely independent of P1. Its assertion only establishes P1 does not imply P3'. In fact P3' implies sqrt(chi)>1/2, hence chi>1/4 and P1; full two-way logical independence is false. Rename/reword this documentary residue if closing the aggregate independence correction. No assertion weakening is needed, and this residue does not invalidate the numerical acceptance above.

### Actionable finding R1.1 — MAJOR — Canonical hypothesis record misstates the physical content and source

- **Severity:** major
- **Lane:** `prose` (scientific attribution/interpretation; no proof or numerical implementation change)
- **Gate:** NarrativeGrounding
- **Location:** `src/core/constants.py:4061`, `:4064`, `:4065`, `:4068`, entry `HYPOTHESIS_REGISTRY[H_VestigialModeIsGraviton]`.
- **Observed:** The registry describes the scalar conjunction as representing a graviton-like DOF, sources the de Sitter second-sound result to Volovik2024, and labels the missing bridge out of scope/a different theory. Its publication-facing prose can propagate these claims into derived records.
- **Scientific distinction:** Satisfying positivity, the cap and the redundant sub-half clause is a scalar compatibility result, not construction of a physical state/tensor mode or microscopic speed law. The source is the separate2026 second-sound paper. The original microscopic BUILD remains an accepted objective; an unchanged registry does not authorize abandoning it.
- **Proposed narrow repair:** Correct only this entry's scientific statement/source/elimination-path/publication prose against actual sources and original owning roadmap. Explicitly retain the open physical construction requirement and distinguish the scalar predicate from it. Preserve key/status and unrelated acceptance/human metadata; use existing hypothesis rendering/writer/finding routes for any derived views. Do not relabel the missing construction as discharged or out of scope.
- **Acceptance/Verify intent:** Exact-entry before/after semantic comparison; read the actual predicate and2026 primary source; compare the complete owning physical BUILD; demonstrate no unrelated registry change. Run the existing tracked-hypothesis ledger/freshness gates if the owning process requires them, and independently review the rendered derived description. This reviewer has not mutated or run those gates. The defect is inherited but remains actionable and unwaived.

### Actionable finding R1.2 — MINOR — Scientific test description claims false logical independence

- **Severity:** minor
- **Lane:** `prose` (test documentation/name interpretation; assertion is correct)
- **Gate:** NarrativeGrounding
- **Location:** `tests/test_gravitational_waves.py:478-480`, `TestStrengtheningPass.test_p3prime_independent_of_p1`.
- **Observed:** Name/docstring claim genuine independence of P3' from P1, but the witness only proves P1 does not imply P3'.
- **Scientific distinction:** If P3' holds then `|sqrt(chi)-1|<1/2`, so `sqrt(chi)>1/2` and `chi>1/4`, hence P1. At chi1/4 P1 holds while P3' and P2 fail. The valid counterexample establishes one-direction nonimplication, not two-way logical independence.
- **Proposed narrow repair:** Rename the test to describe `P1 does not imply P3prime` and rewrite the docstring accordingly. Preserve every assertion and the quarter witness; do not alter the conjunction or weaken numerical coverage.
- **Acceptance/Verify intent:** Compare the actual assertion AST before/after (identical body apart from docstring), independently check the implication/nonimplication argument against the predicate, and use the existing focused GW suite as appropriate after the repair. The defect is inherited but remains actionable and unwaived.

The L1 title's implication that a physical natural range has been established, and the underlying response normalization deriving[0.1,10] as a result, remain original physical acceptance debt. Neither the adopted-window calculation nor the title can close it. Physical state, tensor/polarization/matter/light reference, actual microscopic dynamics and controlled transport/frequency/unit/error matching remain full-strength OPEN BUILD. Source qualification does not replace them.

ROOT still owes current canonical claims/audit/finding reconciliation through existing writers, actual derived-count freshness, independent actual-render disposition including D3 overflow debt, and existing full exact-candidate merge qualification with its genuine failures retained. No donor closure ledger or historical green state was copied. Preserve current native/controller authority and obtain appropriate native proof only through the established route; source equality is not that receipt. Final scientific readiness/main integration/human review remain separate.

## Exact custody

Tracked binary diff against ce194cdc4 SHA256: 5f5944e89e99258a8fcd09ede26cf0ede4de0019a8d957f58577355af6603290 (untracked docs/receipts additionally pinned by continuity packet).

Actual source SHA256:
- L1 tex29f926fef642a352ffb24b2d1fb0d851c1fb58d5c2a50ba7ffaf3083e3c1c5a2
- D3 tex32740b59d35187b869314f1c809890f1c695fb72d501afb15b4ea55a05e0aeec
- Paper25 tex760c21f1295b72cb3fd5bfc66adb09320ef9d5e65da0074215bdfa871675f2ff
- Lean eab4cd660adb486d6b057e8036d2d952bdea55e7ab7686e568cb79ae6a02285d
- scanner43e91d0d16fae8cc4b2d12d1015f10f467b589230d7554d838afbcb760441785
- canonical and all consumer PNG cd3c1de52d177dd19ef6fb49d79319484c66674329624a1e6dd80702c1474976

Only /tmp/l1-main-composed-source-review-r1.md and .json written by reviewer.
