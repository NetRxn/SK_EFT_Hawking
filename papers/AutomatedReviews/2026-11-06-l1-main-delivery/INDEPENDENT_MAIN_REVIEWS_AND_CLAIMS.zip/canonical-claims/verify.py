import hashlib,json,re,sys,subprocess
from pathlib import Path
R=Path.cwd();O=Path('/tmp/l1-main-canonical-claims-r1');sys.path.insert(0,str(R/'scripts'))
from sentence_state import compute_sentence_id,normalize_quote,validate_claims_review
p=json.loads((O/'claims_review.json').read_text());cov=json.loads((O/'coverage.json').read_text());t=(R/'papers/L1/paper_draft.tex').read_text();chars=list(t)
def mask(a,b):
 for i in range(a,b):
  if chars[i]!='\n':chars[i]=' '
for c in cov:mask(c['start'],c['end'])
mask(0,t.index('\\begin{abstract}')+len('\\begin{abstract}'));mask(t.index('\\begin{thebibliography}'),len(t))
for m in re.finditer(r'(?m)^\s*%.*$',t):mask(*m.span())
for m in re.finditer(r'\\(?:section|subsection|subsubsection|paragraph|label)\{[^{}]*\}|\\(?:maketitle|centering|appendix)|\\(?:begin|end)\{(?:abstract|figure|theorem|equation|aligned)\}(?:\[[^]]*\])?|\\includegraphics(?:\[[^]]*\])?\{[^{}]*\}|\\caption\{',t):mask(*m.span())
res=''.join(chars);uncovered=[{'line':i+1,'text':v} for i,v in enumerate(res.splitlines()) if v.strip().strip('{}')]
assert not uncovered,uncovered
assert len({s['id'] for s in p['sentences']})==151
assert all(c['normalized_actual_match'] for c in cov)
assert all(cov[i]['end']<=cov[i+1]['start'] for i in range(150))
assert not validate_claims_review(p)
pins=p['review_evidence']['source_hashes'];actual={k:hashlib.sha256((R/k).read_bytes()).hexdigest() if (R/k).is_file() else None for k in pins};assert actual==pins
schema=subprocess.run([sys.executable,'scripts/sentence_state.py','validate',str(O/'claims_review.json')],capture_output=True,text=True);assert schema.returncode==0
(O/'schema-validation.json').write_text(json.dumps({'command':schema.args,'returncode':schema.returncode,'stdout':schema.stdout,'stderr':schema.stderr},indent=2)+'\n')
r={'head':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'proposal_sha256':hashlib.sha256((O/'claims_review.json').read_bytes()).hexdigest(),'manuscript_sha256':pins['papers/L1/paper_draft.tex'],'actual_active_units':151,'ordered_nonoverlapping_unique_actual_bindings':True,'uncovered_body_lines':uncovered,'main_prior_records_preserved':len(p['review_evidence']['main_prior_catalog']['sentences']),'main_prior_followups_preserved':len(p['review_evidence']['main_prior_catalog']['non_blocking_followups']),'all_fresh_main_assessments':all(s['agent_run_id']==p['reviewer_run_id'] for s in p['sentences']),'donor_acceptance_transferred':False,'donor54candidates_preserved_historically':len(p['review_evidence']['donor151historical_catalog']['non_reproducing_prior_findings']),'automatic_closures':0,'original_obligations_open':[b['id'] for b in p['blocking_issues']],'schema_returncode':schema.returncode,'source_pins_unchanged':actual==pins,'main_prose_state_preimage':'absent; no donor state seeded','ingestion_performed':False,'required_ROOT_commands':['Existing canonical claims JSON writer to install independently accepted proposal after archive/preimage checks; retain main human/audit state.','python3 scripts/sentence_state.py validate papers/L1/claims_review.json','python3 scripts/sentence_state.py ingest_agent_run papers/L1/claims_review.json --dry-run','python3 scripts/sentence_state.py ingest_agent_run papers/L1/claims_review.json'],'summary':p['summary']}
(O/'readback.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
