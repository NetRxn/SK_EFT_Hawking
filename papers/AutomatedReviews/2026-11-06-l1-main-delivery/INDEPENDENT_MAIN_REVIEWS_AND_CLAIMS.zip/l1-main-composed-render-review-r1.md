# Actual main-composition reader/render review R1

Verdict: ACCEPT the scoped conditional-result prose, current GW figure, and changed consumer rendering; retain OPEN publication/scientific and D3 layout holds. This is not full-paper scientific acceptance, a full 66-page D3 editorial pass, stage-9 recording, canonical closure, main merge qualification or final human approval.

Reviewed current frozen HEAD 521f574e91bc0bdf6cfea4bff160f0697e6eb1c4 plus actual regenerated dirty composition. Initial continuity check fresh. Read the dispatch notebook, SCOPE, actual compile readback, CLAUDE/pipeline, figure-reviewer and prose-reviewer roles, authoring/prohibited-pattern instructions, PDF read-only skill, and current Phase6a physical-successor requirements. Only /tmp scratch files were written; no repository writes, tests, compiles, native/graph/controller/dependency or Git mutation.

## Actual visual coverage

Rendered actual current PDFs through Poppler at 1300px longest dimension, roughly118dpi for letter paper. Inspected every L1 and Paper25 page individually at readable full-page scale, including references; not only contact sheets. Surveyed all66 D3 pages via six contact sheets, then individually inspected D3 pages 1,7,9,14,19,20,21,22,23,24,26,27,28,29,30,32,40,43,44,48,52,53,54,55,57,60,61,62,63. This covers the abstract, complete changed vestigial section, section-V transition, the separate changed code-distance wording on p30, all changed concluding consumer passages, associated references and actual Fig1 on p63. Other D3 pages receive layout-survey coverage only, not a complete referee read. D3 unchanged figures2–4 were surveyed, not scientifically reaccepted.

Canonical PNG and all three consumer PNGs were independently opened visually and have identical SHA256. All actual PDFs byte-match their archived receipt members. L1=5pages; Paper25=5pages; D3=66pages. Compiler readback is0errors/0unresolved, with0/0/12 overflows respectively; this review did not rerun compilation.

## Figure and caption/source matching

PASS for rendering, scoped physics encoding, and caption match. The producer samples chi in[0.01,100], plots sqrt(chi)-1 against a logarithmic chi axis and linear vertical axis, highlights adopted[0.1,10], and uses log10 annotation coordinates. Actual endpoint arrows reach chi0.1 at about-0.684 and chi10 at about2.162, with2.3e14 and7.2e14 factors. The star lies at(1,0). All titles/legends state assumed/adopted rather than a derived microscopic response. Labels, serif type, legends, arrows and callouts remain readable in the two-column L1/Paper25 placements and the larger D3 placement; no clipped label or missing trace was observed.

The amber cap is intentionally unresolved, as all three captions disclose. The finite compatible interval has width4tau=1.2e-14, not the singleton represented by a resolvable star. L1/Paper25 explicitly explain the star as anchor; D3 explains unresolved admitted susceptibilities. Width ratio and prior dependence come from algebra rather than visual resolution. Plot and captions agree with actual producer/source: no false whole-range exclusion, physical-mode derivation or transport-band result is imported by the figure. The orange callout boxes partly cover the continuation of the blue curve, but endpoint arrows and trend remain clear; this is no repair finding.

## Reader assessment

L1 abstract leads with the conditional finite-interval result and defines chi,c,tau immediately. The introduction supplies motivation and source-emission assumptions, formal section supplies the interval and endpoints, discussion separates possible mechanisms from established results, and appendix preserves predicates/counterexamples and algebraic correction limits. No new undefined-symbol or process-narration blocker was found in the scoped text. Source theorem identifiers are concentrated in the appendix and break within columns without collision. The strongest physical claim a reader should take away is a conditional scalar interval constraint.

Paper25 likewise leads with the result and consistently distinguishes assumed speed law, free normalized susceptibility, unevaluated RPA inputs, finite flag predicates, and the unmatched real-product correction from physical dynamics. The signed additive-restoration discussion is present and legible. Its proof/API identifier lists on pp2–3 are dense and the 'correctness-push' heading is specialist vocabulary, but they do not obscure the revised conditional result and are not a newly introduced repair requirement. Both papers define the needed symbols before load-bearing use. No deletion list is required for new consumer prose.

D3 revised pp19–23 form a coherent chain: proposed phase, finite classifier versus physical matter trajectories, assumed speed law, event assumptions, compatible finite interval. The scalar response normalization, tensor propagator, physical state/matter reference, and actual stability domain remain explicitly absent. Revised abstract and pp52–55 agree with this scope. The p24 transition and p30 rewrite preserve the adjacent argument. References1/39/40 are visibly present and associated citations render without unresolved tokens. This is source/caption coherence review, not fresh independent primary-literature verification.

Length: D3 compiled66 lies within metadata30–75page budget. L1's budget is3750word-equivalents, not a page cap;5pages cannot establish this budget and no fresh word-equivalent census was run. L1 abstract is compact; its metadata abstract-character threshold itself remains marked primary-source-unverified. Paper25 is a legacy supporting paper with no separately established venue-length acceptance here.

## Open holds and required work

The L1 title still promises 'its natural range' and identifies a vestigial-second-sound graviton before the body qualifies both. A referee can stop at title lines24–25 because the reader-facing headline implies an established physical range while the abstract/body state adopted[0.1,10]. This known whole-physical/title acceptance issue remains OPEN. The scoped conditional text/render repairs do not resolve it. Before publication either original physical range/normalization and identification must actually be established, or the title needs explicit scientific/charter adjudication; this review grants no scope reduction.

D3's12 compiler overflow warnings remain OPEN, not waived by baseline history. At actual readable scale there are right-margin protrusions from long theorem names. A bbox screen plus direct raster inspection identified pp7,9,14,32,40,43,44,48,57; most conspicuous is p14's trace-reversal identifier ending atx567.9pt on a612pt page, beyond ordinary text width but inside the sheet. These observed protrusions are readable and do not overlap another column or crop off the sheet. None lies in the revised vestigial passage/caption. The archived compile summary does not expose twelve individual detailed log entries, so this review does not assert a one-to-one disposition of every warning. Full D3 clean-layout/publication acceptance needs the detailed warning list and repairs/reinspection. Contact-sheet survey alone does not certify all66pages.

Original-strength B3 physical susceptibility normalization and[0.1,10] as a result; positive physical state; constrained tensor/matter/light correspondence; and controlled physical transport/frequency matching with units and errors all remain BUILD. Final human and full-project acceptance remain owed. Current dirty regeneration cannot itself establish the paper's committed-pinned reproducibility claim until checkpointed and qualified by the lead's existing process.

No additional scoped reader/figure repair is required by this review. Do not use this report to close those original scientific or layout holds.

## Exact input SHA256

- `papers/L1/paper_draft.tex`: `29f926fef642a352ffb24b2d1fb0d851c1fb58d5c2a50ba7ffaf3083e3c1c5a2`
- `papers/L1/paper_draft.pdf`: `e39fa1d872e762292f301a620f0435a9cc7959420a37ae67f6e243565266ef5d`
- `papers/D3/paper_draft.tex`: `32740b59d35187b869314f1c809890f1c695fb72d501afb15b4ea55a05e0aeec`
- `papers/D3/paper_draft.pdf`: `21b343309d1899a85b599f66acb0996337c30cfa6e8f560db153ba704f03f65c`
- `papers/paper25_gravitational_waves/paper_draft.tex`: `760c21f1295b72cb3fd5bfc66adb09320ef9d5e65da0074215bdfa871675f2ff`
- `papers/paper25_gravitational_waves/paper_draft.pdf`: `b809ffc48a98ec698abea60b4a511f3d7b24c36628f752a0ea8210f524799ab4`
- `src/core/visualizations.py`: `d723a9bacc93bac9e3b76010b201a3a718b5c55acbff320ca44f5b5496202e6d`
- `src/core/formulas.py`: `7d17a1acc60cd11e5d066141ebe0702b7a319db644e80fd4ce8aca28cf48a3a9`
- `src/core/provenance.py`: `eba5b4ed81cd21fba3ce78d281d3af60224a94c035dc36afadfb348087dc31ae`
- `lean/SKEFTHawking/GravitationalWaves.lean`: `eab4cd660adb486d6b057e8036d2d952bdea55e7ab7686e568cb79ae6a02285d`
- `figures/fig_c_GW_vs_ligo_constraint.png`: `cd3c1de52d177dd19ef6fb49d79319484c66674329624a1e6dd80702c1474976`
- `papers/L1/figures/fig_c_GW_vs_ligo_constraint.png`: `cd3c1de52d177dd19ef6fb49d79319484c66674329624a1e6dd80702c1474976`
- `papers/D3/figures/fig_c_GW_vs_ligo_constraint.png`: `cd3c1de52d177dd19ef6fb49d79319484c66674329624a1e6dd80702c1474976`
- `papers/paper25_gravitational_waves/figures/fig_c_GW_vs_ligo_constraint.png`: `cd3c1de52d177dd19ef6fb49d79319484c66674329624a1e6dd80702c1474976`

Final continuity check: fresh=true, changed=[] after all review output.
