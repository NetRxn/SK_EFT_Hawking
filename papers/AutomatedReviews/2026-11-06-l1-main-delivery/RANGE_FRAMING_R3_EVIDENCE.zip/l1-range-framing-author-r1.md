# L1 bounded range-framing proposal

Scope: read-only paper-drafter proposal for `papers/L1/paper_draft.tex` title (24–25), paragraph heading (149), and caption natural-range wording (263–269). ROOT owns serial integration, review and acceptance. No repository/notebook edits, staging/commit, tests, build, native/Lean/LSP or slot actions performed. The full current L1 draft and metadata were read. House paper-authoring, prohibited-pattern and dispatch-brief references were read in this same continuing assignment session and applied without modification.

Metadata contract: target PRL; declared ceiling 3750 word equivalents. No venue-rule verification, current length measurement, compile, or publication-readiness claim is made here.

## Recommended title: exact replacement

Old:

```tex
\title{GW170817 confines the vestigial-second-sound graviton
identification to one part in $10^{15}$ of its natural range}
```

New, recommended:

```tex
\title{GW170817 confines vestigial susceptibility to a finite interval
under an assumed graviton speed law}
```

Rationale: the title states the actual observationally conditioned mathematical result and discloses that the speed law is assumed. It makes the finite compatible interval explicit without implying that only exact unity survives. It removes the physically unsupported naturalness characterization and avoids presenting the adopted width ratio as an exact one-part precision or probability. The strongest quantitative result remains in the existing abstract and theorem: the interval is exactly `[(1−τ)^2,(1+τ)^2]`, with width `4τ`, and is more than fourteen orders narrower than adopted `[0.1,10]`. A mathematical title need not repeat that conditional benchmark ratio to preserve the theorem or the underlying scientific objective.

Optional alternative if ROOT prefers the second-sound identification explicit in the title:

```tex
\title{GW170817 confines vestigial susceptibility under an assumed
second-sound graviton speed law}
```

The recommended title communicates the finite set more directly. The alternative preserves the specific intended identification in the title; the introduction retains that identification in either case. Neither title changes the physical construction contract or asserts a microscopic graviton has been derived.

## Paragraph heading: exact replacement

Old:

```tex
\paragraph{Vestigial-susceptibility natural range.}
```

New:

```tex
\paragraph{Adopted susceptibility comparison window.}
```

Context retained verbatim: the following paragraph models RPA resummation with unevaluated bare susceptibility and coupling, explicitly says physical normalization remains undetermined, adopts `[0.1,10]`, and states that neither RPA nor dimensional analysis fixes normalization, center or endpoints. It also distinguishes alpha_ADW from chi_vest. The new heading agrees with these actual sentences; no body rewrite or new RPA/primary-literature claim is needed.

## Figure caption: two exact minimal replacements

First old span (262–264):

```tex
  \caption{\textbf{Headline result.} The
  $\dccap = \sqrt{\chivest} - 1$ deviation across the natural
  $\chivest \in [0.1,10]$ range (pale blue band, dashed blue border)
```

First new span:

```tex
  \caption{\textbf{Headline result.} For the assumed speed law, the
  $\dccap = \sqrt{\chivest} - 1$ deviation across the adopted
  comparison window $\chivest \in [0.1,10]$ (pale blue band, dashed blue border)
```

Second old span (268–269):

```tex
  the cap's own width is far below one pixel at this scale). Over the
  natural range $\dccap$ sweeps $[-0.68, +2.16]$, exceeding the cap by
```

Second new span:

```tex
  the cap's own width is far below one pixel at this scale). Over this
  comparison window $\dccap$ sweeps $[-0.68, +2.16]$, exceeding the cap by
```

These are the only proposed caption changes. Subsequent text remains: the approximate cap excess is explicitly at endpoints; the deviation vanishes at unity; the compatible interval has width `4τ=1.2e−14` versus adopted width `9.9`; the finite extent is unresolved; the star marks an anchor rather than a singleton; the interval sits inside the band. This preserves endpoint/range and capratio/deviation distinctions, and retains the full numerical result without adding any new literal numerical claim.

For unambiguous integration, the complete proposed caption context is:

```tex
  \caption{\textbf{Headline result.} For the assumed speed law, the
  $\dccap = \sqrt{\chivest} - 1$ deviation across the adopted
  comparison window $\chivest \in [0.1,10]$ (pale blue band, dashed blue border)
  versus the conservative symmetric envelope of the
  GW170817~\cite{Abbott2017GW170817} multi-messenger constraint,
  $|\dccap| \leq 3\times 10^{-15}$ (amber, drawn at $\dccap = 0$ because
  the cap's own width is far below one pixel at this scale). Over this
  comparison window $\dccap$ sweeps $[-0.68, +2.16]$, exceeding the cap by
  $\sim 10^{14}\times$ \emph{at the endpoints} (orange callouts) and
  vanishing at $\chivest = 1$. The compatible $\chivest$ window
  $[(1-\tau)^2,(1+\tau)^2]$ has width $4\tau = 1.2\times10^{-14}$,
  compared with the adopted range's width $9.9$. Its finite extent is
  unresolved at this scale; the gold star marks its anchor $\chivest=1$,
  not a singleton compatible set. The window sits \emph{inside} the band:
  the datum confines $\chivest$, it does not exclude the range.}
```

The existing image `papers/L1/figures/fig_c_GW_vs_ligo_constraint.png` was directly inspected with view_image. Its visible labels say “Assumed metric-channel speed”, “Assumed speed law”, “Adopted range [0.1, 10]” and “Compatible interval”. No figure regeneration or artwork edit is proposed. Image inspection alone supplies no test or numerical-production acceptance.

## Actual proof-source support and hypotheses

Current `lean/SKEFTHawking/GravitationalWaves.lean` declarations and full relevant proof bodies were read directly, not inferred from metadata.

- `c_GW` (124) defines a free-real scalar law `c * Real.sqrt χ_vest`; `c_GW_deviation` (139) defines `Real.sqrt χ_vest − 1`. The relative-deviation bridge requires `c ≠ 0`. Physical applicability and identification remain hypotheses of the model, not conclusions of these definitions.
- `tolGW170817` (190) fixes the real tolerance to 3e−15, and `LigoSatisfied δ` (193) is `|δ| ≤ tolGW170817`. Source-emission qualifications are retained in the manuscript at 89–97 and in the definition's source documentation. The primary Abbott source was read through complete Section 4.1 in the preceding same-session scoped assignment; no new characterization of the cited source is introduced here.
- `c_GW_match_iff_chi_close_to_one` (206): binder χ:ℝ, hypothesis `0 ≤ χ`, conclusion `LigoSatisfied (c_GW_deviation χ) ↔ ((1−τ)^2 ≤ χ ∧ χ ≤ (1+τ)^2)`. Proof uses fixed τ positivity and τ<1, nonnegative square roots and `Real.sq_sqrt hχ`, `abs_le`, squaring inequalities and square-root monotonicity. This backs the conditional finite interval, not a unique exact parameter, physical normalization or a model-selection no-go.
- `ligo_window_subset_natural_range` (332), `chi_one_mem_ligo_window` (342), and `ligo_window_inter_natural_range_nonempty` (350): the exact compatible interval is nested in adopted `[0.1,10]`, contains unity and intersects it. Proofs use exact strict endpoint comparisons and the biconditional/anchor satisfaction result.
- `ligo_confines_chi_vest_within_natural_range` (365): hypotheses `0 ≤ χ` and cap satisfaction; conclusion squared-window membership plus strict adopted lower<χ<adopted upper. The proof obtains the window bounds from the biconditional and composes exact endpoint inequalities. Its historical declaration name does not confer a physically derived natural range.
- `ligo_window_width_eq` (374): unconditional real equality `(1+τ)^2−(1−τ)^2=4τ`, by `ring`.
- `natural_range_width_eq` (387): adopted upper minus adopted lower =99/10, by unfolding the endpoints and `norm_num`.
- `ligo_window_width_lt_natural_range_width_by_1e14` (397): unconditional fixed-input inequality `1e14*((1+τ)^2−(1−τ)^2)<upper−lower`, by rewriting the two width identities, unfolding fixed τ and `norm_num`. This is a benchmark width comparison, not an inferred probability, action-level coefficient extraction or physical naturalness prediction.

Canonical formula/constant bodies inspected in this same session: `src/core/formulas.py` c_GW_from_chi_vest, c_GW_deviation_from_c, ligo_constraint_check and c_GW_natural_range; `src/core/constants.py` GW speed caps and adopted endpoints. No new numeric computation or primary-source attribution is needed for the proposed lexical corrections.

## Preserved construction and review boundaries

The existing abstract, equations, theorem statements, endpoint examples, source-emission assumptions, appendix and Physical scope paragraph remain intact. The full physical B3 response normalization/range, physical state, tensor mode, matter/light reference and controlled transport/frequency matching with units and error bounds remain OPEN BUILD. Warranted correction of title/heading/caption framing discharges none of that construction and requests no reduced scope.

No claim that stronger proofs are absent was made. No new tests/gates/planner/ledger, review record, claims_review migration, bibliography entry or figure change is proposed. ROOT should propagate any accepted title to already-authoritative title consumers through the existing workflow; that integration is outside this read-only proposal and is not a request to invent a new ledger. Independent review and actual target acceptance remain outstanding.

## Continuity

Initial and final checks of `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/l1-range-framing-author-r1.json` returned `fresh:true`, `changed:[]`. This establishes snapshot agreement only, not execution authority or scientific completion.

## CONTRADICTIONS BETWEEN THE BRIEF AND THE SOURCES

None found against the corrective brief. The current title/heading/caption natural-range framing conflicts with the manuscript's own adopted-input qualification and actual scalar definitions. The current title's “one part in 10^15” is a rounded comparison of interval widths against chosen endpoints, not an exact precision statement or prior-independent probability. The recommended title and minimal replacements resolve that mismatch without weakening the conditional finite-interval theorem or the original physical construction obligations.
