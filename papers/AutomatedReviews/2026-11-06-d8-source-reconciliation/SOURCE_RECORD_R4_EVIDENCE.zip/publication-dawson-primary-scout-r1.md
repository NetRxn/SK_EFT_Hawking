# ROOT record of independent primary-source scout R1

Actual read-only scout `/root/dawson_primary_scout_r1` returned primary-source
confirmation. FIRST and FINAL SAME packet checks were fresh, changed=[]. This
records its returned evidence, not a whole-paper or native review.

- Publisher https://www.rintonpress.com/journals/doi/QIC6.1-6.html confirms
  Dawson/Nielsen, The Solovay-Kitaev algorithm, QIC6(1),January2006,81–95,
  DOI10.26421/QIC6.1-6.
- https://arxiv.org/abs/quant-ph/0505030 and
  https://arxiv.org/abs/quant-ph/0505030v1 both distinguish gate-length3.97
  and classical-runtime2.71; no approximately2 algorithm exponent.
  v1May6,2005; v2August23,2005.
- https://arxiv.org/pdf/quant-ph/0505030 section3,pages6–7,Eqs1–3 gives
  error power3/2,length multiplier5,runtime multiplier3; Eqs8–9 gives
  log5/log(3/2) gate length and log3/log(3/2) runtime.
- Runtime2.71 assumes pointer-compressed earlier outputs. Explicit gate
  output has3.97 runtime; finite arithmetic precision cost is excluded.
  Section5.1 extends the analysis to finite inverse-closed dense SU(d)
  instruction sets; preprocessing grows poorly with dimension.

Live primary confirmation succeeded. DOI resolver and Crossref API variants
returned tool Internal Error/inaccessible; the independently fetched publisher
record confirmed the DOI. A guessed publisher PDF route also failed. Those
failures are not claims of absent records. No local fallback, repository/cache
write, external private identifier or source-text dump was used by the scout.
ROOT separately directly read held primary pages1,3,6–7,10–11 and its existing
publisher metadata record and checked the exact source hashes.
