from pathlib import Path
import os,sys,json,subprocess,hashlib,datetime
r=Path.cwd();primary=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');m=json.load(open('/tmp/publication-source-record-proposal-r4.json'));prefix=Path('/tmp/publication-source-record-controls-r4');assert not prefix.with_suffix('.json').exists()
env=dict(os.environ,UV_PROJECT_ENVIRONMENT=str(primary/'.venv'),UV_NO_SYNC='1',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(r));records=[]
def run(name,argv=None,cmd=None):
 a=cmd if cmd else argv;res=subprocess.run(a,cwd=r,env=env,shell=cmd is not None,capture_output=True,text=True);Path(str(prefix)+'.'+name+'.stdout').write_text(res.stdout);Path(str(prefix)+'.'+name+'.stderr').write_text(res.stderr);records.append({'name':name,'argv':a,'returncode':res.returncode,'stdout':res.stdout,'stderr':res.stderr});return res
py=str(primary/'.venv/bin/python');test=[py,'-m','pytest','tests/test_d1_hierarchy_table.py::TestGenerator::test_cli_json_round_trip','-q','-p','no:cacheprovider']
f=r/'scripts/gen_d1_hierarchy_table.py';saved=f.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
try:
 assert run('json-positive',argv=test).returncode==0
 bad=saved.decode().replace('"cross_below_cutoff": bool(ln_arg < omega_max_over_TH),','"cross_below_cutoff": ln_arg < omega_max_over_TH,');assert bad!=saved.decode();f.write_text(bad)
 a=run('json-real-regression',argv=test);assert a.returncode==1 and 'not JSON serializable' in a.stdout
finally:f.write_bytes(saved)
assert sha(f.read_bytes())==sha(saved)
assert run('json-restored',argv=test).returncode==0
try:
 assert run('d1-declared-positive',cmd=m['new_d1_command']).returncode==0
 bad=saved.decode().replace('ln(1 + 1/delta_diss)','ln(2/delta_diss)');assert bad!=saved.decode();f.write_text(bad)
 a=run('d1-emitted-narrative-fault',cmd=m['new_d1_command']);assert a.returncode!=0 and 'generator narrative still says' in a.stderr
finally:f.write_bytes(saved)
assert sha(f.read_bytes())==sha(saved)
assert run('d1-declared-restored',cmd=m['new_d1_command']).returncode==0
assert run('d8-human-pending',cmd=m['d8_human_confirmation_command']).returncode!=0
assert run('d8-figures-still-owed',cmd=m['d8_figure_command']).returncode!=0
j=run('actual-json-cli',argv=[py,str(f),'--json']);assert j.returncode==0;data=json.loads(j.stdout)
for row in data.values():assert type(row['cross_below_cutoff']) is bool and row['cross_below_cutoff'] is (row['omega_cross_over_TH']<row['omega_max_over_TH'])
l=run('actual-latex-cli',argv=[py,str(f),'--latex']);assert l.returncode==0 and sha(l.stdout.encode())=='644c9f888cf9cb0a403d84592d5dcd81b0331b098bebe9c97fb3f19035614848'
assert run('canonical-source-register-current',argv=[py,'scripts/source_acquisition_register.py','--check']).returncode==0
sys.path.insert(0,str(r/'scripts'));from sentence_state import validate_claims_review
errors=validate_claims_review(json.loads((r/'papers/D8/claims_review.json').read_text()));assert errors==[],errors
out={'scope':'Actual production controls, intentional fault/byte-exact restoration. Original D8 semantic and figures remain OPEN; no physics/native/full project acceptance.','completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'generator_restored_sha256':sha(f.read_bytes()),'strict_claims_schema_errors':errors,'records':records}
prefix.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'controls':[(x['name'],x['returncode']) for x in records],'restored':sha(f.read_bytes())},indent=2))
