REVISE

Independent scientific/source and record-composition review of publication-source-record-review-r2. Selected MAIN HEAD 91d380f4acd6077e55d24e6f213931497ae39e55; unapplied patch SHA256 2747c265e4719983af4e6868315a206b3cb5e54e4257c3b3fd004ccdb6a38470. No author or other reviewer consulted. Only this report and its JSON counterpart were written. No repository/cache/ledger/notebook changes, builds, native lifecycle operations, Lean operations or production Verify runs.

Blocking correction R2-SR1: the D8:1.8 Verify does not require two actual figures.

The actual R2 command correctly escapes literal backslashes and rejects an empty manuscript. However its per-label next(...) selection can select the SAME figure block twice, and it scans commented-out TeX as active content. Executing the exact manifest command against pure in-memory inputs produces:

- two separate active labeled asset-bearing blocks: PASS;
- empty manuscript: FAIL, both required actual figure blocks must exist;
- ONE active figure block with both required labels and one present asset: PASS (false acceptance);
- TWO entirely percent-commented blocks with present assets: PASS (false acceptance: zero rendered figures).

These are source-composition counterexamples, not production or scientific figure acceptance. The fixtures model is_file() true because the defect survives with a genuinely present image asset. TeX renders no figures for the last fixture.

Necessary narrow correction: strip unescaped TeX percent comments before extraction; require each required label to resolve to its own distinct active figure-block occurrence; retain both present-asset checks and the no-deferrals assertion. No checker/ceiling/new infrastructure is required: repair the same existing finding's inline Verify data. Require the two counterexamples to fail and the two-active-block positive to pass. Retain independent source/science/publication-size figure review. Resubmit changed packet/postimage/patch hashes for independent review. No other blocking correction found within assigned scope.

Source and record findings accepted apart from R2-SR1:

1. I directly read the held 15-page PDF using pdftotext, with focused complete pp6–7 and pp10–11 reads, plus abstract and identity. Section3 Eq1 is epsilon_n = c_approx epsilon_(n-1)^(3/2), Eq2 is l_n = 5l_(n-1), Eq3 is t_n <= 3t_(n-1)+const. Eqs4–7 solve the recurrences; Eq8 gives log5/log(3/2) approximately3.97 length and Eq9 gives log3/log(3/2) approximately2.71 runtime. Page7 explicitly assumes pointer reuse; explicit gate output instead makes runtime also3.97. Arithmetic-precision costs are expressly excluded. Section5.1 extends the scaling to SU(d); preprocessing scales poorly with dimension. These statements support the existing Lean attribution; they do not certify the project's complete algorithm or constants.
2. The held abstract cache says 'Abstract (verbatim from arXiv)' but gives the false approximately2 gate-count statement. The held publisher/Crossref JSON independently has the correct title, Dawson/Nielsen authors, QIC6(1), January2006,81–95, DOI10.26421/qic6.1-6 and separate2.71/3.97 abstract. I read the supplied independent scout report; it documents live publisher/arXiv confirmation and failed Crossref/resolver routes honestly. I did not make a new live network request. The PDF's front-page typeset Received November26,2024 is an anomalous template date, not the publication date: identity rests on title/authors/arXivv2 and publisher record. The correction does not rely on that template date.
3. Registry AST comparison shows exactly the existing DawsonNielsen2006 value changes, with identical key population and all other AST values. DOI/PDF promotion is supported. PDF SHA256 4cd7033be2dd4265b228ff0a834d07715558b398b8fa16d8365392638fd4ea7e, 222679 bytes; false abstract ed7651d93abfb903101da49638443e5c5f746f8f49b4d3459b00ef9ed237cbc2; held JSON aaf315b87d1e29a79470d4425667b301eb77c450d5f6241875e606ab6d04a2a5.
4. Sidecar comparison confirms exactly one changed entry plus generated_at. Existing FetchRecord/Sidecar accepts these existing fields; no new mechanism is present. fetched_at is a repair verification timestamp, with explicit no-re-fetch note and url_used=null, not a fresh download assertion. The canonical derived acquisition register already was stale. Using the SELECTED MAIN renderer and its registry with WORKSPACE rebound in memory to the primary workspace, the one-entry revised registry renders EXACTLY the proposed register, SHA256 f0cb87ddd414ca543630bc768d14686843e18c1444ad6c153d49d8ba651a7393. Before promotion fresh-render hash was8c12b053582036a722f3d0a8a0bfd9f0f4f48214dd4fd14e1adec5872376a00d, so the broad register diff includes pre-existing drift, not extra registry edits. An initial comparison erroneously rendered primary-branch manuscripts and failed; correction to selected MAIN source plus primary workspace resolves it. ROOT must use the actual selected source context and canonical regeneration after apply.
5. D4 removes the false author TODO without changing rendered TeX input (unescaped-percent comment stripping) or physical line count. Existing reader-facing prose is unchanged.
6. Lean postimage equals original with exactly two section3.3-to-section3 locator substitutions. Stripping block comments leaves byte-identical code; correct Dawson–Nielsen attribution is retained. Native/hash qualification is still owed; no build or proof acceptance is claimed.
7. D1 shell decoding/AST literal extraction recovers its entire original Python body byte-for-byte, SHA256 e6e752d03651da262d51a980c77616fae6f44029c36535c48850e15c2e446475. The positive Heidelberg-row presence and numerical crossover assertions remain. Command is a single physical line, evaluated under canonical repository-root cwd by the existing consumer. No dropped assertions, thresholds or scientific repairs in this proposal. The four changed D1 tasks are actual generator/renderer/constants/estimator work, appropriately existing pyrust. Full original sections were read.
8. Full original D8 sections were read. The metadata tasks1.2/1.9 concern existing apex claims/annotations, not machinery; prose is appropriate. Boundary/ownership/report claims1.1/1.3/1.6 likewise prose; source acquisition/reconciliation1.4 research; actual canonical renderer work1.8 pyrust. Existing infra1.7 remains infra and retains explicit architecture-change requirement for extractor work. No blind metadata-to-infra rerouting.
9. D8 original1.4 allegation/Expected/Fix are preserved as explicitly dated history alongside immediate current retraction. Retraction of false source allegation does not wait for human confirmation; only terminal semantic supersession awaits the existing claims-reviewer PartD.2 boundary. Candidate_for_supersession, auto_closed=false and deterministic_recheck=null correctly preserve this distinction. The proposed receipt references a new source-reconciliation agent run; old reviewer run identity and all prior fields remain unchanged. No fake human confirmation or blanket review renewal.
10. Parsed claims JSON is identical after removing the one candidate array entry; byte prefix/suffix outside the array are identical, including Unicode spellings and final-newline convention. Existing strict validate_claims_review(postimage) returned[]. No ingestion/writer was invoked. Findings IDs/headings, severities and gates are conserved; original ledger/status is unchanged. D8:1.4 remains OPEN absent actual human AuditEvent.
11. The human Verify reads audit_log_path('D8') and correctly inspects each event's meta.action, meta.target_id and meta.new_state against the existing cmd_supersede/_make_audit_event implementation. It neither creates human state nor runs supersede; it gates terminal candidate retirement on the existing human receipt, not the source's factual retraction. It does not certify ledger closure; ROOT must separately respect the existing single-writer closure contract.
12. Cache custody plan preserves exact old bytes by renaming to DawsonNielsen2006.invalid-abstract-20261106.txt, leaves the full PDF untouched and redistributes no PDF. This is still only a plan here. Older branch aliases/pointers need normal propagation to the corrected source entry; a missing obsolete alias must not be claimed as lack of the full source. Full other-source/figure/physics/human/publication obligations remain open.

Authority read: CLAUDE.md; WAVE_EXECUTION_PIPELINE.md including routing taxonomy/Stage13 contract; CODEX_CONTINUITY.md; claims-reviewer PartD; ADR012 lane/closure/Verify contract; sentence_state audit constructor and supersede implementation; Sidecar/FetchRecord and canonical source-register renderer; referenced notebook and roadmap context. The using-superpowers skill exempts specifically dispatched subagents. Architecture authority is not newly required for these data-record edits; changing check machinery/semantics beyond this inline declared Verify would require the normal architecture workflow.

Commands and execution evidence (all Python invocations used PYTHONDONTWRITEBYTECODE=1; primary .venv used for project helper/schema calls):

Packet checks, twice, exact command:
  python3 scripts/codex_continuity.py check /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/publication-source-record-review-r2.json
Both: fresh=true, changed=[]. First action read the packet; first explicit adapter check followed the initial read-only source reads. Final adapter check followed all substantive review; selected git status --porcelain=v1 was empty. No claim that the adapter ran before those initial reads.

Primary reads:
  pdftotext -layout /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/Lit-Search/Phase-1-and-Background/primary-sources/DawsonNielsen2006.pdf -
  pdftotext -f 6 -l 7 -layout /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/Lit-Search/Phase-1-and-Background/primary-sources/DawsonNielsen2006.pdf -
  pdftotext -f 10 -l 11 -layout /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/Lit-Search/Phase-1-and-Background/primary-sources/DawsonNielsen2006.pdf -
  shasum -a 256 /tmp/publication-source-record-proposal-r2.patch /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/Lit-Search/Phase-1-and-Background/primary-sources/DawsonNielsen2006*

Exact counterexample command body, executed with python3 stdin; no filesystem fixtures or production mutation:
```python
import json,shlex,sys,types
code=shlex.split(json.load(open('/tmp/publication-source-record-proposal-r2.json'))['d8_figure_command'])[2]
fixtures={'valid':r'\begin{figure}\includegraphics{exists.png}\label{fig:d8-coverage}\end{figure}'+'\n'+r'\begin{figure}\includegraphics{exists.png}\label{fig:d8-length-comparison}\end{figure}', 'empty':'', 'one_block_two_labels':r'\begin{figure}\includegraphics{exists.png}\label{fig:d8-coverage}\label{fig:d8-length-comparison}\end{figure}'}
fixtures['commented_blocks']='\n'.join('% '+line for line in fixtures['valid'].splitlines())
class P:
 def __init__(self,*a):pass
 def __truediv__(self,x):return self
 def read_text(self):return current
 def is_file(self):return True
real=sys.modules.get('pathlib');fake=types.ModuleType('pathlib');fake.Path=P;sys.modules['pathlib']=fake
try:
 for name,current in fixtures.items():
  try:exec(code,{});print(name,'PASS')
  except AssertionError as e:print(name,'FAIL',str(e))
finally:
 if real is None:sys.modules.pop('pathlib',None)
 else:sys.modules['pathlib']=real
```

Exact strict-schema command body under primary .venv/bin/python stdin:
```python
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()));from scripts.sentence_state import validate_claims_review
p=Path('/tmp/publication-source-record-proposal-r2/papers/D8/claims_review.json'); e=validate_claims_review(json.loads(p.read_text()));print('STRICT CLAIMS SCHEMA',e);assert not e
```

Canonical selected-source render command body under primary .venv/bin/python stdin:
```python
import sys,importlib.util,hashlib
from pathlib import Path
root=Path.cwd();p=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');sys.path.insert(0,str(root));from src.core.citations import CITATION_REGISTRY
s=importlib.util.spec_from_file_location('reg',root/'scripts/source_acquisition_register.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.WORKSPACE=p.parent
before=m.render();CITATION_REGISTRY['DawsonNielsen2006']['primary_source_path']='Lit-Search/Phase-1-and-Background/primary-sources/DawsonNielsen2006.pdf';CITATION_REGISTRY['DawsonNielsen2006']['doi']='10.26421/QIC6.1-6';after=m.render();post=Path('/tmp/publication-source-record-proposal-r2/docs/SOURCE_ACQUISITION_REGISTER.md').read_text();print('matches selected canonical render with primary workspace:',after==post);print('before derived register sha',hashlib.sha256(before.encode()).hexdigest(),'post',hashlib.sha256(after.encode()).hexdigest());print('baseline stale:',before!=(root/'docs/SOURCE_ACQUISITION_REGISTER.md').read_text());assert after==post
```

Complete eight-file manifest hashes were independently rederived from all before/postimage bytes; listed in JSON companion. Additional in-memory comparisons: registry AST key/value identity outside Dawson, claims parsed equality and original byte-prefix/suffix conservation, sidecar parsed equality outside Dawson/generated_at, D4 physical line and rendered-input identity, Lean exact two-substitution equality/noncomment identity, D1 shell-decoded AST constant versus original full Python body. These passed before the initial wrong-branch renderer assertion; corrected selected-source replay passed separately. No production/whole-tree/native/publication acceptance follows from these local read-only checks.
