# Source and verification-record repair proposal R4

UNAPPLIED author proposal for independent review. Current actual main91d380f4a.

The held15-page Dawson--Nielsen quant-ph/0505030v2 source directly gives gate
length log(5)/log(3/2) approximately3.97 and pointer-compressed runtime
log(3)/log(3/2) approximately2.71 (section3,Eqs1–9; section5 extends to SU(d)).
Explicit gate output has3.97 runtime; arithmetic precision is excluded. The
legacy1324-byte abstract cache is not verbatim and falsely says approximately2.
Live independent arXiv/publisher confirmation agrees with the held full paper.
Publisher DOI10.26421/QIC6.1-6 belongs to this exact work; the registry's old
no-DOI assertion is also false. Primary PDF SHA4cd7033be2dd4265b228ff0a834d07715558b398b8fa16d8365392638fd4ea7e.

The complete proposal promotes only this existing held source in the canonical
registry and existing Sidecar writer, and removes only this newly held key from
the canonical derived acquisition register. Every other registry/sidecar entry
and scientific claim is conserved. A false D4 author comment is corrected with
no rendered prose change or line shift. Existing correct Lean exponent attribution
is retained. No new proof, complexity constant or complete algorithm is certified.

The original semantic D8:1.4 finding does not reproduce. Claims-reviewer PartD.2
requires candidate_for_supersession and terminal human confirmation. The proposal
adds only that canonical candidate, retains the complete old allegation as dated
history and uses the existing human audit receipt as its executable Verify guard.
It intentionally stays OPEN; no agent runs supersede or writes human state/ledger.
This preserves the human boundary instead of silently retiring a judgment.

D1's malformed multiline Verify becomes one physical shell command, with its
entire original Python body unchanged (including positive Heidelberg output).
Four D1 code lanes become existing pyrust. D8 unsupported lane spellings become
existing prose/research/pyrust according to each actual original task; all IDs,
severities/gates/other verifiers stay intact. Its figure Verify now requires both
actual labeled asset-bearing figures and no remaining figuredeferred calls;
it remains red today and cannot be satisfied by merely deleting deferrals.
Independent scientific/source/publication-size figure review is still owed.

The invalid abstract is preserved byte-for-byte under a clearly invalid cache
name in Lit-Search; the full PDF is untouched. It is not replaced by invented
text or redistributed. Older branches retaining the old invalid pointer need
normal propagation to the corrected source entry; absence of that alias is not
absence of the full source. All active paper/physics/human obligations outside
this exact source correction remain OPEN. No ceiling, checker, writer, gate,
planner or schema changes are proposed. Full source/review and strict schema,
record identity/ledger conservation, declared command/fault/restoration checks
precede application/closure claims. Proposal-only helper replay is not a live
production result; the source register must be regenerated normally after apply.

## Author pre-review correction

R1 was never applied. R2 fixes literal-backslash regex escaping, conserves all
prior D8 JSON bytes outside the candidate array, and corrects two nonexistent
section3.3 locators in the Lean comments to section3. All noncomment Lean bytes
are identical; native/hash qualification remains required after application.
The original semantic finding remains a candidate, not agent-closed.

## R3 correction after actual independent review and baseline execution

R2 is preserved as REVISE. The D8 predicate now reuses the existing canonical
TeX comment stripper and demands two DISTINCT active figure occurrences, each
with its own unique required label and present asset. Commented figures and
one figure with two labels must fail; two real blocks must pass. Scientific
figure review remains required; this fixes an existing inline Verify record,
not checker infrastructure.

Executing the unchanged D1 Python body against current production actually
failed: the numeric log1p-equivalent formula is correct, but the human CLI
header and final sentence STILL print the obsolete ln(2/delta) form. R3 fixes
those emitter labels and aligns that human table column; no computed quantity,
parameter, formula or LaTeX table branch changes. The original full body is
retained, not weakened. Actual post-apply existing Verify/fault/restoration and
JSON/LaTeX conservation remain required.

Canonical Sidecar._flush timestamps actual production generation time, which
may differ from the frozen preview; every entry/source field must otherwise
equal the reviewed proposal, and all other old entries remain unchanged.

## R4 exact remaining corrections

R3 REVISE is preserved. Each active required label now occurs EXACTLYonce,
not merely in one matched block; sameblock/two-label and commented blocks
remain rejected. No full TeX grammar or scientific adequacy is claimed.

Actual baseline and R3 advertised --json both fail on the NumPy cutoff bool.
R4 wraps ONLY the existing comparison result in bool(), conserving its truth
and every computed numerical value, and corrects the stale ln/floor docstring.
One end-to-end regression in the existing generator test file executes the real
CLI, parses its entire output, compares it with the canonical evaluator and
checks native Boolean flags against the emitted physical cutoff quantities.
Its exact body is run against unchanged production before application; it must
fail on the actual serialization defect. This is API repair, not a new physics
formula or a predicate relaxation. Actual JSON/LaTeX/source controls and native
qualification remain required after apply; no current successful JSON claim.
