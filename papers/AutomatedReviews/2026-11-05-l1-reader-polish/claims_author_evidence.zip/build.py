import json,re,copy,hashlib,sys,datetime,difflib
from pathlib import Path
from collections import Counter
R=Path.cwd();O=Path('/tmp/l1-reader-polish-claims-20261105-r1');sys.path.insert(0,str(R/'scripts'))
from sentence_state import normalize_quote,compute_sentence_id,validate_claims_review
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
T=R/'papers/L1/paper_draft.tex';t=T.read_text();assert sha(T)=='ba39d45207c8c100f85a4a0712b33d9490d6c7b268e7534a82ecbf0bac958c4f'
B=R/'papers/L1/claims_review.json';assert sha(B)=='77197b489bc16f6e6f61770dba3580f6a3d52efd779c50adeb6d837a4a01f18c';base=json.loads(B.read_text());assert len(base['sentences'])==128
u=json.loads((O/'units.json').read_text());run='claims-reviewer-v2:2026-11-05:l1-reader-polish-catalog-r1'
masked=re.sub(r'\\label\{[^}]*\}',lambda m:' '*len(m[0]),t)
def locate(q):
 ms=list(re.finditer(r'\s+'.join(map(re.escape,q.split())),masked));assert len(ms)==1,(q,len(ms));m=ms[0];return t.count('\n',0,m.start())+1,t.count('\n',0,m.end()-1)+1,m.start(),m.end()
sections=[(m.start(),m[1]) for m in re.finditer(r'\\section\{([^{}]*)\}',t)]
def section(pos):return next((s for a,s in reversed(sections) if a<pos),'abstract')
scope='Actual source/statement/proof-body inspection and accepted source-review consultation only; no Lean/LSP/kernel/native/build/scientific execution. Scalar algebra is not physical mode, normalization, state, tensor, matter or transport construction.'
C={
0:([0,1],'formal-claim','PASS','Combines already source-qualified assumed law, chi>=0 fixed-cap biconditional and observational emission caveat. GravitationalWaves c_GW_match_iff_chi_close_to_one proves the displayed interval at fixed tau; not a physical derivation.'),
1:([0,13,46],'parameter','INFO','Defines c and adopted normalized dimensionless response. Free response normalization is assumed, not measured or extracted; original physical normalization blocker persists.'),
2:([1,2],'numeric','PASS','Same exact4tau width, unity membership and strict1e14width comparison carried by GravitationalWaves chi_one_mem_ligo_window/ligo_window_width_eq; adopted range, not prior probability.'),
3:([3,17,18,93],'qualitative','INFO','Preserves original missing mode/range and adds explicit undetermined normalization; limited kinematic scope does not close scientific BUILD.'),
10:([10],'citation','PASS','Only expands s2 and H definitions. Accepted DEFINITIONS_SOURCE_REVIEW personally reconsulted and r2 source-preservation review retain de Sitter-model-qualified Landau/stiff-component result and H independence; no spin2 generalization.'),
14:([14],'formal-claim','PASS','RPA abbreviation expanded only. Actual VestigialSusceptibility W6Ext.chi_RPA_closed_form is a free-input rational identity/stability result; no evaluated bubble or coupling.'),
26:([26],'qualitative','INFO','ADW acronym expanded and project Phase language removed; explicit no-general-emergent-gravity refutation retained. Assumed identification only.'),
27:([26],'transition','TRANSITION','Forward reference to the three conditional mechanisms actually retained in Discussion.'),
34:([33,34],'citation','PASS','Condenses source-qualified four-primary comparison: actions/operators/cosmologies and background/matter hypotheses retained. Their detailed attribution paragraph is unchanged; no new claim about a theory-independent result.'),
35:([36,37,40],'qualitative','INFO','Explicitly declares assumed scalar identification and constrained free parameter; no microscopic coefficients inferred.'),
36:([35,36,40],'qualitative','INFO','Preserves lack of microscopic Lagrangian/operator constraint. Original physical construction remains open.'),
37:([37,38,39],'formal-claim','PASS','Actual exact interval and widths establish approximate1.2e-15relative width only under adopted range. Removes old39 unsupported theory-versus-identification rationale: both are parameter regions. Explicit no prediction/prior-independent probability is correct; prior WARN record retained, no finding auto-closed.'),
38:([41,42],'qualitative','INFO','Preserves need for operator-level applicability analysis; none supplied by scalar endpoint theorem.'),
39:([43],'qualitative','INFO','Same three possible outcomes, conditional could not assertion of realized mechanism. No fixed-point necessity inferred.'),
40:([44],'formal-claim','PASS','Conditional fixed point can preserve assumed law; exact finite-interval theorem does not select or derive it. No construction upgrade.'),
44:([48],'qualitative','UNGROUNDED','Defines UV cutoff but does not derive normalized central susceptibility or adopted decade range. Same dimensional estimate/normalization gap as predecessor48 remains; source qualification is not a repair.'),
45:([49],'citation','PASS','Removes project wording only. Vergeles unitarity remains distinct from numerical susceptibility/range derivation; source-qualified prior claim preserved.'),
46:([50,120],'parameter','WARN','Companion paper23 defines alpha free dimensionless multiplier of adopted12pi/(Nf Lambda²) baseline; actual LinearizedEFE G_N_emerg defines that scalar expression. Range remains adopted. WARN for same known unresolved species/regulator/source normalization; source wording does not validate physical anchor.'),
47:([50],'qualitative','INFO','Adopted comparison only; paper23 range and distinct alpha/chi response roles do not derive either range or identify the parameters.'),
86:([102],'qualitative','INFO','Same open microscopic fixed-point realization question with Phase bookkeeping removed.'),
87:([103],'qualitative','INFO','Expands UV and DOF only; proposed distinct channel remains conditional, no preferred physical interpretation.'),
90:([106],'qualitative','INFO','R2 corrects exclusive requires claim to research route. Nonlinear action remains proposed venue; no theorem proves it necessary or establishes disambiguation.'),
94:([110],'parameter','INFO','Actual dispersion_correction accepts gamma omega:Real and peak theorem evaluates literal100. It supplies no frequency unit.'),
95:([110],'qualitative','INFO','Physical100Hz interpretation needs convention/normalization absent in real-product statement. Existing registry49–53 transport BUILD persists.'),
96:([110],'qualitative','WARN','gamma=Gamma_H/cGW² is explicitly proposed unmatched metric-channel identification. Real-product source and registry49–53 establish unresolved units/normalization debt; no physical gamma derivation.'),
97:([110],'qualitative','WARN','Actual GravitationalWaves imports Basic/LinearizedEFE/Mathlib and defines free gamma*omega; docstring acoustic SecondOrderSK.GammaH cross-link is not a matched retarded metric observable. Accepted source/registry review marks this same known BUILD; no new closure.'),
98:([111],'formal-claim','PASS','Actual peak theorem assumes abs gamma<=1e-30 and concludes abs(dispersion_correction gamma100)<=fixed tau, proof unfolds product and bounds abs gamma*100 by1e-28. Qualified numeric probe and bound retained; no measured frequency.'),
105:([120],'parameter','PASS','Actual G_N_emerg and G_N_sakharov definitions give alpha*12pi/(Nf Lambda²). Companion is in preparation, not published observational normalization; count parameter interpretation remains open separately.'),
106:([120],'parameter','PASS','Natural-unit unreduced observed Planck definition matches actual match_at_planck_anchor cutoff sqrt(1/Gobs) for positive observed G. This is adopted convention, not species extraction.'),
107:([120],'formal-claim','PASS','Personally inspected LinearizedEFE333–375: positive Real Nf,alpha,Gobs and cutoff sqrt(1/Gobs) yield iff alpha*12pi=Nf; pi>0 gives displayed alpha*. Conditional locus genuinely proved; no physical coefficient selection.'),
108:([120],'numeric','PASS','Companion343–348 prints0.398,0.424,1.194,1.273; r2 says reported rounded values[.40,1.27], not an exact containing interval. These are inside adopted[.1,10]. Count normalization not inferred.'),
109:([120,121],'qualitative','WARN','Actual LinearizedEFE223 says Dirac; companion count choices and GRAV metadata say Weyl15/16/45/48. Existing L1_REGISTRY_REVIEW49–53 and Visser review leave source/projector/species/regulator physical normalization unresolved. Same known BUILD, not new finding or repaired by qualification.'),
110:([120,121],'formal-claim','PASS','Actual positive-real G_N_emerg_match_locus/at_planck_anchor carry algebra. alphaADW_linear=1-1/x; proofs positivity for x>1, critical collapse and deep-gap limit genuinely establish candidate-function properties; H_VergelesNGModeProjection is conjunction of those scalar conditions. No microscopic loop/projector coefficient is extracted. PASS limited to this corrected actual scope; original WARN fully retained in109/history.'),
111:([121],'qualitative','INFO','Two free response normalizations distinguished; this does not establish physical compatibility of either. Prior121 stronger computed-kernel promotion withdrawn on actual source evidence while its normalization debt persists in109.'),
112:([122],'formal-claim','PASS','Only susceptibility notation clarified. Unity lies in adopted range but actual RPA/free scalar setup supplies no value.'),
113:([123],'formal-claim','PASS','Same exact finite-tolerance confinement without microscopic selection; statement carried by scalar biconditional/width results.'),
128:([111],'theorem-ref','PASS','Actual vestigial_dispersion_below_ligo_at_inspiral_peak is conditional abs gamma<=1e-30 at literal100. Repeated theorem name moved to formal checks; no units or leading derivative expansion inferred.'),
}
# Split list prelude from first claim, preserving actual item prose granularity.
q=u[83]['quote'];k=q.index('\\textbf');special=[([98],'transition','TRANSITION',q[:k].strip(),'Three possibilities are present; source-level forward reference, not exhaustive physical theorem.'),([99],'qualitative','INFO',q[k:].strip(),'Only expands deep-IR. Conditional symmetry/fixed-point possibility remains unconstructed; no exact-fixed-point requirement from finite tolerance.')]
records=[];retained=[];moved=[];links={i:[] for i in range(128)};changes=[]
for i,old in enumerate(base['sentences']):
 try:a,b,c,e=locate(old['quote'])
 except AssertionError:continue
 s=copy.deepcopy(old);sec=section(c)
 if sec!=s['section']:
  oldid=s['id'];s['section']=sec;s['id'],s['quote_normalized'],h=compute_sentence_id('L1',sec,s['quote']);s['raw_id_parts'].update(section_slug=s['id'].split(':')[2],quote_hash=h);s['rewrite_of']=oldid;s['bundle_section_hint']=sec;moved.append(i)
 else:retained.append(i)
 records.append(s);links[i].append(s['id'])
for unit,(parents,typ,v,note) in C.items():
 q=u[unit]['quote'];s=copy.deepcopy(base['sentences'][parents[0]]);sec=section(locate(q)[2]);sid,n,h=compute_sentence_id('L1',sec,q)
 s.update(id=sid,section=sec,quote=q,quote_normalized=n,type=typ,agent_verdict=v,agent_notes=note,agent_run_id=run,rewrite_of=base['sentences'][parents[0]]['id'],finding_classes=[],gates_invoked=[])
 s['raw_id_parts'].update(section_slug=sid.split(':')[2],quote_hash=h);s.pop('delta_pct',None)
 # Retain old chains as historical evidence only; new claims use source-addressed chains below.
 targets={0:[('theorem','SKEFTHawking.GravitationalWaves.c_GW_match_iff_chi_close_to_one'),('citation','Abbott2017GW170817')],2:[('theorem','SKEFTHawking.GravitationalWaves.ligo_window_width_eq')],14:[('theorem','SKEFTHawking.VestigialSusceptibility.W6Ext.chi_RPA_closed_form')],46:[('theorem','SKEFTHawking.LinearizedEFE.G_N_emerg'),('citation','Roehm2026LinearizedEFE')],47:[('citation','Roehm2026LinearizedEFE')],94:[('theorem','SKEFTHawking.GravitationalWaves.vestigial_dispersion_below_ligo_at_inspiral_peak')],95:[('parameter','GW.GW170817_PEAK_FREQ_HZ')],96:[('parameter','GW.GAMMA_H_VESTIGIAL_DEFAULT')],97:[('theorem','SKEFTHawking.GravitationalWaves.dispersion_correction')],98:[('theorem','SKEFTHawking.GravitationalWaves.vestigial_dispersion_below_ligo_at_inspiral_peak')],105:[('theorem','SKEFTHawking.LinearizedEFE.G_N_emerg'),('theorem','SKEFTHawking.LinearizedEFE.G_N_sakharov'),('citation','Roehm2026LinearizedEFE')],106:[('parameter','GRAV.M_PLANCK_GEV'),('parameter','GRAV.G_N_OBS_GEV_M2')],107:[('theorem','SKEFTHawking.LinearizedEFE.G_N_emerg_match_at_planck_anchor')],108:[('citation','Roehm2026LinearizedEFE')],109:[('parameter','GRAV.N_F_PER_GEN_NO_NU_R'),('parameter','GRAV.N_F_THREE_GEN_NO_NU_R'),('theorem','SKEFTHawking.LinearizedEFE.G_N_sakharov')],110:[('theorem','SKEFTHawking.LinearizedEFE.G_N_emerg_match_locus'),('theorem','SKEFTHawking.LinearizedEFE.alphaADW_linear'),('theorem','SKEFTHawking.LinearizedEFE.alphaADW_linear_satisfies_all_three'),('theorem','SKEFTHawking.LinearizedEFE.H_VergelesNGModeProjection')],111:[('theorem','SKEFTHawking.LinearizedEFE.G_N_emerg')],128:[('theorem','SKEFTHawking.GravitationalWaves.vestigial_dispersion_below_ligo_at_inspiral_peak')]}
 if unit in targets:
  s['chain_proposed']={'links':[{'kind':k,'target':p,'verification_scope':scope+' '+note} for k,p in targets[unit]],'completeness':'partial' if v in ['WARN','UNGROUNDED','INFO'] else 'full'}
 else:
  # Same backing carried by predecessor claims; no fabricated filename-as-formula target.
  chain=copy.deepcopy(base['sentences'][parents[0]].get('chain_proposed',{'links':[],'completeness':'none'}))
  for link in chain['links']:link['verification_scope']=scope+' '+note
  if v in ['WARN','UNGROUNDED']:chain['completeness']='partial' if chain['links'] else 'none'
  s['chain_proposed']=chain
 s['meta']={'review_unit':0,'source_sha256':sha(T),'assessment_origin':'reader-polish-source-reassessment','prior_assessment_ids':[base['sentences'][j]['id'] for j in parents],'source_scope':scope,'walker_unit':unit}
 records.append(s)
 for p in parents:links[p].append(sid)
 changes.append({'walker_unit':unit,'id':sid,'prior_indices':parents,'prior_verdicts':[base['sentences'][p]['agent_verdict'] for p in parents],'verdict':v,'justification':note})
for parents,typ,v,q,note in special:
 s=copy.deepcopy(base['sentences'][parents[0]]);sid,n,h=compute_sentence_id('L1','Discussion',q);s.update(id=sid,quote=q,quote_normalized=n,type=typ,agent_verdict=v,agent_notes=note,agent_run_id=run,rewrite_of=base['sentences'][parents[0]]['id']);s['raw_id_parts'].update(quote_hash=h);s['meta']={'review_unit':0,'walker_unit':83,'source_scope':scope};records.append(s)
 for p in parents:links[p].append(sid)
 changes.append({'walker_unit':83,'id':sid,'prior_indices':parents,'prior_verdicts':[base['sentences'][p]['agent_verdict'] for p in parents],'verdict':v,'justification':note})
records.sort(key=lambda s:locate(s['quote'])[2]);ords=Counter();coverage=[]
for i,s in enumerate(records):
 a,b,c,e=locate(s['quote']);s.update(tex_line_start=a,tex_line_end=b);ords[s['section']]+=1;s['section_ordinal']=ords[s['section']];s['meta']['review_unit']=i
 assert compute_sentence_id('L1',s['section'],s['quote'])[0]==s['id'];assert normalize_quote(masked[c:e])==s['quote_normalized']
 coverage.append({'review_unit':i,'id':s['id'],'section':s['section'],'section_ordinal':s['section_ordinal'],'line_start':a,'line_end':b,'char_start':c,'char_end_exclusive':e,'unique_actual_binding':True})
assert len(records)==len({s['id'] for s in records})==len({normalize_quote(s['quote']) for s in records})
lineage=[]
for j,old in enumerate(base['sentences']):
 assert links[j],('UNACCOUNTED',j)
 lineage.append({'prior_index':j,'prior_id':old['id'],'successor_ids':links[j],'relation':'same-quote-section-move-new-id' if j in moved else 'retained' if j in retained else 'split/merge/rewrite','disposition':'Scientific content preserved/qualified against actual backing; full predecessor record retained below. No automatic closure. Project Phase/wave narration removed; known physical BUILD unchanged.'})
d=copy.deepcopy(base);d.update(sentences=records,review_date=datetime.datetime.now(datetime.timezone.utc).isoformat(),reviewer_run_id=run)
d['review_scope']['reader_polish_refresh']={'agent_run_id':run,'base_head':'0d45d43d395fc2b1ef524e7ba7baeeba85e08f23','prior_catalog_sha256':sha(B),'current_manuscript_sha256':sha(T),'scope':scope,'original_top_level_review_date':base['review_date'],'original_top_level_reviewer_run_id':base['reviewer_run_id'],'acceptance':'Scratch proposal only, independent review/ROOT intake required. No real ingest/closure or whole-L1 acceptance.'}
sources=['papers/L1/paper_draft.tex','papers/L1/paper_draft.pdf','lean/SKEFTHawking/LinearizedEFE.lean','lean/SKEFTHawking/GravitationalWaves.lean','lean/SKEFTHawking/VestigialSusceptibility.lean','lean/lean_deps.json','papers/paper23_linearized_efe/paper_draft.tex','papers/AutomatedReviews/2026-11-05-l1-reader-polish/DEFINITIONS_SOURCE_REVIEW.md','papers/AutomatedReviews/2026-11-05-l1-reader-polish/VISSER_CONVENTION_REVIEW.md','papers/AutomatedReviews/2026-11-05-publication-computation-coverage/L1_REGISTRY_REVIEW.md']
d['review_evidence']['reader_polish_refresh']={'all_128_predecessor_records':copy.deepcopy(base['sentences']),'all_predecessor_lineage':lineage,'prior_summary_preserved':copy.deepcopy(base['summary']),'assessment_changes':changes,'source_hashes':{p:sha(R/p) for p in sources},'external_review_hashes':{p:sha(p) for p in ['/tmp/l1-reader-polish-source-independent-20261105.md','/tmp/l1-reader-polish-source-r2-independent-20261105.md']},'source_reviews':'Historical r1 BLOCK for two wording issues remains correct; bounded r2 ACCEPT applies to two exact corrections only. Known registry49–53 Dirac/Weyl and unmatched Gamma units debt remains BUILD, not new closure.','no_execution_or_acceptance_promotion':True}
summ=d['summary'];summ.update(total_sentences=len(records),by_type=dict(Counter(s['type'] for s in records)),by_verdict=dict(Counter(s['agent_verdict'] for s in records)),by_finding_class=dict(Counter(c for s in records for c in s['finding_classes'])))
summ['agent_text']=f'{len(records)} current units; {len(retained)} unchanged-ID assessments retained; {len(moved)} same-quote section moves with explicit new-ID relation. All128 full predecessor records/lineage retained. Four scientific blockers,54supersession candidates and prior human/evidence/date state unchanged. No automatic closures. Actual conditional scalar results only; physical BUILD/native/stage/publication acceptance remain open.'
assert not validate_claims_review(d),validate_claims_review(d)
preserve={k:d[k]==base[k] for k in ['blocking_issues','non_blocking_followups','non_reproducing_prior_findings','reproducing_prior_findings','cross_bundle_findings']};assert all(preserve.values())
for k in ['review_scope','review_evidence']:assert all(d[k][a]==b for a,b in base[k].items())
for j in retained+moved:
 old=copy.deepcopy(base['sentences'][j]);cur=copy.deepcopy(next(s for s in records if s['id']==links[j][0]))
 for a in [old,cur]:
  for k in ['tex_line_start','tex_line_end','section_ordinal']:a.pop(k,None)
  a['meta'].pop('review_unit',None)
 if j in moved:
  for a in [old,cur]:
   for k in ['id','section','raw_id_parts','rewrite_of','bundle_section_hint']:a.pop(k,None)
 assert old==cur,('assessment mutated',j)
preserve.update(retained_indices=retained,moved_indices=moved,all128predecessors_accounted=True,full_predecessor_records_retained=128,unchanged_assessments_retained=True,original_review_scope_and_evidence_objects_unchanged=True,human_and_audit_pins={p:sha(R/'papers/L1'/p) for p in ['prose_state.json','audit_log.jsonl']})
for name,obj in [('claims_review',d),('coverage',coverage),('lineage',lineage),('preservation',preserve),('individual-verdict-changes',changes)]: (O/(name+'.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
read=json.loads((O/'claims_review.json').read_text());rb={'proposal_sha256':sha(O/'claims_review.json'),'base_catalog_sha256':sha(B),'source_sha256':sha(T),'active_units':len(records),'unchanged_ID_assessments':len(retained),'moved_assessments':len(moved),'rewritten_predecessors':128-len(retained)-len(moved),'new_units':len(changes),'schema_errors':validate_claims_review(read),'unique_actual_bindings':True,'unique_IDs_quotes':True,'summary':summ}
(O/'readback.json').write_text(json.dumps(rb,indent=2)+'\n');(O/'claims_review.diff').write_text(''.join(difflib.unified_diff(B.read_text().splitlines(True),(O/'claims_review.json').read_text().splitlines(True),fromfile='canonical',tofile='scratch-proposed')));print(json.dumps(rb,indent=2))
