# Focused citation adoption preparation r2 — scratch only

Prepared against current cdc75df665dd68f783a49d1ce90969dcff91b7cb; donor f28cc370f9907419773c5325fe70a838881fe3d8. Initial continuity fresh; return continuity stale only source after ROOT-owned documentation additions. No packet refreshed.

The eight reviewed source preimages still exactly match donor parent0b6012549428b3a5b40c3e51e0c8a787defaf812 and the prior56fe reviewed preimages. Patch changes seven paths; constants remains exactly current78 until current canonical measurement. The thirteen real additions and sole old Barcelo edition qualification are preserved. No state/dossier/science body copied.

Patch SHA256: eee50f463aa2e18a69c787c7c4eabca317eba7877f0a9e8f91b9054c0ff04e3c
Machine report SHA256: 457683cc7085365530399e8041a557417aed1afa13ec6bb1f7aa6e2aab3a43d2
Preparation script SHA256: 386675a4920cb06aaf17ab28f552353b2565d4bbc942c296611fb3efab77999a
Sequence SHA256: 669ee57075132bd201e8406183b5af36d0788156ba23d657b833b14f47fd12bf

git apply --check=0; isolated existing-function AST/stdlib mock: pre-existing5, no fetch_one/transport/disk sidecar writes; all held bytes/modes/mtime conserved. Candidate source/state/Git unchanged by preparer; observed ROOT documentation diff conserved. No tests/project imports/fetches/actual application/writers run. Scratch preparer corrected an initial clean-status guard after ROOT concurrent docs authorization, AST literal reader for annotated PAPER_TO_PHASE, and missing TIER_EXTENSIONS mock binding before successful final preparation; no scientific or runtime result inferred from those scratch-only setup failures.

## Exact path preimages and prepared postimages

| Path | Current preimage SHA256 | Prepared postimage SHA256 |
|---|---|---|
| papers/D1/paper_draft.tex | 0e0ae1be8970816add86ed9491f53f0975660bb02b917f9ecb1ff87c403d1138 | badd7db66a368bc0a80620e10e552e2a56d52ac0fc65f63f60b9651b6a1ee614 |
| papers/D3/paper_draft.tex | 55642bb6be98c68f2feb6cece25b1d7ce405a4f336aeb2807fc206c2a66fac22 | e60c583110b8de5884a62b67ad21aa268da718632528b178a6b519224ce4b15c |
| papers/D8/bibliography.bib | 859f72ecf366bfdf78153db56478847fcefa003d861d3368d6042d66e1ceece2 | 709d0a92da6689ca54e331c18c6e0758582f07512fa9293e586b8e6f784dd4ab |
| papers/D9/paper_draft.tex | d14aa1a4dfa7d8a41923700a179b8925626a2114ebb368a451c69c1e58524fab | c2514912b42cb7eb615791f4030e0dfca5f4d58b8d3ca1263e99834e930d690d |
| papers/E1/paper_draft.tex | 42480eb34627c37ecda4ebdace02ad243d8776e451fcef23d4e1bca5faf30233 | 3570323f966b0bdd488c0af6de76d1e27006fdd848409c47a4412d81796996b1 |
| src/core/citations.py | d0d2720d845ce9fee73bf2ba8b3c3c01b45df41c1212327a5c737c997fb56210 | 3b42687dec73ff6d147bb8b72fae261aed285f706373f95845b74b0322b3d608 |
| src/core/constants.py | 0efa3ffd37d57cec4a942f922d0717024398d70ec33049f57a5e19a06fc32c15 | 0efa3ffd37d57cec4a942f922d0717024398d70ec33049f57a5e19a06fc32c15 |
| tests/test_d5_citations.py | bab2e802e8a4bfc948209fa00da1b441bc67c83373d042f55b22a0bbb4040a2e | c020863fedcf33c9d21527530c7108e3d2c429d7ddf31428a0bb63422f99633b |

State preimage (excluded from patch): b3e7f4e33d3304f6512cfc5450ecf7f8bfe155ddf79b8df82039cc978c07929d

## Source fidelity retained

Barcelo2011 holds2011v3 author preprint, not2005/2024 edition or published journal body. Existing oldBarcelo2024 artifact is not altered, but its wrong-edition declared path is removed; filename fallback limitation remains open. Finazzi is1103.4841v2, not1204.3039 proceedings; Kitaev heldv3 dates2008 while publication is2006; Wang holds2024v1 author preprint with different title/author ordering from2026 publication, with no universal revision-equivalence claim. Verlinde Crossref JSON is metadata ONLY, no abstract/body; its load-bearing content obligation remains unresolved. Internal8 companions remain actual titled manuscripts in preparation with null DOI/arXiv/cache, no fake deposits.

## Input report hashes

- /tmp/l1-citation-predecessor-review.md: 401bca3038e1d32a6782a76ca1deb9faad8d6d8dc99b7ab221b1c57f7050bf0f
- /tmp/l1-citation-predecessor-review.json: d30ca8f8a1329e23ab50f3091bb0d8d5dd981f43959a296d6c94d769456bc878
- /tmp/l1-citation-predecessor-populations.json: 7b336b3bd1045fa33fbd5dc6d839b32dac42ac6299fccea6ccd2dfecda412708
- /tmp/l1-citation-predecessor-held-and-preimages.json: 3b75060e39199d2ffc30652fc2a8e7f24ef23df5e3f3fa07b121eadad91672e2
- /tmp/l1-citation-predecessor-companion-identities.json: 8ebde1f67e6af85e129e824aa7af1448e85d355686276076900fbfda66061c9d

## ROOT execution and acceptance sequence

CURRENT ACCEPTANCE SEQUENCE (ROOT only; none executed by preparer)

1. Reconcile continuity: initial packet fresh; final source staleness is expected ROOT documentation activity, not authorization to refresh. Reissue packet only after ROOT reads current diff. Pin HEAD and all eight preimages from JSON, preserve actual existing ROOT docs, complete state sidecar, ledger, IMPORTS/G4, human state and scientific sources. git apply --check /tmp/l1-citation-adoption-preparation-r2.patch must remain 0. Independently review this scratch patch before deliberate ROOT application. Seven changed files is intentional: constants is the eighth reviewed path, retained unchanged at78. Never normal-merge f28's13 unrelated ancestry commits, transplant old29-file e340 package, or copy donor primary_sources_state success rows/render dossier.

2. After source application and before any writer: inspect active script's SK_ROOT=the candidate, SIDECAR_PATH=candidate/docs/primary_sources_state.json, PROJECT_ROOT=workspace, and find_workspace()=the existing workspace. Read existing state; five alias keys must still be absent and every old entry must be captured for deep equality afterward. Existing source-defined bibkey_phase plus load_entries(include_stubs=False) must yield exactly the five requested external aliases and their real existing Phase-1-and-Background file paths. Preserve bytes/SHA256/mode/mtime_ns for all five and canonical alias files, as in JSON. Four PDF files start %PDF-; Verlinde JSON is Crossref work metadata and has no abstract/body. The supplied stdlib mock independently ran only extracted existing Entry/FetchRecord/load_entries/find_on_disk/run_fetch function nodes, literal registry/phase data, and a memory-only sidecar; httpx Client was replaced by an inert object and fetch_one by an exception. It returned {'pre-existing':5} without a fallback fetch, transport call or state write. This confirms the existing branch for the present held bytes; it is not an actual acquisition receipt and is not a replacement implementation.

3. ROOT may now run existing writer one selected alias at a time, without --force, only while the no-fetch file preflight still holds. Existing CLI has no --no-force option: omission of --force is required. Exact commands:
python -B scripts/back_fill_primary_sources.py --fetch --no-stubs --bibkey Barcelo2011
python -B scripts/back_fill_primary_sources.py --fetch --no-stubs --bibkey FinazziLiberatiSindoni2012
python -B scripts/back_fill_primary_sources.py --fetch --no-stubs --bibkey Kitaev2006
python -B scripts/back_fill_primary_sources.py --fetch --no-stubs --bibkey Verlinde1988
python -B scripts/back_fill_primary_sources.py --fetch --no-stubs --bibkey Wang2026TMDPolariton
Each summary must be pre-existing1 (or independently explained current skipped-cached1 on deliberate retry), and no success-fetch/no-source/fetch-failed branch. No --limit workaround: that limit counts fetched entries, not pre-existing ones. After each write assert old entries deep-equal, added keys exactly the requested prefix of the five, correct live fetched_at, url_used=null, note='pre-existing on disk; recorded without re-fetch', actual size/path/tier. Sidecar _schema_version remains1; generated_at may advance and ordering may normalize through existing writer. These are current file-registration timestamps, not fresh download times. Never relabel Verlinde crossref-json as full content; canonical fidelity must remain metadata. Rehash and compare held-file bytes/mode/mtime_ns after writer. Stop if any preflight changes rather than allowing fetch fallback.

4. Run canonical measurement from established current environment and retain full details/exit/status, not summary-only:
python -B scripts/validate.py --check citation_primary_sources_present --no-memo
Require missing-registry0 and required-cache0, no invalid declarations, no silent scope reduction; preserve metadata/abstract warnings. Measure actual undeclared_class count on CURRENT corpus before editing constants. Donor76 and older75 are only historical numbers. If measured count N<78, ROOT tightens only CITATION_UNDECLARED_CLASS_CEILING to measured N; N=78 means retain78. Any N>78 is a regression, not permission to raise ceiling/exempt residue. Inspect complete summary and details; a green missing-key result does not establish full body/source137/scientific acceptance.

5. Once baseline canonical check is genuinely green and ceiling zero-headroom, serialize production-seeding tests so no other candidate readers/writers or broad tests overlap. Capture full prepared source/state/held artifact hashes+metadata before controls. Existing controls (run their containing class together so setup/restoration remains canonical):
python -B -m pytest -q -p no:cacheprovider tests/test_d5_citations.py::TestExemptionIsClaimedNotInferred
Require test_the_undeclared_ceiling_has_ZERO_headroom and test_seeding_AWAY_a_declaration_turns_the_check_RED pass. Declaration-removal seed must actually reach imported KobayashiNomizu1963, canonical undeclared detail must fail with CEIL+1, and baseline must be green; an already-red missing-key result proves nothing. Preserve other DOI-on-declared-textbook and typo-class guards. Existing seed_journal must restore original bytes/mode/mtime, no surviving PID-owned/residue journal mutation. Then:
python -B scripts/validate.py --check seed_residue_absent --no-memo
python -B scripts/validate.py --check citation_primary_sources_present --no-memo
Compare exact prepared hashes (not HEAD, since intended adoption is uncommitted), full state-entry equality and artifact metadata before/after; inspect git diff for only intended adoption+ROOT-owned docs/writer-derived changes. Never git-reset other people's changes.

6. Run complete existing relevant test modules including slow extraction explicitly once, preserving tmp_path isolation, zero-stub and zero-orphan assertions, and metadata/title/edition controls:
python -B -m pytest -q -p no:cacheprovider -m '' tests/test_d5_citations.py tests/test_phase6i_wave1.py tests/test_workspace_resolver.py
Separately execute unchanged declared cache1.2 Verify:
python -B -m pytest -q -p no:cacheprovider tests/test_phase6i_wave1.py tests/test_workspace_resolver.py
No deselection hiding slow extraction in the first command. Reconcile all13 registry identities, original10 stub-backed vs3 D8 orphan keys, internal8 true inprep records with null external identities/cache, sole changed old Barcelo record, and bibliography-only manuscript scope. Recheck seed residue and byte/mode/mtime restoration after all production mutation tests.

7. Independent current source/state/fidelity/control reviewer accepts exact final source hashes, writer receipts, old-state conservation, held hash/revision distinctions, full command results/restoration and unchanged science. Source acquisition register is existing derived writer: inspect its --check and, if stale from this actual citation input change, regenerate using python -B scripts/source_acquisition_register.py then python -B scripts/source_acquisition_register.py --check. Do not manually change curated overlay/source claims to hide debt. For tracked derived counts/census/inventory use existing writers only and archive exact diffs: python -B scripts/update_counts.py (may invoke existing Lean dependency extraction; ROOT must enforce current read-only preflight/capacity rules; no cache/build repair from this task); python -B scripts/module_census.py --write only if its input-derived document actually needs regeneration. Existing canonical freshness readback: python -B scripts/validate.py --check counts_fresh architecture_inventory_fresh module_census_fresh --no-memo. These validators can regenerate through existing writers; preserve Lean/Aristotle/all unrelated typed values and scientific/human data. Do not use this focused patch as a reason to run new infrastructure, add gates, invent aliases, or waive unrelated red findings. Frozen16fde9 full7119pass34fail evidence is unchanged and not superseded by scoped green tests.

8. Once reviewed source/state/control checkpoint is committed by ROOT, only existing close_finding writer may close the original cache-file infra1.2, retaining original whole Verify (writer reruns it). Concrete schema:
python -B scripts/close_finding.py --doc papers/AutomatedReviews/2026-10-19-managed-worktree-paths/infra.md --section 1.2 --status fixed --commit ACTUAL_REVIEWED_SOURCE_COMMIT --evidence 'Actual current source/state/control review path and exact relevant receipts; original declared Verify green and restoration confirmed.'
Replace actual commit/evidence with real reviewed values, not donor or this scratch report. No --verify override to substitute a narrower test, no fake date/commit or hand-edited ledger. Verify writer changes only intended closure and conserves old ledger entries. Rebuild/read canonical existing graph/gate evidence through ROOT's existing process and read back original finding id status and source-qualified limits. A cache1.2 implementation closure does not close SOURCE137/load-bearing full-body obligations, physical B3, publication stages/human review, main/full/native/security acceptance, or authorize publication.

