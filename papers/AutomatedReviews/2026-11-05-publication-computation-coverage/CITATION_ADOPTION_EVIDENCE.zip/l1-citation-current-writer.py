import contextlib
import hashlib
import io
import json
import runpy
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd().resolve()
WORKSPACE = ROOT.parent
PREFIX = Path('/tmp/l1-citation-current-writer')
proposal = json.loads(Path('/tmp/l1-citation-adoption-preparation-r2.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def metadata(p):
    st = p.stat()
    return {'sha256': sha(p), 'size': st.st_size, 'mode': st.st_mode, 'mtime_ns': st.st_mtime_ns}

for row in proposal['focused_paths']:
    path = ROOT / row['path']
    assert sha(path) == row['prepared_postimage_sha256'], row['path']

statepath = ROOT / 'docs/primary_sources_state.json'
assert sha(statepath) == proposal['state_preimage_sha256']
before = json.loads(statepath.read_text())
keys = [row['key'] for row in proposal['held_sources']]
assert len(keys) == 5 and len(set(keys)) == 5
assert not set(keys) & before['entries'].keys()
held = {row['path']: metadata(Path(row['path'])) for row in proposal['held_sources']}
for row in proposal['held_sources']:
    assert held[row['path']]['sha256'] == row['sha256']

def refuse_network(event, args):
    if event in {'socket.connect', 'socket.getaddrinfo'}:
        raise RuntimeError('No network permitted: current pre-existing-file registration only')

sys.addaudithook(refuse_network)
module = runpy.run_path(str(ROOT / 'scripts/back_fill_primary_sources.py'), run_name='writer_receipt')
assert module['SK_ROOT'] == ROOT
assert module['SIDECAR_PATH'] == statepath
assert module['PROJECT_ROOT'] == WORKSPACE
assert module['LIT_SEARCH'] == WORKSPACE / 'Lit-Search'
entries = {e.bibkey:e for e in module['load_entries'](include_stubs=False)}
for row in proposal['held_sources']:
    tier, path = module['find_on_disk'](entries[row['key']])
    assert path == Path(row['path']) and path.stat().st_size > 0
    assert tier == ('crossref-json' if row['key'] == 'Verlinde1988' else 'arxiv-pdf')

started = datetime.now(timezone.utc)
receipts = []
for i, key in enumerate(keys):
    stdout, stderr = io.StringIO(), io.StringIO()
    argv = ['--fetch', '--no-stubs', '--bibkey', key]
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        code = module['main'](argv)
    assert code == 0 and "summary: {'pre-existing': 1}" in stderr.getvalue(), key
    current = json.loads(statepath.read_text())
    assert current['_schema_version'] == before['_schema_version'] == 1
    assert set(current['entries']) - set(before['entries']) == set(keys[:i+1])
    assert all(current['entries'][k] == v for k,v in before['entries'].items())
    rec = current['entries'][key]
    assert rec['url_used'] is None
    assert rec['note'] == 'pre-existing on disk; recorded without re-fetch'
    assert rec['verdict'] == 'success'
    assert datetime.fromisoformat(rec['fetched_at']) >= started.replace(microsecond=0)
    assert rec['size_bytes'] == Path(WORKSPACE / rec['primary_source_path']).stat().st_size
    receipts.append({'argv':argv,'exit':code,'stdout':stdout.getvalue(),'stderr':stderr.getvalue(),'record':rec})

assert all(metadata(Path(p)) == data for p,data in held.items())
PREFIX.with_suffix('.json').write_text(json.dumps({
    'started_at':started.isoformat(),'finished_at':datetime.now(timezone.utc).isoformat(),
    'source_checkpoint':'85a4c7275','writer_script_sha256':sha(ROOT/'scripts/back_fill_primary_sources.py'),
    'actual_main_invocations':receipts,'network_audit_hook':'refused socket connect and name resolution',
    'all_old_state_entries_conserved':True,'held_bytes_mode_mtime_conserved':True,
    'held_metadata':held,'state_before_sha256':proposal['state_preimage_sha256'],
    'state_after_sha256':sha(statepath),'scope':'existing-file registration; no source download or full-body fidelity acceptance'
},indent=2)+'\n')
print(json.dumps({'registered':len(receipts),'old_entries_conserved':True,'held_unchanged':True}))
