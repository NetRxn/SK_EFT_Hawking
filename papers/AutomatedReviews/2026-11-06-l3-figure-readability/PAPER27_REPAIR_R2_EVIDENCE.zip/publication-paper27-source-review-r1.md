# Paper27 independent source composition review R1

**REVISE**, for one necessary source-attribution echo. This verdict is limited to the exact unapplied single-file proposal. It grants no physical, native, compiler, visual, full-paper or publication acceptance.

## Required correction

**R1-1, major, postimage VIII lines436–444.** “Each anchored to a primary-source-grounded prediction” still describes all four falsifiers. Item1 immediately below now correctly compares a candidate against the *chosen exponential*; item4 concerns the project-original response ansatz. The unchanged universal opening therefore restores the same source/model attribution that III.B and XI repair. Replace it with a literal description of four mathematical checks on specified profiles, supplied sign hypotheses, approach-time predicates and the response ansatz. State their model-conditional scope without implying independently established physical ADW predictions. Preserve all four theorem statements and hypotheses. This is a minimal necessary echo correction, not a request to redraft unrelated literature or to construct the missing physics inside this prose patch.

## Exact reconstruction and conservation

I read the complete current679line manuscript and full662line postimage in order through enddocument, and the complete patch. Independently reconstructed every hunk from the actual current source in memory, checking every old context/deletion byte and each old/new hunk count. Reconstructed postimage exactly equals the proposal JSON. Preimage39cddf7586d4828991a27f0b1803b6256af5a65fbdb32efb45ae0a92fbc063ba; postimage6058b9c360ba50966ef350b5c4131a7fa46361db35df06ccd8835e78485df875; patch37112831c31bf15f467cb7f6856ef65b79148719af321d4b72ad1917398c1c35.

All seven complete displayed equation/align environments are byte-identical, checked separately and hashed in JSON. The full accepted figure environment, width, placement, label and caption are byte-identical; the entire bibliography is byte-identical. No mathematical formula or accepted figure change is needed for R1-1. Token repairs remove the offending module path, retired theorem identifier and internal review path while retaining the substantive entropy limitation. Actual clipping/overflow resolution remains unmeasured here and needs the forced canonical compiler and independent complete-page review.

## Source and theorem assessment

Read the held Balbinot TeX whole sections “The backreaction equations near the horizon”661–796 and “The fate of the acoustic black hole”960–1026. The former explicitly restricts the static-source calculation to cκt≪1. The latter gives the local affine563/(720π) temperature correction and explicitly extrapolates the late-time t∼1/T³ discussion. Neither provides the chosen exponential or identifies nozzle time with horizon affine time; the variable-sound-speed condensate is deferred. The proposed III.B, VII and necessary abstract/introduction corrections faithfully state those limits.

Read the actual complete Python acoustic_evolution module: its executable return is T_H0*exp(-t/tau_cool). Read actual Lean definitions/carriers and proof bodies, including the newer cutoff identities, schwarzschild_profile_deriv, balbinotAffine_deriv and regime_partition_profile_criterion. The latter derives actual local derivatives under a supplied differentiable losing-mass trajectory and a supplied positive-parameter nozzle short-time budget; it does not identify a physical ADW trajectory or bound the truncation remainder. The proposal credits that stronger existing mathematics and does not infer its absence from the older index. Native/index qualification remains separate.

The classifier criterion transports its two supplied sign fields. The acoustic mechanics theorem returns its supplied FourLaws value and reads a supplied negative sign under classification. G_N positivity follows from ADWParams; ADWSecondLaw holds a supplied scalar divergence sign plus the already-positive BHData area. The falsifier_third_law_form quantifiers express incompatible uniform-tail/uniform-bound predicates, without constructing a physical approach-time function. The entropy anchor has only G_N and its positivity as hypotheses; the Kaul–Majumdar definition at A=4G_N exp2 gives exp2−3, but contains no endpoint temperature/dynamics identification. The proposed interpretations of these results are accurate and do not erase stronger source substrate.

Read the owning Phase6a Wave5 roadmap311–349 and actual module Git history (42dd2d3a4, fe154d98f, ad75a3e62). Historical completion/descriptive claims are not substituted for actual theorem types. Directly checked relevant compiled declaration types in the current lean_deps index. No Lean/LSP tool was admitted or used; this review makes no project-wide absence claim.

## Composition and original charter

The repaired manuscript is about a conditional mass classifier together with specified local temperature profiles and the limits of those models. Its new conclusion explicitly preserves the original full physical four-laws construction: action/selected background/state, horizon and generator, variations/charges, entropy/current and energy balances, calibrated mass/cutoff/transport matching, condensate dynamics, controlled remainders and late-time/affine-time evolution. ROOT's existing BUILD ownership and original queue remain intact. Correcting exaggerated completion prose is not a recharter, waiver or construction discharge.

The new abstract gives the conditional result early; III.B, IV/V, VII, IX and X now distinguish supplied hypotheses, mathematical derivative proofs and physical interpretation coherently. R1-1 is the remaining reader-level contradiction in the assigned propagation repair. An optional precision improvement at314–315 is to use singular language: only the M_c positivity field among H_RegimePartition's five fields is implied automatically by ADWParams positivity. This does not block the main correction.

Broader process vocabulary/self-narration, novelty/absence assertions, other second-law/charged-matter/BPS literature claims and Wave2 matching are acknowledged existing OPEN debt outside this focused acceptance; they are not silently passed here. Paper27 has no bundle_metadata.json at the assigned manuscript directory, so no length-target judgment is inferred. No full sentence-state or global claims/citation/novelty review is claimed.

## Custody and next review

Read the original review packet, notebook/roadmap/authorities, actual claims/prose reviewer roles, paper-authoring skill and both mandatory references. The exact original packet check returned exit0/freshtrue/changed[] during review and again at report creation; no refresh was performed. Actual target remains the pinned preimage at candidate36129dd19c321035aeb0c649600dc15468072205. Only this report and its companion JSON were written. No repository/source mutation, build, compile, runtime/controller/Lean operation, Git mutation or closure was performed.

ROOT should preserve R1 immutable, obtain the minimal R2 echo repair and an independent exact-delta re-review, then apply only the accepted source. Forced canonical compilation and fresh complete-page visual review remain required before consumer finding closure. Full native, physical and publication gates remain separate.

## CONTRADICTIONS BETWEEN THE BRIEF AND THE SOURCES

The brief's central source/type distinctions are supported. The proposal's claim that necessary attribution echoes are repaired is incomplete at VIII436–444: its universal primary-source attribution still includes the separately chosen exponential and original response ansatz. The sources warrant the requested narrow correction. No broader physical absence, infeasibility or reduced-scope acceptance follows.
