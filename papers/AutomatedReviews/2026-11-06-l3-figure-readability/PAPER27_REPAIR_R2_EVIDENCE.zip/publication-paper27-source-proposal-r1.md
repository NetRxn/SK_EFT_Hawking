# Paper27 body source-fidelity and typography proposal R1

**UNAPPLIED single-file proposal.** No repository source, figure, PDF, metadata, ledger or runtime has been changed. Original physical four-laws BUILD remains OPEN at full strength. This proposes accurate corrections while substantive construction proceeds; it is not reduced-scope scientific acceptance.

## Candidate and custody

Candidate `.publication-l3-crossing-main`, exact HEAD `db4b41ef2edeeb4114bfe5429e64cce40e962a7f`. Owned output is only this report and its companion patch/JSON under `/tmp/publication-paper27-source-proposal-r1`. Initial and final SAME original packet checks return exit0/freshtrue/changed[]. No packet refresh. ROOT remains the notebook writer and integration/acceptance owner.

The complete original Paper27 manuscript was read through enddocument, together with actual governing AGENTS/CLAUDE/pipeline/continuity, paper-authoring skill, both mandatory references, paper-drafter role, exact notebook/roadmap and the complete independent R3 source/actual-render reports. This author did not repeat the visual review.

## Direct source and substrate evidence

Read the held Balbinot primary TeX directly: whole sections “The backreaction equations near the horizon” (661–796) and “The fate of the acoustic black hole” (960–1026). The former explicitly limits the static-source solution to small c*kappa*t; the latter gives the affine Tsonic coefficient563/(720pi), explicitly calls the late-time t~1/T³ discussion an extrapolation, and defers the variable-sound-speed condensate. No exponential solution or horizon-affine-time identification is supplied by those sections. Full primary hash/path are in JSON.

Read the complete180line current acoustic_evolution implementation. Its actual function returns T_H0*exp(-t/tau_cool); its accepted docstrings already distinguish that illustrative definition from the primary affine nozzle profile. The WKB docstring was inspected as residual attribution debt, not accepted as evidence that the primary ODE system has been implemented.

Read the complete968line BHThermodynamicsFourLaws module, including the later cutoff/local-profile additions and actual carrier/proof bodies. The exponential is literally defined; the conditional regime theorem reads the two supplied sign fields. The stronger existing profile theorem derives slopes under an explicit positive, losing-mass trajectory and supplied local nozzle domain. Both FourLaws structures contain positivity/scalar sign/ansatz fields; the acoustic mechanics theorem takes and returns its supplied structure. ADWSecondLaw holds a supplied scalar divergence sign and the already-positive area. The entropy-anchor theorem takes only G_N and positivity; it has no temperature/evolution argument.

Actual compiled declaration types for the exponential, conditional mechanics theorem and entropy anchor were checked in the current lean_deps index. The new local-profile declarations are present in actual source but not yet indexed in this focused candidate; this is pending native/index qualification, not a conclusion of source absence. No Lean/LSP call was admitted or performed. Module Git history and owning Phase6a Wave5 roadmap were read; stale summary/docstring/roadmap completion claims do not override actual types.

## Exact proposed repair

The patch corrects III.B’s false exponential/full-coupled-ODE attribution, VII’s unproved affine-time guarantee and XII’s full-four-laws/structurally-complete claim. Their necessary echoes in the abstract/introduction, IV/V mechanics account, VIII exponential falsifier, IX carrier audit, X entropy interpretation and XI source flags are corrected coherently. Leaving those echoes unchanged would preserve the same contradiction elsewhere in the same manuscript. No scientific objective is rechartered: the title is unchanged and the conclusion explicitly retains the original full physical four-laws construction as required. An internal TeX comment points to the existing repair/disposition map, without adding a second task ledger or internal reader-facing process text.

The proposal replaces the oversized module path with its unambiguous filename, removes the retired-theorem drafting history while preserving the scientific limitation of the actual entropy anchor, adds permissible break opportunities to the current long anchor identifier, and moves the internal acknowledgment/review history out of reader-facing text. No font-size/length waiver is introduced. Exact long-token repair still requires real compile and visual verification; this author does not predict a zero-overfull result.

All displayed equation/align blocks, the complete already-accepted figure environment/caption/placement and the entire bibliography are byte-exact. Numerical definitions, Lean/Python source, tests, metadata/registries/closure records and all other files remain untouched. Full pre/postimages and individual change descriptions are in JSON.

## Original scientific obligations remain owed

The physical microscopic action/selected state/background, horizon/generator, thermodynamic variations/charges, acoustic energy/entropy balances, physical susceptibility/transport and cutoff matching, condensate sign, controlled remainder, late-time evolution and affine-time approach law remain original BUILD objectives. The entropy anchor also needs physical endpoint identification before a Nernst conclusion. These are not discharged by truthful prose or the local profile theorem. Current Phase6a completion claims and related WKB/Lean attribution must be reconciled separately.

This is not a complete Paper27 claims/prose or Stage13 review. Existing broader taxonomy/self-narration, Wave2 metric-speed/thermal matching, literature claims in the unchanged second-law/charged-matter/BPS passages and universal novelty wording remain outside the accepted evidence of this proposal. Their retention does not endorse them. The changed scalar-carrier account is established from actual types, without claiming the prior literature was re-reviewed.

## Next acceptance

ROOT and a fresh independent source/prose reviewer should inspect the full single-file postimage against the same source locations and original physical charter. On acceptance ROOT can apply only that patch, force the existing canonical out-of-tree compiler, confirm all three reported body-overflow defects are actually repaired without new clipping/length problems, and obtain fresh all-page visual review. Preserve exact accepted L3/Paper27 figure bytes and L3 source. Native/index and complete publication/physical acceptance remain separate. No finding closure is proposed here.

## CONTRADICTIONS BETWEEN THE BRIEF AND THE SOURCES

The assigned body defects are substantiated. The source also contradicts the same late-time/physical-completion implications in the abstract/introduction and conditional-mechanics/entropy sections; the proposal includes their necessary echoes rather than leaving an internally contradictory account. The actual newer local-profile theorem is stronger than an assumed scalar sign but still has explicit trajectory/domain hypotheses; it must not be missed because the current focused index has not yet been refreshed. The owning roadmap’s shipped full-four-laws account and several inherited module comments overstate what the inspected carrier types prove. Those remain separate scientific/completion reconciliation debt. No absence, infeasibility, accepted deferral or reduced scientific scope is inferred.

## Hashes

- preimage_sha256: `39cddf7586d4828991a27f0b1803b6256af5a65fbdb32efb45ae0a92fbc063ba`
- postimage_sha256: `6058b9c360ba50966ef350b5c4131a7fa46361db35df06ccd8835e78485df875`
- patch_sha256: `37112831c31bf15f467cb7f6856ef65b79148719af321d4b72ad1917398c1c35`
