# Independent L3 figure-source review r1

Verdict: **ACCEPT_SOURCE_ONLY**, exclusively for immutable `/tmp/publication-l3-figure-author-r1.patch`, SHA256 `8f163921a1f090212545cda9f1b12e0e6fe749f95c31d6bff8a8e4c37a8e08de`, against focused candidate `42dd2d3a41a693dd4ca48e4669f7f3a69944006a`. This permits ROOT to consider that exact source proposal. It does not accept a generated figure, complete source attribution, runtime behavior, publication readiness, or the physical four-laws BUILD.

The initial original reviewer-packet check returned exit 0, fresh true, changed []. The final same-packet result is appended below and in JSON; no refreshed packet is used. No repository file, notebook, source, test, generated figure, or Git state was changed. Only the two assigned `/tmp/publication-l3-figure-source-review-r1` reports were written. ROOT remains acceptance reviewer and notebook writer.

## Independent source/scientific assessment

I read the actual complete candidate producer, complete supplied patch, complete changed-function postimage and author rationale; the current carrying manuscript section and caption; the original stronger review 3.2; the held Balbinot TeX's complete fate-of-hole section; relevant Wave 5 goal, current primary notebook disposition, CLAUDE/pipeline/continuity authorities and figure/claims reviewer contracts. This is a bounded source review, not the full sentence-walk or actual PNG review those roles require for publication.

The repair changes real plotted coordinates. In the actual source the raw Schwarzschild grid is 0..4.5, its mass is `(1-0.2*t)^(1/3)`, and lifetime is 5. Passing `t_grid_schw/5` gives X in [0,0.9]; the unchanged Y is `(1-X)^(-1/3)`. It starts at 1, increases on that domain, and ends at `10^(1/3)` (about 2.1544). This is the correct normalized representative trajectory and stops before the endpoint singularity. These conclusions are symbolic source analysis, not an executed producer result.

For blue, actual fixed T_H0=1 and tau_cool=1 give Y=exp(-t/tau_cool), and explicit X=t/tau_cool gives Y=exp(-X), X in [0,5]. The existing function returns T_H0 times math.exp(-t/tau_cool), which I read directly. With the fixed initial amplitude the displayed Y is correctly normalized. Its independent positive cooling timescale is not the Schwarzschild lifetime. No relative physical timescale calibration, common absolute-time evolution, mass-dependent acoustic trajectory, matching through the cutoff, or source-derived full evaporation solution follows from putting these independent normalized axes on one horizontal scale.

Held Balbinot Eq.(Tsonic), lines989-994, is `T=(hbar*c/(2*pi))*kappa*[1-(563/(720*pi))*epsilon*kappa^3*c*A0*t]`, with an initial negative slope for positive parameters. The carrying section states the near-horizon lower-dimensional Polyakov/static-source approximation and only preliminary departure from the classical configuration. Its subsequent `Delta T proportional to -T^4 Delta t` and `t~1/T^3` discussion is expressly an extrapolation. That inverse-cubic law is not exponential decay. The constant-sound-speed Laval-nozzle case does not establish a condensate law; the authors explicitly defer c proportional to sqrt(rho). The revised docstring accurately separates these facts and the chosen exponential. Its source qualifier 'local cooling sign only', illustrative legend/title, and infinite-time annotation avoid attributing the plotted blue curve to that source. The standard Schwarzschild temperature relation explains heating for decreasing positive mass; the figure's representative mass-cubed trajectory is separately labeled. The held full Hawking text was not independently re-audited here.

The actual current manuscript lines170-208 already writes the local affine law, positivity/short-time conditions, a separate exponential, the missing condensate derivation and required remainder-derivative bound. Current caption214-224 explicitly calls blue illustrative and distinguishes plotted profiles from the local affine criterion. It also describes the actual focused cutoff/crossing right panel, unlike the obsolete main-branch response-panel caption. No mandatory manuscript edit follows solely from this source correction. Adding independent-timescale and 0.9 truncation language to the caption would improve standalone clarity, but its present source attribution is already qualified.

## Exact conservation independently checked

I reconstructed the unified patch in memory by matching every context/deleted line against actual source, without Git apply or repository writes. AST parsing of that full reconstructed source succeeded. Its full function matches the author's complete embedded postimage exactly. Prefix and suffix outside this single function are byte-identical. Independent SHA256s:

- Actual preimage file: `7cb4897323d91ceaa6c63859a8b66dc52cc3948b4122d06b5c0fc94a2eec84c8`.
- Reconstructed complete proposed file: `6d1aa4fbeb1ebb02cd451c1021dd088a8682fd92da178b4b1066bb8f3ed86afc`.
- Complete changed-function postimage: `428db561f074467518e79e1ecd9f1a06b93c90ebf465bae7adbf09472dd25553`.
- Right-panel block: `cabc55dc779d2ecf85409d0deecebc13352cda04ec1cd9c8a5a90518b84b4823`.

The complete right construction is byte-identical: fixed positive parameters, canonical gravitational coupling, critical mass, sampled mass ratios, both traces, dedicated legend, both shaded regions, boundary line and annotation. Unchanged right axes/layout are visible in the full source/patch comparison. Directly reading M_c_default and G_N_emergent also shows G_N*M_c=1/Lambda in the stated ansatz, so their dimensionless ratio is M/M_c. This is a model-defined equality, not an independently calibrated universal physical threshold.

All five author-protected file hashes independently match: actual L3 manuscript; complete original review; scripts/review_figures.py; acoustic_evolution.py; tests/test_bh_thermodynamics.py. The complete original stronger 3.2 Verify string is byte-identical to the actual review, including four traces, common mass grid, unit cutoff, unique sampled equality at 1, strict ordering on both sides and exact three shape endpoints. It is reproduced verbatim in JSON; it was not executed or weakened. No formula, assertion, theorem, dependency, charter or scientific acceptance condition was changed.

## Annotation disposition and actual-render limits

Blue (2.8,1.0) is above exp(-2.8), about 0.061, in source coordinates. Moving it away from the previous low tail and removing the extremality claim is reasonable. Actual text extents, line breaks, legend/title/axis clearance and page-scale readability remain UNREVIEWED.

Orange remains (3.5,2.5), while the corrected orange curve ends at X=0.9. This location no longer lies near the orange curve. The text is an unarrowed amber explanatory box, so it is not a claimed orange data point or proof that the trajectory reaches X=3.5. Its color/text can still identify the trend. Source alone does not prove a rendering defect, so it does not require changing immutable r1 before source application. Fresh figure review must explicitly judge that association. If it reads as detached or misleading, move/reanchor it next to the corrected curve (for example, with an arrow to an actual point at X=0.8, Y=5^(1/3), with the text offset into whitespace) and regenerate/re-review. Do not simply replace 3.5 with an arbitrary normalized coordinate without checking text/curve overlap. Both annotation decisions must be reviewed on the actual PNG and at compiled publication size.

The author's visual negative control claiming that restoring the old blue location MUST fail is only an expected outcome. A coordinate token or source inspection cannot establish visual failure; compare actual rendered artifacts independently and report what was observed. Likewise, right-panel source identity does not itself establish identical raster output when the global title/layout changes.

## Mandatory consumer follow-through before broader claims acceptance

1. Qualify the actual FigureSpec caption in scripts/review_figures.py lines1382ff. 'cooling acoustic branches' still suggests the chosen exponential is the physical acoustic branch. Use explicit 'illustrative exponential cooling profile' and, preferably, state independent normalized timescales. Keep four traces, expected axes, structural checks and all substantive checks intact.
2. Correct attribution prose in actual src/bh_thermodynamics/acoustic_evolution.py, including its module opening and T_H_acoustic_evolution docstring. It currently calls the exponential a leading-order form per Balbinot Eq.Tsonic. Keep its API, formula, parameter validation and numerical behavior unchanged; identify it as a chosen illustrative profile and distinguish the source's local affine result/extrapolation.
3. Include actual src/bh_thermodynamics/__init__.py module documentation, omitted from the author's protected-file list, whose acoustic_evolution scope explicitly says 'Balbinot 2005 acoustic time-evolution' followed by the exponential. Its present SHA256 is `befddb903d84317856d8dda5c51b398532ba106ffbe3a40275092b126a429fe7`.
4. Repair explanatory attribution in tests/test_bh_thermodynamics.py, especially the module scope, TestAcousticEvolution class and asymptotic-zero test docstrings. Their assertions about the chosen exponential remain substantive and must remain unchanged. A finite t=100*tau bound is a numerical sample check, not by itself a proof of the mathematical limit or the source's inverse-cubic asymptotic law.

These are actual known provenance follow-ups, not numerical defects. They prevent a whole-source claims-green statement until separately owned changes and independent review. This verdict covers only the exact figure-source proposal; it does not silently absorb those files or declare a global provenance audit complete.

## Remaining production and scientific requirements

After ROOT applies/reconciles source and consumer changes, check actual producer arrays: all 121 orange X/Y samples, domain/endpoints and Y=(1-X)^(-1/3); all blue X/Y samples and Y=exp(-X). Serialized real-production faults restoring raw orange X or wrong divisors 4/25 must be rejected, with exact restoration evidence. Attribution faults restoring the false blue legend or false producer docstring must be detected by semantic source/render review even if numerical arrays stay correct. Preserve and run the original complete strong 3.2 Verify; test actual gravitational/cutoff/boundary faults with every existing predicate retained. Compare actual right-panel arrays, styles, legends and shapes under the same runtime as well as source conservation.

Regenerate through the existing canonical producer, establish output custody/readback into the actual papers/L3/figures PNG, independently inspect PNG against the held source/current manuscript/manifest, compile L3 out of tree through its canonical process and inspect all actual rendered pages at publication size. Existing appropriate scoped and broader project gates and review/closure remain required. No pytest, producer call, simulation, Lean/LSP, build, controller/process operation, extraction/cache work, generated baseline, compile or fault injection was performed in this review.

The original Wave 5 objective is the full Bardeen-Carter-Hawking four laws in the emergent framework, including regime reconciliation; its physical construction remains OPEN at full strength. Current honest manuscript scope says that two laws enter only partially. Correcting these factual attributions and coordinates neither fulfills that BUILD nor authorizes narrowing, retitling away, deferring or accepting its physical obligations. Native qualification of focused42dd and the original production Verify remain pending, exactly as in the notebook.

## Exact reviewer verification commands

Working directory for every candidate command: `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l3-crossing-main`.

Initial/final packet command (same packet, no refresh):

`python3 scripts/codex_continuity.py check /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/publication-l3-figure-source-review-r1.json`

The exact pure-source Python analysis command is embedded under `source_analysis_command` in the companion JSON. It reads/reconstructs/matches/hash-checks/AST-parses only; it imports no project code. Other reviewer commands were read-only cat, sed and rg inspections of the references/paths and sections recorded above. No test/build command in the sources or author report was executed by this reviewer.

Final SAME original reviewer-packet check: exit 0, `fresh: true`, `changed: []`. No refreshed snapshot.
