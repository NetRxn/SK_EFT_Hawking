# L3 figure source proposal r1

Status: UNAPPLIED SOURCE PROPOSAL. Candidate is `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l3-crossing-main` at `42dd2d3a41a693dd4ca48e4669f7f3a69944006a`. ROOT retains L1 leadership and acceptance; the Executor's deep physical construction remit is unaffected. Only the three assigned `/tmp/publication-l3-figure-author-r1` artifacts were written. No repository path or notebook was edited.

## Authority and custody

The original packet is `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/publication-l3-figure-author-r1.json`. Initial same-packet check returned `fresh: true`, `changed: []`. Final same-packet result is recorded in JSON after completion. No packet refresh or continuity waiver is used. The packet's candidate/source hash is the preimage authority, not an execution/closure grant.

Read the complete actual producer, current carrying section/caption, original full 3.2 production Verify, source numerical implementation and existing thermodynamics tests; read CLAUDE, pipeline, continuity contract, figure/claims reviewer contracts, relevant Phase6a Wave5 charter and current L3 disposition/notebook entries, and the held Balbinot TeX's complete carrying fate-of-hole section. Older notebook history is not re-certified. Used systematic-debugging for source tracing. Paper-authoring skill inspected; manuscript editing is not proposed. No new architecture is introduced.

## Exact repair and physical rationale

1. Actual old Schwarzschild raw times are 0..4.5 and `M_t=(1-0.2*t_grid_schw)^(1/3)`, with lifetime5. The old trace plotted raw times under `t/t_evap`. The patch sets explicit `t_evap=5.0` and passes `x=t_grid_schw/t_evap`. All sampled Y values and raw sampling stay byteexact. Thus actual plotted X is 0..0.9 and Y is `(1-X)^(-1/3)`, rather than merely relabeling invalid units.
2. The blue profile still calls existing `T_H_acoustic_evolution` with `T_H0=tau_cool=1`; its actual X is explicitly divided by its own `tau_cool`. The shared horizontal label names which independent timescale belongs to which trace and wraps to two lines. No common absolute clock, physical timescale calibration or matched trajectory is inferred.
3. The blue legend becomes `Illustrative exponential cooling`. Titles and blue annotation describe chosen temperature histories. The source docstring distinguishes the held source's local affine result from the exponential and from its long-time extrapolation; removing the obsolete internal work-unit header also satisfies the original 3.1 source-text requirement without changing that Verify.
4. Blue annotation moves from `(2.0,0.25)` to `(2.8,1.0)` above the low exponential tail and says explicitly that the infinite-time zero limit belongs to the illustrative exponential. This is a proposed placement, requiring fresh PNG review, not a claim of visual acceptance.

Held source: `Balbinot2005PRD.source/acusticpap.tex` lines961-1024, especially Eq.(Tsonic) lines989-994, discussion997-1008, BEC deferral1020-1024. They solve a near-horizon, constant-sound-speed, lower-dimensional Polyakov/static-source approximation. Their leading coefficient is `563/(720π)` in the local linear correction; the manuscript's `cκt≪1` and finite-range positive-temperature conditions belong to its separate local criterion. Their `t~1/T³` is explicitly an extrapolation and is not exponential cooling. No source-derived global acoustic or BEC evolution is substituted.

Current manuscript lines170-208 already says separate illustrative exponential, local nozzle sign, condensate derivation needed and remainder derivative bound; caption214-224 already distinguishes profiles from the local affine criterion. No mandatory manuscript/caption change follows from the coordinate repair. The model's full four-laws construction remains OPEN and full strength; a corrected figure is not that BUILD or a source-calibrated acoustic solution.

## Conserved scientific source and controls

The exact full right-panel construction from its parameter comment through final critical-mass annotation is byteidentical, SHA256 `cabc55dc779d2ecf85409d0deecebc13352cda04ec1cd9c8a5a90518b84b4823`. It still uses the same ADW parameters, canonical `G_N_emergent`, `M_c_default`, 101 samples, cutoff trace, unique equality at ratio1, side ordering, branch shading, boundary, names/legend2/styles and axis definitions. No source numerical formula or signature, Lean, metadata, ledger, registry, checker, pipeline, or test is altered. The Schwarzschild mass/temperature calculation is byteidentical; only its plotted X coordinate changes.

The entire review file, including the original stronger finding3.2 full production Verify and all assertions, is untouched. The original Verify remains copied verbatim in JSON. Manuscript, review manifest, acoustic numerical module and full thermodynamics test file remain untouched with source hashes in JSON. No test relaxation or blanket scope contraction is proposed.

## Consumer follow-through

The existing FigureSpec caption in `scripts/review_figures.py` says representative heating Schwarzschild and cooling acoustic branches. Qualify its cooling phrase to illustrative exponential when lead coordinates canonical regeneration/review; no trace-count/axis/schema change is necessary. This is a consumer prose follow-through, outside this patch's ownership.

The acoustic module and existing tests retain false explanatory attribution of the exponential to Eq.Tsonic. Their chosen-exponential numerical definitions and substantive assertions must remain unchanged. Separately owned attribution-only cleanup is required before whole-source claims acceptance. This proposal neither conceals nor edits that debt.

Canonical generated figure must reach the actual L3 PNG consumer with explicit readback. Then independent reviewers must inspect actual PNG and compiled pages; source-only proposed placement cannot establish absence of overlap. No generated PNG/PDF was created or baseline regenerated here.

## Meaningful production controls and gates owed

The JSON contains complete expected controls. All are PROPOSED, NOT RUN:

- Actual output X/Y relationship for Schwarzschild at every sample, X domain/endpoints and blue exponential; raw-X reversion and wrong divisors4/25 must fail actual producer checks. A correct axis string cannot hide wrong actual coordinates.
- False Balbinot trace-legend restoration must fail source/actual-rendered-text claims assessment even with a correct docstring. Restore old false source paragraph separately; numerical correctness cannot validate attribution.
- Run the exact original full3.2 Verify, preserving every crossing/ordering/shading predicate. Actual right-trace multiplier/cutoff/boundary regressions must fail; compare unchanged right-panel output as well as source bytes.
- Restoring old blue annotation location must fail independent visual review even if arrays pass; inspect linebreak/axis/title/legend overlap at publication scale.

After independent source approval/application: actual normalized-coordinate positives and serialized fault controls with exact restoration; canonical existing producer regeneration and output readback; fresh independent figure/claims review against held source/manuscript; canonical out-of-tree L3 compile and full-page render inspection; existing appropriate pipeline/qualification gates and original exact full3.2 Verify. No canonical closure, native evidence, stage-green or publication readiness is claimed here.

## Artifact integrity and performed validation

Patch SHA256 `8f163921a1f090212545cda9f1b12e0e6fe749f95c31d6bff8a8e4c37a8e08de`.
Preimage full file SHA256 `7cb4897323d91ceaa6c63859a8b66dc52cc3948b4122d06b5c0fc94a2eec84c8`.
Proposed full file SHA256 `6d1aa4fbeb1ebb02cd451c1021dd088a8682fd92da178b4b1066bb8f3ed86afc`.
Full changed-function postimage SHA256 `428db561f074467518e79e1ecd9f1a06b93c90ebf465bae7adbf09472dd25553`.

JSON embeds the entire unified patch and complete changed-function postimage, hashes and conservation notes. Pure-source `ast.parse` of proposed entire file succeeded; exact prefix/suffix and right-panel string conservation were checked without importing or executing the producer. No pytest, Lean/LSP, build, extraction, controller/process operation or scientific simulation ran. Final packet result follows in JSON. Independent review/application and all runtime/render gates remain pending.

Final SAME original packet check: exit0, `fresh: true`, `changed: []`; no refresh.
