from pathlib import Path
import os,sys,subprocess,json,hashlib,shlex
from datetime import datetime,timezone
repo=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l3-crossing-main')
os.chdir(repo);sys.path.insert(0,str(repo/'scripts'))
from seed_journal import seeded_mutation
source=repo/'src/core/visualizations.py'; original=source.read_bytes(); mtime=source.stat().st_mtime_ns
assert hashlib.sha256(original).hexdigest()=='c6f788aefbb2d949565a42bbe4bd92d11419b0a905a7f5aea960eb9988338b81'
proposal=json.loads(Path('/tmp/publication-l3-figure-author-r2.json').read_text())
declared=proposal['original_3_2_verify'].strip('`')
words=shlex.split(declared); inner=words[words.index('-c')+1]
code='''import numpy as np,json,inspect,os,base64
from pathlib import Path
import src.core.visualizations as v
f=v.fig_T_H_evolution_regime_partition();a,b=f.data[:2]
assert Path(v.__file__).resolve()==Path.cwd()/'src/core/visualizations.py'
x=np.asarray(b.x,dtype=float);y=np.asarray(b.y,dtype=float)
assert len(x)==121 and np.all(x>=0) and np.all(x<1)
assert np.allclose(x,np.linspace(0,.9,121),rtol=1e-12,atol=1e-12), 'actual normalized Schwarzschild coordinates'
assert np.allclose(y,(1-x)**(-1/3),rtol=1e-12,atol=1e-12), 'Schwarzschild normalized history'
u=np.asarray(a.x,dtype=float);w=np.asarray(a.y,dtype=float)
assert len(u)==121 and np.allclose(u,np.linspace(0,5,121))
assert np.allclose(w,np.exp(-u),rtol=1e-12,atol=1e-12), 'chosen exponential actual history'
assert a.name=='Illustrative exponential cooling', 'actual blue source attribution'
assert 'exponential' in f.layout.xaxis.title.text and 'Schwarzschild' in f.layout.xaxis.title.text
orange=[t for t in f.layout.annotations if t.text.startswith('dT_H/dt > 0')]
assert len(orange)==1 and orange[0].showarrow is True
assert f.layout.width == 480 and f.layout.height == 640
assert f.layout.yaxis.domain[0] > f.layout.yaxis2.domain[1], 'panels stack without domain overlap'
assert min(a.font.size for a in f.layout.annotations) >= 16
for axis in [f.layout.xaxis,f.layout.yaxis,f.layout.xaxis2,f.layout.yaxis2]:
 assert axis.tickfont.size >= 16 and axis.title.font.size >= 17
t=orange[0]; assert 0<=t.x<=.9 and np.isclose(t.y,(1-t.x)**(-1/3))
assert np.any(np.isclose(x,t.x)&np.isclose(y,t.y)), 'arrow points to actual curve sample'
'''+f'exec({inner!r}, {{}})'+'''
if os.environ.get('WRITE_OUTPUT')=='1':
 baseline=json.loads(Path('/tmp/publication-l3-figure-baseline-r1.plotly.json').read_text()); current=json.loads(f.to_json())
 assert current['data'][2:]==baseline['data'][2:], 'complete right traces preserved'
 for key in ['shapes']:
  assert current['layout'].get(key)==baseline['layout'].get(key),key
 def array(a):
  return np.frombuffer(base64.b64decode(a['bdata']),dtype=a['dtype']) if isinstance(a,dict) else np.asarray(a)
 assert np.array_equal(array(baseline['data'][0]['y']),w)
 assert np.array_equal(array(baseline['data'][1]['y']),y)
 Path('/tmp/publication-l3-figure-qualified-r3.plotly.json').write_text(f.to_json())
print('PASS actual normalized histories, attribution, sampled arrow and complete original crossing controls')
'''
python='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(repo)+os.pathsep+str(repo/'scripts'),REPO=str(repo))
def run(label,positive=False):
 r=subprocess.run([python,'-B','-c',code],cwd=repo,env=dict(env,WRITE_OUTPUT='1' if positive else '0'),text=True,capture_output=True)
 return {'case':label,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
results=[run('accepted source positive',True)]; assert results[-1]['returncode']==0,results[-1]
faults=[
 ('raw Schwarzschild time','x=t_grid_schw / t_evap, y=T_H_schw_normalized,','x=t_grid_schw, y=T_H_schw_normalized,'),
 ('wrong Schwarzschild divisor4','x=t_grid_schw / t_evap, y=T_H_schw_normalized,','x=t_grid_schw / 4.0, y=T_H_schw_normalized,'),
 ('wrong Schwarzschild divisor25','x=t_grid_schw / t_evap, y=T_H_schw_normalized,','x=t_grid_schw / 25.0, y=T_H_schw_normalized,'),
 ('doubled exponential input','T_H_acoustic_evolution(T_H0, tau_cool, t) for t in t_grid_acoustic','T_H_acoustic_evolution(T_H0, tau_cool, 2*t) for t in t_grid_acoustic'),
 ('false blue source attribution','name="Illustrative exponential cooling",','name="Acoustic / sonic (Balbinot 2005)",'),
 ('off-curve orange arrow','x=0.75, y=(1.0 - 0.75) ** (-1.0 / 3.0),','x=3.5, y=(1.0 - 0.75) ** (-1.0 / 3.0),'),
 ('right gravitational multiplier','gravitational_length = emergent_newton * mass','gravitational_length = 2 * emergent_newton * mass'),
 ('right cutoff level','x=mass_ratio, y=np.ones_like(mass_ratio),','x=mass_ratio, y=2*np.ones_like(mass_ratio),'),
 ('right boundary line','x=1.0, line=dict(color="rgba(80,80,80,0.6)", width=1, dash="dot"),','x=1.1, line=dict(color="rgba(80,80,80,0.6)", width=1, dash="dot"),'),
]
for name,old,new in faults:
 assert original.decode().count(old)==1,name
 with seeded_mutation(source,lambda text:text.replace(old,new,1),reason='L3 actual producer control: '+name):
  result=run(name); results.append(result); assert result['returncode']==1,result
 assert source.read_bytes()==original and source.stat().st_mtime_ns==mtime,name
results.append(run('all actual source bytes/mtime restored',True));assert results[-1]['returncode']==0,results[-1]
assert source.read_bytes()==original and source.stat().st_mtime_ns==mtime
e={'base_commit':'42dd2d3a41a693dd4ca48e4669f7f3a69944006a','patch_sha256':hashlib.sha256(Path('/tmp/publication-l3-layout-author-r3.patch').read_bytes()).hexdigest(),'measured_at':datetime.now(timezone.utc).isoformat(),'source_sha256':hashlib.sha256(original).hexdigest(),'checker_code':code,'python':python,'declared_original_3_2_verify':declared,'exact_original_python_preserved':True,'results':results,'all_source_restoration_exact_bytes_and_mtime':True,'scope':'actual R3 canonical producer; trace arrays/styles and all shapes conserved, panel routing/domain/typography intentionally changed; complete original3.2 command preserved; no simulation/full-tree/physical/publication acceptance'}
Path('/tmp/publication-l3-runtime-controls-r3.json').write_text(json.dumps(e,indent=2)+'\n')
print(json.dumps({'positive_returncodes':[results[0]['returncode'],results[-1]['returncode']],'faults_detected':len(faults),'restoration_exact':True}))
