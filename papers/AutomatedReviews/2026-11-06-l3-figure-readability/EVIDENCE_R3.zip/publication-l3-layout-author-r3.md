# L3 publication-scale figure layout and caption proposal r3

UNAPPLIED bounded proposal against CURRENT APPLIED R2 working source at HEAD`42dd2d3a41a693dd4ca48e4669f7f3a69944006a` in `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l3-crossing-main`. Do not apply against raw42dd or reset accepted R2. ROOT remains L1 lead and owns application, actual qualification, acceptance and canonical closure. Original physical four-laws BUILD remains open at full strength.

Only the three assigned `/tmp/publication-l3-layout-author-r3` files were written. Full4 postimages/pre/post hashes, complete unified patch and changed producer postimage are embedded in JSON. R1/R2 proposal artifacts remain immutable with pinned hashes; all actual applied R2 numeric/doc/test source and generated PNG/PDF remain untouched.

## Authority and source reading

Initial same-packet check of `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/publication-l3-layout-author-r3.json` returned exit0, freshtrue/changed[]. The changed primary notebook's current15:23UTC entry and exact R2 preimages were read; relevant common CLAUDE/pipeline/continuity/figure-reviewer contracts from R1 remain current. For R3, read paper-authoring SKILL, mandatory prohibited-patterns and dispatch-brief, paper-drafter and prose-reviewer role contracts. ROOT invoked paper-authoring; this proposal applies its source/voice discipline to bounded captions. The complete actual render-review Markdown/JSON and runtime-controls JSON were read. Actual compiled PDF page2 image was directly viewed; no new page rendering or output regeneration was performed.

Read current source producer in full, target manifest caption, both actual figure/caption consumers, L3 carrying local/illustrative math and manuscript length metadata. Held primary source's whole fate-of-acoustic-hole section961-1024 was read directly again. No theorem claim is added and no historical Paper27 source assertion is used as backing.

## Diagnosis and chosen layout

Actual independent R2 visual review measured235.246pt consumer width for1100CSSpx;10px annotations became2.14pt, base14px≈3pt, title16px≈3.42pt against9.96pt body. Full-canvas PNG science passed; compiled publication typography was explicitly REVISE. Actual page2 viewed here confirms the figure is substantially undersized in its column. The R2 reviewer reports all4pages reviewed; this author directly viewed page2 only and does not claim a new all-page review.

Propose480x640CSSpx with vertically stacked full-width panels, row-height proportions0.55/0.45 and vertical spacing0.22. Remove the redundant overall title. The panel titles `(a) Temperature histories` and `(b) Critical-mass boundary` stay scientific. Every essential annotation, tick, legend and panel-title font is explicitly16px; axis titles17px. Default typography remains the project's serif family. Legends are inside their proper panels, using upper empty space rather than consuming an outside canvas column. Top legend anchors0.98/0.99; lower legend0.02/0.34 in the proposed lower domain. Concise sign annotations keep actual R2 orange sample target `(0.75,(1-0.75)^(-1/3))`; only its text offset changes to85,-38pixels. The blue sign annotation remains at2.8/1.0 and says illustrative exponential. The lower critical-mass annotation moves fromY0.87 to0.75 for clearance with larger text.

At the measured235.246pt width, predicted scale is235.246/480=0.490096pt/CSSpx. Thus16px essentials predict7.842pt,17px axis titles8.332pt; predicted figure height313.661pt. This is a source-based geometric estimate, NOT a measured render, typography pass or new gate. Export scale cancels between raster pixel dimensions and placement. Actual canonical regenerated geometry, legends, text boxes, all-page layout and the four-page ceiling still require measurement/independent acceptance.

The larger figure uses roughly185pt more height than R2 before caption savings. The revised L3 caption removes redundant long formal-witness identifiers already present in unchanged carrying prose and makes clocks/panel labels explicit. This is caption compression, not a weaker theorem or physical charter. No claim that the larger float will definitely remain4pages is made. Paper27's existing0.8textwidth figure* placement is left exact because its assigned change is the caption; its larger stacked graphic must be compiled and reviewed, including float fit, as a separate actual consumer. No fontsize/length waiver is proposed.

## Scientific content and caption propagation

L3 keeps its current0.96columnwidth single-column figure placement and figure label. Its caption now refers to panels(a)/(b), assigns `t/t_evap` to representative Schwarzschild and `t/tau_cool` to chosen exponential, preserves the exponential asymptotic-zero statement and local-affine distinction, and describes the same normalized model length equality/shading with the existing cutoff-equation reference.

Paper27's caption is replaced coherently: no internal Phase/Wave text, no attribution of the exponential curve to Balbinot, no assertion that this chosen curve demonstrates acoustic extremality, and no obsolete delta_ADW-vs-alpha_ADW right-panel description. It describes the same actual two-panel graphic, separate clocks, illustrative exponential and normalized model cutoff crossing. Its existing Balbinot citation now supports only the local affine nozzle result. Existing Paper27 macros `GN`, `Ladw`, `Mc` are used without adding macros or theorem claims. The surrounding manuscript, figure placement and labels remain byteexact. Known stronger/global body claims are outside this caption repair and remain source-consumer debt.

The target FigureSpec scientific caption changes only orientation from Left/Right to Panel(a)/(b); all schema, axes/traces, registrations, function mapping, checks and every other field are exact. No manuscript history narration or new technical project scaffolding is introduced. The corrected captions were inspected for forbidden em-dashes; compound eponyms in unchanged text remain intact.

Primary factual support: actual current producer/R2 runtime evidence supplies normalized histories/colors/signs/arrow/crossing; L3 carrying math supplies chosen-exponential interpretation; Balbinot held Tsonic989-994 supplies local affine coefficient563/(720π),997-1008 explicitly extrapolates t~1/T³,1020-1024 defers BEC. No actual source calibration, global acoustic evolution, controlled remainder, branch matching or condensate derivation is asserted by the caption.

## Exact conservation and intentional formatting deltas

Pure AST analysis compares every import and non-figure data assignment in the function. It also compares every argument of all4go.Scatter/add_trace calls and all3shading/boundary calls after removing only their row/col presentation keywords. These ordered AST lists are exactly equal, with hash in JSON. Thus all121normalized exponential/Schwarzschild XY expressions/raw grids/normalizations/temperature calculations, right101points/unit cutoff/canonical coupling/criticalmass expressions, names/colors/line styles/order, crossing and shape endpoints remain exact R2 source. Orange x/y/showarrow/arrowhead/arrowcolor ASTs are exact, preserving sample100's actual curve target. No numerical module/validation/API/test assertion changed.

The complete visualizations prefix/suffix outside this producer is byteexact. Manifest AST is identical after masking only this FigureSpec caption. Both manuscripts are exact outside their caption spans, including placements, all body math/prose/theorem references, citations outside captions, labels and headers. Full4postimages and source hashes allow ROOT to verify exact application.

Do NOT claim the full right-panel SOURCE block byteidentical: its row/col placement changes to2/1 and axis/legend/annotation presentation intentionally changes. Numerical data/source-call arguments remain exact. The original full3.2 Verify LINE and entire review file are unchanged against original R1; JSON carries exact line and review hash. Its4trace/rightdata[2:]/unique crossing/side ordering/shapeendpoint predicates remain fullstrength. The R2 runtime receipt's displayed line omits a closing Markdown backtick; a pure bookkeeping comparison caught that. Actual source Verify line matches R1 byteexact and executable command matches the receipt; no evidence or source was rewritten to hide it.

Old R2 output comparisons of xaxis2/yaxis2/legend2 complete layouts are deliberately no longer geometry identity claims. ROOT should retain exact scientific data/style/name/order and original3.2 predicates while verifying new layout domains separately. This is an intentional layout change, not a relaxed repository test/checker; no test/checker file is modified.

## Required actual acceptance and remaining work

ROOT already owns actual R2 positives,9meaningful source faults/restorations and58unchanged numerical tests. Those receipts were read, not rerun and not claimed as R3 evidence. After independent complete R3 source/prose approval/application: call actual producer, compare every scientific trace array/style/name/order/sample-anchor with actual R2; run original full3.2 unchanged and meaningful coordinate/input/attribution/arrow/rightcrossing/shading faults with exact restoration; canonical regeneration and exact-copy/readback to BOTH actual L3 and Paper27 PNG consumers; canonical out-of-tree compile of BOTH; independent all-page publication-scale visual/prose review and measured physical font sizes/float fit/L3 four-page limit. Existing scoped/broader pipeline/review/closure gates remain required.

No PNG, PDF or baseline is written by this author. No producer import/call, tests, scientific simulation, Lean/LSP/build/extraction, slot/controller/process operation or Git mutation occurred. Only pure AST/text/hash bookkeeping ran. Repository scientific source, tests, R1/R2 evidence and accepted applied files remain intact. Final original packet freshness must be checked without refresh before return.

Out-of-scope inherited false prose remains at WKB backreaction457-460 (related13,359,583), Lean BHThermodynamicsFourLaws518ff/709ff/780ff/836/946ff, and Paper27 body outside this caption. This is no whole-tree attribution closure. Physical source calibration, branch matching, quantitative remainder, BEC extension and all full four-laws constructions remain explicitly owed at full strength. No new research/index/citation/infra task or scope contraction is proposed.

## Integrity

Patch SHA256 `f6d556d7e6bc480ba385cb452ff2bb7686ec4e6e866af75153f8de9088fb3e3e`.
Changed producer postimage SHA256 `ddc130522480567f81dfb318c6e1ede6ac8c99828290cc96618fa07cfd7ad09f`.
Full4postimages/preimage/postimage hashes and AST conservation evidence are in companion JSON. Python source parses, pure AST conservation predicates and exact caption-span isolation passed; actual runtime/render/compile acceptance remains PENDING.

Final SAME original R3 packet check: exit0, `fresh:true`, `changed:[]`; no refresh. All candidate preimages and all6 R1/R2 artifact hashes remain exact.

## CONTRADICTIONS BETWEEN THE BRIEF AND THE SOURCES

No substantive contradiction with the R3 brief was found. The brief correctly rejects two existing-source conflicts: the applied R2 full-canvas figure's microscopic compiled typography, and Paper27's old Balbinot/exponential/obsolete-right-panel caption. This proposal follows actual measured review and primary Tsonic/local-vs-illustrative distinction instead of carrying those conflicts forward. R2's runtime display has only the closing Markdown-delimiter discrepancy described above; its executable3.2 command and actual source acceptance are not changed. No unresolved factual claim was silently substituted for stronger evidence.
