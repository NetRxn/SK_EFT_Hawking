# Independent L3 figure-source review r2

**ACCEPT_SOURCE_ONLY** for the complete five-file proposal, patch SHA256 `8cb979f8a3aeb6e35c527c4e6ccd45c834551a3ffeb64dca7dfa4316cbd36b75`, against actual focused candidate `42dd2d3a41a693dd4ca48e4669f7f3a69944006a`. This source verdict covers the immutable r2 proposal and its immediate attribution consumers. It grants no render, runtime, whole-tree provenance, native qualification, physical construction or publication acceptance. ROOT owns application and acceptance.

Initial SAME new reviewer-packet check: exit 0, fresh true, changed []. Final check uses the same original r2 packet and is appended below/in JSON. No packet was refreshed. R1 author artifacts and R1 reviewer reports were preserved. Only the two assigned r2 reviewer reports were written.

## Independent complete-source conservation

I independently reconstructed every unified-patch hunk against actual base42dd, matching every context and deleted line, and checked each reconstructed complete file against its complete embedded postimage and independent SHA256. All five files parse as Python source, without importing or executing project code.

- `scripts/review_figures.py`: `7bf67a8c184eeabb9656425406f2b429edb4b7d9ae218c82a93cc60fd43f496d`.
- `src/bh_thermodynamics/__init__.py`: `c8b16b4c97cc00d7052152afa015be3ff17dae03a9fff809d65f8a5897c70ba0`.
- `src/bh_thermodynamics/acoustic_evolution.py`: `a6823252ed1b9956c7cb5ba851449bd2c0a3106627364c47007ccaf8f5ac43e1`.
- `src/core/visualizations.py`: `25b4a36b0fc0461d5826386c368f9d878edd565d010bb5eba415245a27699075`.
- `tests/test_bh_thermodynamics.py`: `1e9fd12085974a586502e07fba9b0d8059fc72a6f8d8a4dc5ccca875876c7e1c`.

The complete revised figure-function hash is `0bd34c34a1dbb1c3baafccc8d629810f2b17d34648780ec7c4a541e3f753dace`. The immutable author's JSON retains all five complete postimages; the companion reviewer JSON records the independently checked hashes and exact analysis command.

For acoustic_evolution.py, package __init__.py and the complete thermodynamics test file, the full AST is equal after removing only genuine leading module/class/function docstrings. Removal does not mask any other string expression, annotation, signature, decorator or executable value. The independently computed stripped-AST hashes match the author's. Thus every numerical expression, function, validation branch, helper, test name, decorator, assertion, tolerance, loop, API/export/import and supplied-sign bundle operation is unchanged. Complete patch inspection confirms changes in these three files are documentary only; this is conservation evidence, not proof that existing numerical code or tests fully represent the physics.

For scripts/review_figures.py the complete AST is equal after masking only the caption keyword of the uniquely named target FigureSpec. Complete textual patch inspection shows only that caption changes. No axis expectation, four-trace requirement, check, schema or other figure is altered.

For visualizations.py the complete prefix/suffix outside the target function are byte-identical. Against accepted R1's complete function, replacing exactly the old orange annotation block with the proposed arrow block reproduces the R2 function exactly. Every other R1 correction is preserved. The complete right-panel block remains byte-identical, SHA256 `cabc55dc779d2ecf85409d0deecebc13352cda04ec1cd9c8a5a90518b84b4823`; right axes/legend2/style/shape declarations are unchanged. Actual current L3 manuscript, original review, upstream WKB file and Lean module retain the pinned protected hashes.

The original complete stronger 3.2 Verify is exactly the same in actual review, R1 JSON and R2 JSON. It retains all four traces, common right mass grid, unit cutoff, unique sampled crossing at one, strict ordering on both sides and exact shading/boundary shape endpoints. It was not executed or weakened. Its verbatim command is retained in companion JSON.

## New scientific claims and orange annotation

The actual revised target FigureSpec caption now identifies separate normalized clocks t/t_evap and t/tau_cool, representative Schwarzschild evaporation, a chosen illustrative exponential, and the distinct local affine nozzle result. Its right-panel caption remains the focused candidate's actual gravitational/cutoff crossing rather than obsolete main's response panel.

The revised acoustic module and package explicitly state that positivity/decrease/asymptotic zero are properties of the chosen exponential. They accurately attribute only the local affine correction to Balbinot Eq.(Tsonic), distinguish the inverse-cubic long-time extrapolation, retain the constant-sound-speed sonic-nozzle restriction, and reject automatic BEC cooling-sign inheritance. Removing the old claim of a physical full-ODE solution from this module is scientifically appropriate; no numerical implementation was replaced. Source calibration, local remainder control and physical branch construction remain owed. These additions agree with the held primary source fully read during R1 and pinned unchanged by the r2 packet.

New test prose truthfully identifies what the unchanged assertions check: chosen profiles and supplied-sign bundles, not the validity of the source approximation, its remainder or a condensate derivation. The asymptotic-zero test still checks a finite large-time sample; its new explanation states the mathematical definition's limit, which the finite numerical sample alone does not prove. No test relaxation is proposed or accepted.

Orange's arrow head now lies at X=0.75 and Y=(1-0.75)^(-1/3), about 1.5874, on the corrected normalized orange trajectory. With 121 samples through X=0.9, this is zero-based sample index100 (raw t=3.75). The arrow therefore supplies the association absent from old text at X=3.5. Offset ax=80, ay=-65 is a text-placement offset in pixels, not a change to physical coordinates. The amber color, arrowhead and left anchoring are reasonable source-level choices. No new layout shape is added; right crossing/shading assertions stay intact.

The exact target should still be compared against actual producer sample arrays within floating tolerance. Source geometry cannot establish arrow/text extent, clipping, overlap, line readability or page-scale adequacy. Blue remains accepted R1's proposed (2.8,1.0); its actual visual clearance remains unreviewed. The author's expected failure on restoring old blue placement is an unexecuted visual prediction, not established evidence and not a justification for a token-only visual guard.

## R1 science retained, bounded acceptance

The retained real plotted orange coordinates divide raw time0..4.5 by lifetime5, yielding X0..0.9 and unchanged Y=(1-X)^(-1/3). Blue uses its independently normalized cooling time and fixed initial temperature1, giving Y=exp(-X). This is symbolic source review; neither producer was invoked. It supplies no calibration between physical clocks, physical acoustic trajectory, matched cross-cutoff solution or global BEC sign. The current manuscript/caption already distinguish the chosen exponential from the local affine criterion; no mandatory manuscript edit is needed for this bounded correction.

Immediate false exponential-to-Tsonic attribution is corrected in the five proposed paths. This does not close all source provenance. I directly read the untouched WKB backreaction_evolution docstring at457ff: it still calls the exponential an analytic approximation from Balbinot and claims full coupled evolution. I also read untouched Lean prose at518ff,709ff and946ff, which still generalizes cooling/sign/asymptotic provenance beyond the local source. These are genuine inherited prose debts; the proposal records them explicitly. No WKB numerical validity, Lean proof validity or whole-tree source audit is inferred from preserving their bytes.

The original full physical four-laws objective remains OPEN at full strength. Accurate attribution and illustration do not fulfill it or authorize narrowing its acceptance conditions. Existing manuscript limitations remain substantive. This review does not certify existing theorem inventories, novelty markers, all inherited test prose, native builds or the complete scientific construction.

## Production, render and compile work still required

ROOT must apply/reconcile the accepted exact proposal and run the actual producer positive controls: all121 orange X/Y values/domain/endpoints and Y=(1-X)^(-1/3); blue X/Y and Y=exp(-X); real orange arrow head on its sampled trajectory with expected arrow configuration. Serialized faults using raw orange X, wrong divisors4/25, altered blue input time, off-curve arrow coordinates or old detached orange placement must be detected by the appropriate actual-output controls with exact restoration. False Balbinot legend and false immediate-consumer attribution require independent semantic review even when numerical controls pass.

Run the exact original complete 3.2 Verify and meaningful actual gravitational/cutoff/boundary faults without dropping predicates. Preserve source/mtime and restoration evidence. Compare actual unchanged right-panel arrays/styles/legends/shapes under the same runtime; identical source alone does not imply unchanged raster pixels after title/layout changes.

Use canonical regeneration and readback into the actual L3 PNG consumer, independent figure/claims review against held source/current manuscript/updated manifest, canonical out-of-tree L3 compilation and all-page visual review at publication scale. Inspect both annotations, orange arrow target, text/curve/legend/title/axis clearance, line wrapping and accessibility. Appropriate existing scoped/broader pipeline gates, native qualification and canonical review/closure remain owed.

No producer call/import, physics execution, pytest, Lean/LSP, native build, process/controller operation, cache/extraction, generated baseline, fault injection or compile was performed. No source, manuscript, test, notebook or Git state was changed.

## Reviewer command evidence

Working directory: `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l3-crossing-main`.

Same initial/final command:

`python3 scripts/codex_continuity.py check /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/publication-l3-figure-source-review-r2.json`

The exact executed complete Python source-reconstruction/AST/hash command is embedded in companion JSON. Other commands read the full r2 patch/rationale, all three documentary postimages, JSON metadata and the exact inherited WKB/Lean sections described above. No executable command quoted from author reports was run.

Final SAME original r2 reviewer-packet check: exit0, fresh true, changed []. No refresh.
