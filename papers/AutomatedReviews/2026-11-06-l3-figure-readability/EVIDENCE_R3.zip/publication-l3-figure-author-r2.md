# L3 figure and immediate attribution propagation r2

UNAPPLIED SOURCE PROPOSAL for ROOT independent review. Candidate `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l3-crossing-main` at `42dd2d3a41a693dd4ca48e4669f7f3a69944006a`. ROOT retains L1 and acceptance; no transfer to the Executor or reduction of the original physical four-laws BUILD.

Only `/tmp/publication-l3-figure-author-r2.patch`, `.md`, `.json` were written. No repository path changed. Original R1 artifacts remain immutable and their hashes are pinned in R2 JSON. Full five postimages, individual pre/post hashes, complete patch, full changed-function postimage and AST conservation details are embedded in JSON.

## Continuity

Initial check of the new SAME packet `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/publication-l3-figure-author-r2.json` returned exit0, `fresh:true`, `changed:[]`. Its candidate hashes match the original42dd source. R1 and shared roadmap/notebook/authority remain the same pinned inputs; relevant contracts were read during R1. This assignment's broader five-file ownership has been read directly. Final same original R2 packet check follows below/in JSON; no refresh is allowed to hide drift.

## R1 preserved and R2 delta

The complete R1 actual-coordinate/legend/docstring/title/blue-annotation correction is preserved. Schwarzschild raw time samples remain0..4.5 and all temperature calculations stay exact. Actual trace X is divided by `t_evap=5`, so X ends0.9 and Y follows `(1-X)^(-1/3)`. The chosen exponential remains the existing function with explicit X=`t/tau_cool`. The shared axis names both separate timescales. The blue legend is `Illustrative exponential cooling` and its annotation remains R1 `(2.8,1.0)`.

R2 makes four coherent additions:

- This figure's existing `FigureSpec.caption` identifies separately normalized representative Schwarzschild evaporation and illustrative exponential cooling, distinct from the local affine nozzle result. Every other FigureSpec/schema/axes/traces/registration/logic field is exact.
- `acoustic_evolution.py` module/scalar/grid docstrings identify the exponential as chosen and mirrored, remove unsupported full-ODE physical-solution claims and reject automatic condensate sign inheritance. No implementation/API/validation/data changed.
- Package `__init__.py` identifies the exported exponential honestly and qualifies the local source/extrapolation/BEC scope. Its imports, public names and all other code are exact.
- Thermodynamics test explanatory docstrings identify the chosen profile, its built-in monotonicity/asymptotic limit and supplied-sign bundles. Every test name, decorator, assertion, loop, parameter, threshold, helper and numerical implementation is exact.

The orange text previously at x3.5 became detached when the corrected curve ended0.9. R2 points an amber arrow to `(x,y)=(0.75,(1-0.75)^(-1/3))`, at actual sample100 of121 on the dimensionless orange curve (raw time3.75), with external text offset `(80,-65)` pixels and left anchoring. Only that annotation block differs from R1. This geometry is a proposal pending actual render review; no numerical output or overlap-free claim is made. The arrow is an annotation, not an added layout shape: all right-panel shape bytes remain exact.

## Scientific basis and boundaries

Held Balbinot TeX `acusticpap.tex` carrying section was read directly in R1. Eq.(Tsonic) lines989-994 gives the local affine correction with `563/(720π)` in a constant-sound-speed Laval nozzle calculation. Lines997-1008 explicitly extrapolate to `t~1/T³`; they do not supply exponential cooling. Lines1020-1024 defer the condensate case with density-dependent sound speed. R2 carries that distinction into the actual figure manifest and numerical/test docstrings. It asserts no automatic BEC sign, calibrated cooling time, quantitative remainder control, full-ODE physical solution, or globally matched acoustic/Schwarzschild evolution.

The current L3 manuscript's section170-208 and caption214-224 already distinguish illustrative exponential/local affine criterion, finite-range positivity/short-time hypotheses, and the separate remainder/condensate requirements. No manuscript change is needed to make this patch's figure description truthful. The exact right-panel critical-mass equality and physical signs/cutoff formulas are retained. The full original four-laws physical construction remains owed.

## Source conservation

The original stronger3.2 production Verify is copied verbatim into JSON and its review source remains untouched. It still checks all4traces, exact common right-X grid, unit cutoff, unique sampled crossing at1, strict side ordering and all3shading/boundary shapes. No predicate is removed or replaced by a source-token/zero-exit proxy.

Three files (`acoustic_evolution.py`, `__init__.py`, thermodynamics tests) have exactly equal complete ASTs after removing only true module/class/function docstrings. SHA256 fingerprints are in JSON. Comments do not occur in ASTs; actual patch inspection additionally confirms no executable-line/comment algorithm edits there. This establishes unchanged assertions, names, decorators, arguments, validation, exports and code data.

The review manifest AST is identical with only the one named FigureSpec caption masked. The complete visualizations AST outside `fig_T_H_evolution_regime_partition` is identical. Inside the function, R1->R2 source delta is only the orange annotation block; R1's source-only changes are retained. Full figure AST equality would be a false claim because the requested coordinate/annotation changes are intentional.

Right-panel source block SHA256 is `cabc55dc779d2ecf85409d0deecebc13352cda04ec1cd9c8a5a90518b84b4823`, byteexact against original42dd and R1. All mass/cutoff sampling, canonical formula calls, equality/side-ordering data, style/legend2/shape declarations, right axes and boundary labels are unchanged. All left temperature numerical expressions/raw sampling are exact; plotted X normalization alone changes data coordinates. No reviewer/checker/schema/registration machinery, Lean, registry, metadata, ledger, notebook, gate, test logic or scientific numerical formula was changed.

## Related remaining propagation, outside ownership

ROOT identified and this author located the inherited upstream prose at `src/wkb/backreaction.py:457-460` (`backreaction_evolution` docstring's false analytic Balbinot exponential attribution); related overview/evolution prose appears at13,359-360,583. This source is untouched. Its existence prevents whole-tree attribution closure and does not justify claiming a physical ODE solution here.

`lean/SKEFTHawking/BHThermodynamicsFourLaws.lean` inherited overview/bundle/falsifier comments at518-525,709-758,780-807,836 and946-949 still overstate source-derived/global acoustic sign or exponential provenance, despite narrower illustrative/local-profile declarations at408ff/544ff/580ff/608ff. These are exact remaining-propagation pointers, not a new Lean task or proof finding. No Lean operation/edit was performed.

No additional research/citation/indexing tasks or code scope expansion is proposed. The immediate five-path package is bounded; unresolved original physical construction remains full strength.

## Production controls and acceptance still owed

The JSON lists detailed expected actual-producer faults. None ran here. ROOT should execute actual positive output assertions (not a copied formula/source token substitute), then serialized real-source mutations with exact restoration:

1. Both actual traces start1; exponential satisfies `Y=exp(-X)` and Schwarzschild satisfies `Y=(1-X)^(-1/3)` at every sample with X0..0.9<1. Revert actual Schwarzschild plotted X to raw0..4.5 or wrong divisors4/25: domain/endpoint/curve assertions must fail. Change actual blue input `t` to `2*t` with displayed X unchanged: exponential relation must fail.
2. Restore false Balbinot blue legend or false Eq.(Tsonic)-exponential attribution independently in each actual immediate consumer. Scientific claims review must reject false text even when arrays pass and the word illustrative appears elsewhere. Original API and numerical positives remain full strength.
3. Run the exact unchanged original3.2 full production Verify. Mutate actual right-trace multiplier, cutoff level or boundary/shading: appropriate existing assertions must fail. Compare pre/post actual right-panel output under the same runtime, in addition to byteexact source.
4. Assert actual orange arrow/showarrow and its on-curve relation; off-curve X/Y or old unanchored x3.5 must fail. Canonical PNG and compiled-page independent visual review must assess arrow target/line, both annotations, normalized-axis line breaks, legends/titles and publication-scale readability. Restore old blue overlap separately and require visual rejection.

After independent source approval/application: existing canonical regeneration; output custody/readback into the actual L3 PNG consumer; independent fresh figure/claims review against held source/current manuscript; out-of-tree canonical L3 compile plus full-page render inspection; existing required scoped/broader gates and original full3.2 Verify/canonical review-closure procedure. No new infrastructure or relaxed gate is needed. No generated baseline, physical simulation, producer import/call, pytest, Lean/LSP, build/extraction, controller or process operation ran here.

## Artifact integrity

Patch SHA256 `8cb979f8a3aeb6e35c527c4e6ccd45c834551a3ffeb64dca7dfa4316cbd36b75`.
Changed function postimage SHA256 `0bd34c34a1dbb1c3baafccc8d629810f2b17d34648780ec7c4a541e3f753dace`.
Full five proposed files and hashes are in JSON. Pure-source parsing of every proposed file succeeded; AST/source conservation checks passed as described. R1 hashes and all candidate preimages remain pinned, final same-packet freshness still required before return. This is a reviewable proposal, not applied/accepted/rendered/compiled/publication-ready source.

Final SAME original R2 packet check returned exit0, `fresh:true`, `changed:[]`. All R1 artifact hashes remain exact.
