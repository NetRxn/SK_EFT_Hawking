import ast,collections,hashlib,json,os,runpy,shlex,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
R=Path.cwd().resolve(); W=R.parent; P=Path('/tmp/publication-source-register-postfreeze-measurement-r3'); old=json.loads(Path('/tmp/publication-source-register-existing-producer-design-r2-manifest.json').read_text()); prior=json.loads(Path('/tmp/publication-source-register-existing-producer-design-r2-population.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def meta(p):
 s=p.stat(); return {'sha256':sha(p),'size':s.st_size,'mode':s.st_mode,'mtime_ns':s.st_mtime_ns}
carrying={n:meta(R/n) for n in old['carrying_input_sha256']}
assert all(carrying[n]['sha256']==h for n,h in old['carrying_input_sha256'].items()),'INPUT HASH DIFF: stop before metadata assumptions'
keys={r['key'] for r in prior['rows']}; held=set()
for phase in (W/'Lit-Search').iterdir():
 d=phase/'primary-sources'
 if d.is_dir():
  for p in d.iterdir():
   if p.is_file() and any(p.name.lower().startswith(k.lower()+'.') for k in keys): held.add(p)
inputs={R/n for n in old['carrying_input_sha256']};inputs|={R/'src/core/provenance.py',R/'src/core/formulas.py',R/'docs/primary_sources_state.json',R/'docs/SOURCE_ACQUISITION_REGISTER.md'}
for d in (R/'papers').iterdir():
 if (d/'bundle_metadata.json').is_file(): inputs|={d/'bundle_metadata.json',d/'paper_draft.tex'}
inputs|=held
snapshot=lambda:{str(p):meta(p) for p in sorted(inputs) if p.is_file()}
before=snapshot(); status0=subprocess.check_output(['git','status','--porcelain=v1']).decode(); head0=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(); started=datetime.now(timezone.utc).isoformat()
sys.path[:0]=[str(R),str(R/'scripts')]
def audit(event,args):
 if event in {'socket.connect','socket.getaddrinfo'}: raise RuntimeError('read-only postfreeze pilot forbids network')
sys.addaudithook(audit)
code=Path('/tmp/publication-source-register-existing-producer-design-r2-pilot.py').read_text().replace('/tmp/publication-source-register-existing-producer-design-r2-population.json',str(P)+'-population.json')
# Original bound r2 pilot source, only output path redirected to NEW r3 artifact.
exec(compile(code,str(P)+'-reused-pilot','exec'),{})
x=json.loads(Path(str(P)+'-population.json').read_text())
from src.core.citations import CITATION_REGISTRY as REG
from src.core.provenance import PARAMETER_PROVENANCE as PROV
from validation.checks import citations as C
from src.core import workspace as CW
M=runpy.run_path(str(R/'scripts/source_acquisition_register.py')); overlay=json.loads(M['OVERLAY'].read_text()); rows=[r for r in x['rows'] if r['held_with_declared_and_canonical_phase']!='full']; bearing=M['_bearing']([r['key'] for r in rows],REG,PROV)
for r in rows:
 ov=overlay.get(r['key'],{}); bears=bool(ov['load_bearing']) if 'load_bearing' in ov else bool(bearing.get(r['key'])); route='internal' if REG[r['key']].get('inprep') is True else ov.get('route') or 'unassessed';r['projected_route']=route;r['projected_priority']='—' if route=='internal' else 'P0' if bears else 'P1' if len(r['bundles'])>1 else 'P2'
x['summary']['projected_priority_counts']=dict(collections.Counter(r['projected_priority'] for r in rows));x['summary']['projected_P0']=[r['key'] for r in rows if r['projected_priority']=='P0'];x['summary']['overlay_conflicting_inprep']=[k for k,v in REG.items() if v.get('inprep') is True and k in overlay and overlay[k].get('route') not in [None,'internal']];x['projected_rows']=rows
finding=R/'papers/AutomatedReviews/2026-11-05-source-register-fidelity/source_register_fidelity.md'; line=next(l for l in finding.read_text().splitlines() if l.startswith('- **Verify:**')); cmd=line.split('**Verify:**',1)[1].strip().strip('`'); argv=shlex.split(cmd);assert argv[:2]==['python','-B']; argv[0]=sys.executable
v=subprocess.run(argv,cwd=R,capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});Path(str(P)+'-original-verify.txt').write_text(v.stdout+v.stderr);assert v.returncode==1 and 'AssertionError: existing register disagrees' in v.stderr and "'Verlinde1988_canonical': 'metadata', 'register': 'full'" in v.stdout
probe=subprocess.run([sys.executable,'-B','.claude/plugins/skeft-qa/skills/architecture-change/scripts/registration_sites.py','citation_primary_sources_present','--repo',str(R)],capture_output=True,text=True);Path(str(P)+'-registration.txt').write_text(probe.stdout+probe.stderr);assert probe.returncode==1 and '1 site(s) owed: verify_scope path mapping' in probe.stdout
V=runpy.run_path(str(R/'scripts/verify_scope.py')); plan=V['_plan'](['scripts/source_acquisition_register.py','scripts/validation/checks/citations.py']);assert any('fast suite' in label for label,argv in plan[0])
after=snapshot();head1=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();status1=subprocess.check_output(['git','status','--porcelain=v1']).decode();assert before==after and head0==head1== '4a0d736866adb4cdc006d6835f2895254bc942cb' and status0==status1
compare={k:(prior['summary'].get(k),v) for k,v in x['summary'].items() if k!='head' and prior['summary'].get(k)!=v};assert not compare,compare
bindings={'registry':str(Path(sys.modules['src.core.citations'].__file__).resolve()),'canonical_classifier':str(Path(C.__file__).resolve()),'workspace_owner':str(Path(CW.__file__).resolve()),'producer':str(R/'scripts/source_acquisition_register.py')};assert all(str(R) in p for p in bindings.values())
x['measurement_status']='CONFIRMED post-terminal read-only remeasurement; design still proposed for independent specification review';Path(str(P)+'-population.json').write_text(json.dumps(x,indent=2)+'\n')
receipt={'started_at':started,'finished_at':datetime.now(timezone.utc).isoformat(),'head_before':head0,'head_after':head1,'git_status_before':status0,'git_status_after':status1,'input_files':len(inputs),'held_files':len(held),'pre_post_bytes_mode_mtime_equal':before==after,'before':before,'after':after,'actual_source_bindings':bindings,'r2_pilot_sha256':sha(Path('/tmp/publication-source-register-existing-producer-design-r2-pilot.py')),'r2_output_path_only_changed':True,'r2_nonhead_summary_differences':compare,'original_finding_Verify':cmd,'original_Verify_interpreter':sys.executable,'original_Verify_exit':v.returncode,'registration_probe_exit':probe.returncode,'actual_generic_verify_scope_plan':plan,'network_audit':'socket connect and resolution refused','carrying_hashes_equal_r2':True}
Path(str(P)+'-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'success':True,'postfreeze_counts':x['summary'],'inputs_conserved':len(inputs),'held_files_conserved':len(held),'Verify_exit':v.returncode,'registration_exit':probe.returncode},indent=2))
