# Proposed document-first amendments — existing owners only


These are proposed changes, rebound to confirmed postfreeze r3 inputs, for ROOT to apply only after independent specification intake and before implementation. No repository document was edited by this designer. Do not create a new ADR or duplicate gate description.

## ADR014 D2: keep its existing number and writer; add the precise hookup contract

After the existing D2 paragraph, add:

> The register reads cache holdings through the canonical workspace resolver and the citation check's shared strongest-tier discovery/classification. It compares any declared cache with discovered nonempty caches; metadata or an abstract remains an acquisition gap, and a stronger held body is not hidden by a weaker declaration. `none` and `missing` remain distinct. Internal routing follows the registry's actual `inprep` identity rather than a citation-key prefix. Curated bearing and external acquisition routes survive regeneration; inconsistent internal identity is refused, not silently published. These are derived acquisition states, not evidence that a source body has been read or its scientific claims accepted.

Reference the existing open source_register_fidelity finding as pending implementation in the dated spec/audit. Do not change D1's advisory semantics, D3's curated floor, D4 gate routing, D7 exemption vocabulary or ratchet. Existing historical measured counts in ADR context remain explicitly historical; do not rewrite them into asserted current progress. The patch is an implementation of its standing contract, not a new architecture.

## QA_QI_INFRASTRUCTURE_MAP §2 writer table

Add the existing omitted producer surface in the table, without splitting the table:

| `docs/SOURCE_ACQUISITION_REGISTER.md` | `source_acquisition_register.py` using canonical citation cache fidelity/discovery, registry identity and the curated overlay | **content compare** via the writer's `--check` against current bundle citations, registry, overlay, bearing inputs and held caches | no — explicit existing writer |

Below the table, if explanatory text is needed, state only the mechanism: fidelity/identity have canonical owners; acquisition advice is indirect and does not certify body reading. No new count, standalone index or recurring gate is introduced. The topology document already owns when the canonical gates run and does not need a duplicate roster or claim that this producer directly evaluates readiness.

## Producer docstring and derived output

Replace the producer docstring's filename-only holding description with the shared canonical content/discovery mechanism; replace any prefix-only internal identity description with the actual registry inprep property. Preserve the existing render language about the bearing signal being a floor. Regenerate the derived register only through its existing main writer after source/control acceptance; do not hand-edit its rows or curated overlay.
