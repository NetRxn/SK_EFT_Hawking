# Post-freeze existing-producer measurement and refreshed design r3

CONFIRMED current read-only measurement; specification/implementation acceptance remains pending. First and final actual continuity checks on publication-source-register-postfreeze-measurement-r3 both returned fresh=true, changed=[]. Frozen actual29828 was terminal before this assignment. Candidate HEAD remained4a0d736866adb4cdc006d6835f2895254bc942cb. All original provisional r2 artifacts remain untouched historical evidence.

Before any project imports, the driver compared actual producer/classifier/workspace/registry/overlay hashes to r2: all exact, no input-hash difference. It snapshots330 inputs including279 real held files, current bundle drafts/metadata, registry/state/overlay, producer/classifier/workspace/provenance/formulas and derived register. Pre/post bytes/SHA256/size/mode/nsmtime all equal; Git HEAD/status also exact. Actual registry, canonical classifier, workspace owner and producer source bindings all resolve inside the candidate, with the primary venv serving only as interpreter. An audit hook refuses socket connect/name resolution. Full timestamps and source/path/hash snapshots are in -receipt.json.

The original correctly bound r2 pilot source was executed unchanged except its output destination was redirected to NEW r3 population output. Its SHA256 is recorded. The same read-only overlay/bearing projection was then applied. Every non-HEAD summary value equals r2, so the provisional measurements are now independently refreshed against the post-terminal inputs:

| measured property | result |
|---|---:|
| bundle-cited keys / registry keys |317 /677|
| existing producer rows |174|
| holding transitions |79|
| none→full /full→metadata /none→metadata /abstract→full /none→abstract |22 /22 /23 /10 /2|
| first-header vs strongest-canonical tier disagreements |17|
| projected full /metadata /abstract /none /missing |153 /45 /43 /76 /0|
| projected gap rows |164|
| actual internal bundle keys /misrouted actual internal aliases |23 /7|
| projected P0 /P1 /P2 /internal |5 /23 /113 /23|

Every317 actual row and its declared/discovered cache candidates, tiers, bundles and identity/routing dispositions are in -population.json. Projected P0 keys are Adler1982,BB84,Mather1982,PDG2024,Rokhlin1952. The seven misrouted keys are CompanionCompilation,CompanionFaultTolerance,CompanionStochastic,RoehmD4Topological,RoehmD6FaultTolerant,RoehmD8Compilation,RoehmD9Certification. There are no actual falseprefix-external, declared-missing, conflicting-inprep-overlay, header-only discovery or declared-outranking-canonical cases in this slice. The refreshed plan therefore still requires both-direction/absent/conflict/alias-path/standalone controlled tests rather than claiming current-corpus coverage for empty categories.

Original canonical finding Verify was read from source_register_fidelity.md and executed unchanged, substituting only its python executable with the established primary venv interpreter. Actual exit1 at the intended assertion: canonical Verlinde metadata/register full and exactly seven inprep misroutes. Original stdout/stderr are preserved in -original-verify.txt. No import-setup error is counted as defect sensitivity, and no repaired-source GREEN is claimed.

The existing registration_sites probe was rerun and again actually exit1 for name-literal absence in verify_scope. Its raw output remains -registration.txt. Existing verify_scope._plan was separately invoked read-only for the two proposed code paths and genuinely returns generic fast-suite plus architecture/module/count freshness steps; its exact returned plan is recorded in the receipt. This producer remains an explicit writer; the optional missing sync edge is not an instruction to add autosync. No new check, registry, gate, floor or ceiling change is proposed or owed by literal-name presence alone.

Refreshed scratch specification, plan and document amendments are NEW r3 files, with confirmed postfreeze facts and the precise reuse seam: promote the canonical check's existing strongest-tier enumeration into a shared same-module helper, replace the original loop with its call, and have the producer consume that owner/classifier plus its declared alias path. Keep `_discover_cache_for` header-first behavior separate and unchanged; seventeen actual differences justify that distinction. Internal route follows actual registry inprep identity, not prefix, with curated consistent routes/bearing retained. No alternative classifier, resolver, cache index or check is introduced. Proposed existing ADR014D2/QA writer-map wording is enough; no new architecture/ADR/gate topology is invented.

This refresh confirms the pilot facts; it does not settle the specification. ROOT must assign an independent adversarial specification/intent review before document-first application and code. Meaningful full input matrix, serial journalled production regressions and exact restoration, original finding Verify, existing writer then --check, canonical result conservation and nonauthor implementation review remain required. No actual register was regenerated, and no source/state/cache/overlay/ledger file was changed. No fetching, broad tests, Lean build or scientific execution occurred.

Projected164 is an analytical disposition of current already-held bytes and truthful weaker tiers, not a new acquisition, source-body reading, edition-equivalence or scientific result. SOURCE137/physicalB3/human/main/full/native/security/publication conditions remain owed. Canonical closure and normal merge remain ROOT's later actions against an actual reviewed source commit.
