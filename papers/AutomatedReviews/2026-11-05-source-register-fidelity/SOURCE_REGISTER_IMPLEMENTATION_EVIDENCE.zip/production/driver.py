from pathlib import Path
import ast,hashlib,json,os,shlex,subprocess,sys
ROOT=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
PRIMARY=ROOT.parent/'SK_EFT_Hawking';EXE=PRIMARY/'.venv/bin/python';OUT=Path('/tmp/publication-source-register-production-r9');OUT.mkdir(exist_ok=False)
os.chdir(ROOT);sys.path.insert(0,str(ROOT/'scripts'))
from seed_journal import seeded_mutation
ENV=dict(os.environ,PATH=str(EXE.parent)+os.pathsep+os.environ.get('PATH',''),UV_PROJECT_ENVIRONMENT=str(EXE.parent.parent),UV_NO_SYNC='1',UV_OFFLINE='1',UV_CACHE_DIR='/tmp/l1-window-uv-cache',PYTHONDONTWRITEBYTECODE='1')
text=(ROOT/'papers/AutomatedReviews/2026-11-05-source-register-fidelity/source_register_fidelity.md').read_text()
line=next(x for x in text.splitlines() if x.startswith('- **Verify:** `'));verify=shlex.split(line.split('`',2)[1]);commands=[]
def run(label,argv,expected):
 p=subprocess.run(argv,cwd=ROOT,env=ENV,capture_output=True,text=True)
 (OUT/(label+'.out')).write_text(p.stdout);(OUT/(label+'.err')).write_text(p.stderr)
 receipt={'label':label,'argv':list(map(str,argv)),'exit':p.returncode,'expected_exit':expected};commands.append(receipt);(OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 assert p.returncode==expected,(label,p.returncode,p.stdout[-1200:],p.stderr[-1200:]);return p
writer=[str(EXE),'-B','scripts/source_acquisition_register.py'];check=writer+['--check']
def snap(path):
 s=path.stat();return {'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'mode':s.st_mode,'mtime_ns':s.st_mtime_ns,'size':s.st_size}
run('baseline-original-verify',verify,0)
# The pre-repair derived file is expected stale under corrected executable source.
run('pre-writer-stale-check',check,1)
run('existing-writer',writer,0);run('baseline-writer-check',check,0)
producer=ROOT/'scripts/source_acquisition_register.py';register=ROOT/'docs/SOURCE_ACQUISITION_REGISTER.md'
protected=[producer,register,ROOT/'scripts/validation/checks/citations.py',ROOT/'tests/test_d5_citations.py']
before={str(p):snap(p) for p in protected}
old=(Path('/tmp/publication-source-register-root-preimages-r8')/'scripts/source_acquisition_register.py').read_text()
def body(source,name):
 node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name==name)
 lines=source.splitlines(keepends=True);return ''.join(lines[node.lineno-1:node.end_lineno])
old_holding=body(old,'_holding')
def seed_fidelity(source):
 current=body(source,'_holding');assert current!=old_holding
 return source.replace(current,old_holding,1)
def seed_identity(source):
 good='route = ov.get("route") or ("internal" if (REG.get(key) or {}).get("inprep") is True else "unassessed")'
 bad='route = ov.get("route") or ("internal" if key.startswith("Roehm2026") else "unassessed")'
 assert source.count(good)==1;return source.replace(good,bad,1)
for label,mutate in [('fidelity',seed_fidelity),('identity',seed_identity)]:
 with seeded_mutation(producer,mutate,reason='Source-register '+label+' actual production sensitivity'):
  red=run(label+'-verify-red',verify,1)
  assert 'existing register disagrees with canonical cache fidelity or actual inprep identity' in red.stderr
  assert 'ModuleNotFoundError' not in red.stderr
  run(label+'-writer-red',check,1)
 assert snap(producer)==before[str(producer)]
 run(label+'-restored-verify',verify,0);run(label+'-restored-writer',check,0)
with seeded_mutation(register,lambda s:s+'\n<!-- deliberate source-register freshness probe -->\n',reason='Actual source acquisition derivative stale control'):
 run('derivative-writer-red',check,1)
assert {str(p):snap(p) for p in protected}==before
run('final-original-verify',verify,0);run('final-writer-check',check,0)
run('journal-status',[str(EXE),'-B','scripts/seed_journal.py','status'],0)
run('seed-residue',[str(EXE),'-B','scripts/validate.py','--check','seed_residue_absent','--no-memo'],0)
run('canonical-presence',[str(EXE),'-B','scripts/validate.py','--check','citation_primary_sources_present','--no-memo'],0)
prior=json.loads(Path('/tmp/publication-source-register-postfreeze-measurement-r3-receipt.json').read_text())['before']
allowed={str(producer),str(register),str(ROOT/'scripts/validation/checks/citations.py'),str(ROOT/'tests/test_d5_citations.py')}
drift=[]
for path,expected in prior.items():
 if path not in allowed and snap(Path(path))!=expected:drift.append(path)
assert not drift,drift
(OUT/'result.json').write_text(json.dumps({'scope':'Production Verify/writer defect sensitivity and exact restoration; final composition/closure still required','commands':commands,'protected_restoration':before,'prior_input_files':len(prior),'allowed_source_and_derivative_changes':sorted(allowed),'other_prior_input_drift':drift,'source_seed_count':2,'derivative_seed_count':1},indent=2)+'\n')
print(json.dumps({'commands':len(commands),'original_verify':'GREEN; fidelity and identity each intended RED then restored GREEN','writer':'GREEN; both source seeds and derivative seed RED then restored GREEN','restoration':'bytes/mode/nsmtime exact','other_prior_input_drift':0}),flush=True)
