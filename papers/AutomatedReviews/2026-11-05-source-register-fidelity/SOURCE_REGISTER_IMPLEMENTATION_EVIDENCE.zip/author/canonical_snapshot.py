import sys,json,dataclasses
from pathlib import Path
code=Path(sys.argv[1]); candidate=Path(sys.argv[2]); out=Path(sys.argv[3])
sys.path[:0]=[str(code),str(code/'scripts')]
import validate_helpers as h
from src.core import workspace
from validation.checks import citations
h.SRC_DIR=candidate/'src'; h.PAPERS_DIR=candidate/'papers'
workspace.find_workspace=lambda: candidate.parent
r=citations.check_citation_primary_sources_present()
out.write_text(json.dumps(dataclasses.asdict(r),indent=2,sort_keys=True)+'\n')
print(json.dumps({'source':citations.__file__,'passed':r.passed,'details':len(r.details),'output':str(out)}))
