# Scratch source-register implementation r6

Ready for ROOT intake and nonauthor implementation review. This is source/control evidence only. No candidate, primary, shared cache/state/registry/overlay/derived register, Git, network, production seed, scientific runner or Lean/build operation was performed.

Initial continuity command (first action):

```
python3 SK_EFT_Hawking/scripts/codex_continuity.py check SK_EFT_Hawking/.codex/continuity/publication-source-register-implementation-r6.json
```

Returned fresh=true, changed=[]. All final candidate owned-file preimage hashes still match that packet; manifest.json gives exact pre/postimage and patch hashes. Scratch source tree copies the existing validation package and src for isolation. Its papers/docs symlinks and workspace Lit-Search symlink are read-only inputs to these controls; writer tests redirect to newly constructed temporary fixture outputs. Only the exact three assigned source postimages appear in source-register-fidelity.patch. The additional scratch scaffolding/harness files are not proposed repository changes.

## Source behavior

The canonical existing strongest-phase loop is moved, not copied, to `_best_cache_for`. The original presence check calls it. Extension order, full/abstract/metadata ranking, positive-size regular-file checks and phase selection are conserved. `_cache_fidelity` and `_discover_cache_for` are unchanged. The producer uses canonical workspace discovery with its active root/scripts import bootstrap; classifies real declared aliases and shared canonical discovery through the same authority/ranking; retains missing versus none; uses registry inprep is True; and rejects contradictory explicit overlay routing before writing or even filtering full holdings. Curated bearing, routes, reason/note/cost input bytes, sorting, render/main and --check remain in their existing owners. Holdings are computed once per used key.

## Commands and actual results

Interpreter throughout: `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python`, with -B; no uv/environment refresh or editable-primary substitution.

1. Initial new six-test class invocation against original source: pytest -q -p no:cacheprovider -c /tmp/publication-source-register-implementation-r6/tree/pytest.ini /tmp/publication-source-register-implementation-r6/tree/tests/test_d5_citations.py::TestSourceAcquisitionRegister. Result 5 failed, 1 passed (red.txt). After implementation the same invocation gave 6 passed (green.txt). These preceded the final two real/header controls.
2. New real-source control separately observed original Verlinde1988 full-versus-metadata assertion RED: real-red.txt, 1 failed. No import failure.
3. Complete final scratch original/corrected source replay, explicit subprocess return codes:

```
<interpreter> -B /tmp/publication-source-register-implementation-r6/run_controls.py <absolute-candidate-root>
```

The harness copies only scratch original/corrected executable files; it never seeds production. Original producer/citations: returncode1, **6 failed, 2 passed** (complete-red.txt). Corrected source: returncode0, **8 passed** (complete-green.txt). Exact subprocess argv and exit codes are in control-exits.json. Semantic failures name declared metadata, wrong-phase discovery, actual internal identity, overlay identity refusal, foreign-cwd metadata derivation and actual Verlinde1988; writer-idempotence and preserved header controls already pass the original implementation.

4. Existing affected-module controls excluding the production-seeding class:

```
<interpreter> -B -m pytest -q -p no:cacheprovider -c /tmp/publication-source-register-implementation-r6/tree/pytest.ini /tmp/publication-source-register-implementation-r6/tree/tests/test_d5_citations.py -k 'not TestExemptionIsClaimedNotInferred' --junitxml=/tmp/publication-source-register-implementation-r6/scoped-junit.xml
```

**56 passed, 7 deselected, 21.96s**, scoped-green.txt and scoped-junit.xml. The excluded class has journalled source mutations outside this assignment. No candidate conftest, cache provider or bytecode writer was active in the copied scratch tree.

5. Complete actual canonical result conservation:

```
<interpreter> -B /tmp/publication-source-register-implementation-r6/canonical_snapshot.py <absolute-candidate-root> <absolute-candidate-root> /tmp/publication-source-register-implementation-r6/canonical-before.json
<interpreter> -B /tmp/publication-source-register-implementation-r6/canonical_snapshot.py /tmp/publication-source-register-implementation-r6/tree <absolute-candidate-root> /tmp/publication-source-register-implementation-r6/canonical-after.json
cmp /tmp/publication-source-register-implementation-r6/canonical-before.json /tmp/publication-source-register-implementation-r6/canonical-after.json
```

Both direct check calls passed. Their complete dataclass serialization deep-equals byte-for-byte, including passed/error/measured and every detail name/message/passed/warning/measured field. Actual summary: 516 keys, 64 papers; 364 cached = 251 full,49 abstract,64 metadata;33 inprep,43 declared,76 undeclared at unchanged ceiling76;zero missing/uncached. Each has11 details. Raw JSON SHA25697634492a684d70bfbaea177c9ebee4a7d17d87013c67604897a8b3e7dd5711d. Harness pins validation paper/source anchors and workspace to the actual candidate/workspace and records citations __file__, choosing either actual baseline or scratch corrected module in distinct fresh processes. This is the direct function, not a validate.py framework/memo/seed admission run.

6. Parsed every final postimage with stdlib ast.parse and constructed exact unified diff/manifest with stdlib difflib/hashlib. No syntax errors. The final three source postimages hash identically before/after complete replay.

## Controls present

Same-extension Crossref metadata/abstract versus JSON body; unknown-kind+valid-body full positive; unknown-shape/corrupt JSON metadata; positive PDF/tex/abstract; zero/missing/directory/none; wrong-phase-only refusal; declared alias; stale/null declaration stronger discovery; abstract+full JSON and metadata+PDF; stable equal-tier extension tie; header-first helper and actual title/venue/dangling-path failures surviving stronger PDF. Identity covers arbitrary nonprefix true/false, false-internal-prefix external, identifier-empty external, both curated bearing directions and external routes/notes, explicit identity conflicts in both directions and no output write, consistent internal overlay, isolated write/check/idempotence/stale rejection. Subprocess controls execute an absolute copied active script from unrelated cwd in a nested managed fixture with canonical workspace sentinel, poison PYTHONPATH with the source test checkout, and assert active registry/check module __file__, workspace and generated metadata row. Real-input positives cover Verlinde,ADW,Barcelo,Irwin,Eddington,ADM,ABP and all eight actual companion keys with null external identity conservation.

## Remaining ROOT work / limits

This delivery is not source acceptance, integration, full-module/full-tree qualification, original production Verify completion or canonical closure. ROOT must obtain nonauthor review of exact final postimages, integrate only these three files, run original unchanged finding Verify and specified complete citation/phase/workspace suite including slow in the prepared environment, and run the separate canonical validate checks. ROOT alone owns serialized production-seeded fidelity/identity/register mutations with existing seed_journal, exact byte/mode/nsmtime restoration and residue readback, actual derivative writer/check, every-row projection comparison and protected-source conservation, architecture/module/count freshness, registration probe interpretation, verify_scope/full gates, reviewed source commit and existing closure writer. No actual production --check or writer was invoked here. No whole-suite claims: the scoped result deliberately excludes seven production seed tests and does not include the phase/workspace modules. SOURCE137, physicalB3, source reading/edition applicability, broad failures, main/human/publication remain separate.
