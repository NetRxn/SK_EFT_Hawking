"""Run scratch-only original/corrected producer controls with explicit exit receipts."""
from pathlib import Path
import subprocess,sys,json
r=Path(__file__).resolve().parent
base=Path(sys.argv[1])
files=['scripts/source_acquisition_register.py','scripts/validation/checks/citations.py']
corrected={rel:(r/'tree'/rel).read_bytes() for rel in files}
cmd=[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider','-c',str(r/'tree/pytest.ini'),str(r/'tree/tests/test_d5_citations.py')+'::TestSourceAcquisitionRegister']
receipts=[]
try:
 for rel in files: (r/'tree'/rel).write_bytes((base/rel).read_bytes())
 result=subprocess.run(cmd,capture_output=True,text=True)
 (r/'complete-red.txt').write_text(result.stdout+result.stderr)
 receipts.append({'stage':'original-source-red','command':cmd,'returncode':result.returncode})
finally:
 for rel in files: (r/'tree'/rel).write_bytes(corrected[rel])
result=subprocess.run(cmd,capture_output=True,text=True)
(r/'complete-green.txt').write_text(result.stdout+result.stderr)
receipts.append({'stage':'corrected-source-green','command':cmd,'returncode':result.returncode})
(r/'control-exits.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps(receipts,indent=2))
print((r/'complete-red.txt').read_text().splitlines()[-1])
print((r/'complete-green.txt').read_text().splitlines()[-1])
