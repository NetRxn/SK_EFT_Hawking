from pathlib import Path
import sys,json,tempfile,hashlib
root=Path(__file__).parent/'tree'; sys.path[:0]=[str(root),str(root/'scripts'),str(root/'tests')]
from pytest import MonkeyPatch
from test_d5_citations import TestSourceAcquisitionRegister as T
import source_acquisition_register as p
checks=[]
# A fully held row must still refuse either contradictory identity before main writes.
for internal,route in ((True,'paywalled'),(False,'internal')):
 with tempfile.TemporaryDirectory(prefix='publication-source-register-implementation-review-r7-') as td, MonkeyPatch.context() as mp:
  p=T._rows_fixture(Path(td),mp,{'FullConflict':{'inprep':internal}},{'FullConflict':{'route':route}})
  mp.setattr(p,'_holding',lambda key,reg:'full')
  mp.setattr(sys,'argv',['source_acquisition_register.py'])
  p.REGISTER.write_bytes(b'preserve this output')
  try:p.main()
  except ValueError as e:
   assert 'FullConflict' in str(e) and 'inprep' in str(e)
  else:raise AssertionError('full holding masked conflicting overlay identity')
  assert p.REGISTER.read_bytes()==b'preserve this output'
  checks.append({'full_holding_conflict_refused_before_write':{'inprep':internal,'route':route}})
# Exactly True identity; strings and numeric truthiness must remain external here.
for flag in (1,'true',None,False):
 with tempfile.TemporaryDirectory(prefix='publication-source-register-implementation-review-r7-') as td, MonkeyPatch.context() as mp:
  p=T._rows_fixture(Path(td),mp,{'Nonprefix':{'inprep':flag}}, {})
  row=p._rows()[0]; assert row['route']=='unassessed' and row['priority']=='P2'
checks.append({'nonboolean_truthiness_not_internal':[1,'true',None,False]})
before=Path(__file__).parent/'canonical-before.json';after=Path(__file__).parent/'canonical-after.json'
assert before.read_bytes()==after.read_bytes()
assert json.loads(before.read_text())==json.loads(after.read_text())
checks.append({'canonical_deep_and_byte_equality':True,'sha256':hashlib.sha256(before.read_bytes()).hexdigest()})
out=Path(__file__).parent/'reviewer-extra-results.json';out.write_text(json.dumps(checks,indent=2)+'\n');print(out.read_text())
