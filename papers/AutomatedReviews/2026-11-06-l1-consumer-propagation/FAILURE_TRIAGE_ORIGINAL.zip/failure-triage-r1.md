# Exact87ae default-suite failure triage

**Qualification remains RED. All61 FAILED and30 ERROR test outcomes are mapped individually below and in the companion JSON; they are not91 independent regressions.** Read-only analysis only. No tests, evaluators, source/Git/cache/dependency/controller/slot/worktree/notebook changes. The initial official continuity check was fresh=true, changed=[].

## Evidence and exact boundaries

Tested source87ae47bfdfd1b2ed3b395ead1d40cca9b1d72f31; current documentary source70f51f0717052a6fbbc15f929df66249f2ced055. Read-only Git comparison confirms no src/scripts/tests differences between them. Exact main basece194cdc4bf939b108c17edc9530a7f0a14565f9 and primary4fca5970f4f4cb0b408ea33243076c72058f6e56 are compared separately. Current public/head status is supplied by ROOT, not newly queried remotely here.

Read the complete4148-line raw stdout and result JSON. BROAD_DEFAULT_RAW.zip contains stdout/stderr; its stdout is byte-identical to /tmp/l1-consumer-broad-87ae47bfd.stdout (SHA256 e01644400e41f1c41b14e41f5dedff3be8d25d76e5f247ca0b866297fba7b1db); stderr is empty. Public BROAD_DEFAULT_RESULT.json agrees with /tmp/l1-consumer-broad-87ae47bfd-result.json at the declared result scope. Original exit1,7081passed/61failed/30errors/40skipped/92deselected/7warnings,280.81s remains unchanged. Its failure_ids array also contains logger ERROR lines; those are not test outcomes. This mapping uses exactly the terminal61FAILED+30ERROR identities, each paired uniquely with its traceback heading. No XML or richer nontruncated assertion payload was supplied for this run.

JSON /tmp/l1-qualification-failure-triage-r1.json preserves all91 exact traceback blocks, every emitted E assertion/exception line, raw stdout line bounds, emitted test/producer source paths and lines, group assignments and Git blob comparisons. The Markdown table is an index; JSON is the complete emitted-detail mapping. Truncated pytest reprs remain truncated rather than guessed. Historical FROZEN_4B6408_DISPOSITION.md and the current REPAIR_DISPOSITION_MAP.md were read as dated evidence, not current validation.

## Root-cause separation

- **58 ExtractDeps-dependent outcomes:**30 setup ERRORs plus28 FAILED, including four dashboard HTTP500 assertions. Direct root exception: scripts/extract_lean_deps.py:161 raises RuntimeError after `lake env lean --run SKEFTHawking/ExtractDeps.lean` tries to acquire Physlib in the unprepared publication checkout; Git exits128 with `Could not resolve host: github.com`. Loader209→extraction138→161 propagates through graph, closures, native_decide population, readiness and dashboard. Three empty-population seam controls fail on the earlier extraction error, not their intended EMPTY/measurable-closure branch. The absent-source freshness witness similarly gets an earlier UNMEASURED closure error rather than the intended UNMEASURABLE absent-source branch. Chain StopIteration at tests/test_d5_reviews.py:753 is secondary: reviews.py:942 returns a graph-unverified result without an unresolvable detail; its companion baseline assertion explicitly prints the same DNS failure. Do not report those as58 repaired checks; they need a qualified existing native environment and actual replay. Historical corpus chain debt111/109 remains separate and masked here.
- **One additional environment failure:** tests/test_d5_freshness.py:395 reaches update_counts.py:389; its nested `uv run python -m pytest ... --collect-only` attempts maturin acquisition and fails DNS for pypi.org. ZERO collected tests is correctly refused. Do not publish zero or alter freshness timestamps.
- **Five host fixture failures:** two `_proc_start(...)` assertions at tests/test_lean_slots.py:552/574 receive None; three fixture localhost server binds fail PermissionError at socketserver.py:478 (test helper1554 and tests1597/1618/1632). Public ISOLATED_SLOT_FIXTURES.json/stdout/stderr independently record exactly these five passing5/5 in1.02s with host process/localhost access, unchanged tested code and no actual slot/native use. The original failed run is retained; no other failure is waived.
- **27 remaining outcomes are corpus/process/population/stale-test findings, including four mixed open-finding cases.** ExtractDeps warnings co-occur in those four, but real per-bundle blocking counts and57unattributed vs44 also exceed their frozen requirements. No evidence makes those four purely environmental. Do not subtract environment warnings to manufacture a pass or call all remaining56 failed tests regressions.

## Existing repairs and history: reuse before implementing

Actual primary4fca contains the already implemented D7 regression correction06c7d8eb28541f9b664350f17594a61336ec8a2f, absent from tested87 and exact main. It replaces the stale doubled-backslash required token with TeX-normalized phantom rejection, a current headline theorem-block assertion, declaration/index resolution and negative-form controls. Its existing review anchor e7047b7aa is recorded by the earlier disposition. This triage establishes source presence, not a new proof/equivalence/kernel acceptance. Reconcile its exact preimage through the existing review/composition route; do not reinsert retired prose or duplicate the implementation.

Primary also contains30b82f375's existing apex floor636 and vacuity ceiling19, plus count ceiling90/spelled census67 and accompanying scientific claim/disclosure review machinery. Tested87 has floor634/vacuity20/count95/spelled71. These directly explain stale guard failures; actual87 measured count89, so copying primary constants wholesale would still leave count headroom1. Preserve source-qualified census review and actual candidate measurements. The primary's additional physical/provenance/code changes are not prerequisites for paper-only delivery and must not be copied wholesale. The existing metadata serialization6a6cd7ee6/b8f352bd8 and IMPORTS d5585d16/closure are already integrated publication work; do not reopen them merely because an older disposition mentioned them. The87 run's failure list does not reproduce the earlier serialization/managed-path/citation failures.

The existing route already records exact-main composition of serializer, D7 regression, managed-path, inventory and citation repairs with generated tables and reviewed polariton reconciliation; receipt901f5012d, module reach3f1e7dcee, citation predecessorf28cc370f and current publication route remain producer anchors, not permission to cherry-pick or transplant entire trees. Source compatibility or a historical focused pass is not current whole-candidate acceptance. Every traceback-referenced src/scripts/tests blob comparison is retained in JSON. In particular, tested extraction loader, closure/count producers and most failing test files equal main; build_graph, formulas and current readiness tests differ. Primary controller/dashboard test/source differences are broad and do not establish repairs for this run's DNS failures.

## Prioritized concrete existing-process work

1. **Qualified replay prerequisite:** ROOT reconciles exact source/dependency identities with the existing ADR-008 primary/controller route before any native-dependent validation. Preserve87 raw failure evidence. No new runner, timestamp/cache substitution, primary retarget or dependency repair follows from this review. The separate nested uv collection needs its existing environment/acquisition prerequisites satisfied before counts can certify freshness. Do not restart a broad suite on an unprepared checkout merely to rediscover this cascade.
2. **Prepare the narrow paper composition through existing source/evidence ownership.** Main paper-only feasibility from MAIN_PAPER_ROUTE_ASSESSMENT.md stands. Reconcile actual ce194 manuscript/metadata/figure preimages and independently compile/review that composed candidate. The ce194 paper-scope wrapper avoids direct Lake but still invokes counts freshness and corpus paper checks; its counts leg may transitively need extraction/collection. Therefore “no direct Lake step” never promises no dependency admission is needed. Existing exact-candidate full merge gate still unconditionally compiles ExtractDeps and remains OPEN until actually qualified.
3. **Reuse proven-source guard repairs narrowly:** existing D7 test06c7d8eb2 and reviewed census/apex30b82f375 belong to their established repair packages, with exact preimages and independent review. Neither is inherently part of a D3/P25 paper-only source patch. Do not raise limits or delete real claims. The count89 measurement differs from primary90; the two extra scored claims and19 flagged rows need their established scientific/disclosure accounting preserved.
4. **Real paper/corpus owners:** repair185 registered-but-absent vs147 via actual claim/module reach review, not deregistration to hide science (bundles_readiness.py:1122); stage D10/D6/D8 historical vocabulary via existing metadata writer without promoting acceptance; shorten the actual23>100-word sentences vs18 preserving science; resolve current required findings (per-bundle counts,57unattributed/44) through existing planner/closer. Apex grounding now35 numeral omissions vs31 (earlier dated33); score636 actual claims with exact statements/carriers and retain substantive duties. Never treat name text as proof absence.
5. **Existing provenance/review routes:** bind15 handwritten tables vs1 to existing tables.py/spec/generated artifacts; resolve150 numerical literals vs117 using pipeline/units rather than ceiling growth; repair94 legacy references vs90 and the one modern unresolved FAIL through statement/type/import/history review; repair56 malformed Verify lines preserving executable invariant commands; correct actual remaining review severity/lane/Blocked-by records through ADR-012. Seed tests failing baseline do not prove mutant-specific rejection or fixture restoration failure. After valid improvements, lower count/spelled/vacuity limits through reviewed existing writers; never inflate ceilings.

## Narrow package blockers versus portfolio obligations

No current run proves a D3/P25-introduced code regression or a new Lean/code dependency. Paper sources already accepted at87 have their explicit conditional physics boundaries. Yet this run is not a ce194 composition test. Module/apex/numerical/table/Verify/prose-reference/count freshness guards are actual existing paper-scope or full-merge blockers when activated on the composed candidate. Historical main parity must be checked against that exact candidate; inherited red is not a waiver. Long-sentence, metadata-stage and required-finding populations are portfolio obligations that the full suite can expose, not reasons to merge all frontier science into a paper patch. Whether individual offending rows lie in D3/P25 is incomplete where pytest elides detail; obtain full existing producer diagnostics at the next authorized qualification, not a new evaluator here.

D3 twelve unresolved overflows, full-D3 catalog coverage, OPEN FixPropagation and original B3/physical-state/tensor/matter/transport BUILD duties remain independent. Canonical closures, all publication gates, main merge and human approval are not established. Existing review package contains no permission to reduce those requirements.

## Complete test index

Status is the original87 result. Exact unabridged emitted blocks are in the companion JSON, including source paths/lines and stdout boundaries. Rows with setup failures cite fixture source locations and the common extraction root; the final assertion location alone is not necessarily the production cause.

| # | Original outcome and test | Group | Emitted source locations | Raw stdout lines |
|---|---|---|---|---|
| 1 | ERROR `tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_has_multiple_types` | extractdeps_environment_cascade | `tests/test_build_graph.py:470`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 103–160 |
| 2 | ERROR `tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_axiom_nodes_have_eliminability` | extractdeps_environment_cascade | `tests/test_build_graph.py:470`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 161–211 |
| 3 | ERROR `tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_nodes_have_shape` | extractdeps_environment_cascade | `tests/test_build_graph.py:470`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 212–262 |
| 4 | ERROR `tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_structure_has_field_constraints` | extractdeps_environment_cascade | `tests/test_build_graph.py:470`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 263–313 |
| 5 | ERROR `tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_no_duplicate_ids` | extractdeps_environment_cascade | `tests/test_build_graph.py:470`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 314–364 |
| 6 | ERROR `tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_count_greater_than_500` | extractdeps_environment_cascade | `tests/test_build_graph.py:470`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 365–415 |
| 7 | ERROR `tests/test_build_graph.py::TestDependsOnAxiomEdges::test_edges_point_to_axioms` | extractdeps_environment_cascade | `tests/conftest.py:111`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 416–484 |
| 8 | ERROR `tests/test_build_graph.py::TestDependsOnAxiomEdges::test_edges_have_correct_type` | extractdeps_environment_cascade | `tests/conftest.py:111`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 485–546 |
| 9 | ERROR `tests/test_build_graph.py::TestDependsOnAxiomEdges::test_no_self_edges` | extractdeps_environment_cascade | `tests/conftest.py:111`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 547–608 |
| 10 | ERROR `tests/test_build_graph.py::TestVerifiesEdges::test_edges_carry_test_kind` | extractdeps_environment_cascade | `tests/conftest.py:111`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 609–670 |
| 11 | ERROR `tests/test_build_graph.py::TestFlagsEdges::test_edge_shape` | extractdeps_environment_cascade | `tests/conftest.py:111`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 671–732 |
| 12 | ERROR `tests/test_build_graph.py::TestReportsEdges::test_edges_carry_delta` | extractdeps_environment_cascade | `tests/conftest.py:111`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 733–794 |
| 13 | ERROR `tests/test_dashboard_graph_cache.py::TestTheKeyCoversTheReviewCorpus::test_the_review_corpus_is_in_the_watched_read_set` | extractdeps_environment_cascade | `tests/test_dashboard_graph_cache.py:46`; `scripts/provenance_dashboard.py:520`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 795–863 |
| 14 | ERROR `tests/test_dashboard_graph_cache.py::TestTheKeyCoversTheReviewCorpus::test_editing_a_review_document_moves_the_key` | extractdeps_environment_cascade | `tests/test_dashboard_graph_cache.py:46`; `scripts/provenance_dashboard.py:520`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 864–925 |
| 15 | ERROR `tests/test_dashboard_graph_cache.py::TestTheKeyCoversTheReviewCorpus::test_editing_the_ledger_moves_the_key` | extractdeps_environment_cascade | `tests/test_dashboard_graph_cache.py:46`; `scripts/provenance_dashboard.py:520`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 926–987 |
| 16 | ERROR `tests/test_dashboard_graph_cache.py::TestTheKeyCoversFilesThatDoNotExistYet::test_the_corpus_root_itself_is_watched` | extractdeps_environment_cascade | `tests/test_dashboard_graph_cache.py:46`; `scripts/provenance_dashboard.py:520`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 988–1049 |
| 17 | ERROR `tests/test_dashboard_graph_cache.py::TestTheKeyCoversFilesThatDoNotExistYet::test_creating_a_new_finding_directory_moves_the_key` | extractdeps_environment_cascade | `tests/test_dashboard_graph_cache.py:46`; `scripts/provenance_dashboard.py:520`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1050–1111 |
| 18 | ERROR `tests/test_dashboard_graph_cache.py::TestTheCacheStillCaches::test_an_unchanged_tree_keeps_the_key_stable` | extractdeps_environment_cascade | `tests/test_dashboard_graph_cache.py:46`; `scripts/provenance_dashboard.py:520`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1112–1173 |
| 19 | ERROR `tests/test_dashboard_graph_cache.py::TestTheCacheStillCaches::test_an_unchanged_tree_serves_the_cached_object` | extractdeps_environment_cascade | `tests/test_dashboard_graph_cache.py:46`; `scripts/provenance_dashboard.py:520`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1174–1235 |
| 20 | ERROR `tests/test_dashboard_graph_cache.py::TestTheFailSafeDirection::test_no_read_set_yields_a_key_that_cannot_match` | extractdeps_environment_cascade | `tests/test_dashboard_graph_cache.py:46`; `scripts/provenance_dashboard.py:520`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1236–1297 |
| 21 | ERROR `tests/test_dashboard_graph_cache.py::TestTheSeam::test_a_newly_filed_finding_reaches_the_dashboard_graph` | extractdeps_environment_cascade | `tests/test_dashboard_graph_cache.py:46`; `scripts/provenance_dashboard.py:520`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1298–1359 |
| 22 | ERROR `tests/test_flags_ratchet_seam.py::test_both_surfaces_are_non_empty` | extractdeps_environment_cascade | `tests/test_flags_ratchet_seam.py:63`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1360–1437 |
| 23 | ERROR `tests/test_flags_ratchet_seam.py::test_every_finding_in_a_bundle_ratchet_flags_that_bundle` | extractdeps_environment_cascade | `tests/test_flags_ratchet_seam.py:63`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1438–1496 |
| 24 | ERROR `tests/test_flags_ratchet_seam.py::test_every_bundle_flagged_by_a_finding_counts_it_in_its_ratchet` | extractdeps_environment_cascade | `tests/test_flags_ratchet_seam.py:63`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1497–1555 |
| 25 | ERROR `tests/test_flags_ratchet_seam.py::test_every_bundle_the_aggregation_iterates_has_a_paper_node` | extractdeps_environment_cascade | `tests/test_flags_ratchet_seam.py:63`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1556–1614 |
| 26 | ERROR `tests/test_readiness_blocker_refs.py::test_fix_propagation_keeps_the_finding_id_it_already_has` | extractdeps_environment_cascade | `tests/test_readiness_blocker_refs.py:86`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1615–1680 |
| 27 | ERROR `tests/test_readiness_blocker_refs.py::test_the_refs_carry_the_routing_fields_the_operator_needs` | extractdeps_environment_cascade | `tests/test_readiness_blocker_refs.py:86`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1681–1739 |
| 28 | ERROR `tests/test_readiness_blocker_refs.py::test_an_absent_lane_reads_unclassified_and_never_a_default` | extractdeps_environment_cascade | `tests/test_readiness_blocker_refs.py:86`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1740–1798 |
| 29 | ERROR `tests/test_readiness_blocker_refs.py::test_the_evaluator_no_longer_truncates_before_it_counts[blocked]` | extractdeps_environment_cascade | `tests/test_readiness_blocker_refs.py:86`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1799–1857 |
| 30 | ERROR `tests/test_readiness_blocker_refs.py::test_the_evaluator_no_longer_truncates_before_it_counts[needs-recheck]` | extractdeps_environment_cascade | `tests/test_readiness_blocker_refs.py:86`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1858–1917 |
| 31 | FAILED `tests/test_build_graph.py::TestExtractLeanTheoremNodes::test_extract_lean_theorem_nodes` | extractdeps_environment_cascade | `tests/test_build_graph.py:153`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1918–1975 |
| 32 | FAILED `tests/test_build_graph_memo.py::TestTheMemoCannotOutliveABuild::test_the_memo_is_drained_after_a_build` | extractdeps_environment_cascade | `tests/test_build_graph_memo.py:151`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 1976–2040 |
| 33 | FAILED `tests/test_build_graph_memo.py::TestTheMemoCannotOutliveABuild::test_an_extractor_called_outside_a_build_reads_LIVE_state` | extractdeps_environment_cascade | `tests/test_build_graph_memo.py:171`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 2041–2123 |
| 34 | FAILED `tests/test_build_graph_memo.py::TestTheMemoIsSemanticallyInvisible::test_the_memoized_build_equals_the_unmemoized_build` | extractdeps_environment_cascade | `tests/test_build_graph_memo.py:215`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 2124–2203 |
| 35 | FAILED `tests/test_build_graph_memo.py::TestASeededMutationSurvivesTheMemo::test_a_finding_seeded_into_the_REAL_corpus_is_visible_to_the_next_build` | extractdeps_environment_cascade | `tests/test_build_graph_memo.py:313`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 2204–2276 |
| 36 | FAILED `tests/test_build_graph_memo.py::TestASeededMutationSurvivesTheMemo::test_removing_the_seeded_finding_is_visible_too` | extractdeps_environment_cascade | `tests/test_build_graph_memo.py:322`; `scripts/build_graph.py:5348`; `scripts/build_graph.py:5358`; `scripts/build_graph.py:3509`; `scripts/build_graph.py:282`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 2277–2345 |
| 37 | FAILED `tests/test_bundle_closure.py::TestD11ModuleSetIsDerived::test_derived_set_is_nonempty_and_path_shaped` | extractdeps_environment_cascade | `tests/test_bundle_closure.py:355`; `scripts/update_counts.py:468`; `scripts/bundle_closure.py:199`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 2346–2406 |
| 38 | FAILED `tests/test_bundle_closure.py::TestD11ModuleSetIsDerived::test_empty_closure_raises_rather_than_guessing` | extractdeps_environment_cascade | `tests/test_bundle_closure.py:369`; `scripts/update_counts.py:468`; `scripts/bundle_closure.py:199`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161`; `tests/test_bundle_closure.py:368` | 2407–2492 |
| 39 | FAILED `tests/test_d5_bundles_readiness.py::TestProducerDemotesGreenOnBlockedP1::test_the_helper_exists_and_returns_a_mapping` | extractdeps_environment_cascade | `tests/test_d5_bundles_readiness.py:838` | 2493–2524 |
| 40 | FAILED `tests/test_d5_bundles_readiness.py::TestBundleLeanModuleCoverage::test_the_ratchet_has_zero_headroom` | module_reach_corpus | `tests/test_d5_bundles_readiness.py:1739` | 2525–2540 |
| 41 | FAILED `tests/test_d5_bundles_readiness.py::TestBundleNativeDecideDebt::test_live_state_passes` | extractdeps_environment_cascade | `tests/test_d5_bundles_readiness.py:1767` | 2541–2559 |
| 42 | FAILED `tests/test_d5_bundles_readiness.py::TestBundleNativeDecideDebt::test_every_ceiling_has_zero_headroom` | extractdeps_environment_cascade | `tests/test_d5_bundles_readiness.py:1774` | 2560–2584 |
| 43 | FAILED `tests/test_d5_bundles_readiness.py::TestBundleNativeDecideDebt::test_a_bundle_absent_from_the_map_is_asserted_zero` | extractdeps_environment_cascade | `tests/test_d5_bundles_readiness.py:1784` | 2585–2608 |
| 44 | FAILED `tests/test_d5_bundles_readiness.py::TestBundleNativeDecideDebt::test_growth_past_the_ceiling_fails` | extractdeps_environment_cascade | `tests/test_d5_bundles_readiness.py:1798` | 2609–2634 |
| 45 | FAILED `tests/test_d5_bundles_readiness.py::TestNativeDecideSeamGuard::test_an_empty_native_decide_set_is_UNVERIFIED_not_clean` | extractdeps_environment_cascade | `tests/test_d5_bundles_readiness.py:1892` | 2635–2656 |
| 46 | FAILED `tests/test_d5_bundles_readiness.py::TestNativeDecideSeamGuard::test_no_measurable_closure_is_UNVERIFIED_not_clean` | extractdeps_environment_cascade | `tests/test_d5_bundles_readiness.py:1901` | 2657–2678 |
| 47 | FAILED `tests/test_d5_bundles_readiness.py::TestNativeDecideSeamGuard::test_the_live_population_is_plausible` | extractdeps_environment_cascade | `tests/test_d5_bundles_readiness.py:1906` | 2679–2701 |
| 48 | FAILED `tests/test_d5_bundles_readiness.py::TestUnmeasuredIsDistinctFromYellow::test_stage_status_enum_covers_the_live_vocabulary` | stage_metadata | `tests/test_d5_bundles_readiness.py:1961` | 2702–2730 |
| 49 | FAILED `tests/test_d5_bundles_readiness.py::TestSentenceLengthRatchet::test_gate_is_green_at_the_frozen_ratchet` | long_sentence_corpus | `tests/test_d5_bundles_readiness.py:1985` | 2731–2742 |
| 50 | FAILED `tests/test_d5_bundles_readiness.py::TestSentenceLengthRatchet::test_ceiling_matches_the_live_measurement` | long_sentence_corpus | `tests/test_d5_bundles_readiness.py:2035` | 2743–2758 |
| 51 | FAILED `tests/test_d5_bundles_readiness.py::TestTheOpenRequiredPopulationRatchets::test_the_check_is_green_at_the_frozen_ceilings` | open_finding_population_mixed_environment | `tests/test_d5_bundles_readiness.py:2046` | 2759–2784 |
| 52 | FAILED `tests/test_d5_bundles_readiness.py::TestTheOpenRequiredPopulationRatchets::test_A_REAL_NEW_BLOCKING_FINDING_TURNS_THE_LEG_RED` | open_finding_population_mixed_environment | `tests/test_d5_bundles_readiness.py:2105` | 2785–2856 |
| 53 | FAILED `tests/test_d5_bundles_readiness.py::TestTheOpenRequiredPopulationRatchets::test_the_per_bundle_ratchet_has_zero_headroom` | open_finding_population_mixed_environment | `tests/test_d5_bundles_readiness.py:2158` | 2857–2912 |
| 54 | FAILED `tests/test_d5_bundles_readiness.py::TestTheOpenRequiredPopulationRatchets::test_the_unattributed_ratchet_has_zero_headroom` | open_finding_population_mixed_environment | `tests/test_d5_bundles_readiness.py:2186` | 2913–2957 |
| 55 | FAILED `tests/test_d5_bundles_readiness.py::TestLeanModuleDeregistration::test_PRODUCTION_SEEDED_a_false_deregistration_turns_the_real_corpus_red` | module_reach_corpus | `tests/test_d5_bundles_readiness.py:2508` | 2958–2980 |
| 56 | FAILED `tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_live_state_passes` | apex_grounding_population | `tests/test_d5_bundles_readiness.py:2702` | 2981–2992 |
| 57 | FAILED `tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_the_population_floor_has_zero_headroom` | apex_grounding_population | `tests/test_d5_bundles_readiness.py:2769` | 2993–3006 |
| 58 | FAILED `tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_the_numeral_ratchet_has_zero_headroom` | apex_grounding_population | `tests/test_d5_bundles_readiness.py:2776` | 3007–3021 |
| 59 | FAILED `tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_PRODUCTION_SEEDED_a_placeholder_claim_turns_the_real_corpus_red` | apex_grounding_population | `tests/test_d5_bundles_readiness.py:2786` | 3022–3040 |
| 60 | FAILED `tests/test_d5_bundles_readiness.py::TestApexClaimsNotVacuous::test_the_population_floor_has_zero_headroom` | apex_vacuity_population | `tests/test_d5_bundles_readiness.py:2926` | 3041–3054 |
| 61 | FAILED `tests/test_d5_bundles_readiness.py::TestApexClaimsNotVacuous::test_both_ratchets_have_zero_headroom` | apex_vacuity_population | `tests/test_d5_bundles_readiness.py:2936` | 3055–3072 |
| 62 | FAILED `tests/test_d5_bundles_readiness.py::TestApexClaimsNotVacuous::test_every_flagged_row_is_NAMED_in_the_output` | apex_vacuity_population | `tests/test_d5_bundles_readiness.py:2947` | 3073–3088 |
| 63 | FAILED `tests/test_d5_freshness.py::TestCountsFreshness::test_the_cheap_split_agrees_with_the_full_counter` | nested_collection_environment | `tests/test_d5_freshness.py:395`; `scripts/update_counts.py:389` | 3089–3139 |
| 64 | FAILED `tests/test_d5_freshness.py::TestBundleSourceFreshness::test_an_absent_source_directory_is_UNMEASURABLE_not_fresh` | extractdeps_environment_cascade | `tests/test_d5_freshness.py:866` | 3140–3190 |
| 65 | FAILED `tests/test_d5_freshness.py::TestBundleCountsFresh::test_live_tree_is_fresh` | extractdeps_environment_cascade | `tests/test_d5_freshness.py:933` | 3191–3209 |
| 66 | FAILED `tests/test_d5_papers_prose.py::TestBundleTablesUsePipeline::test_the_ceiling_has_ZERO_HEADROOM_against_the_live_tree` | manual_table_corpus | `tests/test_d5_papers_prose.py:359` | 3210–3226 |
| 67 | FAILED `tests/test_d5_prose_checks.py::TestSpelledOutCensusFigures::test_the_live_ceiling_has_ZERO_headroom` | count_literal_population | `tests/test_d5_prose_checks.py:87` | 3227–3246 |
| 68 | FAILED `tests/test_d5_prose_lean_refs.py::TestProseTheoremReferenceCoverage::test_the_live_legacy_ceiling_has_ZERO_headroom` | prose_reference_corpus | `tests/test_d5_prose_lean_refs.py:203` | 3247–3276 |
| 69 | FAILED `tests/test_d5_reviews.py::TestReviewVerifyIsOneCommand::test_the_live_corpus_is_clean` | review_verify_contract | `tests/test_d5_reviews.py:522` | 3277–3291 |
| 70 | FAILED `tests/test_d5_reviews.py::TestChainBackingTargetsResolve::test_a_dangling_link_seeded_past_the_ceiling_fails` | extractdeps_environment_cascade | `tests/test_d5_reviews.py:727` | 3292–3328 |
| 71 | FAILED `tests/test_d5_reviews.py::TestChainBackingTargetsResolve::test_the_ceiling_carries_no_headroom` | extractdeps_environment_cascade | `tests/test_d5_reviews.py:753` | 3329–3345 |
| 72 | FAILED `tests/test_d5_reviews.py::TestBlockedByResolvesLeg::test_a_dangling_blocked_by_in_a_REAL_document_turns_the_check_red` | review_routing_contract | `tests/test_d5_reviews.py:869` | 3346–3376 |
| 73 | FAILED `tests/test_lean_slots.py::test_global_backend_limit_counts_other_repository_roles` | host_fixture_resolved_separately | `tests/test_lean_slots.py:552` | 3377–3388 |
| 74 | FAILED `tests/test_lean_slots.py::test_one_physical_slot_cannot_have_two_repository_backends` | host_fixture_resolved_separately | `tests/test_lean_slots.py:574` | 3389–3399 |
| 75 | FAILED `tests/test_lean_slots.py::test_an_idle_slot_mints_a_session_on_initialize` | host_fixture_resolved_separately | `tests/test_lean_slots.py:1597`; `tests/test_lean_slots.py:1554` | 3400–3447 |
| 76 | FAILED `tests/test_lean_slots.py::test_each_initialize_mints_a_distinct_session` | host_fixture_resolved_separately | `tests/test_lean_slots.py:1618`; `tests/test_lean_slots.py:1554` | 3448–3489 |
| 77 | FAILED `tests/test_lean_slots.py::test_the_minted_session_does_not_weaken_the_lease_gate` | host_fixture_resolved_separately | `tests/test_lean_slots.py:1632`; `tests/test_lean_slots.py:1554` | 3490–3531 |
| 78 | FAILED `tests/test_ratchets_have_zero_headroom.py::TestRatchetsHaveZeroHeadroom::test_population_equals_ceiling[count_literals]` | count_literal_population | `tests/test_ratchets_have_zero_headroom.py:145` | 3532–3557 |
| 79 | FAILED `tests/test_ratchets_have_zero_headroom.py::TestRatchetsHaveZeroHeadroom::test_population_equals_ceiling[numerical_literals]` | numerical_literal_corpus | `tests/test_ratchets_have_zero_headroom.py:145` | 3558–3583 |
| 80 | FAILED `tests/test_ratchets_have_zero_headroom.py::TestRatchetsHaveZeroHeadroom::test_population_equals_ceiling[bundle_tables_use_pipeline]` | manual_table_corpus | `tests/test_ratchets_have_zero_headroom.py:145` | 3584–3609 |
| 81 | FAILED `tests/test_readiness_cannot_measure.py::TestUncomputableGatesWithholdGreen::test_healthy_path_returns_a_mapping` | extractdeps_environment_cascade | `tests/test_readiness_cannot_measure.py:103` | 3610–3642 |
| 82 | FAILED `tests/test_readiness_gate_measured.py::TestTheReaderHasAProductionCaller::test_an_unmeasured_gate_reaches_the_log` | extractdeps_environment_cascade | `tests/test_readiness_gate_measured.py:212`; `tests/test_readiness_gate_measured.py:208`; `scripts/build_graph.py:279`; `scripts/build_graph.py:3348`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 3643–3709 |
| 83 | FAILED `tests/test_readiness_gate_measured.py::TestTheReaderHasAProductionCaller::test_a_measured_gate_is_SILENT` | extractdeps_environment_cascade | `tests/test_readiness_gate_measured.py:220`; `tests/test_readiness_gate_measured.py:208`; `scripts/build_graph.py:279`; `scripts/build_graph.py:3348`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 3710–3778 |
| 84 | FAILED `tests/test_readiness_gate_measured.py::TestG4CompleteInternalEvidence::test_partial_measurement_log_does_not_claim_nothing_was_read` | extractdeps_environment_cascade | `tests/test_readiness_gate_measured.py:278`; `scripts/build_graph.py:279`; `scripts/build_graph.py:3348`; `scripts/build_graph.py:279`; `scripts/build_graph.py:729`; `scripts/extract_lean_deps.py:209`; `scripts/extract_lean_deps.py:138`; `scripts/extract_lean_deps.py:161` | 3779–3852 |
| 85 | FAILED `tests/test_template_contract.py::test_each_tab_returns_200_with_its_own_panel_active` | extractdeps_environment_dashboard_cascade | `tests/test_template_contract.py:474` | 3853–3896 |
| 86 | FAILED `tests/test_template_contract.py::test_exactly_one_panel_is_active_per_request` | extractdeps_environment_dashboard_cascade | `tests/test_template_contract.py:482` | 3897–3911 |
| 87 | FAILED `tests/test_template_contract.py::test_a_partial_backed_tab_carries_its_own_partials_marker` | extractdeps_environment_dashboard_cascade | `tests/test_template_contract.py:505` | 3912–3935 |
| 88 | FAILED `tests/test_template_contract.py::test_the_default_tab_matches_the_servers_own_default` | extractdeps_environment_dashboard_cascade | `tests/test_template_contract.py:526` | 3936–4001 |
| 89 | FAILED `tests/test_validate_prose_checks.py::TestLiveRepoSmoke::test_prose_theorem_reference_coverage_passes` | prose_reference_corpus | `tests/test_validate_prose_checks.py:337` | 4002–4016 |
| 90 | FAILED `tests/test_validate_public_surface.py::TestNumericalLiteralPopulationComposition::test_ceiling_matches_the_live_population` | numerical_literal_corpus | `tests/test_validate_public_surface.py:501` | 4017–4027 |
| 91 | FAILED `tests/test_validate_public_surface.py::TestTexQuoteReferencesAreExtracted::test_d7_no_longer_cites_a_nonexistent_theorem` | stale_D7_regression_already_repaired_primary | `tests/test_validate_public_surface.py:542` | 4028–4055 |

## Exact emitted assertion/exception lines by row

These are verbatim pytest E-lines; a truncated repr reflects the original producer output. Full surrounding tracebacks are retained in JSON.

### Row 1: tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_has_multiple_types

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 2: tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_axiom_nodes_have_eliminability

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 3: tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_nodes_have_shape

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 4: tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_structure_has_field_constraints

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 5: tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_no_duplicate_ids

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 6: tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_count_greater_than_500

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 7: tests/test_build_graph.py::TestDependsOnAxiomEdges::test_edges_point_to_axioms

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 8: tests/test_build_graph.py::TestDependsOnAxiomEdges::test_edges_have_correct_type

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 9: tests/test_build_graph.py::TestDependsOnAxiomEdges::test_no_self_edges

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 10: tests/test_build_graph.py::TestVerifiesEdges::test_edges_carry_test_kind

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 11: tests/test_build_graph.py::TestFlagsEdges::test_edge_shape

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 12: tests/test_build_graph.py::TestReportsEdges::test_edges_carry_delta

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 13: tests/test_dashboard_graph_cache.py::TestTheKeyCoversTheReviewCorpus::test_the_review_corpus_is_in_the_watched_read_set

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 14: tests/test_dashboard_graph_cache.py::TestTheKeyCoversTheReviewCorpus::test_editing_a_review_document_moves_the_key

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 15: tests/test_dashboard_graph_cache.py::TestTheKeyCoversTheReviewCorpus::test_editing_the_ledger_moves_the_key

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 16: tests/test_dashboard_graph_cache.py::TestTheKeyCoversFilesThatDoNotExistYet::test_the_corpus_root_itself_is_watched

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 17: tests/test_dashboard_graph_cache.py::TestTheKeyCoversFilesThatDoNotExistYet::test_creating_a_new_finding_directory_moves_the_key

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 18: tests/test_dashboard_graph_cache.py::TestTheCacheStillCaches::test_an_unchanged_tree_keeps_the_key_stable

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 19: tests/test_dashboard_graph_cache.py::TestTheCacheStillCaches::test_an_unchanged_tree_serves_the_cached_object

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 20: tests/test_dashboard_graph_cache.py::TestTheFailSafeDirection::test_no_read_set_yields_a_key_that_cannot_match

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 21: tests/test_dashboard_graph_cache.py::TestTheSeam::test_a_newly_filed_finding_reaches_the_dashboard_graph

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 22: tests/test_flags_ratchet_seam.py::test_both_surfaces_are_non_empty

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 23: tests/test_flags_ratchet_seam.py::test_every_finding_in_a_bundle_ratchet_flags_that_bundle

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 24: tests/test_flags_ratchet_seam.py::test_every_bundle_flagged_by_a_finding_counts_it_in_its_ratchet

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 25: tests/test_flags_ratchet_seam.py::test_every_bundle_the_aggregation_iterates_has_a_paper_node

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 26: tests/test_readiness_blocker_refs.py::test_fix_propagation_keeps_the_finding_id_it_already_has

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 27: tests/test_readiness_blocker_refs.py::test_the_refs_carry_the_routing_fields_the_operator_needs

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 28: tests/test_readiness_blocker_refs.py::test_an_absent_lane_reads_unclassified_and_never_a_default

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 29: tests/test_readiness_blocker_refs.py::test_the_evaluator_no_longer_truncates_before_it_counts[blocked]

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 30: tests/test_readiness_blocker_refs.py::test_the_evaluator_no_longer_truncates_before_it_counts[needs-recheck]

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 31: tests/test_build_graph.py::TestExtractLeanTheoremNodes::test_extract_lean_theorem_nodes

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 32: tests/test_build_graph_memo.py::TestTheMemoCannotOutliveABuild::test_the_memo_is_drained_after_a_build

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 33: tests/test_build_graph_memo.py::TestTheMemoCannotOutliveABuild::test_an_extractor_called_outside_a_build_reads_LIVE_state

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 34: tests/test_build_graph_memo.py::TestTheMemoIsSemanticallyInvisible::test_the_memoized_build_equals_the_unmemoized_build

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 35: tests/test_build_graph_memo.py::TestASeededMutationSurvivesTheMemo::test_a_finding_seeded_into_the_REAL_corpus_is_visible_to_the_next_build

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 36: tests/test_build_graph_memo.py::TestASeededMutationSurvivesTheMemo::test_removing_the_seeded_finding_is_visible_too

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 37: tests/test_bundle_closure.py::TestD11ModuleSetIsDerived::test_derived_set_is_nonempty_and_path_shaped

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 38: tests/test_bundle_closure.py::TestD11ModuleSetIsDerived::test_empty_closure_raises_rather_than_guessing

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
E       AssertionError: Regex pattern did not match.
E         Expected regex: 'D11 closure empty'
E         Actual message: "ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git\ninfo: stderr:\nCloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...\nfatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com\nerror: external command 'git' exited with code 128"
```

### Row 39: tests/test_d5_bundles_readiness.py::TestProducerDemotesGreenOnBlockedP1::test_the_helper_exists_and_returns_a_mapping

```text
E       AssertionError: _blocked_p1_gates_by_paper returned NoneType; aggregate_by_bundle indexes it by paper key
E       assert False
E        +  where False = isinstance(None, dict)
```

### Row 40: tests/test_d5_bundles_readiness.py::TestBundleLeanModuleCoverage::test_the_ratchet_has_zero_headroom

```text
E       AssertionError: ceiling 147 but live count 185 — a ratchet with headroom silently permits drift
E       assert 185 == 147
E        +  where 147 = bru.LEAN_MODULE_ABSENT_CEILING
```

### Row 41: tests/test_d5_bundles_readiness.py::TestBundleNativeDecideDebt::test_live_state_passes

```text
E       assert False
E        +  where False = CheckResult(passed=False, details=[Detail(name='measure', passed=False, message="could not derive closures / native_de...er-bundle compiler-trust surface is UNVERIFIED, not clean", warning=False, measured=True)], error=None, measured=False).passed
E        +    where CheckResult(passed=False, details=[Detail(name='measure', passed=False, message="could not derive closures / native_de...er-bundle compiler-trust surface is UNVERIFIED, not clean", warning=False, measured=True)], error=None, measured=False) = <function check_bundle_native_decide_debt at 0x10fb7b060>()
E        +      where <function check_bundle_native_decide_debt at 0x10fb7b060> = bru.check_bundle_native_decide_debt
```

### Row 42: tests/test_d5_bundles_readiness.py::TestBundleNativeDecideDebt::test_every_ceiling_has_zero_headroom

```text
E       AssertionError: could not derive closures / native_decide set (ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E         info: stderr:
E         Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E         fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E         error: external command 'git' exited with code 128)
E       assert not "could not derive closures / native_decide set (ExtractDeps failed: info: Physlib: cloning https://github.com/leanprov...rover-community/physlib.git/': Could not resolve host: github.com\nerror: external command 'git' exited with code 128)"
```

### Row 43: tests/test_d5_bundles_readiness.py::TestBundleNativeDecideDebt::test_a_bundle_absent_from_the_map_is_asserted_zero

```text
E       AssertionError: could not derive closures / native_decide set (ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E         info: stderr:
E         Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E         fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E         error: external command 'git' exited with code 128)
E       assert not "could not derive closures / native_decide set (ExtractDeps failed: info: Physlib: cloning https://github.com/leanprov...rover-community/physlib.git/': Could not resolve host: github.com\nerror: external command 'git' exited with code 128)"
```

### Row 44: tests/test_d5_bundles_readiness.py::TestBundleNativeDecideDebt::test_growth_past_the_ceiling_fails

```text
E       assert False
E        +  where False = any(<generator object TestBundleNativeDecideDebt.test_growth_past_the_ceiling_fails.<locals>.<genexpr> at 0x11f8b4110>)
```

### Row 45: tests/test_d5_bundles_readiness.py::TestNativeDecideSeamGuard::test_an_empty_native_decide_set_is_UNVERIFIED_not_clean

```text
E       assert ({} == {}
E         
E         Use -v to get more diff and "could not derive closures / native_decide set (ExtractDeps failed: info: Physlib: cloning https://github.com/leanprov...rover-community/physlib.git/': Could not resolve host: github.com\nerror: external command 'git' exited with code 128)" and 'EMPTY' in "could not derive closures / native_decide set (ExtractDeps failed: info: Physlib: cloning https://github.com/leanprov...rover-community/physlib.git/': Could not resolve host: github.com\nerror: external command 'git' exited with code 128)")
```

### Row 46: tests/test_d5_bundles_readiness.py::TestNativeDecideSeamGuard::test_no_measurable_closure_is_UNVERIFIED_not_clean

```text
E       assert ({} == {}
E         
E         Use -v to get more diff and "could not derive closures / native_decide set (ExtractDeps failed: info: Physlib: cloning https://github.com/leanprov...rover-community/physlib.git/': Could not resolve host: github.com\nerror: external command 'git' exited with code 128)" and 'measurable apex closure' in "could not derive closures / native_decide set (ExtractDeps failed: info: Physlib: cloning https://github.com/leanprov...rover-community/physlib.git/': Could not resolve host: github.com\nerror: external command 'git' exited with code 128)")
```

### Row 47: tests/test_d5_bundles_readiness.py::TestNativeDecideSeamGuard::test_the_live_population_is_plausible

```text
E       AssertionError: could not derive closures / native_decide set (ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E         info: stderr:
E         Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E         fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E         error: external command 'git' exited with code 128)
E       assert not "could not derive closures / native_decide set (ExtractDeps failed: info: Physlib: cloning https://github.com/leanprov...rover-community/physlib.git/': Could not resolve host: github.com\nerror: external command 'git' exited with code 128)"
```

### Row 48: tests/test_d5_bundles_readiness.py::TestUnmeasuredIsDistinctFromYellow::test_stage_status_enum_covers_the_live_vocabulary

```text
E       AssertionError: ["D10.stage10_status='redrafted-2026-08-17'", "D6.stage10_status='redrafted'", "D8.stage10_status='redrafted-2026-08-15'"]
E       assert ["D10.stage10...-2026-08-15'"] == []
E         
E         Left contains 3 more items, first extra item: "D10.stage10_status='redrafted-2026-08-17'"
E         Use -v to get more diff
```

### Row 49: tests/test_d5_bundles_readiness.py::TestSentenceLengthRatchet::test_gate_is_green_at_the_frozen_ratchet

```text
E       AssertionError: ['23 sentence(s) over 100 words exceeds the frozen ratchet 18. Shorten the new prose, or lower the ratchet only after shortening: longest is 160 words.', '192 sentence(s) over 60 words (advisory baseline 220; not gated, see docstring)']
E       assert False
E        +  where False = CheckResult(passed=False, details=[Detail(name='over_100_words', passed=False, message='23 sentence(s) over 100 words ...60 words (advisory baseline 220; not gated, see docstring)', warning=False, measured=True)], error=None, measured=True).passed
```

### Row 50: tests/test_d5_bundles_readiness.py::TestSentenceLengthRatchet::test_ceiling_matches_the_live_measurement

```text
E       AssertionError: (23, 18)
E       assert 23 == 18
```

### Row 51: tests/test_d5_bundles_readiness.py::TestTheOpenRequiredPopulationRatchets::test_the_check_is_green_at_the_frozen_ceilings

```text
E       assert False is True
E        +  where False = CheckResult(passed=False, details=[Detail(name='summary', passed=False, message='21 bundle Stage-13 claim(s) checked a...atchet. Re-attribute it or fix it; never raise this limit.", warning=False, measured=True)], error=None, measured=True).passed
E        +    where CheckResult(passed=False, details=[Detail(name='summary', passed=False, message='21 bundle Stage-13 claim(s) checked a...atchet. Re-attribute it or fix it; never raise this limit.", warning=False, measured=True)], error=None, measured=True) = <function check_bundle_stage13_claim_consistent at 0x10fb2fcc0>()
```

### Row 52: tests/test_d5_bundles_readiness.py::TestTheOpenRequiredPopulationRatchets::test_A_REAL_NEW_BLOCKING_FINDING_TURNS_THE_LEG_RED

```text
E       assert False is True
E        +  where False = CheckResult(passed=False, details=[Detail(name='summary', passed=False, message='21 bundle Stage-13 claim(s) checked a...atchet. Re-attribute it or fix it; never raise this limit.", warning=False, measured=True)], error=None, measured=True).passed
E        +    where CheckResult(passed=False, details=[Detail(name='summary', passed=False, message='21 bundle Stage-13 claim(s) checked a...atchet. Re-attribute it or fix it; never raise this limit.", warning=False, measured=True)], error=None, measured=True) = <function check_bundle_stage13_claim_consistent at 0x10fb2fcc0>()
E        +      where <function check_bundle_stage13_claim_consistent at 0x10fb2fcc0> = <module 'validation.checks.bundles_readiness' from '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/scripts/validation/checks/bundles_readiness.py'>.check_bundle_stage13_claim_consistent
```

### Row 53: tests/test_d5_bundles_readiness.py::TestTheOpenRequiredPopulationRatchets::test_the_per_bundle_ratchet_has_zero_headroom

```text
E       AssertionError: ceilings carry headroom or have drifted; if the population SHRANK, lower them in the commit that shrank it — headroom makes a ratchet unfireable
E       assert {'D1': 13, 'D...'D3': 14, ...} == {'D1': 2, 'D1... 'D3': 1, ...}
E         
E         Omitting 6 identical items, use -vv to show
E         Differing items:
E         {'E1': 7} != {'E1': 1}
E         {'D1': 13} != {'D1': 2}
E         {'D4': 13} != {'D4': 4}
E         {'D2': 10} != {'D2': 3}...
E         
E         ...Full output truncated (4 lines hidden), use '-vv' to show
```

### Row 54: tests/test_d5_bundles_readiness.py::TestTheOpenRequiredPopulationRatchets::test_the_unattributed_ratchet_has_zero_headroom

```text
E       assert 57 == 44
```

### Row 55: tests/test_d5_bundles_readiness.py::TestLeanModuleDeregistration::test_PRODUCTION_SEEDED_a_false_deregistration_turns_the_real_corpus_red

```text
E       AssertionError: precondition: the live check is green before seeding
E       assert False
E        +  where False = CheckResult(passed=False, details=[Detail(name='ratchet', passed=False, message='185 registered-but-absent module(s) a...Schellekens.HolomorphicVOAc24, Schellekens.NiemeierLattice)', warning=True, measured=True)], error=None, measured=True).passed
E        +    where CheckResult(passed=False, details=[Detail(name='ratchet', passed=False, message='185 registered-but-absent module(s) a...Schellekens.HolomorphicVOAc24, Schellekens.NiemeierLattice)', warning=True, measured=True)], error=None, measured=True) = <function check_bundle_lean_module_coverage at 0x10fb79380>()
E        +      where <function check_bundle_lean_module_coverage at 0x10fb79380> = bru.check_bundle_lean_module_coverage
```

### Row 56: tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_live_state_passes

```text
E       AssertionError: assert False
E        +  where False = CheckResult(passed=False, details=[Detail(name='summary', passed=False, message='636 declared apex claim(s) scored (fl...'claim_numeral_absent', passed=True, message='… and 15 more', warning=True, measured=True)], error=None, measured=True).passed
E        +    where CheckResult(passed=False, details=[Detail(name='summary', passed=False, message='636 declared apex claim(s) scored (fl...'claim_numeral_absent', passed=True, message='… and 15 more', warning=True, measured=True)], error=None, measured=True) = <function check_apex_theorem_claims_grounded at 0x10fb7ac40>()
E        +      where <function check_apex_theorem_claims_grounded at 0x10fb7ac40> = bru.check_apex_theorem_claims_grounded
```

### Row 57: tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_the_population_floor_has_zero_headroom

```text
E       AssertionError: floor 634 but live 636
E       assert 636 == 634
E        +  where 634 = bru.APEX_CLAIMS_SCORED_FLOOR
```

### Row 58: tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_the_numeral_ratchet_has_zero_headroom

```text
E       AssertionError: ceiling 31 but live count 35
E       assert 35 == 31
E        +  where 31 = bru.APEX_CLAIM_NUMERAL_CEILING
```

### Row 59: tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_PRODUCTION_SEEDED_a_placeholder_claim_turns_the_real_corpus_red

```text
E       AssertionError: precondition: green
E       assert False
E        +  where False = CheckResult(passed=False, details=[Detail(name='summary', passed=False, message='636 declared apex claim(s) scored (fl...'claim_numeral_absent', passed=True, message='… and 15 more', warning=True, measured=True)], error=None, measured=True).passed
E        +    where CheckResult(passed=False, details=[Detail(name='summary', passed=False, message='636 declared apex claim(s) scored (fl...'claim_numeral_absent', passed=True, message='… and 15 more', warning=True, measured=True)], error=None, measured=True) = <function check_apex_theorem_claims_grounded at 0x10fb7ac40>()
E        +      where <function check_apex_theorem_claims_grounded at 0x10fb7ac40> = bru.check_apex_theorem_claims_grounded
```

### Row 60: tests/test_d5_bundles_readiness.py::TestApexClaimsNotVacuous::test_the_population_floor_has_zero_headroom

```text
E       AssertionError: floor 634 but live 636
E       assert 636 == 634
E        +  where 634 = bru.APEX_CLAIMS_SCORED_FLOOR
```

### Row 61: tests/test_d5_bundles_readiness.py::TestApexClaimsNotVacuous::test_both_ratchets_have_zero_headroom

```text
E       AssertionError: ceiling 20 but live 19
E       assert 19 == 20
E        +  where 20 = bru.APEX_VACUITY_CEILING
```

### Row 62: tests/test_d5_bundles_readiness.py::TestApexClaimsNotVacuous::test_every_flagged_row_is_NAMED_in_the_output

```text
E       AssertionError: assert 19 == 20
E        +  where 19 = len([Detail(name='apex_content_free', passed=True, message='F: `r_d_independent_count_eight` — MODELING_ASSUMPTION_THEOREM... does NOT disclose it — say what the statement carries, or strengthen the theorem]', warning=True, measured=True), ...])
E        +  and   20 = bru.APEX_VACUITY_CEILING
```

### Row 63: tests/test_d5_freshness.py::TestCountsFreshness::test_the_cheap_split_agrees_with_the_full_counter

```text
E           RuntimeError: pytest collection reported ZERO tests. The suite has >6000; a zero here means the collection errored or the regex stopped matching, not that the tests are gone. stdout tail: 'failed after 3 retries in 6.5s\n  cause: Failed to fetch: https://pypi.org/simple/maturin/\n  cause: error sending request for url (https://pypi.org/simple/maturin/)\n  cause: client error (Connect)\n  cause: dns error\n  cause: failed to lookup address information: nodename nor servname provided, or not known\n\nhint: `sk-eft-rhmc` was included because `sk-eft-hawking` (v0.2.0) depends on `sk-eft-rhmc`\n'
```

### Row 64: tests/test_d5_freshness.py::TestBundleSourceFreshness::test_an_absent_source_directory_is_UNMEASURABLE_not_fresh

```text
E       AssertionError: a bundle whose only source names an absent directory reported "Lean freshness leg UNMEASURED (apex-closure derivation failed) — this bundle's Lean substrate was NOT compared to last_lift; the source-paper leg below stands alone" — the vacuous-freshness hole is back
E       assert 'UNMEASURABLE' in "Lean freshness leg UNMEASURED (apex-closure derivation failed) — this bundle's Lean substrate was NOT compared to last_lift; the source-paper leg below stands alone"
```

### Row 65: tests/test_d5_freshness.py::TestBundleCountsFresh::test_live_tree_is_fresh

```text
E       assert False
E        +  where False = CheckResult(passed=False, details=[Detail(name='derive', passed=False, message="could not derive per-bundle counts (Ex...mmand 'git' exited with code 128) — UNVERIFIED, not fresh", warning=False, measured=True)], error=None, measured=False).passed
E        +    where CheckResult(passed=False, details=[Detail(name='derive', passed=False, message="could not derive per-bundle counts (Ex...mmand 'git' exited with code 128) — UNVERIFIED, not fresh", warning=False, measured=True)], error=None, measured=False) = <function check_bundle_counts_fresh at 0x10fad9f30>()
E        +      where <function check_bundle_counts_fresh at 0x10fad9f30> = fr.check_bundle_counts_fresh
```

### Row 66: tests/test_d5_papers_prose.py::TestBundleTablesUsePipeline::test_the_ceiling_has_ZERO_HEADROOM_against_the_live_tree

```text
E       AssertionError: 15 hand-written tabular(s) live against a ceiling of 1. If it dropped, LOWER the ceiling in the same commit; if it rose, add the tables.py spec.
E       assert 15 == 1
E        +  where 1 = pp.BUNDLE_HANDWRITTEN_TABLE_CEILING
```

### Row 67: tests/test_d5_prose_checks.py::TestSpelledOutCensusFigures::test_the_live_ceiling_has_ZERO_headroom

```text
E       AssertionError: 67 spelled-out census figures against a ceiling of 71. If the corpus improved, LOWER the ceiling in the same commit. ⚠️ If it grew, do NOT raise it — bind the new figure to a macro or name the mechanism instead.
E       assert 67 == 71
```

### Row 68: tests/test_d5_prose_lean_refs.py::TestProseTheoremReferenceCoverage::test_the_live_legacy_ceiling_has_ZERO_headroom

```text
E       AssertionError: the live corpus carries 94 unresolved legacy references but the ceiling is 90. If the corpus improved, LOWER the ceiling in the same commit — headroom is how a ratchet stops ratcheting.
E       assert 94 == 90
E        +  where 94 = int('94')
E        +    where '94' = <built-in method group of re.Match object at 0x12320cf70>(1)
E        +      where <built-in method group of re.Match object at 0x12320cf70> = <re.Match object; span=(0, 13), match='94 unresolved'>.group
```

### Row 69: tests/test_d5_reviews.py::TestReviewVerifyIsOneCommand::test_the_live_corpus_is_clean

```text
E       AssertionError: [('summary', '307 `Verify:` line(s) checked, 56 carrying anything other than a single backticked command'), ('papers/A...g can then be neither verified nor closed. Put the explanation on the following line as `*What it asserts:* …`.'), ...]
E       assert False is True
E        +  where False = CheckResult(passed=False, details=[Detail(name='summary', passed=False, message='307 `Verify:` line(s) checked, 56 car...planation on the following line as `*What it asserts:* …`.', warning=False, measured=True)], error=None, measured=True).passed
```

### Row 70: tests/test_d5_reviews.py::TestChainBackingTargetsResolve::test_a_dangling_link_seeded_past_the_ceiling_fails

```text
E       AssertionError: baseline must be green, or this mutation proves nothing
E       assert False is True
E        +  where False = CheckResult(passed=False, details=[Detail(name='graph', passed=False, message="SKIPPED — could not build the graph ind...mand 'git' exited with code 128); UNVERIFIED, not passing", warning=False, measured=True)], error=None, measured=False).passed
```

### Row 71: tests/test_d5_reviews.py::TestChainBackingTargetsResolve::test_the_ceiling_carries_no_headroom

```text
E       StopIteration
```

### Row 72: tests/test_d5_reviews.py::TestBlockedByResolvesLeg::test_a_dangling_blocked_by_in_a_REAL_document_turns_the_check_red

```text
E       AssertionError: assert False is True
E        +  where False = CheckResult(passed=False, details=[Detail(name='summary', passed=False, message='77 review document(s) dated >= 2026-0...ked-by:` names a minted finding or a valued release scheme', warning=False, measured=True)], error=None, measured=True).passed
E        +    where CheckResult(passed=False, details=[Detail(name='summary', passed=False, message='77 review document(s) dated >= 2026-0...ked-by:` names a minted finding or a valued release scheme', warning=False, measured=True)], error=None, measured=True) = <function check_review_severity_declared at 0x10fb2de80>()
E        +      where <function check_review_severity_declared at 0x10fb2de80> = rv.check_review_severity_declared
```

### Row 73: tests/test_lean_slots.py::test_global_backend_limit_counts_other_repository_roles

```text
E       assert None
```

### Row 74: tests/test_lean_slots.py::test_one_physical_slot_cannot_have_two_repository_backends

```text
E       assert None
```

### Row 75: tests/test_lean_slots.py::test_an_idle_slot_mints_a_session_on_initialize

```text
E       PermissionError: [Errno 1] Operation not permitted
```

### Row 76: tests/test_lean_slots.py::test_each_initialize_mints_a_distinct_session

```text
E       PermissionError: [Errno 1] Operation not permitted
```

### Row 77: tests/test_lean_slots.py::test_the_minted_session_does_not_weaken_the_lease_gate

```text
E       PermissionError: [Errno 1] Operation not permitted
```

### Row 78: tests/test_ratchets_have_zero_headroom.py::TestRatchetsHaveZeroHeadroom::test_population_equals_ceiling[count_literals]

```text
E       AssertionError: count_literals: live population 89 against ceiling 95 — 6 of headroom. LOWER the ceiling in the same commit (the population shrank, which is good news the ratchet must record).
E       assert 89 == 95
```

### Row 79: tests/test_ratchets_have_zero_headroom.py::TestRatchetsHaveZeroHeadroom::test_population_equals_ceiling[numerical_literals]

```text
E       AssertionError: numerical_literals: live population 150 against ceiling 117 — 33 of headroom. The population GREW past its ceiling; fix the underlying debt rather than raising the number.
E       assert 150 == 117
```

### Row 80: tests/test_ratchets_have_zero_headroom.py::TestRatchetsHaveZeroHeadroom::test_population_equals_ceiling[bundle_tables_use_pipeline]

```text
E       AssertionError: bundle_tables_use_pipeline: live population 15 against ceiling 1 — 14 of headroom. The population GREW past its ceiling; fix the underlying debt rather than raising the number.
E       assert 15 == 1
```

### Row 81: tests/test_readiness_cannot_measure.py::TestUncomputableGatesWithholdGreen::test_healthy_path_returns_a_mapping

```text
E       assert (False)
E        +  where False = isinstance(None, dict)
```

### Row 82: tests/test_readiness_gate_measured.py::TestTheReaderHasAProductionCaller::test_an_unmeasured_gate_reaches_the_log

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 83: tests/test_readiness_gate_measured.py::TestTheReaderHasAProductionCaller::test_a_measured_gate_is_SILENT

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 84: tests/test_readiness_gate_measured.py::TestG4CompleteInternalEvidence::test_partial_measurement_log_does_not_claim_nothing_was_read

```text
E               RuntimeError: ExtractDeps failed: info: Physlib: cloning https://github.com/leanprover-community/physlib.git
E               info: stderr:
E               Cloning into '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/lean/.lake/packages/Physlib'...
E               fatal: unable to access 'https://github.com/leanprover-community/physlib.git/': Could not resolve host: github.com
E               error: external command 'git' exited with code 128
```

### Row 85: tests/test_template_contract.py::test_each_tab_returns_200_with_its_own_panel_active

```text
E       AssertionError: tab render failures:
E           attention: HTTP 500
E           bundles: HTTP 500
E           chains: HTTP 500
E           citations: HTTP 500
E           flow: HTTP 500
E           formulas: HTTP 500
E           graph: HTTP 500
E           lean: HTTP 500
E           loops: HTTP 500
E           paper: HTTP 500
E           parameters: HTTP 500
E           qi: HTTP 500
E           readiness: HTTP 500
E       assert not ['attention: HTTP 500', 'bundles: HTTP 500', 'chains: HTTP 500', 'citations: HTTP 500', 'flow: HTTP 500', 'formulas: HTTP 500', ...]
```

### Row 86: tests/test_template_contract.py::test_exactly_one_panel_is_active_per_request

```text
E           AssertionError: attention: HTTP 500
E           assert 500 == 200
```

### Row 87: tests/test_template_contract.py::test_a_partial_backed_tab_carries_its_own_partials_marker

```text
E           assert 500 == 200
```

### Row 88: tests/test_template_contract.py::test_the_default_tab_matches_the_servers_own_default

```text
E       assert 500 == 200
E        +  where 500 = <WrapperTestResponse streamed [500 INTERNAL SERVER ERROR]>.status_code
```

### Row 89: tests/test_validate_prose_checks.py::TestLiveRepoSmoke::test_prose_theorem_reference_coverage_passes

```text
E       AssertionError: [('summary', '21 bundle drafts scanned / 1385 candidate Lean references — 1 unresolved FAIL(s) / 2 drifted advisory / ...alsifier_anomalyMatch', 'falsifier_logBound', 'falsifier_positivity', 'falsifier_quarterCoefficient'] (+1 more)"), ...]
E       assert False
E        +  where False = CheckResult(passed=False, details=[Detail(name='summary', passed=False, message='21 bundle drafts scanned / 1385 candi...anaPMNS_of_majoranaRungData', 'NeutrinoMixing.standParam']", warning=False, measured=True)], error=None, measured=True).passed
```

### Row 90: tests/test_validate_public_surface.py::TestNumericalLiteralPopulationComposition::test_ceiling_matches_the_live_population

```text
E       assert (15 + 135) <= 117
```

### Row 91: tests/test_validate_public_surface.py::TestTexQuoteReferencesAreExtracted::test_d7_no_longer_cites_a_nonexistent_theorem

```text
E       AssertionError: assert 'analog\\_hawking\\_simulable\\_iff\\_fourCycleFree' in '\\documentclass[aps,prx,reprint,nofootinbib,floatfix]{revtex4-2}\n\\usepackage{amsmath,amssymb,amsthm}\n\\usepackage{...in coordinate space},\nPhys.\\ Rev.\\ B \\textbf{84}, 241106(R) (2011).\n\n\\end{thebibliography}\n\n\\end{document}\n'
```

## Final verification of this read-only report

Official continuity check fresh=true, changed=[]. Parsed mapping has exactly91 unique terminal test IDs:61FAILED and30ERROR, matched to91 unique traceback sections. Public/local result JSON equality verified; ZIP/raw stdout byte equality verified; isolated fixture raw stdout says5 passed in1.02s. These are artifact consistency checks, not test/evaluator execution. One guessed validation module path was absent and excluded from comparisons; an initial broad /tmp filename search was truncated and replaced with exact known paths. Only the two assigned /tmp output artifacts were written.
